<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('order_editing')) {
    flash_error('Order editing disabled.');
    redirect(url('admin/dashboard.php'));
}

$id = (int)get('id', 0);
$order = get_order($id);
if (!$order) { flash_error('Order not found.'); redirect(url('admin/orders/index.php')); }

if (!in_array($order['order_status'], ['pending', 'confirmed'], true)) {
    flash_error('Cannot edit order — already in preparation/delivery.');
    redirect(url('admin/orders/view.php?id=' . $id));
}

$pageTitle = 'Edit Order ' . $order['order_number'];
$items = get_order_items($id);
$errors = [];

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'update_item') {
        $itemId = (int)post('item_id', 0);
        $qty = max(1, (int)post('quantity', 1));
        $unitPrice = max(0, (float)post('unit_price', 0));
        $it = Database::fetch("SELECT * FROM order_items WHERE id = ? AND order_id = ?", [$itemId, $id]);
        if ($it) {
            $lineTotal = $qty * $unitPrice + (float)$it['addons_total'];
            Database::execute("UPDATE order_items SET quantity = ?, unit_price = ?, line_total = ? WHERE id = ?",
                [$qty, $unitPrice, $lineTotal, $itemId]);
            recalc_order_totals($id);
            flash_success('Item updated.');
        }
    } elseif ($action === 'delete_item') {
        Database::execute("DELETE FROM order_item_options WHERE order_item_id = ?", [(int)post('item_id')]);
        Database::execute("DELETE FROM order_item_addons WHERE order_item_id = ?", [(int)post('item_id')]);
        Database::execute("DELETE FROM order_items WHERE id = ? AND order_id = ?", [(int)post('item_id'), $id]);
        recalc_order_totals($id);
        flash_success('Item removed.');
    }
    redirect(url('admin/orders/edit.php?id=' . $id));
}

require __DIR__ . '/../common/header.php';
?>

<a href="<?= url('admin/orders/view.php?id=' . $id) ?>" class="text-sm text-gray-500 hover:text-brand mb-4 inline-block">← Back to order</a>

<div class="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-5 text-sm text-yellow-900">
  <i class="fa-solid fa-exclamation-triangle mr-1"></i>
  Order editing allowed only until "preparing" status. Sensitive totals — server recalculates on save.
</div>

<div class="bg-white rounded-xl border overflow-hidden mb-5">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr>
        <th class="text-left px-4 py-3">Item</th>
        <th class="text-right px-4 py-3">Qty</th>
        <th class="text-right px-4 py-3">Unit Price</th>
        <th class="text-right px-4 py-3">Line Total</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $it): ?>
      <tr class="border-t">
        <td class="px-4 py-3">
          <div class="font-semibold"><?= e($it['product_name']) ?></div>
          <?php foreach ($it['options'] as $op): ?>
            <div class="text-xs text-gray-500">- <?= e($op['variation_option_name']) ?></div>
          <?php endforeach; ?>
        </td>
        <td class="px-4 py-3 text-right">
          <form method="post" class="inline flex items-center justify-end gap-1">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_item">
            <input type="hidden" name="item_id" value="<?= (int)$it['id'] ?>">
            <input type="number" name="quantity" value="<?= (int)$it['quantity'] ?>" min="1" class="w-16 border rounded px-2 py-1 text-center">
        </td>
        <td class="px-4 py-3 text-right">
            <input type="number" step="0.01" name="unit_price" value="<?= (float)$it['unit_price'] ?>" class="w-24 border rounded px-2 py-1 text-right">
        </td>
        <td class="px-4 py-3 text-right font-bold"><?= money($it['line_total']) ?></td>
        <td class="px-4 py-3 text-right whitespace-nowrap">
            <button class="text-blue-600 text-xs mr-2"><i class="fa-solid fa-save"></i> Save</button>
          </form>
          <form method="post" class="inline" data-confirm="Remove this item?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete_item">
            <input type="hidden" name="item_id" value="<?= (int)$it['id'] ?>">
            <button class="text-red-600 text-xs"><i class="fa-solid fa-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="bg-white rounded-xl border p-5 max-w-md ml-auto text-sm space-y-1">
  <div class="flex justify-between"><span class="text-gray-500">Subtotal:</span><span><?= money($order['subtotal']) ?></span></div>
  <div class="flex justify-between"><span class="text-gray-500">Delivery:</span><span><?= money($order['delivery_fee']) ?></span></div>
  <div class="flex justify-between border-t pt-2 font-bold"><span>Total:</span><span class="text-brand"><?= money($order['total']) ?></span></div>
</div>

<?php
// Helper
function recalc_order_totals(int $orderId): void {
    $sub = (float)(Database::fetch("SELECT COALESCE(SUM(line_total),0) s FROM order_items WHERE order_id = ?", [$orderId])['s'] ?? 0);
    $order = get_order($orderId);
    if (!$order) return;
    $total = $sub - (float)$order['discount_total'] + (float)$order['delivery_fee'] + (float)$order['tax_amount'] + (float)$order['service_fee'] + (float)$order['packaging_fee'];
    Database::execute("UPDATE orders SET subtotal = ?, total = ? WHERE id = ?", [$sub, max(0, $total), $orderId]);
}
?>

<?php require __DIR__ . '/../common/footer.php'; ?>