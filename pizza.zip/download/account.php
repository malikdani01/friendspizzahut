<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$pageTitle = 'My Account';
$user = current_customer();
$orders = get_user_orders((int)$user['id'], 10);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-6xl mx-auto px-4 py-10">
  <div class="mb-8">
    <h1 class="text-3xl font-extrabold">Hi, <?= e($user['name']) ?> 👋</h1>
    <p class="text-white/60">Manage your account and orders</p>
  </div>

  <?php if (feature_enabled('customer_tiers')): 
    $tier = get_customer_tier((int)$user['id']);
    $spent = customer_total_spent((int)$user['id']);
    if ($tier):
      $next = get_next_tier($tier);
  ?>
  <div class="mb-6 p-5 rounded-2xl border-2" style="border-color: <?= e($tier['color']) ?>; background: <?= e($tier['color']) ?>15;">
    <div class="flex items-center justify-between flex-wrap gap-3">
      <div class="flex items-center gap-3">
        <i class="fa-solid <?= e($tier['icon']) ?> text-3xl" style="color: <?= e($tier['color']) ?>"></i>
        <div>
          <div class="text-xs text-white/60 uppercase">Your Tier</div>
          <div class="text-xl font-extrabold" style="color: <?= e($tier['color']) ?>"><?= e($tier['name']) ?></div>
        </div>
      </div>
      <div class="text-right text-sm">
        <div class="text-white/60">Total Spent</div>
        <div class="font-bold text-lg"><?= money($spent) ?></div>
      </div>
    </div>
    <?php if ((float)$tier['discount_percent'] > 0): ?>
      <div class="mt-3 text-sm"><i class="fa-solid fa-percent text-brand mr-1"></i> <?= (float)$tier['discount_percent'] ?>% discount on all orders<?= $tier['free_delivery'] ? ' + free delivery' : '' ?></div>
    <?php endif; ?>
    <?php if ($next): ?>
      <?php $need = (float)$next['min_spent'] - $spent; ?>
      <div class="mt-3 pt-3 border-t border-white/10 text-xs text-white/60">
        <i class="fa-solid fa-arrow-up text-brand mr-1"></i>
        Spend <strong><?= money($need) ?></strong> more to unlock <strong><?= e($next['name']) ?></strong>
      </div>
    <?php endif; ?>
  </div>
  <?php endif; endif; ?>

  <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
    <a href="<?= url('orders.php') ?>" class="bg-white/5 border border-white/10 hover:border-brand rounded-xl p-4 text-center transition">
      <i class="fa-solid fa-receipt text-2xl text-brand mb-2"></i>
      <div class="text-sm font-semibold">My Orders</div>
    </a>
    <a href="<?= url('profile.php') ?>" class="bg-white/5 border border-white/10 hover:border-brand rounded-xl p-4 text-center transition">
      <i class="fa-solid fa-user text-2xl text-brand mb-2"></i>
      <div class="text-sm font-semibold">Profile</div>
    </a>
    <a href="<?= url('addresses.php') ?>" class="bg-white/5 border border-white/10 hover:border-brand rounded-xl p-4 text-center transition">
      <i class="fa-solid fa-location-dot text-2xl text-brand mb-2"></i>
      <div class="text-sm font-semibold">Addresses</div>
    </a>
    <a href="<?= url('logout.php') ?>" class="bg-white/5 border border-white/10 hover:border-red-500 rounded-xl p-4 text-center transition">
      <i class="fa-solid fa-right-from-bracket text-2xl text-red-500 mb-2"></i>
      <div class="text-sm font-semibold">Logout</div>
    </a>
  </div>

  <div class="bg-white/5 border border-white/10 rounded-2xl overflow-hidden">
    <div class="px-5 py-4 border-b border-white/10 flex justify-between items-center">
      <h3 class="font-bold">Recent Orders</h3>
      <a href="<?= url('orders.php') ?>" class="text-xs text-brand hover:underline">View all →</a>
    </div>
    <?php if (!$orders): ?>
      <div class="p-10 text-center text-white/60">No orders yet. <a href="<?= url('menu.php') ?>" class="text-brand hover:underline">Order now</a></div>
    <?php else: ?>
      <table class="w-full text-sm">
        <thead class="bg-white/5 text-xs text-white/50 uppercase">
          <tr><th class="text-left px-5 py-3">Order</th><th class="text-left px-5 py-3">Date</th><th class="text-left px-5 py-3">Total</th><th class="text-left px-5 py-3">Status</th><th></th></tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $o): ?>
          <tr class="border-t border-white/5">
            <td class="px-5 py-3 font-mono text-xs"><?= e($o['order_number']) ?></td>
            <td class="px-5 py-3 text-xs text-white/60"><?= date('d M, H:i', strtotime($o['created_at'])) ?></td>
            <td class="px-5 py-3 font-semibold"><?= money($o['total']) ?></td>
            <td class="px-5 py-3"><?= status_badge($o['order_status']) ?></td>
            <td class="px-5 py-3 text-right"><a href="<?= url('track-order.php?order=' . urlencode($o['order_number'])) ?>" class="text-brand text-xs">Track →</a></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>