<?php
// reject.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/payments/index.php'));
verify_csrf();
$id = (int)post('id', 0);
mark_payment_failed($id, 'Rejected by admin');
audit_log('payment.reject', 'payment', $id);
flash_success('Payment marked as failed.');
redirect(url('admin/payments/view.php?id=' . $id));