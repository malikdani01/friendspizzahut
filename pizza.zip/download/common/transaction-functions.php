<?php
/**
 * Transaction ID validation for Easypaisa / JazzCash manual payments
 */

function payment_requires_transaction_id(string $method): bool {
    return in_array($method, ['easypaisa', 'jazzcash'], true);
}

function validate_transaction_id(string $txnId): array {
    $txnId = trim($txnId);
    if ($txnId === '') {
        return ['ok' => false, 'error' => 'Transaction ID required.'];
    }
    if (strlen($txnId) < 6 || strlen($txnId) > 60) {
        return ['ok' => false, 'error' => 'Transaction ID must be 6-60 characters.'];
    }
    if (!preg_match('/^[A-Za-z0-9\-]+$/', $txnId)) {
        return ['ok' => false, 'error' => 'Only letters, numbers, and hyphens allowed.'];
    }
    // Duplicate check
    $exists = Database::fetch(
        "SELECT id FROM orders WHERE transaction_id = ? AND payment_status IN ('pending','paid') LIMIT 1",
        [$txnId]
    );
    if ($exists) {
        return ['ok' => false, 'error' => 'This Transaction ID is already used.'];
    }
    return ['ok' => true, 'txn_id' => $txnId];
}