<?php
function paginate(int $total, int $perPage, int $current, array $params = []): array {
    $pages = max(1, (int)ceil($total / $perPage));
    $current = max(1, min($pages, $current));
    $offset = ($current - 1) * $perPage;
    return [
        'total' => $total, 'pages' => $pages, 'current' => $current,
        'per_page' => $perPage, 'offset' => $offset, 'params' => $params,
    ];
}
function pagination_links(array $p, string $baseUrl): string {
    if ($p['pages'] <= 1) return '';
    $html = '<div class="flex justify-center gap-2 mt-5">';
    for ($i = 1; $i <= $p['pages']; $i++) {
        $qs = http_build_query(array_merge($p['params'], ['page' => $i]));
        $cls = $i === $p['current'] ? 'bg-brand text-white' : 'bg-white border';
        $html .= '<a href="' . e($baseUrl) . '?' . $qs . '" class="px-3 py-1.5 rounded text-sm ' . $cls . '">' . $i . '</a>';
    }
    return $html . '</div>';
}