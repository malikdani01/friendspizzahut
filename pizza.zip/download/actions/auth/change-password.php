<?php
// actions/auth/change-password.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('profile.php'));
verify_csrf();
$u = current_customer();
$cur = (string)post('current_password','');
$new = (string)post('new_password','');
if (!password_verify($cur, $u['password_hash'])) { flash_error('Current password incorrect.'); redirect(url('profile.php')); }
if (strlen($new) < 6) { flash_error('New password 6+ chars.'); redirect(url('profile.php')); }
Database::execute("UPDATE users SET password_hash=? WHERE id=?", [password_hash($new, PASSWORD_DEFAULT), $u['id']]);
flash_success('Password changed.');
redirect(url('profile.php'));