<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();

$id = (int)get('id', 0);
$msg = contact_message_get($id);
if (!$msg) { flash_error('Message not found.'); redirect(url('admin/messages/index.php?tab=contact')); }

$pageTitle = 'Message from ' . $msg['name'];

// Mark as read
contact_message_mark_read($id);

if (is_post()) {
    verify_csrf();
    $action = post('action', 'reply');

    if ($action === 'reply') {
        $reply = (string)post('reply_text', '');
        if (contact_message_reply($id, $reply)) {
            flash_success('Reply saved.');
        } else {
            flash_error('Failed to save reply.');
        }
    } elseif ($action === 'archive') {
        contact_message_archive($id);
        flash_success('Archived.');
        redirect(url('admin/messages/index.php?tab=contact'));
    } elseif ($action === 'delete') {
        contact_message_delete($id);
        flash_success('Deleted.');
        redirect(url('admin/messages/index.php?tab=contact'));
    }
    redirect(url('admin/messages/contact-view.php?id=' . $id));
}

require __DIR__ . '/../common/header.php';
?>

<style>
.cv-wrap { max-width: 800px; margin: 0 auto; }
.cv-back {
  display: inline-flex; align-items: center; gap: 6px;
  color: rgba(255,255,255,0.6); text-decoration: none;
  font-size: 13px; margin-bottom: 14px; font-weight: 600;
}
.cv-back:hover { color: #dc2626; }

.cv-card {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  padding: 22px;
  margin-bottom: 16px;
}
.cv-head {
  display: flex; gap: 14px; align-items: flex-start;
  padding-bottom: 16px; margin-bottom: 16px;
  border-bottom: 1px solid rgba(255,255,255,0.06);
}
.cv-avatar {
  width: 52px; height: 52px; border-radius: 50%;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-weight: 800; font-size: 20px;
  flex-shrink: 0;
}
.cv-name { font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 4px; }
.cv-meta { font-size: 13px; color: rgba(255,255,255,0.6); line-height: 1.6; }
.cv-meta a { color: #dc2626; text-decoration: none; }
.cv-meta strong { color: #fff; }

.cv-subject {
  font-size: 15px;
  font-weight: 800;
  color: #dc2626;
  margin-bottom: 12px;
}
.cv-message {
  font-size: 14px;
  color: rgba(255,255,255,0.85);
  line-height: 1.7;
  padding: 16px;
  background: rgba(0,0,0,0.3);
  border-radius: 10px;
  border-left: 3px solid #dc2626;
}

.cv-reply-box {
  background: rgba(34,197,94,0.08);
  border: 1px solid rgba(34,197,94,0.25);
  border-radius: 12px;
  padding: 14px;
  margin-top: 16px;
}
.cv-reply-label {
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #4ade80;
  margin-bottom: 6px;
}
.cv-reply-text { font-size: 14px; color: #f9fafb; line-height: 1.6; }
.cv-reply-date { font-size: 11px; color: rgba(255,255,255,0.4); margin-top: 8px; }

.cv-form-title {
  font-size: 14px;
  font-weight: 800;
  color: #dc2626;
  margin-bottom: 12px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.cv-textarea {
  width: 100%;
  min-height: 130px;
  padding: 14px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  color: #fff;
  font-size: 14px;
  font-family: inherit;
  outline: none;
  resize: vertical;
  line-height: 1.5;
}
.cv-textarea:focus {
  border-color: #dc2626;
  box-shadow: 0 0 0 3px rgba(220,38,38,0.15);
}

.cv-actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 14px;
}
.cv-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 11px 20px;
  border-radius: 10px;
  font-size: 13.5px;
  font-weight: 800;
  cursor: pointer;
  border: 0;
  text-decoration: none;
  transition: all .15s;
}
.cv-btn-primary {
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  box-shadow: 0 4px 14px rgba(220,38,38,0.3);
}
.cv-btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(220,38,38,0.45); }
.cv-btn-neutral {
  background: rgba(255,255,255,0.08);
  color: #fff;
  border: 1px solid rgba(255,255,255,0.1);
}
.cv-btn-neutral:hover { background: rgba(255,255,255,0.15); }
.cv-btn-danger {
  background: rgba(220,38,38,0.15);
  color: #f87171;
  border: 1px solid rgba(220,38,38,0.3);
}
.cv-btn-danger:hover { background: rgba(220,38,38,0.25); }
</style>

<div class="cv-wrap">
  <a href="<?= url('admin/messages/index.php?tab=contact') ?>" class="cv-back">
    <i class="fa-solid fa-arrow-left"></i> Back to Contact Form
  </a>

  <div class="cv-card">
    <div class="cv-head">
      <div class="cv-avatar"><?= e(strtoupper(mb_substr($msg['name'], 0, 1))) ?></div>
      <div style="flex:1;min-width:0;">
        <div class="cv-name"><?= e($msg['name']) ?></div>
        <div class="cv-meta">
          <strong>Phone:</strong> <a href="tel:<?= e($msg['phone']) ?>"><?= e($msg['phone']) ?></a><br>
          <?php if ($msg['email']): ?><strong>Email:</strong> <a href="mailto:<?= e($msg['email']) ?>"><?= e($msg['email']) ?></a><br><?php endif; ?>
          <strong>Received:</strong> <?= date('d M Y, H:i', strtotime($msg['created_at'])) ?>
        </div>
      </div>
    </div>

    <?php if ($msg['subject']): ?>
      <div class="cv-subject"><?= e($msg['subject']) ?></div>
    <?php endif; ?>

    <div class="cv-message"><?= nl2br(e($msg['message'])) ?></div>

    <?php if (!empty($msg['admin_reply'])): ?>
      <div class="cv-reply-box">
        <div class="cv-reply-label"><i class="fa-solid fa-reply"></i> Your Reply</div>
        <div class="cv-reply-text"><?= nl2br(e($msg['admin_reply'])) ?></div>
        <?php if ($msg['replied_at']): ?>
          <div class="cv-reply-date"><?= date('d M Y, H:i', strtotime($msg['replied_at'])) ?></div>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="cv-card">
    <div class="cv-form-title"><i class="fa-solid fa-reply"></i> <?= $msg['admin_reply'] ? 'Update Reply' : 'Send Reply' ?></div>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="reply">
      <textarea name="reply_text" required class="cv-textarea" placeholder="Type your reply..."><?= e($msg['admin_reply']) ?></textarea>
      <div class="cv-actions">
        <button type="submit" class="cv-btn cv-btn-primary">
          <i class="fa-solid fa-paper-plane"></i> <?= $msg['admin_reply'] ? 'Update' : 'Send Reply' ?>
        </button>
      </div>
    </form>

    <div class="cv-actions" style="border-top:1px solid rgba(255,255,255,0.06);padding-top:14px;margin-top:16px;">
      <form method="post" style="display:inline;" onsubmit="return confirm('Archive this message?');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="archive">
        <button type="submit" class="cv-btn cv-btn-neutral"><i class="fa-solid fa-box-archive"></i> Archive</button>
      </form>
      <form method="post" style="display:inline;" onsubmit="return confirm('Delete this message?');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="delete">
        <button type="submit" class="cv-btn cv-btn-danger"><i class="fa-solid fa-trash"></i> Delete</button>
      </form>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>