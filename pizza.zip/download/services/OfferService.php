<?php
// services/OfferService.php
class OfferService {
    public static function active(): array { return get_active_offers(); }
    public static function discount(array $o, float $s): float { return calculate_offer_discount($o, $s); }
}