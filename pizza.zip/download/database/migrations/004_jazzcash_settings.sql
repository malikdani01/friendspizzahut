-- ═══════════════════════════════════════════════════════════════
-- FRIENDS PIZZA HUT — Migration 004
-- JazzCash + Easypaisa + SMS + Email + SMTP Settings Defaults
-- 
-- Ye migration payment gateway aur notification settings ke saare
-- default keys database mein register karta hai. Admin panel se
-- values update hongi.
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── JAZZCASH SETTINGS ────────────────────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('jazzcash_enabled',         '0',      'payment'),
('jazzcash_mode',            'sandbox','payment'),
('jazzcash_merchant_id',     '',       'payment'),
('jazzcash_password',        '',       'payment'),
('jazzcash_integrity_salt',  '',       'payment')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── EASYPAISA SETTINGS ───────────────────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('easypaisa_enabled',       '0',      'payment'),
('easypaisa_mode',          'sandbox','payment'),
('easypaisa_store_id',      '',       'payment'),
('easypaisa_hash_key',      '',       'payment'),
('easypaisa_username',      '',       'payment'),
('easypaisa_password',      '',       'payment'),
('easypaisa_mobile_number', '',       'payment')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── SMS SETTINGS (Twilio + Local Gateway) ────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('sms_provider',         '',                    'notifications'),
('sms_api_key',          '',                    'notifications'),
('sms_api_secret',       '',                    'notifications'),
('sms_sender_id',        '',                    'notifications'),
('sms_sender_name',      'Friends Pizza Hut',   'notifications')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── EMAIL / SMTP SETTINGS ────────────────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('smtp_host',            'smtp.gmail.com',      'notifications'),
('smtp_port',            '587',                 'notifications'),
('smtp_user',            '',                    'notifications'),
('smtp_pass',            '',                    'notifications'),
('smtp_from_name',       'Friends Pizza Hut',   'notifications'),
('smtp_from_email',      '',                    'notifications'),
('smtp_encryption',      'tls',                 'notifications')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── WHATSAPP BUSINESS API SETTINGS ───────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('whatsapp_business_enabled',   '0',          'integrations'),
('whatsapp_phone_number_id',    '',           'integrations'),
('whatsapp_access_token',       '',           'integrations'),
('whatsapp_api_version',        'v20.0',      'integrations'),
('whatsapp_business_number',    '',           'integrations')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── WHATSAPP CLICK-TO-CHAT (Free, floating button) ───────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('whatsapp_float_enabled',  '0',                        'marketing'),
('whatsapp_float_number',   '',                         'marketing'),
('whatsapp_float_message',  'Hello, I want to place an order', 'marketing')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── MARKETING / TRACKING ─────────────────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('facebook_pixel_id',              '',  'marketing'),
('facebook_conversion_api_token',  '',  'marketing'),
('google_analytics_id',            '',  'marketing'),
('google_tag_manager_id',          '',  'marketing')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── ORDERING OPTIONS (Pickup + COD toggles) ──────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('pickup_enabled',  '1',  'ordering'),
('cod_enabled',     '1',  'payment')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);