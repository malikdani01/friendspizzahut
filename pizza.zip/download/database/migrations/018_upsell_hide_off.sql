-- ═══════════════════════════════════════════════════════════════
-- Migration 018: Complete Your Meal — Always show products
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- Change default: don't hide in-cart products
UPDATE settings SET setting_value = '0' WHERE setting_key = 'upsell_hide_in_cart';

INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('upsell_hide_in_cart', '0', 'cart')
ON DUPLICATE KEY UPDATE setting_value = '0';