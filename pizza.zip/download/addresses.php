<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$pageTitle = 'My Addresses';
$userId = (int)$_SESSION['user_id'];

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'create') {
        Database::insert('addresses', [
            'user_id' => $userId,
            'label' => trim((string)post('label','')) ?: null,
            'customer_name' => trim((string)post('customer_name','')),
            'mobile' => trim((string)post('mobile','')),
            'address_line' => trim((string)post('address_line','')),
            'area' => trim((string)post('area','')) ?: null,
            'city' => trim((string)post('city','')) ?: null,
            'landmark' => trim((string)post('landmark','')) ?: null,
            'is_default' => post('is_default') ? 1 : 0,
        ]);
        if (post('is_default')) Database::execute("UPDATE addresses SET is_default=0 WHERE user_id=? AND id != LAST_INSERT_ID()", [$userId]);
        flash_success('Address added.');
    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM addresses WHERE id=? AND user_id=?", [(int)post('id'), $userId]);
        flash_success('Address deleted.');
    } elseif ($action === 'default') {
        Database::execute("UPDATE addresses SET is_default=0 WHERE user_id=?", [$userId]);
        Database::execute("UPDATE addresses SET is_default=1 WHERE id=? AND user_id=?", [(int)post('id'), $userId]);
        flash_success('Default address set.');
    }
    redirect(url('addresses.php'));
}

$rows = Database::fetchAll("SELECT * FROM addresses WHERE user_id=? ORDER BY is_default DESC, id DESC", [$userId]);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-8">My Addresses</h1>

  <div class="space-y-3 mb-8">
    <?php foreach ($rows as $a): ?>
    <div class="bg-white/5 border border-white/10 rounded-xl p-5">
      <div class="flex justify-between items-start">
        <div>
          <div class="font-bold"><?= e($a['label'] ?: 'Address') ?> <?= $a['is_default']?'<span class="text-xs bg-brand px-2 py-0.5 rounded ml-2">Default</span>':'' ?></div>
          <div class="text-sm text-white/70 mt-1"><?= e($a['customer_name']) ?> • <?= e($a['mobile']) ?></div>
          <div class="text-sm text-white/60"><?= e($a['address_line']) ?><?= $a['area'] ? ', ' . e($a['area']) : '' ?><?= $a['city'] ? ', ' . e($a['city']) : '' ?></div>
        </div>
        <div class="flex gap-2 text-xs">
          <?php if (!$a['is_default']): ?>
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="default">
            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <button class="text-brand hover:underline">Set Default</button>
          </form>
          <?php endif; ?>
          <form method="post" data-confirm="Delete this address?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <button class="text-red-400 hover:underline">Delete</button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (!$rows): ?>
      <div class="text-white/60 text-center py-8">No saved addresses yet.</div>
    <?php endif; ?>
  </div>

  <details class="bg-white/5 border border-white/10 rounded-2xl p-6">
    <summary class="font-bold cursor-pointer">+ Add New Address</summary>
    <form method="post" class="space-y-3 mt-4">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <input name="label" placeholder="Label (Home, Work)" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5">
      <input name="customer_name" required placeholder="Full name *" value="<?= e(current_customer()['name']) ?>" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5">
      <input name="mobile" required placeholder="Mobile *" value="<?= e(current_customer()['phone']) ?>" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5">
      <input name="address_line" required placeholder="Address *" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5">
      <div class="grid grid-cols-2 gap-3">
        <input name="area" placeholder="Area" class="bg-black/40 border border-white/10 rounded-lg px-3 py-2.5">
        <input name="city" placeholder="City" value="<?= e(setting('restaurant_city','')) ?>" class="bg-black/40 border border-white/10 rounded-lg px-3 py-2.5">
      </div>
      <input name="landmark" placeholder="Landmark" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5">
      <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_default" value="1"> Set as default</label>
      <button class="bg-brand hover:bg-red-700 px-6 py-2.5 rounded-lg font-bold">Save Address</button>
    </form>
  </details>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>