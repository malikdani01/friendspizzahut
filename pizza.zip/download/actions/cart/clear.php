<?php
// actions/cart/clear.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('cart.php'));
verify_csrf();
clear_cart();
flash_info('Cart cleared.');
redirect(url('cart.php'));