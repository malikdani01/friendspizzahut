<?php
function has_permission(string $slug): bool {
    if (admin_logged_in()) return true; // super admin
    if (!staff_logged_in()) return false;
    $staff = current_staff();
    if (!$staff || !$staff['role_id']) return false;
    return (bool) Database::fetch(
        "SELECT rp.permission_id FROM role_permissions rp
         JOIN permissions p ON p.id=rp.permission_id
         WHERE rp.role_id=? AND p.slug=?",
        [(int)$staff['role_id'], $slug]
    );
}
function require_permission(string $slug): void {
    if (!has_permission($slug)) {
        http_response_code(403);
        flash_error('Permission denied.');
        redirect(url('admin/dashboard.php'));
    }
}