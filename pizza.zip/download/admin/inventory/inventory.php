<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('inventory_tracking')) { flash_error('Inventory module disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'Inventory';

if (is_post()) {
    verify_csrf();
    if (post('action') === 'adjust') {
        $pid = (int)post('product_id');
        $type = (string)post('type','add');
        $qty = (int)post('quantity', 0);
        $reason = trim((string)post('reason',''));
        $change = $type === 'remove' ? -abs($qty) : abs($qty);
        inventory_adjust($pid, $change, $type, $reason ?: null);
        flash_success('Stock adjusted.');
    } elseif (post('action') === 'enable_tracking') {
        Database::execute("UPDATE products SET stock_tracking=1 WHERE id=?", [(int)post('product_id')]);
        flash_success('Stock tracking enabled.');
    }
    redirect(url('admin/inventory/index.php'));
}

$products = Database::fetchAll("SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.status='active' ORDER BY p.name LIMIT 200");
$lowStock = low_stock_products();
require __DIR__ . '/../common/header.php';
?>
<?php if ($lowStock): ?>
<div class="mb-6 bg-yellow-50 border border-yellow-200 rounded-xl p-5">
  <h3 class="font-bold text-yellow-900 mb-3"><i class="fa-solid fa-triangle-exclamation"></i> Low Stock Alerts (<?= count($lowStock) ?>)</h3>
  <div class="grid md:grid-cols-3 gap-3">
    <?php foreach ($lowStock as $p): ?>
      <div class="bg-white rounded-lg p-3 border"><div class="font-semibold text-sm"><?= e($p['name']) ?></div><div class="text-xs text-red-600 font-bold">Stock: <?= (int)$p['stock_quantity'] ?></div></div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr><th class="text-left px-4 py-3">Product</th><th class="text-left px-4 py-3">Tracking</th><th class="text-left px-4 py-3">Stock</th><th class="text-right px-4 py-3">Adjust</th></tr>
    </thead>
    <tbody>
      <?php foreach ($products as $p): ?>
      <tr class="border-t hover:bg-gray-50">
        <td class="px-4 py-3"><div class="font-semibold"><?= e($p['name']) ?></div><div class="text-xs text-gray-400"><?= e($p['category_name']) ?></div></td>
        <td class="px-4 py-3">
          <?php if ($p['stock_tracking']): ?>
            <span class="text-xs px-2 py-1 rounded bg-green-100 text-green-800 font-semibold">Tracked</span>
          <?php else: ?>
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="enable_tracking"><input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>"><button class="text-xs px-2 py-1 rounded bg-gray-200 hover:bg-gray-300">Enable</button></form>
          <?php endif; ?>
        </td>
        <td class="px-4 py-3 font-bold <?= $p['stock_tracking'] && $p['stock_quantity'] <= $p['low_stock_threshold'] ? 'text-red-600' : '' ?>"><?= (int)$p['stock_quantity'] ?></td>
        <td class="px-4 py-3">
          <form method="post" class="flex gap-1 justify-end items-center">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="adjust">
            <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
            <select name="type" class="border rounded px-2 py-1 text-xs">
              <option value="add">Add</option>
              <option value="remove">Remove</option>
              <option value="set">Set to</option>
            </select>
            <input type="number" name="quantity" placeholder="Qty" class="w-20 border rounded px-2 py-1 text-xs">
            <button class="text-xs bg-brand text-white px-3 py-1 rounded">Go</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>