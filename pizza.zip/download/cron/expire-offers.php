<?php
require_once __DIR__ . '/../common/bootstrap.php';
$n = Database::execute("UPDATE offers SET is_active=0 WHERE end_date IS NOT NULL AND end_date < NOW() AND is_active=1");
echo "[" . date('c') . "] Offers expired: $n\n";