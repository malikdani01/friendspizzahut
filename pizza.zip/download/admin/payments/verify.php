<?php
// verify.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/payments/index.php'));
verify_csrf();
$id = (int)post('id', 0);
mark_payment_paid($id, (int)$_SESSION['admin_id']);
audit_log('payment.verify', 'payment', $id);
flash_success('Payment marked as paid.');
redirect(url('admin/payments/view.php?id=' . $id));