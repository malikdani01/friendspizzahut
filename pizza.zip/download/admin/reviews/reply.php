<?php
// reply.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/reviews/index.php'));
verify_csrf();
Database::execute("UPDATE reviews SET admin_reply=? WHERE id=?", [mb_substr((string)post('reply',''),0,1000), (int)post('id')]);
flash_success('Reply saved.');
redirect(url('admin/reviews/index.php'));