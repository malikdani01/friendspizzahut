<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Checkout';

$rawItems = get_cart_items();
if (!$rawItems) { flash_error('Your cart is empty.'); redirect(url('menu.php')); }

// ═══════════════════════════════════════════════════════════════
// STEP 1: VALIDATE AND CLEAN CART ITEMS
// Skip items with missing product (deleted) or NULL name
// ═══════════════════════════════════════════════════════════════
$items = [];
$invalidCount = 0;
foreach ($rawItems as $it) {
    $pname = trim((string)($it['name'] ?? ''));

    // If name missing, try to fetch fresh from products table
    if ($pname === '' && !empty($it['product_id'])) {
        try {
            $prod = Database::fetch("SELECT name FROM products WHERE id = ?", [(int)$it['product_id']]);
            if ($prod && !empty($prod['name'])) {
                $pname = $prod['name'];
            }
        } catch (Throwable $e) { /* ignore */ }
    }

    // Combo items: check combo name
    if ($pname === '' && !empty($it['combo_id'])) {
        try {
            $combo = Database::fetch("SELECT name FROM combos WHERE id = ?", [(int)$it['combo_id']]);
            if ($combo && !empty($combo['name'])) {
                $pname = $combo['name'];
            }
        } catch (Throwable $e) { /* ignore */ }
    }

    // If still no name → invalid item, skip it
    if ($pname === '') {
        $invalidCount++;
        // Clean up broken cart item
        try { remove_cart_item((int)$it['id']); } catch (Throwable $e) {}
        continue;
    }

    $it['name'] = $pname;
    $items[] = $it;
}

if (empty($items)) {
    flash_error('Some products in your cart are no longer available. Cart has been cleaned.');
    redirect(url('cart.php'));
}

if ($invalidCount > 0) {
    flash_info($invalidCount . ' unavailable item(s) were removed from your cart.');
}

$subtotal = calculate_cart_subtotal();
$minCheck = validate_minimum_order($subtotal);
$user = current_customer();

// Cities
$cities = [];
try {
    $cities = Database::fetchAll("SELECT id, name, delivery_fee FROM delivery_areas WHERE is_active = 1 ORDER BY sort_order, name");
} catch (Throwable $e) { $cities = []; }
if (empty($cities)) {
    $cities = [[
        'id' => 0,
        'name' => setting('restaurant_city', 'City Tamman'),
        'delivery_fee' => (float)setting('default_delivery_fee', 100),
    ]];
}

$errors = [];
$selectedMode = post('mode', '');

if (is_post()) {
    verify_csrf();

    $name          = trim((string)post('customer_name', ''));
    $phone         = trim((string)post('customer_phone', ''));
    $mode          = (string)post('mode', '');
    $cityId        = isset($_POST['city_id']) && $_POST['city_id'] !== '' ? (int)post('city_id') : -1;
    $addressLine   = trim((string)post('address_line', ''));
    $transactionId = trim((string)post('transaction_id', ''));
    $selectedMode  = $mode;

    $validModes = ['cod', 'pickup', 'easypaisa', 'jazzcash'];
    if (!in_array($mode, $validModes, true)) $errors[] = 'Please select an option (COD, Pickup, Easypaisa or JazzCash).';
    if (strlen($name) < 2)       $errors[] = 'Please enter your full name.';
    if (!validate_phone($phone)) $errors[] = 'Please enter a valid phone number.';

    $isDelivery = in_array($mode, ['cod', 'easypaisa', 'jazzcash'], true);
    $isPickup   = $mode === 'pickup';
    $needsTxn   = in_array($mode, ['easypaisa', 'jazzcash'], true);

    $deliveryFee = 0;
    $cityName = null;
    $addressFull = null;

    if ($isDelivery) {
        if ($cityId < 0) {
            $errors[] = 'Please select your city.';
        } else {
            $city = null;
            foreach ($cities as $c) if ((int)$c['id'] === $cityId) { $city = $c; break; }
            if (!$city) $errors[] = 'Invalid city.';
            else {
                $cityName = $city['name'];
                $deliveryFee = (float)$city['delivery_fee'];
            }
        }
        if (strlen($addressLine) < 5) $errors[] = 'Please enter your complete address.';
        else $addressFull = $addressLine;
    }

    if ($needsTxn) {
        if ($transactionId === '')          $errors[] = 'Transaction ID is required.';
        elseif (strlen($transactionId) < 6) $errors[] = 'Transaction ID too short (min 6 chars).';
    }

    if (!restaurant_is_open()) $errors[] = 'Restaurant is currently closed.';
    if (!$minCheck['ok'])      $errors[] = $minCheck['error'];

    $tax       = calculate_tax($subtotal);
    $service   = calculate_service_fee();
    $packaging = calculate_packaging_fee();
    $finalTotal = calculate_final_total([
        'subtotal' => $subtotal, 'discount_total' => 0,
        'delivery_fee' => $deliveryFee,
        'tax_amount' => $tax, 'service_fee' => $service, 'packaging_fee' => $packaging,
    ]);

    if (!$errors) {
        Database::beginTransaction();
        try {
            $orderNumber = generate_order_number();
            $orderType   = $isPickup ? 'pickup' : 'delivery';
            $paymentMode = match($mode) {
                'cod' => 'cod', 'pickup' => 'cod',
                'easypaisa' => 'easypaisa', 'jazzcash' => 'jazzcash',
                default => 'cod',
            };

            // ═══ Insert order (base columns only) ═══
            $orderId = Database::insert('orders', [
                'order_number'              => $orderNumber,
                'user_id'                   => $user['id'] ?? null,
                'customer_name'             => $name,
                'customer_phone'            => $phone,
                'customer_email'            => null,
                'order_type'                => $orderType,
                'delivery_address_snapshot' => $addressFull,
                'subtotal'                  => $subtotal,
                'discount_total'            => 0,
                'delivery_fee'              => $deliveryFee,
                'tax_amount'                => $tax,
                'service_fee'               => $service,
                'packaging_fee'             => $packaging,
                'total'                     => $finalTotal,
                'payment_method'            => $paymentMode,
                'payment_status'            => 'pending',
                'order_status'              => 'pending',
                'ip_address'                => client_ip(),
            ]);

            // Optional: city
            if ($cityName) {
                try {
                    Database::execute("UPDATE orders SET city = ? WHERE id = ?", [$cityName, $orderId]);
                } catch (Throwable $e) { error_log('city: ' . $e->getMessage()); }
            }

            // ═══ Insert order items (with GUARANTEED product_name) ═══
            foreach ($items as $it) {
                $addonSum = array_sum(array_column($it['addons'] ?? [], 'addon_price'));
                $unitPrice = (float)($it['unit_price_snapshot'] ?? 0);
                $lineTotal = ($unitPrice + $addonSum) * (int)$it['quantity'];

                // Final fallback — never NULL
                $productName = trim((string)$it['name']);
                if ($productName === '') {
                    $productName = 'Product #' . (int)($it['product_id'] ?? 0);
                }

                $oid = Database::insert('order_items', [
                    'order_id'              => $orderId,
                    'product_id'            => !empty($it['product_id']) ? (int)$it['product_id'] : null,
                    'combo_id'              => !empty($it['combo_id']) ? (int)$it['combo_id'] : null,
                    'product_name'          => $productName,
                    'unit_price'            => $unitPrice,
                    'quantity'              => max(1, (int)$it['quantity']),
                    'addons_total'          => $addonSum,
                    'line_total'            => $lineTotal,
                    'special_instructions'  => !empty($it['special_instructions']) ? $it['special_instructions'] : null,
                ]);

                // Item options
                foreach (($it['options'] ?? []) as $op) {
                    try {
                        Database::insert('order_item_options', [
                            'order_item_id'         => $oid,
                            'variation_option_name' => (string)($op['option_name'] ?? ''),
                            'option_price_delta'    => (float)($op['option_price_delta'] ?? 0),
                        ]);
                    } catch (Throwable $e) { error_log('opt: ' . $e->getMessage()); }
                }

                // Item addons
                foreach (($it['addons'] ?? []) as $ad) {
                    try {
                        Database::insert('order_item_addons', [
                            'order_item_id' => $oid,
                            'addon_name'    => (string)($ad['addon_name'] ?? ''),
                            'addon_price'   => (float)($ad['addon_price'] ?? 0),
                        ]);
                    } catch (Throwable $e) { error_log('ad: ' . $e->getMessage()); }
                }
            }

            // ═══ Payment ═══
            Database::insert('payments', [
                'order_id'       => $orderId,
                'method'         => $paymentMode,
                'amount'         => $finalTotal,
                'currency'       => 'PKR',
                'payment_status' => 'pending',
            ]);

            // ═══ Status history ═══
            Database::insert('order_status_history', [
                'order_id'   => $orderId,
                'old_status' => null,
                'new_status' => 'pending',
                'note'       => 'Order placed via ' . strtoupper($mode),
            ]);

            Database::commit();

            // ═══ Post-commit: optional operations ═══
            if ($needsTxn && $transactionId !== '') {
                try {
                    Database::execute("UPDATE orders SET transaction_id = ? WHERE id = ?", [$transactionId, $orderId]);
                } catch (Throwable $e) { error_log('txn: ' . $e->getMessage()); }
            }

            try {
                Database::insert('notifications', [
                    'user_type' => 'admin', 'user_id' => 1,
                    'type' => 'new_order', 'title' => 'New Order',
                    'message' => "Order #$orderNumber — Rs. " . number_format($finalTotal, 0) . " — $name",
                    'link' => '/admin/orders/view.php?id=' . $orderId,
                ]);
            } catch (Throwable $e) { error_log('notif: ' . $e->getMessage()); }

            clear_cart();
            $_SESSION['last_order_number'] = $orderNumber;
            flash_success('Order placed successfully!');
            redirect(url('order-success.php?order=' . urlencode($orderNumber)));

        } catch (Throwable $e) {
            Database::rollback();
            error_log('CHECKOUT: ' . $e->getMessage() . ' | ' . $e->getFile() . ':' . $e->getLine());
            $errors[] = '🔴 DEBUG: ' . $e->getMessage();
            $errors[] = '📍 Line: ' . $e->getLine() . ' in ' . basename($e->getFile());
        }
    }
}

$tax       = calculate_tax($subtotal);
$service   = calculate_service_fee();
$packaging = calculate_packaging_fee();

require __DIR__ . '/common/header.php';
?>

<style>
.co-wrap { max-width: 1100px; margin: 0 auto; padding: 16px 16px 140px; box-sizing: border-box; }
.co-wrap * { box-sizing: border-box; }
.co-title { font-size: 28px; font-weight: 900; color: #fff; margin: 0 0 6px; }
.co-sub { font-size: 14px; color: rgba(255,255,255,0.55); margin: 0 0 24px; }
.co-layout { display: grid; grid-template-columns: 1fr; gap: 18px; }
@media (min-width: 900px) { .co-layout { grid-template-columns: 1fr 400px; gap: 24px; } }
.co-card { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 20px; margin-bottom: 16px; }
.co-card h3 { font-size: 14px; font-weight: 800; color: #dc2626; margin: 0 0 16px; display: flex; align-items: center; gap: 8px; text-transform: uppercase; letter-spacing: 0.6px; }
.co-label { display: block; font-size: 13px; font-weight: 600; color: rgba(255,255,255,0.72); margin-bottom: 6px; }
.co-input, .co-select {
  width: 100%; padding: 13px 14px;
  background: rgba(0,0,0,0.45);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 11px; color: #fff; font-size: 15px;
  outline: none; margin-bottom: 14px; font-family: inherit;
}
.co-input:focus, .co-select:focus { border-color: #dc2626; box-shadow: 0 0 0 3px rgba(220,38,38,0.15); }
.co-input::placeholder { color: rgba(255,255,255,0.35); }
.co-modes { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
@media (min-width: 700px) { .co-modes { grid-template-columns: repeat(4, 1fr); } }
.co-mode {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 16px 8px; border: 2px solid rgba(255,255,255,0.1);
  border-radius: 14px; background: rgba(255,255,255,0.02);
  cursor: pointer; text-align: center; min-height: 110px;
}
.co-mode input { display: none; }
.co-mode-icon { width: 42px; height: 42px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 8px; background: rgba(255,255,255,0.06); color: rgba(255,255,255,0.5); }
.co-mode-label { font-weight: 700; font-size: 12.5px; color: rgba(255,255,255,0.75); line-height: 1.25; }
.co-mode-hint { display: block; font-size: 10.5px; color: rgba(255,255,255,0.4); margin-top: 3px; }
.co-mode.selected { border-color: #dc2626; background: rgba(220,38,38,0.08); }
.co-mode.selected .co-mode-icon { background: #dc2626; color: #fff; transform: scale(1.1); }
.co-mode.selected .co-mode-label { color: #dc2626; }
.co-pay-details { background: rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 12px 14px; font-size: 13px; line-height: 1.7; margin-bottom: 14px; }
.co-pay-details .row { display: flex; justify-content: space-between; color: rgba(255,255,255,0.65); }
.co-pay-details .row strong { color: #fff; font-weight: 700; font-family: monospace; }
.co-pay-details .title { font-size: 12px; font-weight: 800; text-transform: uppercase; margin-bottom: 6px; color: #f59e0b; }
.co-txn { background: linear-gradient(135deg, rgba(234,179,8,0.12), rgba(234,179,8,0.05)); border: 1.5px solid rgba(234,179,8,0.4); border-radius: 12px; padding: 14px; margin-top: 4px; }
.co-txn-title { font-size: 13px; font-weight: 800; color: #fcd34d; margin-bottom: 6px; }
.co-txn-hint { font-size: 11.5px; color: rgba(252,211,77,0.75); margin: 0 0 10px; }
.co-txn .co-input { margin-bottom: 0; }
.co-hidden { display: none !important; }
.co-summary { background: linear-gradient(180deg, #1a1a1a 0%, #0f0f0f 100%); border: 1px solid rgba(220,38,38,0.25); border-radius: 16px; padding: 22px; position: sticky; top: 80px; }
@media (max-width: 899px) { .co-summary { position: static; } }
.co-summary h3 { font-size: 16px; color: #fff; margin: 0 0 16px; font-weight: 800; }
.co-items-mini { background: rgba(0,0,0,0.35); border-radius: 10px; padding: 12px; margin-bottom: 16px; max-height: 200px; overflow-y: auto; }
.co-items-mini-row { display: flex; justify-content: space-between; font-size: 13px; padding: 5px 0; color: rgba(255,255,255,0.72); }
.co-items-mini-row span:last-child { color: #fff; font-weight: 600; }
.co-summary-row { display: flex; justify-content: space-between; padding: 8px 0; font-size: 14px; color: rgba(255,255,255,0.72); }
.co-summary-row span:last-child { color: #fff; font-weight: 600; }
.co-summary-row.total { border-top: 2px solid rgba(220,38,38,0.3); padding-top: 14px; margin-top: 10px; font-size: 18px; font-weight: 800; color: #fff; }
.co-summary-row.total span:last-child { color: #dc2626; font-size: 22px; font-weight: 900; }
.co-submit { display: flex; align-items: center; justify-content: center; gap: 10px; width: 100%; padding: 18px; background: linear-gradient(135deg, #dc2626, #b91c1c); color: #fff; border: 0; border-radius: 14px; font-size: 16px; font-weight: 800; cursor: pointer; margin-top: 20px; font-family: inherit; }
.co-submit:disabled { opacity: 0.6; cursor: not-allowed; }
.co-submit.need-select { background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.4); box-shadow: none; }
.co-secure { text-align: center; font-size: 11.5px; color: rgba(255,255,255,0.4); margin: 14px 0 0; }
.co-error { background: rgba(239,68,68,0.15); border: 1.5px solid #dc2626; color: #fca5a5; padding: 16px; border-radius: 12px; font-size: 13.5px; margin-bottom: 18px; line-height: 1.7; word-break: break-word; }
.co-error strong { color: #fff; display: block; margin-bottom: 6px; }
.co-error div { padding: 3px 0; }
</style>

<div class="co-wrap">
  <h1 class="co-title">🛍️ Checkout</h1>
  <p class="co-sub">Choose how you want your order</p>

  <?php if ($errors): ?>
    <div class="co-error">
      <strong><i class="fa-solid fa-circle-exclamation"></i> Please fix:</strong>
      <?php foreach ($errors as $er): ?><div>• <?= e($er) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <form method="post" id="coForm" novalidate>
    <?= csrf_field() ?>
    <div class="co-layout">
      <div>
        <div class="co-card">
          <h3><i class="fa-solid fa-wallet"></i> Choose Payment & Type</h3>
          <div class="co-modes">
            <label class="co-mode <?= $selectedMode === 'cod' ? 'selected' : '' ?>" data-mode="cod">
              <input type="radio" name="mode" value="cod" <?= $selectedMode === 'cod' ? 'checked' : '' ?>>
              <div class="co-mode-icon"><i class="fa-solid fa-money-bill-wave"></i></div>
              <span class="co-mode-label">Cash on Delivery</span>
              <span class="co-mode-hint">Pay when received</span>
            </label>
            <label class="co-mode <?= $selectedMode === 'pickup' ? 'selected' : '' ?>" data-mode="pickup">
              <input type="radio" name="mode" value="pickup" <?= $selectedMode === 'pickup' ? 'checked' : '' ?>>
              <div class="co-mode-icon"><i class="fa-solid fa-store"></i></div>
              <span class="co-mode-label">Pick Up</span>
              <span class="co-mode-hint">From restaurant</span>
            </label>
            <label class="co-mode <?= $selectedMode === 'easypaisa' ? 'selected' : '' ?>" data-mode="easypaisa">
              <input type="radio" name="mode" value="easypaisa" <?= $selectedMode === 'easypaisa' ? 'checked' : '' ?>>
              <div class="co-mode-icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
              <span class="co-mode-label">Easypaisa</span>
              <span class="co-mode-hint">Online payment</span>
            </label>
            <label class="co-mode <?= $selectedMode === 'jazzcash' ? 'selected' : '' ?>" data-mode="jazzcash">
              <input type="radio" name="mode" value="jazzcash" <?= $selectedMode === 'jazzcash' ? 'checked' : '' ?>>
              <div class="co-mode-icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
              <span class="co-mode-label">JazzCash</span>
              <span class="co-mode-hint">Online payment</span>
            </label>
          </div>
          <div id="easypaisaBlock" class="co-pay-details co-hidden" style="margin-top:16px;">
            <div class="title">Easypaisa Account Details</div>
            <div class="row"><span>Account Name</span><strong>Hamid Jabbar</strong></div>
            <div class="row"><span>Account Number</span><strong>03001494249</strong></div>
          </div>
          <div id="jazzcashBlock" class="co-pay-details co-hidden" style="margin-top:16px;">
            <div class="title">JazzCash Account Details</div>
            <div class="row"><span>Account Name</span><strong>Hamid Jabbar</strong></div>
            <div class="row"><span>Account Number</span><strong>03001494249</strong></div>
          </div>
          <div id="txnBlock" class="co-txn co-hidden">
            <div class="co-txn-title">Transaction ID Required</div>
            <p class="co-txn-hint">Payment ke baad Transaction ID yahan paste karein.</p>
            <input class="co-input" name="transaction_id" id="txnInput" value="<?= e(post('transaction_id','')) ?>" placeholder="e.g. 1234567890">
          </div>
        </div>
        <div class="co-card">
          <h3><i class="fa-solid fa-user"></i> Your Details</h3>
          <label class="co-label">Full Name *</label>
          <input class="co-input" name="customer_name" required value="<?= e($user['name'] ?? post('customer_name','')) ?>" placeholder="Enter your full name">
          <label class="co-label">Phone Number *</label>
          <input class="co-input" name="customer_phone" required value="<?= e($user['phone'] ?? post('customer_phone','')) ?>" placeholder="03XXXXXXXXX" style="margin-bottom:0;">
        </div>
        <div class="co-card co-hidden" id="addressBlock">
          <h3><i class="fa-solid fa-location-dot"></i> Delivery Address</h3>
          <label class="co-label">Select City *</label>
          <select class="co-select" name="city_id" id="citySelect">
            <option value="" data-fee="0">— Select your city —</option>
            <?php foreach ($cities as $c): ?>
              <option value="<?= (int)$c['id'] ?>" data-fee="<?= (float)$c['delivery_fee'] ?>" <?= (int)post('city_id') === (int)$c['id'] ? 'selected' : '' ?>>
                <?= e($c['name']) ?> — Rs. <?= number_format((float)$c['delivery_fee'], 0) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <label class="co-label">Full Address *</label>
          <input class="co-input" name="address_line" value="<?= e(post('address_line','')) ?>" placeholder="House / Street / Block / Area" style="margin-bottom:0;">
        </div>
      </div>
      <div>
        <div class="co-summary">
          <h3>Order Summary</h3>
          <div class="co-items-mini">
            <?php foreach ($items as $it): ?>
              <div class="co-items-mini-row">
                <span><?= (int)$it['quantity'] ?>× <?= e($it['name']) ?></span>
                <span><?= money($it['line_total']) ?></span>
              </div>
            <?php endforeach; ?>
          </div>
          <div class="co-summary-row"><span>Subtotal</span><span><?= money($subtotal) ?></span></div>
          <div class="co-summary-row" id="deliveryFeeRow" style="display:none;"><span>Delivery Fee</span><span id="deliveryFeeAmount">Rs. 0</span></div>
          <div class="co-summary-row total"><span>Grand Total</span><span id="grandTotalAmount"><?= money($subtotal + $tax + $service + $packaging) ?></span></div>
          <button type="submit" class="co-submit need-select" id="coSubmitBtn" disabled>Select an Option Above</button>
          <p class="co-secure">Your information is safe & secure</p>
        </div>
      </div>
    </div>
  </form>
</div>

<script>
(function() {
  var subtotal = <?= (float)$subtotal ?>, tax = <?= (float)$tax ?>, service = <?= (float)$service ?>, packaging = <?= (float)$packaging ?>;
  var addressBlock = document.getElementById('addressBlock');
  var easypaisaBlk = document.getElementById('easypaisaBlock');
  var jazzcashBlk = document.getElementById('jazzcashBlock');
  var txnBlock = document.getElementById('txnBlock');
  var txnInput = document.getElementById('txnInput');
  var citySelect = document.getElementById('citySelect');
  var deliveryRow = document.getElementById('deliveryFeeRow');
  var deliveryAmt = document.getElementById('deliveryFeeAmount');
  var grandAmt = document.getElementById('grandTotalAmount');
  var submitBtn = document.getElementById('coSubmitBtn');
  function money(n) { return 'Rs. ' + Math.round(Number(n) || 0).toLocaleString('en-PK'); }
  function getMode() { var r = document.querySelector('input[name="mode"]:checked'); return r ? r.value : ''; }
  function getCityFee() {
    if (!citySelect) return 0;
    var opt = citySelect.options[citySelect.selectedIndex];
    if (!opt || !opt.value) return 0;
    return parseFloat(opt.getAttribute('data-fee') || '0') || 0;
  }
  function isDelivery(m) { return m === 'cod' || m === 'easypaisa' || m === 'jazzcash'; }
  function recalc() {
    var mode = getMode();
    var fee = isDelivery(mode) ? getCityFee() : 0;
    if (deliveryRow) { if (isDelivery(mode) && fee > 0) { deliveryRow.style.display = ''; deliveryAmt.textContent = money(fee); } else deliveryRow.style.display = 'none'; }
    if (grandAmt) grandAmt.textContent = money(subtotal + fee + tax + service + packaging);
  }
  function updateUI() {
    var mode = getMode();
    [addressBlock, easypaisaBlk, jazzcashBlk, txnBlock].forEach(function(b) { if (b) b.classList.add('co-hidden'); });
    if (txnInput) txnInput.required = false;
    if (!mode) { submitBtn.disabled = true; submitBtn.classList.add('need-select'); submitBtn.textContent = 'Select an Option Above'; recalc(); return; }
    submitBtn.disabled = false; submitBtn.classList.remove('need-select'); submitBtn.innerHTML = '<i class="fa-solid fa-check-circle"></i> Place Order';
    if (mode === 'pickup') {}
    else if (mode === 'cod') { if (addressBlock) addressBlock.classList.remove('co-hidden'); }
    else if (mode === 'easypaisa') { [addressBlock, easypaisaBlk, txnBlock].forEach(function(b) { if (b) b.classList.remove('co-hidden'); }); if (txnInput) txnInput.required = true; }
    else if (mode === 'jazzcash') { [addressBlock, jazzcashBlk, txnBlock].forEach(function(b) { if (b) b.classList.remove('co-hidden'); }); if (txnInput) txnInput.required = true; }
    recalc();
  }
  document.querySelectorAll('.co-mode').forEach(function(el) {
    el.addEventListener('click', function(e) {
      e.preventDefault();
      var radio = el.querySelector('input[type="radio"]'); if (!radio) return;
      document.querySelectorAll('.co-mode').forEach(function(x) { x.classList.remove('selected'); var r = x.querySelector('input'); if (r) r.checked = false; });
      radio.checked = true; el.classList.add('selected'); updateUI();
    });
  });
  if (citySelect) citySelect.addEventListener('change', recalc);
  var form = document.getElementById('coForm');
  if (form) form.addEventListener('submit', function(e) { if (!getMode()) { e.preventDefault(); return false; } submitBtn.disabled = true; submitBtn.innerHTML = 'Placing Order...'; });
  updateUI();
})();
</script>

<?php require __DIR__ . '/common/footer.php'; ?>