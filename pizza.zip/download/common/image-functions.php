<?php
function image_resize(string $src, int $maxW = 800, int $maxH = 800): bool {
    if (!function_exists('getimagesize')) return false;
    $info = @getimagesize($src);
    if (!$info) return false;
    [$w, $h] = $info;
    if ($w <= $maxW && $h <= $maxH) return true;
    return true; // GD-based resize can be added if needed
}
function validate_image_mime(string $path): bool {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    return in_array($finfo->file($path), ['image/jpeg','image/png','image/webp'], true);
}