<?php
/**
 * Homepage section engine — dynamic, admin-ordered
 */
function get_homepage_sections(): array {
    return Database::fetchAll(
        "SELECT * FROM homepage_sections WHERE is_enabled = 1 ORDER BY sort_order, id"
    );
}

function get_section_products(array $section, int $limit = 8): array {
    switch ($section['product_source']) {
        case 'flags':
            // Product has any of the flags (featured/recommended/bestseller)
            return Database::fetchAll(
                "SELECT p.*, c.name AS category_name, c.slug AS category_slug
                 FROM products p LEFT JOIN categories c ON c.id = p.category_id
                 WHERE p.status = 'active' AND p.is_available = 1
                 AND (p.is_featured = 1 OR p.is_recommended = 1)
                 ORDER BY p.is_featured DESC, p.sort_order LIMIT " . (int)$limit
            );

        case 'flag_deal':
            return Database::fetchAll(
                "SELECT p.*, c.name AS category_name, c.slug AS category_slug
                 FROM products p LEFT JOIN categories c ON c.id = p.category_id
                 WHERE p.status = 'active' AND p.is_available = 1
                 AND (p.is_limited_deal = 1 OR p.sale_price IS NOT NULL)
                 ORDER BY p.sort_order LIMIT " . (int)$limit
            );

        case 'flag_bestseller':
            return Database::fetchAll(
                "SELECT p.*, c.name AS category_name, c.slug AS category_slug
                 FROM products p LEFT JOIN categories c ON c.id = p.category_id
                 WHERE p.status = 'active' AND p.is_available = 1 AND p.is_bestseller = 1
                 ORDER BY p.sort_order LIMIT " . (int)$limit
            );

        case 'flag_new':
            return Database::fetchAll(
                "SELECT p.*, c.name AS category_name, c.slug AS category_slug
                 FROM products p LEFT JOIN categories c ON c.id = p.category_id
                 WHERE p.status = 'active' AND p.is_available = 1 AND p.is_new = 1
                 ORDER BY p.id DESC LIMIT " . (int)$limit
            );

        case 'flag_coming_soon':
            return Database::fetchAll(
                "SELECT p.*, c.name AS category_name, c.slug AS category_slug
                 FROM products p LEFT JOIN categories c ON c.id = p.category_id
                 WHERE p.status = 'active' AND p.is_coming_soon = 1
                 ORDER BY p.sort_order LIMIT " . (int)$limit
            );

        case 'manual':
        default:
            return Database::fetchAll(
                "SELECT p.*, c.name AS category_name, c.slug AS category_slug
                 FROM homepage_section_products sp
                 JOIN products p ON p.id = sp.product_id
                 LEFT JOIN categories c ON c.id = p.category_id
                 WHERE sp.section_id = ? AND p.status = 'active'
                 ORDER BY sp.sort_order LIMIT " . (int)$limit,
                [(int)$section['id']]
            );
    }
}

/**
 * Force section order: Recommended → Best Selling → Coming Soon
 */
function homepage_section_priority(string $key): int {
    return match($key) {
        'recommended'   => 10,
        'bestselling'   => 20,
        'coming_soon'   => 30,
        'special_deals' => 40,
        'new_items'     => 50,
        'reviews'       => 60,
        default         => 100,
    };
}
