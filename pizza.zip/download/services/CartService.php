<?php
// services/CartService.php
class CartService {
    public static function items(): array { return get_cart_items(); }
    public static function count(): int { return get_cart_count(); }
    public static function add(...$args) { return add_to_cart(...$args); }
    public static function update(int $id, int $q): bool { return update_cart_quantity($id, $q); }
    public static function remove(int $id): bool { return remove_cart_item($id); }
    public static function clear(): void { clear_cart(); }
}