<?php
require_once __DIR__ . '/../common/bootstrap.php';
require_once __DIR__ . '/../common/dashboard-functions.php';
require_admin();

$pageTitle = 'Dashboard';

// ─── Date Filter ───────────────────────────────────────────────
$filter = (string)get('range', 'today');
$fromGet = (string)get('from', '');
$toGet   = (string)get('to', '');

$range = dashboard_date_range($filter, $fromGet, $toGet);
$from  = $range['from'];
$to    = $range['to'];
$label = $range['label'];

// ─── Load Data ─────────────────────────────────────────────────
$stats        = dashboard_stats($from, $to);
$topProducts  = dashboard_top_products($from, $to, 10);
$topCustomers = dashboard_top_customers($from, $to, 10);
$chartData    = dashboard_revenue_chart($from, $to);
$statusDist   = dashboard_status_distribution($from, $to);
$recentOrders = dashboard_recent_orders($from, $to, 8);
$payments     = dashboard_payment_breakdown($from, $to);

// Extra counters
$featuresTotal = (int)(Database::fetch("SELECT COUNT(*) c FROM features")['c'] ?? 0);
$featuresOn    = (int)(Database::fetch("SELECT COUNT(*) c FROM features WHERE is_enabled = 1")['c'] ?? 0);
$pendingReviews = (int)(Database::fetch("SELECT COUNT(*) c FROM reviews WHERE is_approved = 0")['c'] ?? 0);
$unreadMessages = (int)(Database::fetch("SELECT COUNT(*) c FROM contact_messages WHERE is_read = 0")['c'] ?? 0);
$lowStock = feature_enabled('inventory_tracking')
    ? Database::fetchAll("SELECT id, name, stock_quantity FROM products WHERE stock_tracking = 1 AND stock_quantity <= low_stock_threshold AND status='active' LIMIT 5")
    : [];

require __DIR__ . '/common/header.php';
?>

<style>
/* ─── DASHBOARD STYLES ───────────────────────────────────────── */
.db-wrap { max-width: 1400px; margin: 0 auto; }

/* Date filter bar */
.db-filter {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  padding: 14px 18px;
  margin-bottom: 20px;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  justify-content: space-between;
}
.db-filter-left {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
}
.db-chip {
  padding: 8px 14px;
  border-radius: 10px;
  background: rgba(255,255,255,0.04);
  color: rgba(255,255,255,0.7);
  font-size: 12.5px;
  font-weight: 700;
  text-decoration: none;
  border: 1px solid rgba(255,255,255,0.06);
  transition: all .15s;
  white-space: nowrap;
}
.db-chip:hover {
  background: rgba(220,38,38,0.15);
  color: #fff;
  border-color: rgba(220,38,38,0.35);
  transform: translateY(-1px);
}
.db-chip.active {
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  border-color: #dc2626;
  box-shadow: 0 4px 14px rgba(220,38,38,0.35);
}
.db-filter-custom {
  display: flex;
  gap: 6px;
  align-items: center;
}
.db-filter-custom input[type="date"] {
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 8px;
  padding: 7px 10px;
  color: #fff;
  font-size: 12.5px;
  outline: none;
  font-family: inherit;
}
.db-filter-custom input[type="date"]:focus { border-color: #dc2626; }
.db-btn-apply {
  background: #dc2626;
  color: #fff;
  border: 0;
  padding: 8px 14px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 700;
  cursor: pointer;
}
.db-btn-apply:hover { background: #b91c1c; }

/* Header for range */
.db-range-label {
  font-size: 12.5px;
  color: rgba(255,255,255,0.55);
  margin-bottom: 14px;
  padding-left: 4px;
}
.db-range-label strong { color: #fff; font-weight: 800; }

/* Stats grid */
.db-stats {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
  margin-bottom: 20px;
}
@media (min-width: 768px) { .db-stats { grid-template-columns: repeat(4, 1fr); gap: 16px; } }
.db-stat {
  background: linear-gradient(180deg, #1a1a1a 0%, #141414 100%);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  padding: 16px;
  position: relative;
  overflow: hidden;
  transition: all .25s;
}
.db-stat:hover {
  transform: translateY(-2px);
  border-color: rgba(220,38,38,0.25);
  box-shadow: 0 8px 24px rgba(0,0,0,0.4);
}
.db-stat::after {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: var(--db-accent, #dc2626);
  border-radius: 14px 14px 0 0;
}
.db-stat-label {
  font-size: 10.5px;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  font-weight: 800;
  color: rgba(255,255,255,0.5);
  margin-bottom: 6px;
}
.db-stat-value {
  font-size: 24px;
  font-weight: 900;
  color: #fff;
  line-height: 1;
  letter-spacing: -0.02em;
}
@media (min-width: 768px) { .db-stat-value { font-size: 28px; } }
.db-stat-sub {
  margin-top: 6px;
  font-size: 11.5px;
  color: rgba(255,255,255,0.45);
  font-weight: 500;
}
.db-stat-icon {
  position: absolute;
  right: 14px;
  top: 14px;
  font-size: 20px;
  opacity: 0.2;
  color: var(--db-accent, #dc2626);
}

/* Two-column layout */
.db-grid-2 {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
  margin-bottom: 20px;
}
@media (min-width: 1024px) { .db-grid-2 { grid-template-columns: 1fr 1fr; } }

/* Card */
.db-card {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  overflow: hidden;
}
.db-card-head {
  padding: 16px 18px;
  border-bottom: 1px solid rgba(255,255,255,0.06);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}
.db-card-title {
  font-size: 14px;
  font-weight: 800;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 8px;
}
.db-card-title i { color: #dc2626; font-size: 13px; }
.db-card-link {
  font-size: 12px;
  font-weight: 700;
  color: #dc2626;
  text-decoration: none;
  white-space: nowrap;
}
.db-card-link:hover { color: #f87171; }
.db-card-body { padding: 0; }

/* List rows */
.db-list-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 18px;
  border-bottom: 1px solid rgba(255,255,255,0.04);
  text-decoration: none;
  color: inherit;
  transition: background .15s;
}
.db-list-row:last-child { border-bottom: 0; }
.db-list-row:hover { background: rgba(255,255,255,0.03); }
.db-list-rank {
  width: 26px;
  height: 26px;
  flex-shrink: 0;
  border-radius: 8px;
  background: rgba(255,255,255,0.05);
  color: rgba(255,255,255,0.55);
  font-size: 11px;
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
}
.db-list-rank.top { background: linear-gradient(135deg, #dc2626, #b91c1c); color: #fff; }
.db-list-img {
  width: 42px;
  height: 42px;
  flex-shrink: 0;
  border-radius: 10px;
  background: #111;
  overflow: hidden;
}
.db-list-img img { width: 100%; height: 100%; object-fit: cover; }
.db-list-info { flex: 1; min-width: 0; }
.db-list-name {
  font-size: 13.5px;
  font-weight: 700;
  color: #fff;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.db-list-meta {
  font-size: 11.5px;
  color: rgba(255,255,255,0.5);
  margin-top: 2px;
}
.db-list-value {
  font-size: 14px;
  font-weight: 800;
  color: #dc2626;
  white-space: nowrap;
  text-align: right;
}
.db-list-value small {
  display: block;
  font-size: 10.5px;
  color: rgba(255,255,255,0.4);
  font-weight: 500;
  margin-top: 2px;
}

/* Empty */
.db-empty {
  padding: 40px 20px;
  text-align: center;
  color: rgba(255,255,255,0.4);
  font-size: 13px;
}

/* Chart */
.db-chart-wrap { padding: 18px; }

/* Recent orders table */
.db-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}
.db-table thead {
  background: rgba(255,255,255,0.03);
}
.db-table th {
  padding: 11px 16px;
  text-align: left;
  font-size: 10.5px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  font-weight: 800;
  color: rgba(255,255,255,0.55);
  border-bottom: 1px solid rgba(255,255,255,0.06);
}
.db-table td {
  padding: 12px 16px;
  border-top: 1px solid rgba(255,255,255,0.04);
  color: #f9fafb;
}
.db-table tr:hover { background: rgba(255,255,255,0.03); }
.db-status-chip {
  display: inline-block;
  padding: 3px 9px;
  border-radius: 999px;
  font-size: 10.5px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.3px;
}
.db-status-pending { background: rgba(234,179,8,0.18); color: #fcd34d; }
.db-status-confirmed { background: rgba(59,130,246,0.18); color: #93c5fd; }
.db-status-preparing { background: rgba(139,92,246,0.18); color: #c4b5fd; }
.db-status-ready { background: rgba(168,85,247,0.18); color: #d8b4fe; }
.db-status-out_for_delivery { background: rgba(249,115,22,0.18); color: #fdba74; }
.db-status-delivered,
.db-status-completed { background: rgba(34,197,94,0.18); color: #4ade80; }
.db-status-cancelled { background: rgba(220,38,38,0.18); color: #fca5a5; }

/* Widgets row */
.db-widgets {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
}
@media (min-width: 768px) { .db-widgets { grid-template-columns: repeat(2, 1fr); } }
@media (min-width: 1024px) { .db-widgets { grid-template-columns: repeat(4, 1fr); } }
.db-widget {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  padding: 16px;
  display: flex;
  gap: 12px;
  align-items: flex-start;
}
.db-widget-icon {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  flex-shrink: 0;
}
.db-widget-info { flex: 1; min-width: 0; }
.db-widget-value {
  font-size: 22px;
  font-weight: 900;
  color: #fff;
  line-height: 1;
}
.db-widget-label {
  font-size: 11.5px;
  color: rgba(255,255,255,0.5);
  margin-top: 5px;
  font-weight: 600;
}
</style>

<div class="db-wrap">

  <!-- ═══════════ DATE FILTER ═══════════ -->
  <div class="db-filter">
    <div class="db-filter-left">
      <a href="?range=today" class="db-chip <?= $filter === 'today' ? 'active' : '' ?>">Today</a>
      <a href="?range=yesterday" class="db-chip <?= $filter === 'yesterday' ? 'active' : '' ?>">Yesterday</a>
      <a href="?range=week" class="db-chip <?= $filter === 'week' ? 'active' : '' ?>">This Week</a>
      <a href="?range=month" class="db-chip <?= $filter === 'month' ? 'active' : '' ?>">This Month</a>
      <a href="?range=year" class="db-chip <?= $filter === 'year' ? 'active' : '' ?>">This Year</a>
      <a href="?range=last7" class="db-chip <?= $filter === 'last7' ? 'active' : '' ?>">Last 7</a>
      <a href="?range=last30" class="db-chip <?= $filter === 'last30' ? 'active' : '' ?>">Last 30</a>
      <a href="?range=last90" class="db-chip <?= $filter === 'last90' ? 'active' : '' ?>">Last 90</a>
    </div>
    <form method="get" class="db-filter-custom">
      <input type="hidden" name="range" value="custom">
      <input type="date" name="from" value="<?= e($filter === 'custom' ? $from : date('Y-m-01')) ?>">
      <span style="color:rgba(255,255,255,0.4);font-size:12px;">to</span>
      <input type="date" name="to" value="<?= e($filter === 'custom' ? $to : date('Y-m-d')) ?>">
      <button type="submit" class="db-btn-apply"><i class="fa-solid fa-filter"></i> Apply</button>
    </form>
  </div>

  <div class="db-range-label">
    Showing: <strong><?= e($label) ?></strong>
    <?php if ($filter === 'custom'): ?>
      (<?= date('d M Y', strtotime($from)) ?> — <?= date('d M Y', strtotime($to)) ?>)
    <?php endif; ?>
  </div>

  <!-- ═══════════ STATS CARDS ═══════════ -->
  <div class="db-stats">
    <div class="db-stat" style="--db-accent:#dc2626;">
      <div class="db-stat-icon"><i class="fa-solid fa-receipt"></i></div>
      <div class="db-stat-label">Total Orders</div>
      <div class="db-stat-value"><?= number_format($stats['orders']) ?></div>
      <div class="db-stat-sub"><?= $stats['completed'] ?> completed · <?= $stats['cancelled'] ?> cancelled</div>
    </div>
    <div class="db-stat" style="--db-accent:#16a34a;">
      <div class="db-stat-icon"><i class="fa-solid fa-money-bill-wave"></i></div>
      <div class="db-stat-label">Revenue</div>
      <div class="db-stat-value"><?= money($stats['revenue']) ?></div>
      <div class="db-stat-sub">Avg: <?= money($stats['avg_order']) ?></div>
    </div>
    <div class="db-stat" style="--db-accent:#0ea5e9;">
      <div class="db-stat-icon"><i class="fa-solid fa-user-plus"></i></div>
      <div class="db-stat-label">New Customers</div>
      <div class="db-stat-value"><?= number_format($stats['new_customers']) ?></div>
      <div class="db-stat-sub">Registered in period</div>
    </div>
    <div class="db-stat" style="--db-accent:#f59e0b;">
      <div class="db-stat-icon"><i class="fa-solid fa-pizza-slice"></i></div>
      <div class="db-stat-label">Items Sold</div>
      <div class="db-stat-value"><?= number_format($stats['products_sold']) ?></div>
      <div class="db-stat-sub"><?= $stats['delivery_orders'] ?> delivery · <?= $stats['pickup_orders'] ?> pickup</div>
    </div>
  </div>

  <!-- ═══════════ REVENUE CHART ═══════════ -->
  <div class="db-card" style="margin-bottom:20px;">
    <div class="db-card-head">
      <div class="db-card-title"><i class="fa-solid fa-chart-line"></i> Revenue Trend</div>
      <div style="font-size:12px;color:rgba(255,255,255,0.5);"><?= e($label) ?></div>
    </div>
    <div class="db-chart-wrap">
      <canvas id="revenueChart" height="90"></canvas>
    </div>
  </div>

  <!-- ═══════════ TOP PRODUCTS + TOP CUSTOMERS ═══════════ -->
  <div class="db-grid-2">

    <!-- TOP PRODUCTS -->
    <div class="db-card">
      <div class="db-card-head">
        <div class="db-card-title"><i class="fa-solid fa-crown"></i> Top Selling Products</div>
        <a href="<?= url('admin/reports/index.php?from=' . $from . '&to=' . $to) ?>" class="db-card-link">View Report →</a>
      </div>
      <div class="db-card-body">
        <?php if (!$topProducts): ?>
          <div class="db-empty">
            <i class="fa-solid fa-chart-simple" style="font-size:32px;opacity:0.3;display:block;margin-bottom:8px;"></i>
            No sales in this period
          </div>
        <?php else: foreach ($topProducts as $i => $p):
          $img = !empty($p['image']) ? upload_url($p['image']) : '';
        ?>
          <div class="db-list-row">
            <div class="db-list-rank <?= $i < 3 ? 'top' : '' ?>"><?= $i + 1 ?></div>
            <div class="db-list-img">
              <?php if ($img): ?>
                <img src="<?= e($img) ?>" onerror="this.style.display='none'" alt="">
              <?php else: ?>
                <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,0.2);font-size:18px;">
                  <i class="fa-solid fa-pizza-slice"></i>
                </div>
              <?php endif; ?>
            </div>
            <div class="db-list-info">
              <div class="db-list-name"><?= e($p['product_name']) ?></div>
              <div class="db-list-meta"><i class="fa-solid fa-box"></i> <?= number_format((int)$p['qty_sold']) ?> sold</div>
            </div>
            <div class="db-list-value"><?= money($p['revenue']) ?></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>

    <!-- TOP CUSTOMERS -->
    <div class="db-card">
      <div class="db-card-head">
        <div class="db-card-title"><i class="fa-solid fa-user-tie"></i> Top Spending Customers</div>
        <a href="<?= url('admin/customers/index.php') ?>" class="db-card-link">All Customers →</a>
      </div>
      <div class="db-card-body">
        <?php if (!$topCustomers): ?>
          <div class="db-empty">
            <i class="fa-solid fa-user-group" style="font-size:32px;opacity:0.3;display:block;margin-bottom:8px;"></i>
            No orders in this period
          </div>
        <?php else: foreach ($topCustomers as $i => $c):
          $initial = strtoupper(mb_substr($c['customer_name'] ?? 'U', 0, 1));
        ?>
          <div class="db-list-row">
            <div class="db-list-rank <?= $i < 3 ? 'top' : '' ?>"><?= $i + 1 ?></div>
            <div class="db-list-img" style="background:linear-gradient(135deg,#dc2626,#7f1d1d);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:15px;border-radius:50%;">
              <?= e($initial) ?>
            </div>
            <div class="db-list-info">
              <div class="db-list-name"><?= e($c['customer_name']) ?></div>
              <div class="db-list-meta"><i class="fa-solid fa-phone"></i> <?= e($c['customer_phone']) ?> · <?= (int)$c['order_count'] ?> orders</div>
            </div>
            <div class="db-list-value"><?= money($c['total_spent']) ?></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>

  </div>

  <!-- ═══════════ RECENT ORDERS ═══════════ -->
  <div class="db-card" style="margin-bottom:20px;">
    <div class="db-card-head">
      <div class="db-card-title"><i class="fa-solid fa-clock-rotate-left"></i> Recent Orders</div>
      <a href="<?= url('admin/orders/index.php') ?>" class="db-card-link">View All →</a>
    </div>
    <?php if (!$recentOrders): ?>
      <div class="db-empty">No orders in this period</div>
    <?php else: ?>
    <div style="overflow-x:auto;">
      <table class="db-table">
        <thead>
          <tr>
            <th>Order #</th>
            <th>Customer</th>
            <th>Total</th>
            <th>Payment</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recentOrders as $o): ?>
          <tr>
            <td>
              <a href="<?= url('admin/orders/view.php?id=' . (int)$o['id']) ?>"
                 style="color:#dc2626;text-decoration:none;font-family:monospace;font-weight:700;font-size:12px;">
                <?= e($o['order_number']) ?>
              </a>
            </td>
            <td>
              <div style="font-weight:700;color:#fff;"><?= e($o['customer_name']) ?></div>
              <div style="font-size:11.5px;color:rgba(255,255,255,0.5);"><?= e($o['customer_phone']) ?></div>
            </td>
            <td style="font-weight:800;"><?= money($o['total']) ?></td>
            <td>
              <span style="text-transform:uppercase;font-size:11.5px;font-weight:700;color:rgba(255,255,255,0.7);">
                <?= e($o['payment_method']) ?>
              </span>
            </td>
            <td><span class="db-status-chip db-status-<?= e($o['order_status']) ?>"><?= str_replace('_', ' ', $o['order_status']) ?></span></td>
            <td style="font-size:11.5px;color:rgba(255,255,255,0.5);"><?= date('d M, H:i', strtotime($o['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- ═══════════ QUICK WIDGETS ═══════════ -->
  <div class="db-widgets">
    <a href="<?= url('admin/features/index.php') ?>" class="db-widget" style="text-decoration:none;color:inherit;">
      <div class="db-widget-icon" style="background:rgba(220,38,38,0.15);color:#dc2626;"><i class="fa-solid fa-toggle-on"></i></div>
      <div class="db-widget-info">
        <div class="db-widget-value"><?= $featuresOn ?>/<?= $featuresTotal ?></div>
        <div class="db-widget-label">Features Enabled</div>
      </div>
    </a>
    <a href="<?= url('admin/orders/index.php?status=pending') ?>" class="db-widget" style="text-decoration:none;color:inherit;">
      <div class="db-widget-icon" style="background:rgba(234,179,8,0.15);color:#fcd34d;"><i class="fa-solid fa-hourglass-half"></i></div>
      <div class="db-widget-info">
        <div class="db-widget-value"><?= $stats['pending'] ?></div>
        <div class="db-widget-label">Pending Orders</div>
      </div>
    </a>
    <a href="<?= url('admin/reviews/index.php?tab=pending') ?>" class="db-widget" style="text-decoration:none;color:inherit;">
      <div class="db-widget-icon" style="background:rgba(139,92,246,0.15);color:#c4b5fd;"><i class="fa-solid fa-star"></i></div>
      <div class="db-widget-info">
        <div class="db-widget-value"><?= $pendingReviews ?></div>
        <div class="db-widget-label">Pending Reviews</div>
      </div>
    </a>
    <a href="<?= url('admin/messages/index.php') ?>" class="db-widget" style="text-decoration:none;color:inherit;">
      <div class="db-widget-icon" style="background:rgba(59,130,246,0.15);color:#93c5fd;"><i class="fa-solid fa-envelope"></i></div>
      <div class="db-widget-info">
        <div class="db-widget-value"><?= $unreadMessages ?></div>
        <div class="db-widget-label">Unread Messages</div>
      </div>
    </a>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function() {
  var canvas = document.getElementById('revenueChart');
  if (!canvas || !window.Chart) return;

  var labels = <?= json_encode($chartData['labels']) ?>;
  var revenue = <?= json_encode($chartData['revenue']) ?>;
  var orders  = <?= json_encode($chartData['orders']) ?>;

  new Chart(canvas.getContext('2d'), {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Revenue (Rs.)',
          data: revenue,
          borderColor: '#dc2626',
          backgroundColor: function(ctx) {
            var g = ctx.chart.ctx.createLinearGradient(0, 0, 0, 260);
            g.addColorStop(0, 'rgba(220,38,38,0.35)');
            g.addColorStop(1, 'rgba(220,38,38,0.02)');
            return g;
          },
          fill: true,
          tension: 0.35,
          borderWidth: 2.5,
          pointRadius: 3,
          pointBackgroundColor: '#dc2626',
          pointBorderColor: '#fff',
          pointBorderWidth: 1.5,
          yAxisID: 'y',
        },
        {
          label: 'Orders',
          data: orders,
          borderColor: '#f59e0b',
          backgroundColor: 'transparent',
          borderWidth: 2,
          borderDash: [6, 4],
          tension: 0.35,
          pointRadius: 3,
          pointBackgroundColor: '#f59e0b',
          yAxisID: 'y1',
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      interaction: { intersect: false, mode: 'index' },
      plugins: {
        legend: {
          labels: { color: 'rgba(255,255,255,0.7)', font: { size: 12, weight: '600' } }
        },
        tooltip: {
          backgroundColor: '#0a0a0a',
          titleColor: '#fff',
          bodyColor: '#f9fafb',
          borderColor: 'rgba(220,38,38,0.4)',
          borderWidth: 1,
          padding: 12,
          callbacks: {
            label: function(ctx) {
              if (ctx.datasetIndex === 0) {
                return 'Revenue: Rs. ' + Math.round(ctx.parsed.y).toLocaleString('en-PK');
              }
              return 'Orders: ' + ctx.parsed.y;
            }
          }
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(255,255,255,0.04)', drawBorder: false },
          ticks: { color: 'rgba(255,255,255,0.5)', font: { size: 11 } }
        },
        y: {
          position: 'left',
          grid: { color: 'rgba(255,255,255,0.04)', drawBorder: false },
          ticks: {
            color: 'rgba(255,255,255,0.5)',
            font: { size: 11 },
            callback: function(v) { return 'Rs. ' + v.toLocaleString('en-PK'); }
          }
        },
        y1: {
          position: 'right',
          grid: { drawOnChartArea: false },
          ticks: { color: 'rgba(255,255,255,0.5)', font: { size: 11 } }
        }
      }
    }
  });
})();
</script>

<?php require __DIR__ . '/common/footer.php'; ?>