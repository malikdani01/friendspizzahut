<?php
require_once __DIR__ . '/../common/bootstrap.php';
require_admin();
$id = (int)($_GET['id'] ?? 0);
redirect(url('admin/kitchen/ticket.php?id=' . $id));