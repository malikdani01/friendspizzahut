<?php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('contact.php'));
verify_csrf();

$action = (string)post('action', 'new');
$user = customer_logged_in() ? current_customer() : null;

if ($action === 'new') {
    $r = message_create_thread([
        'user_id' => $user['id'] ?? null,
        'name'    => (string)post('name', ''),
        'phone'   => (string)post('phone', ''),
        'email'   => (string)post('email', ''),
        'subject' => (string)post('subject', ''),
        'message' => (string)post('message', ''),
    ]);
    if ($r['ok']) flash_success('Message sent!');
    else flash_error($r['error']);

} elseif ($action === 'reply') {
    if (!$user) { flash_error('Login required.'); redirect(url('login.php')); }
    $threadId = (int)post('thread_id', 0);
    $text     = (string)post('reply_text', '');

    $thread = Database::fetch("SELECT * FROM contact_messages WHERE id = ? AND user_id = ?", [$threadId, $user['id']]);
    if (!$thread) {
        flash_error('Thread not found.');
    } else {
        $r = message_add_reply($threadId, 'user', $text, (int)$user['id'], [
            'name' => $user['name'],
            'phone' => $user['phone'],
            'email' => $user['email'],
        ]);
        if ($r['ok']) flash_success('Reply sent.');
        else flash_error($r['error']);
    }
}

redirect(url('contact.php'));