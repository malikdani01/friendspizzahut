<?php
// advanced.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Advanced Settings';
if (is_post()) {
    verify_csrf();
    foreach (['timezone','currency','currency_symbol'] as $k) update_setting($k, (string)post($k,''));
    flash_success('Saved.');
    redirect(url('admin/settings/advanced.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <div><label class="text-xs text-gray-500">Timezone</label><input name="timezone" value="<?= e(setting('timezone','Asia/Karachi')) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Currency</label><input name="currency" value="<?= e(setting('currency','PKR')) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Currency Symbol</label><input name="currency_symbol" value="<?= e(setting('currency_symbol','Rs.')) ?>" class="w-full border rounded px-3 py-2"></div>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>