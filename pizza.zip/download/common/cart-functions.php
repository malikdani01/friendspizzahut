<?php
/** Cart — session-based for guests, DB-backed for logged users */

function cart_identifier(): string {
    if (customer_logged_in()) return 'user:' . (int)$_SESSION['user_id'];
    if (empty($_SESSION['guest_sid'])) {
        $_SESSION['guest_sid'] = bin2hex(random_bytes(16));
    }
    return 'guest:' . $_SESSION['guest_sid'];
}

function cart_query(): array {
    if (customer_logged_in()) {
        return ['user_id = ?', [(int)$_SESSION['user_id']]];
    }
    return ['session_id = ?', [$_SESSION['guest_sid'] ?? '']];
}

function get_cart_items(): array {
    [$where, $params] = cart_query();
    $items = Database::fetchAll(
        "SELECT ci.*, p.name, p.slug, p.image, p.price AS base_price, p.status AS pstatus
         FROM cart_items ci
         LEFT JOIN products p ON p.id = ci.product_id
         WHERE ci.$where
         ORDER BY ci.id DESC",
        $params
    );
    foreach ($items as &$it) {
        $it['options'] = Database::fetchAll(
            "SELECT * FROM cart_item_options WHERE cart_item_id = ? ORDER BY id", [$it['id']]
        );
        $it['addons'] = Database::fetchAll(
            "SELECT * FROM cart_item_addons WHERE cart_item_id = ? ORDER BY id", [$it['id']]
        );
        $it['line_total'] = calculate_cart_item_total($it);
    }
    return $items;
}

function get_cart_count(): int {
    [$where, $params] = cart_query();
    $r = Database::fetch("SELECT COALESCE(SUM(quantity),0) c FROM cart_items WHERE $where", $params);
    return (int)($r['c'] ?? 0);
}

function add_to_cart(int $productId, int $qty, array $variationOptionIds = [], array $addonIds = [], string $notes = ''): array {
    $product = get_product($productId);
    if (!$product) return ['ok' => false, 'error' => 'Product not found.'];
    if ($product['status'] !== 'active' || (int)$product['is_available'] !== 1) {
        return ['ok' => false, 'error' => 'Product is not available.'];
    }
    if ($qty < 1 || $qty > 50) return ['ok' => false, 'error' => 'Invalid quantity.'];

    Database::beginTransaction();
    try {
        $unitPrice = calculate_base_variation_price($product, $variationOptionIds);

        if (customer_logged_in()) {
            $cartItemId = Database::insert('cart_items', [
                'user_id' => (int)$_SESSION['user_id'],
                'session_id' => null,
                'product_id' => $productId,
                'quantity' => $qty,
                'special_instructions' => mb_substr($notes, 0, 500),
                'unit_price_snapshot' => $unitPrice,
            ]);
        } else {
            if (empty($_SESSION['guest_sid'])) $_SESSION['guest_sid'] = bin2hex(random_bytes(16));
            $cartItemId = Database::insert('cart_items', [
                'user_id' => null,
                'session_id' => $_SESSION['guest_sid'],
                'product_id' => $productId,
                'quantity' => $qty,
                'special_instructions' => mb_substr($notes, 0, 500),
                'unit_price_snapshot' => $unitPrice,
            ]);
        }

        // Save selected variation options
        foreach ($variationOptionIds as $optId) {
            $opt = Database::fetch(
                "SELECT o.*, g.display_name AS gname FROM variation_options o
                 JOIN variation_groups g ON g.id = o.group_id WHERE o.id = ?", [(int)$optId]);
            if ($opt) {
                Database::insert('cart_item_options', [
                    'cart_item_id' => $cartItemId,
                    'variation_group_id' => (int)$opt['group_id'],
                    'variation_option_id' => (int)$opt['id'],
                    'option_name' => $opt['gname'] . ': ' . $opt['name'],
                    'option_price_delta' => (float)($opt['absolute_price'] ?? $opt['price_delta'] ?? 0),
                ]);
            }
        }

        // Save addons with sizes.
        // $addonIds can be [1, 2, 3] or an array of ['id' => 1, 'size' => 'M'] entries.
        $addonSizes = $_POST['addon_sizes'] ?? [];
        foreach ($addonIds as $i => $addonEntry) {
            // Support both legacy scalar IDs and structured addon entries.
            $aid = is_array($addonEntry) ? ($addonEntry['id'] ?? 0) : $addonEntry;
            $a = Database::fetch("SELECT * FROM addons WHERE id = ? AND is_active = 1", [(int)$aid]);
            if (!$a) continue;

            // Determine size, preferring a size supplied directly with the addon entry.
            $size = null;
            $price = (float)$a['price'];
            $hasSz = (int)($a['has_sizes'] ?? 0) === 1;

            if ($hasSz) {
                $requestedSize = is_array($addonEntry) ? ($addonEntry['size'] ?? null) : null;
                $size = strtoupper((string)($requestedSize ?? $addonSizes[$aid] ?? $addonSizes[$i] ?? 'S'));
                if (!in_array($size, ['S', 'M', 'L'], true)) $size = 'S';
                $price = match ($size) {
                    'S' => (float)($a['price_s'] ?? $a['price']),
                    'M' => (float)($a['price_m'] ?? $a['price']),
                    'L' => (float)($a['price_l'] ?? $a['price']),
                    default => (float)($a['price_s'] ?? $a['price']),
                };
            }

            Database::insert('cart_item_addons', [
                'cart_item_id' => $cartItemId,
                'addon_id' => (int)$a['id'],
                'addon_name' => $a['name'],
                'addon_size' => $size,
                'addon_price' => $price,
            ]);
        }

        Database::commit();
        return ['ok' => true, 'cart_item_id' => $cartItemId];
    } catch (Throwable $e) {
        Database::rollback();
        error_log('add_to_cart: ' . $e->getMessage());
        return ['ok' => false, 'error' => 'Could not add to cart.'];
    }
}

function update_cart_quantity(int $cartItemId, int $qty): bool {
    [$where, $params] = cart_query();
    if ($qty < 1) return false;
    if ($qty > 50) $qty = 50;
    $params = array_merge([$qty, $cartItemId], $params);
    return Database::execute("UPDATE cart_items SET quantity = ? WHERE id = ? AND $where", $params) > 0;
}

function remove_cart_item(int $cartItemId): bool {
    [$where, $params] = cart_query();
    $params = array_merge([$cartItemId], $params);
    Database::execute("DELETE FROM cart_item_options WHERE cart_item_id = ?", [$cartItemId]);
    Database::execute("DELETE FROM cart_item_addons WHERE cart_item_id = ?", [$cartItemId]);
    return Database::execute("DELETE FROM cart_items WHERE id = ? AND $where", $params) > 0;
}

function clear_cart(): void {
    [$where, $params] = cart_query();
    $ids = Database::fetchAll("SELECT id FROM cart_items WHERE $where", $params);
    foreach ($ids as $r) {
        Database::execute("DELETE FROM cart_item_options WHERE cart_item_id = ?", [$r['id']]);
        Database::execute("DELETE FROM cart_item_addons WHERE cart_item_id = ?", [$r['id']]);
    }
    Database::execute("DELETE FROM cart_items WHERE $where", $params);
}

function merge_guest_cart_after_login(int $userId): void {
    $sid = $_SESSION['guest_sid'] ?? '';
    if (!$sid) return;
    Database::execute(
        "UPDATE cart_items SET user_id = ?, session_id = NULL WHERE session_id = ? AND user_id IS NULL",
        [$userId, $sid]
    );
    unset($_SESSION['guest_sid']);
}

function calculate_cart_item_total(array $item): float {
    $base = (float)$item['unit_price_snapshot'];
    $addonsTotal = 0;
    foreach ($item['addons'] ?? [] as $a) $addonsTotal += (float)$a['addon_price'];
    return ($base + $addonsTotal) * (int)$item['quantity'];
}