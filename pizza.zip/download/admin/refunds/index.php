<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('refunds')) { flash_error('Refunds module disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'Refunds';

if (is_post()) {
    verify_csrf();
    $action = post('action');
    $id = (int)post('id');
    if ($action === 'approve') {
        Database::execute("UPDATE refunds SET status='approved', approved_by=? WHERE id=?", [$_SESSION['admin_id'], $id]);
        flash_success('Approved.');
    } elseif ($action === 'process') {
        Database::execute("UPDATE refunds SET status='refunded' WHERE id=?", [$id]);
        $r = Database::fetch("SELECT order_id FROM refunds WHERE id=?", [$id]);
        if ($r) Database::execute("UPDATE orders SET payment_status='refunded' WHERE id=?", [(int)$r['order_id']]);
        flash_success('Refund processed.');
    } elseif ($action === 'reject') {
        Database::execute("UPDATE refunds SET status='rejected' WHERE id=?", [$id]);
        flash_success('Rejected.');
    }
    redirect(url('admin/refunds/index.php'));
}

$rows = Database::fetchAll("SELECT r.*, o.order_number, o.customer_name FROM refunds r LEFT JOIN orders o ON o.id=r.order_id ORDER BY r.id DESC LIMIT 100");
require __DIR__ . '/../common/header.php';
?>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr><th class="text-left px-4 py-3">Order</th><th class="text-left px-4 py-3">Customer</th><th class="text-left px-4 py-3">Amount</th><th class="text-left px-4 py-3">Reason</th><th class="text-left px-4 py-3">Status</th><th class="text-right">Action</th></tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr class="border-t">
        <td class="px-4 py-3 font-mono text-xs"><?= e($r['order_number']) ?></td>
        <td class="px-4 py-3"><?= e($r['customer_name']) ?></td>
        <td class="px-4 py-3 font-semibold"><?= money($r['amount']) ?></td>
        <td class="px-4 py-3 text-xs"><?= e($r['reason']) ?></td>
        <td class="px-4 py-3"><?= status_badge($r['status']) ?></td>
        <td class="px-4 py-3 text-right space-x-1">
          <?php if ($r['status']==='requested'): ?>
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="approve"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="text-xs bg-green-600 text-white px-2 py-1 rounded">Approve</button></form>
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="reject"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="text-xs bg-red-600 text-white px-2 py-1 rounded">Reject</button></form>
          <?php elseif ($r['status']==='approved'): ?>
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="process"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="text-xs bg-blue-600 text-white px-2 py-1 rounded">Mark Refunded</button></form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="6" class="py-8 text-center text-gray-400">No refunds yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>