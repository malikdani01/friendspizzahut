<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

$configFile = __DIR__ . '/common/config.php';
if (!file_exists($configFile)) die('Config not found.');
require_once $configFile;

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('DB failed: ' . $e->getMessage());
}

// ═══════════════════════════════════════════════════════════════
// ADD COLUMNS
// ═══════════════════════════════════════════════════════════════
$migrations = [
    // ═══ BANNERS: Video + extra fields ═══
    ['banners', 'video_url',      "VARCHAR(500) NULL"],
    ['banners', 'media_type',     "VARCHAR(20) NOT NULL DEFAULT 'image'"],
    ['banners', 'overlay_opacity',"INT NOT NULL DEFAULT 50"],
    ['banners', 'text_align',     "VARCHAR(20) NOT NULL DEFAULT 'left'"],

    // ═══ PRODUCTS: Advanced columns ═══
    ['products', 'has_sizes',            "TINYINT(1) NOT NULL DEFAULT 0"],
    ['products', 'price_s',              "DECIMAL(12,2) NULL"],
    ['products', 'price_m',              "DECIMAL(12,2) NULL"],
    ['products', 'price_l',              "DECIMAL(12,2) NULL"],
    ['products', 'size_labels',          "VARCHAR(60) NOT NULL DEFAULT 'Small,Medium,Large'"],
    ['products', 'button_mode',          "VARCHAR(30) NOT NULL DEFAULT 'add_to_cart'"],
    ['products', 'order_button_text',    "VARCHAR(60) NULL DEFAULT 'Add to Cart'"],
    ['products', 'order_button_enabled', "TINYINT(1) NOT NULL DEFAULT 1"],
    ['products', 'button_bg_color',      "VARCHAR(20) NULL"],
    ['products', 'button_text_color',    "VARCHAR(20) NULL"],
    ['products', 'prep_time_minutes',    "INT NULL DEFAULT 15"],
    ['products', 'is_recommended',       "TINYINT(1) NOT NULL DEFAULT 0"],
    ['products', 'is_limited_deal',      "TINYINT(1) NOT NULL DEFAULT 0"],
    ['products', 'is_coming_soon',       "TINYINT(1) NOT NULL DEFAULT 0"],

    // ═══ ADDONS ═══
    ['addons', 'price',        "DECIMAL(12,2) NOT NULL DEFAULT 0"],
    ['addons', 'has_sizes',    "TINYINT(1) NOT NULL DEFAULT 0"],
    ['addons', 'price_s',      "DECIMAL(12,2) NULL"],
    ['addons', 'price_m',      "DECIMAL(12,2) NULL"],
    ['addons', 'price_l',      "DECIMAL(12,2) NULL"],

    // ═══ CART / ORDER ITEM ADDONS ═══
    ['cart_item_addons', 'addon_size',    "VARCHAR(10) NULL"],
    ['order_item_addons', 'addon_size',   "VARCHAR(10) NULL"],

    // ═══ ORDERS ═══
    ['orders', 'transaction_id',    "VARCHAR(120) NULL"],
    ['orders', 'estimated_minutes', "INT NULL"],
    ['orders', 'eta_started_at',    "DATETIME NULL"],
];

$log = [];
$stats = ['added' => 0, 'skipped' => 0, 'errors' => 0];

foreach ($migrations as $m) {
    [$table, $column, $def] = $m;
    
    // Check table
    try {
        $t = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
        if ($t->rowCount() === 0) {
            $log[] = ['error', $table, $column, 'Table missing'];
            $stats['errors']++;
            continue;
        }
    } catch (Throwable $e) {
        $log[] = ['error', $table, $column, 'Check failed'];
        $stats['errors']++;
        continue;
    }

    // Check column
    try {
        $c = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $c->execute([$column]);
        if ($c->rowCount() > 0) {
            $log[] = ['skip', $table, $column, 'Already exists'];
            $stats['skipped']++;
            continue;
        }
    } catch (Throwable $e) {}

    // Add column
    try {
        $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` $def");
        $log[] = ['added', $table, $column, 'Added'];
        $stats['added']++;
    } catch (Throwable $e) {
        $log[] = ['error', $table, $column, $e->getMessage()];
        $stats['errors']++;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Migration</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@600;700;800;900&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0a0a0a;color:#fff;font-family:'Inter',sans-serif;padding:40px 20px;line-height:1.5}
.wrap{max-width:800px;margin:0 auto}
h1{font-size:24px;font-weight:900;margin-bottom:8px;text-align:center}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:24px 0}
.stat{background:#171717;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:16px;text-align:center}
.num{font-size:26px;font-weight:900}
.num.g{color:#4ade80}.num.y{color:#facc15}.num.r{color:#f87171}
.lbl{font-size:11px;color:rgba(255,255,255,.5);font-weight:700;text-transform:uppercase;margin-top:4px}
.list{background:#171717;border:1px solid rgba(255,255,255,.08);border-radius:12px;overflow:hidden;max-height:500px;overflow-y:auto;margin-bottom:24px}
.item{display:flex;gap:12px;padding:10px 16px;border-bottom:1px solid rgba(255,255,255,.04);font-size:13px;align-items:center}
.item:last-child{border-bottom:0}
.item i{width:16px;flex-shrink:0}
.item.added i{color:#4ade80}.item.skip i{color:#facc15}.item.error i{color:#f87171}
.tbl{background:rgba(220,38,38,.15);color:#fca5a5;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:700;font-family:monospace}
.col{color:#fff;font-weight:600;flex:1}
.msg{font-size:11px;color:rgba(255,255,255,.4)}
.btn{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;background:linear-gradient(135deg,#dc2626,#b91c1c);color:#fff;border-radius:10px;font-weight:800;text-decoration:none;font-size:14px;box-shadow:0 8px 24px rgba(220,38,38,.4)}
.btn:hover{transform:translateY(-1px)}
.warn{background:rgba(234,179,8,.12);border:1.5px solid rgba(234,179,8,.4);color:#fcd34d;padding:14px;border-radius:10px;font-size:13px;line-height:1.6;margin-top:20px}
</style>
</head>
<body>
<div class="wrap">
    <h1>✅ Migration Complete</h1>
    <div class="stats">
        <div class="stat"><div class="num g"><?= $stats['added'] ?></div><div class="lbl">Added</div></div>
        <div class="stat"><div class="num y"><?= $stats['skipped'] ?></div><div class="lbl">Skipped</div></div>
        <div class="stat"><div class="num r"><?= $stats['errors'] ?></div><div class="lbl">Errors</div></div>
    </div>
    <div class="list">
        <?php foreach ($log as $r): 
            [$s, $t, $c, $m] = $r;
            $ic = match($s){'added'=>'fa-circle-check','skip'=>'fa-circle-minus','error'=>'fa-circle-xmark'};
        ?>
            <div class="item <?= $s ?>">
                <i class="fa-solid <?= $ic ?>"></i>
                <span class="tbl"><?= htmlspecialchars($t) ?></span>
                <span class="col"><?= htmlspecialchars($c) ?></span>
                <span class="msg"><?= htmlspecialchars($m) ?></span>
            </div>
        <?php endforeach; ?>
    </div>
    <a href="admin/banners/index.php" class="btn"><i class="fa-solid fa-arrow-right"></i> Go to Banners</a>
    <div class="warn">
        <strong>⚠️ Ye file DELETE kar do</strong> — security ke liye.
    </div>
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</body>
</html>