<?php
/**
 * Peak hours heatmap data
 * Feature-gated: peak_hours_heatmap
 */

function get_heatmap_data(string $from, string $to): array {
    // Get orders grouped by day-of-week (1=Mon, 7=Sun) and hour
    $rows = Database::fetchAll(
        "SELECT DAYOFWEEK(created_at) dow, HOUR(created_at) h,
                COUNT(*) c, COALESCE(SUM(total), 0) amt
         FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?
         AND order_status NOT IN ('cancelled','refunded')
         GROUP BY dow, h",
        [$from, $to]
    );

    // Build matrix: [day][hour] = { count, amount }
    $matrix = [];
    for ($d = 1; $d <= 7; $d++) {
        for ($h = 0; $h < 24; $h++) {
            $matrix[$d][$h] = ['count' => 0, 'amount' => 0.0];
        }
    }

    $maxCount = 0;
    foreach ($rows as $r) {
        $d = (int)$r['dow'];
        $h = (int)$r['h'];
        // MySQL: 1=Sunday, 2=Monday...7=Saturday
        // Convert to Monday=1..Sunday=7
        $dayMap = [1 => 7, 2 => 1, 3 => 2, 4 => 3, 5 => 4, 6 => 5, 7 => 6];
        $day = $dayMap[$d] ?? $d;
        $matrix[$day][$h] = [
            'count' => (int)$r['c'],
            'amount' => (float)$r['amt'],
        ];
        if ((int)$r['c'] > $maxCount) $maxCount = (int)$r['c'];
    }

    // Peak hour stats
    $peakDay = 1; $peakHour = 0; $peakCount = 0;
    for ($d = 1; $d <= 7; $d++) {
        for ($h = 0; $h < 24; $h++) {
            if ($matrix[$d][$h]['count'] > $peakCount) {
                $peakCount = $matrix[$d][$h]['count'];
                $peakDay = $d;
                $peakHour = $h;
            }
        }
    }

    // Hourly totals (across all days)
    $hourlyTotals = array_fill(0, 24, 0);
    foreach ($matrix as $d => $hours) {
        foreach ($hours as $h => $info) {
            $hourlyTotals[$h] += $info['count'];
        }
    }

    // Day totals
    $dayTotals = array_fill(1, 7, 0);
    foreach ($matrix as $d => $hours) {
        foreach ($hours as $info) {
            $dayTotals[$d] += $info['count'];
        }
    }

    return [
        'from' => $from,
        'to' => $to,
        'matrix' => $matrix,
        'max_count' => $maxCount,
        'peak_day' => $peakDay,
        'peak_hour' => $peakHour,
        'peak_count' => $peakCount,
        'hourly_totals' => $hourlyTotals,
        'day_totals' => $dayTotals,
    ];
}

function heatmap_day_name(int $d): string {
    return ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][$d] ?? '';
}

function heatmap_day_short(int $d): string {
    return ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][$d] ?? '';
}