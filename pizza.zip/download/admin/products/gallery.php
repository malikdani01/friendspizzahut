<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('product_gallery')) {
    flash_error('Product gallery disabled.');
    redirect(url('admin/dashboard.php'));
}

$productId = (int)get('product_id', 0);
$product = get_product($productId);
if (!$product) { flash_error('Product not found.'); redirect(url('admin/products/index.php')); }

$pageTitle = 'Gallery: ' . $product['name'];

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'upload' && !empty($_FILES['images']['name'][0])) {
        $count = 0;
        foreach ($_FILES['images']['tmp_name'] as $i => $tmp) {
            if (empty($_FILES['images']['name'][$i])) continue;
            $file = [
                'name' => $_FILES['images']['name'][$i],
                'tmp_name' => $tmp,
                'size' => $_FILES['images']['size'][$i],
                'error' => $_FILES['images']['error'][$i],
            ];
            $r = save_uploaded_image($file, 'products/gallery');
            if ($r['ok']) {
                Database::insert('product_images', [
                    'product_id' => $productId,
                    'image' => $r['path'],
                    'sort_order' => $count++,
                ]);
            }
        }
        flash_success("$count image(s) uploaded.");
    } elseif ($action === 'delete') {
        $imgId = (int)post('image_id', 0);
        $img = Database::fetch("SELECT image FROM product_images WHERE id = ? AND product_id = ?", [$imgId, $productId]);
        if ($img) {
            $full = UPLOAD_PATH . '/' . $img['image'];
            if (file_exists($full)) @unlink($full);
            Database::execute("DELETE FROM product_images WHERE id = ?", [$imgId]);
            flash_success('Image deleted.');
        }
    }
    redirect(url('admin/products/gallery.php?product_id=' . $productId));
}

$images = get_product_images($productId);
require __DIR__ . '/../common/header.php';
?>

<a href="<?= url('admin/products/edit.php?id=' . $productId) ?>" class="text-sm text-gray-500 hover:text-brand mb-4 inline-block">← Back to product</a>

<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl border p-5 h-fit">
    <h3 class="font-bold mb-3">Upload Images</h3>
    <form method="post" enctype="multipart/form-data" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="upload">
      <input type="file" name="images[]" multiple accept="image/*" required class="w-full border rounded px-3 py-2 text-sm">
      <div class="text-xs text-gray-500">Ek saath multiple images select kar sakte ho. Max 5MB each.</div>
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Upload</button>
    </form>
  </div>

  <div class="md:col-span-2 bg-white rounded-xl border p-5">
    <h3 class="font-bold mb-3">Gallery (<?= count($images) ?>)</h3>
    <?php if (!$images): ?>
      <div class="text-center py-10 text-gray-400">No images yet.</div>
    <?php else: ?>
      <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
        <?php foreach ($images as $img): ?>
          <div class="relative group">
            <img src="<?= upload_url($img['image']) ?>" class="w-full aspect-square object-cover rounded-lg border">
            <form method="post" class="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition" data-confirm="Delete this image?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="image_id" value="<?= (int)$img['id'] ?>">
              <button class="bg-red-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-xs">
                <i class="fa-solid fa-trash"></i>
              </button>
            </form>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>