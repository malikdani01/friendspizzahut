<?php
function gift_card_validate(string $code): array {
    $code = strtoupper(trim($code));
    if (!$code) return ['ok' => false, 'error' => 'Code required.'];
    $c = Database::fetch("SELECT * FROM gift_cards WHERE code=? AND is_active=1", [$code]);
    if (!$c) return ['ok' => false, 'error' => 'Invalid gift card.'];
    if ((float)$c['current_balance'] <= 0) return ['ok' => false, 'error' => 'No balance remaining.'];
    if ($c['expires_at'] && $c['expires_at'] < date('Y-m-d H:i:s')) return ['ok' => false, 'error' => 'Gift card expired.'];
    return ['ok' => true, 'card' => $c];
}
function gift_card_redeem(int $cardId, int $orderId, float $amount): void {
    Database::execute("UPDATE gift_cards SET current_balance = current_balance - ? WHERE id=?", [$amount, $cardId]);
    Database::insert('gift_card_transactions', ['gift_card_id'=>$cardId,'order_id'=>$orderId,'amount'=>$amount,'type'=>'redeem']);
}