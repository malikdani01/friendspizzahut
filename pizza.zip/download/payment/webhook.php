<?php
/**
 * Universal Webhook Handler
 * Payment gateways server-to-server notifications yahan bhejenge.
 * Ye handler actual payment verify karta hai (frontend return pe depend nahi karta).
 */
require_once __DIR__ . '/../common/bootstrap.php';

// Only accept POST for webhooks
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Read raw body
$rawBody = file_get_contents('php://input');
$data = $_POST ?: json_decode($rawBody, true) ?: [];

// Detect gateway from payload signature
$gateway = 'unknown';
if (isset($data['pp_SecureHash']) || isset($data['pp_TxnRefNo'])) {
    $gateway = 'jazzcash';
} elseif (isset($data['merchantHashedReq']) || isset($data['orderRefNum'])) {
    $gateway = 'easypaisa';
} elseif (isset($data['gateway'])) {
    $gateway = (string)$data['gateway'];
}

// Log every webhook call
try {
    Database::insert('audit_logs', [
        'user_type'  => 'system',
        'action'     => 'webhook.received',
        'entity'     => 'payment',
        'new_data'   => json_encode([
            'gateway'  => $gateway,
            'payload'  => $data,
            'raw'      => mb_substr($rawBody, 0, 2000),
        ]),
        'ip_address' => client_ip(),
        'user_agent' => mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250),
    ]);
} catch (Throwable $e) {
    error_log('webhook log failed: ' . $e->getMessage());
}

// Route to gateway-specific webhook logic
try {
    switch ($gateway) {
        case 'jazzcash':
            handle_jazzcash_webhook($data);
            break;

        case 'easypaisa':
            handle_easypaisa_webhook($data);
            break;

        default:
            // Unknown gateway — log and accept (return 200 to prevent retries)
            http_response_code(200);
            echo json_encode(['status' => 'ignored', 'reason' => 'unknown gateway']);
            exit;
    }

    http_response_code(200);
    echo json_encode(['status' => 'ok']);
    exit;

} catch (Throwable $e) {
    error_log('webhook processing failed: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Processing failed']);
    exit;
}

/**
 * ─────────────────────────────────────────────────────────────
 * Gateway Handlers
 * ─────────────────────────────────────────────────────────────
 */

function handle_jazzcash_webhook(array $data): void {
    $orderNumber = (string)($data['pp_BillReference'] ?? '');
    if (!$orderNumber) {
        throw new Exception('Missing pp_BillReference');
    }

    $order = get_order_by_number($orderNumber);
    if (!$order) {
        throw new Exception('Order not found: ' . $orderNumber);
    }

    // Verify hash
    if (!jazzcash_verify_response($data)) {
        jazzcash_log('webhook_hash_mismatch', ['order' => $orderNumber]);
        throw new Exception('Hash verification failed');
    }

    $responseCode = (string)($data['pp_ResponseCode'] ?? '');
    $txnRefNo     = (string)($data['pp_TxnRefNo'] ?? '');
    $amountPaid   = ((int)($data['pp_Amount'] ?? 0)) / 100;

    if (!jazzcash_response_success($responseCode)) {
        // Failed payment — mark
        $payment = Database::fetch("SELECT id FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1", [(int)$order['id']]);
        if ($payment) {
            mark_payment_failed((int)$payment['id'], "Webhook: JazzCash $responseCode");
        }
        jazzcash_log('webhook_payment_failed', [
            'order' => $orderNumber, 'code' => $responseCode,
        ]);
        return;
    }

    // Success — idempotent update
    if ($order['payment_status'] === 'paid') {
        jazzcash_log('webhook_already_paid', ['order' => $orderNumber]);
        return;
    }

    Database::beginTransaction();
    try {
        $payment = Database::fetch("SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1", [(int)$order['id']]);
        if (!$payment) {
            $paymentId = create_payment((int)$order['id'], 'jazzcash', (float)$order['total']);
        } else {
            $paymentId = (int)$payment['id'];
            Database::execute("UPDATE payments SET method = 'jazzcash' WHERE id = ?", [$paymentId]);
        }

        mark_payment_paid($paymentId, null, $txnRefNo);

        Database::insert('payment_transactions', [
            'payment_id'   => $paymentId,
            'gateway'      => 'jazzcash',
            'reference'    => $txnRefNo,
            'amount'       => $amountPaid,
            'status'       => 'success',
            'raw_response' => json_encode($data),
        ]);

        if ($order['order_status'] === 'pending') {
            update_order_status((int)$order['id'], 'confirmed', null, null, 'Auto-confirmed via JazzCash webhook');
        }

        Database::insert('notifications', [
            'user_type' => 'admin', 'user_id' => 1,
            'type'      => 'payment_received',
            'title'     => 'JazzCash Payment (Webhook)',
            'message'   => "Order {$orderNumber} — Rs. " . number_format($amountPaid, 0) . " paid via JazzCash.",
            'link'      => '/admin/orders/view.php?id=' . (int)$order['id'],
        ]);

        Database::commit();
        jazzcash_log('webhook_payment_success', [
            'order' => $orderNumber, 'txn' => $txnRefNo, 'amount' => $amountPaid,
        ]);
    } catch (Throwable $e) {
        Database::rollback();
        throw $e;
    }
}

function handle_easypaisa_webhook(array $data): void {
    $orderNumber = (string)($data['orderRefNum'] ?? '');
    if (!$orderNumber) {
        throw new Exception('Missing orderRefNum');
    }

    $order = get_order_by_number($orderNumber);
    if (!$order) {
        throw new Exception('Order not found: ' . $orderNumber);
    }

    if (!easypaisa_verify_response($data)) {
        easypaisa_log('webhook_hash_mismatch', ['order' => $orderNumber]);
        throw new Exception('Hash verification failed');
    }

    $responseCode = (string)($data['responseCode'] ?? '');
    $txnRefNo     = (string)($data['transactionId'] ?? $orderNumber);
    $amountPaid   = (float)($data['amount'] ?? 0);

    if (!easypaisa_response_success($responseCode)) {
        $payment = Database::fetch("SELECT id FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1", [(int)$order['id']]);
        if ($payment) {
            mark_payment_failed((int)$payment['id'], "Webhook: Easypaisa $responseCode");
        }
        easypaisa_log('webhook_payment_failed', [
            'order' => $orderNumber, 'code' => $responseCode,
        ]);
        return;
    }

    if ($order['payment_status'] === 'paid') {
        easypaisa_log('webhook_already_paid', ['order' => $orderNumber]);
        return;
    }

    Database::beginTransaction();
    try {
        $payment = Database::fetch("SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1", [(int)$order['id']]);
        if (!$payment) {
            $paymentId = create_payment((int)$order['id'], 'easypaisa', (float)$order['total']);
        } else {
            $paymentId = (int)$payment['id'];
            Database::execute("UPDATE payments SET method = 'easypaisa' WHERE id = ?", [$paymentId]);
        }

        mark_payment_paid($paymentId, null, $txnRefNo);

        Database::insert('payment_transactions', [
            'payment_id'   => $paymentId,
            'gateway'      => 'easypaisa',
            'reference'    => $txnRefNo,
            'amount'       => $amountPaid,
            'status'       => 'success',
            'raw_response' => json_encode($data),
        ]);

        if ($order['order_status'] === 'pending') {
            update_order_status((int)$order['id'], 'confirmed', null, null, 'Auto-confirmed via Easypaisa webhook');
        }

        Database::insert('notifications', [
            'user_type' => 'admin', 'user_id' => 1,
            'type'      => 'payment_received',
            'title'     => 'Easypaisa Payment (Webhook)',
            'message'   => "Order {$orderNumber} — Rs. " . number_format($amountPaid, 0) . " paid via Easypaisa.",
            'link'      => '/admin/orders/view.php?id=' . (int)$order['id'],
        ]);

        Database::commit();
        easypaisa_log('webhook_payment_success', [
            'order' => $orderNumber, 'txn' => $txnRefNo, 'amount' => $amountPaid,
        ]);
    } catch (Throwable $e) {
        Database::rollback();
        throw $e;
    }
}