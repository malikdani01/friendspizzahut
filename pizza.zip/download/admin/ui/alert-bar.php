<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Alert Bar (Scrolling)';

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'settings') {
        update_setting('alert_bar_enabled', isset($_POST['alert_bar_enabled']) ? '1' : '0');
        update_setting('alert_bar_speed', (string)(int)post('alert_bar_speed', 30));
        update_setting('alert_bar_bg', (string)post('alert_bar_bg', '#0a0a0a'));
        update_setting('alert_bar_text', (string)post('alert_bar_text', '#ffffff'));
        flash_success('Settings saved.');
    } elseif ($action === 'create') {
        $text = trim((string)post('text', ''));
        if (strlen($text) >= 3) {
            Database::insert('alert_bar_items', [
                'text' => $text,
                'icon' => trim((string)post('icon', '')) ?: null,
                'link_url' => trim((string)post('link_url', '')) ?: null,
                'link_text' => trim((string)post('link_text', '')) ?: null,
                'sort_order' => (int)post('sort_order', 0),
                'is_active' => 1,
            ]);
            flash_success('Item added.');
        }
    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM alert_bar_items WHERE id = ?", [(int)post('id')]);
        flash_success('Deleted.');
    } elseif ($action === 'toggle') {
        Database::execute("UPDATE alert_bar_items SET is_active = 1 - is_active WHERE id = ?", [(int)post('id')]);
        flash_success('Updated.');
    }

    redirect(url('admin/ui/alert-bar.php'));
}

$items = Database::fetchAll("SELECT * FROM alert_bar_items ORDER BY sort_order, id");
require __DIR__ . '/../common/header.php';
?>

<div class="space-y-5">

  <!-- Settings -->
  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-4">Settings</h3>
    <form method="post" class="grid md:grid-cols-2 gap-4">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="settings">

      <label class="flex items-center gap-2 md:col-span-2">
        <input type="checkbox" name="alert_bar_enabled" value="1" <?= setting('alert_bar_enabled') === '1' ? 'checked' : '' ?> class="w-4 h-4">
        <span class="font-semibold">Enable alert bar</span>
      </label>

      <div>
        <label class="block text-sm font-semibold mb-1">Scroll Speed (seconds)</label>
        <input type="number" name="alert_bar_speed" value="<?= e(setting('alert_bar_speed','30')) ?>" min="10" max="120" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Background</label>
        <input type="color" name="alert_bar_bg" value="<?= e(setting('alert_bar_bg','#0a0a0a')) ?>" class="w-full border rounded px-3 py-1 h-10">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Text Color</label>
        <input type="color" name="alert_bar_text" value="<?= e(setting('alert_bar_text','#ffffff')) ?>" class="w-full border rounded px-3 py-1 h-10">
      </div>

      <button class="md:col-span-2 bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save Settings</button>
    </form>
  </div>

  <!-- Add Item -->
  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-4">Add Message</h3>
    <form method="post" class="grid md:grid-cols-2 gap-4">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">

      <div class="md:col-span-2">
        <label class="block text-sm font-semibold mb-1">Message Text *</label>
        <input name="text" required maxlength="500" placeholder="Free delivery on orders above Rs. 1500" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Icon (FontAwesome)</label>
        <input name="icon" value="fa-bullhorn" placeholder="fa-bullhorn" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Sort Order</label>
        <input type="number" name="sort_order" value="0" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Link URL (optional)</label>
        <input name="link_url" placeholder="/menu.php" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Link Button Text</label>
        <input name="link_text" placeholder="Order Now" class="w-full border rounded px-3 py-2">
      </div>

      <button class="md:col-span-2 bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Add Message</button>
    </form>
  </div>

  <!-- Items List -->
  <div class="bg-white rounded-xl border overflow-hidden">
    <div class="px-5 py-4 border-b font-bold">Messages (<?= count($items) ?>)</div>
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
        <tr>
          <th class="text-left px-4 py-3">Message</th>
          <th class="text-left px-4 py-3">Order</th>
          <th class="text-left px-4 py-3">Status</th>
          <th class="text-right px-4 py-3">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $it): ?>
        <tr class="border-t">
          <td class="px-4 py-3">
            <i class="fa-solid <?= e($it['icon'] ?: 'fa-bullhorn') ?> text-brand mr-2"></i>
            <?= e($it['text']) ?>
          </td>
          <td class="px-4 py-3"><?= (int)$it['sort_order'] ?></td>
          <td class="px-4 py-3">
            <form method="post" class="inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
              <button class="text-xs px-2 py-1 rounded <?= $it['is_active'] ? 'bg-green-100 text-green-800' : 'bg-gray-200' ?>">
                <?= $it['is_active'] ? 'Active' : 'Inactive' ?>
              </button>
            </form>
          </td>
          <td class="px-4 py-3 text-right">
            <form method="post" class="inline" data-confirm="Delete?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
              <button class="text-red-600 text-xs">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$items): ?><tr><td colspan="4" class="py-8 text-center text-gray-400">No messages yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>