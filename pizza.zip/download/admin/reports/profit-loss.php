<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('profit_loss_report')) {
    flash_error('P&L feature disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Profit & Loss';

$from = (string)get('from', date('Y-m-01'));
$to = (string)get('to', date('Y-m-d'));
$data = get_pl_data($from, $to);
$autoPrint = get('print') === '1';

require __DIR__ . '/../common/header.php';
?>

<form class="flex flex-wrap gap-2 mb-5">
  <input type="date" name="from" value="<?= e($from) ?>" class="border rounded px-3 py-2 text-sm">
  <input type="date" name="to" value="<?= e($to) ?>" class="border rounded px-3 py-2 text-sm">
  <button class="bg-gray-800 text-white px-4 py-2 rounded text-sm">Apply</button>
  <a href="?from=<?= e($from) ?>&to=<?= e($to) ?>&print=1" target="_blank" class="bg-brand text-white px-4 py-2 rounded text-sm font-semibold">
    <i class="fa-solid fa-print mr-1"></i> Print
  </a>
</form>

<div class="grid md:grid-cols-4 gap-4 mb-6">
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Gross Revenue</div>
    <div class="text-2xl font-extrabold text-brand"><?= money($data['gross_revenue']) ?></div>
  </div>
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">COGS</div>
    <div class="text-2xl font-extrabold text-red-600"><?= money($data['cogs']) ?></div>
  </div>
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Net Profit</div>
    <div class="text-2xl font-extrabold <?= $data['net_profit'] >= 0 ? 'text-green-600' : 'text-red-600' ?>">
      <?= money($data['net_profit']) ?>
    </div>
  </div>
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Margin</div>
    <div class="text-2xl font-extrabold"><?= pl_margin_percent($data['net_profit'], $data['gross_revenue']) ?>%</div>
  </div>
</div>

<div class="grid md:grid-cols-2 gap-5">

  <!-- Revenue Section -->
  <div class="bg-white rounded-xl border overflow-hidden">
    <div class="px-5 py-3 bg-brand text-white font-bold">REVENUE</div>
    <table class="w-full text-sm">
      <tbody>
        <tr class="border-b"><td class="px-5 py-3">Order Revenue</td><td class="px-5 py-3 text-right font-semibold"><?= money($data['gross_revenue']) ?></td></tr>
        <tr class="border-b"><td class="px-5 py-3 text-red-600">Less: Refunds</td><td class="px-5 py-3 text-right text-red-600">-<?= money($data['refunds']) ?></td></tr>
        <tr class="bg-gray-50"><td class="px-5 py-3 font-bold">Net Revenue</td><td class="px-5 py-3 text-right font-bold"><?= money($data['net_revenue']) ?></td></tr>
      </tbody>
    </table>
  </div>

  <!-- Costs Section -->
  <div class="bg-white rounded-xl border overflow-hidden">
    <div class="px-5 py-3 bg-gray-800 text-white font-bold">COSTS</div>
    <table class="w-full text-sm">
      <tbody>
        <tr class="border-b"><td class="px-5 py-3">Cost of Goods Sold</td><td class="px-5 py-3 text-right"><?= money($data['cogs']) ?></td></tr>
        <tr class="border-b"><td class="px-5 py-3">Marketing (SMS)</td><td class="px-5 py-3 text-right"><?= money($data['marketing_cost']) ?></td></tr>
        <tr class="bg-gray-50"><td class="px-5 py-3 font-bold">Total Costs</td><td class="px-5 py-3 text-right font-bold"><?= money($data['cogs'] + $data['marketing_cost']) ?></td></tr>
      </tbody>
    </table>
  </div>

  <!-- Detailed Breakdown -->
  <div class="bg-white rounded-xl border p-5 md:col-span-2">
    <h3 class="font-bold mb-3">Full Breakdown</h3>
    <table class="w-full text-sm">
      <tbody>
        <tr class="border-b"><td class="py-3">Total Orders</td><td class="py-3 text-right font-bold"><?= (int)$data['total_orders'] ?></td></tr>
        <tr class="border-b"><td class="py-3">Discounts Given</td><td class="py-3 text-right text-red-600">-<?= money($data['discounts']) ?></td></tr>
        <tr class="border-b"><td class="py-3">Delivery Fees Collected</td><td class="py-3 text-right"><?= money($data['delivery_collected']) ?></td></tr>
        <tr class="border-b"><td class="py-3">Gross Profit (Rev - COGS)</td><td class="py-3 text-right font-bold text-green-700"><?= money($data['gross_profit']) ?></td></tr>
        <tr class="bg-brand text-white"><td class="py-4 px-3 font-bold text-lg">NET PROFIT</td><td class="py-4 px-3 text-right font-extrabold text-2xl"><?= money($data['net_profit']) ?></td></tr>
      </tbody>
    </table>
  </div>

</div>

<div class="mt-5 bg-blue-50 border border-blue-200 rounded-xl p-5 text-sm text-blue-900">
  <div class="font-bold mb-2"><i class="fa-solid fa-info-circle mr-1"></i> How P&L Works</div>
  <ul class="list-disc list-inside space-y-1">
    <li><strong>COGS</strong> = Sum of <code>cost_price × quantity</code> for sold products. Product pe cost_price set karo tab actual COGS aayega.</li>
    <li><strong>Marketing</strong> = SMS cost estimate (Rs. 2/SMS). Aap apna actual cost change kar sakte ho.</li>
    <li><strong>Not included</strong>: staff salaries, rent, utilities — manually accountant handle karega.</li>
    <li>Product edit page mein <strong>cost_price</strong> field zaroor fill karo — tab actual P&L milega.</li>
  </ul>
</div>

<?php if ($autoPrint): ?>
<script>window.print();</script>
<?php endif; ?>

<?php require __DIR__ . '/../common/footer.php'; ?>