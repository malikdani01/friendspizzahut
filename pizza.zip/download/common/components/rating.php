<?php /** @var float $rating @var int $count */
$rating = $rating ?? 0; $count = $count ?? 0; ?>
<div class="text-yellow-400 text-sm flex items-center gap-1">
  <i class="fa-solid fa-star"></i>
  <span><?= number_format((float)$rating, 1) ?></span>
  <?php if ($count): ?><span class="text-white/40">(<?= (int)$count ?>)</span><?php endif; ?>
</div>