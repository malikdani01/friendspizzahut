<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$pageTitle = 'Notifications';
$uid = (int)$_SESSION['user_id'];

if (is_post()) {
    verify_csrf();
    if (post('action') === 'mark_all_read') {
        Database::execute("UPDATE notifications SET is_read=1, read_at=NOW() WHERE user_type='customer' AND user_id=? AND is_read=0", [$uid]);
        flash_success('All marked as read.');
    } elseif (post('action') === 'read') {
        Database::execute("UPDATE notifications SET is_read=1, read_at=NOW() WHERE id=? AND user_id=?", [(int)post('id'), $uid]);
    }
    redirect(url('notifications.php'));
}

$rows = get_user_notifications($uid, 50);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-10">
  <div class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-extrabold">Notifications</h1>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="mark_all_read"><button class="text-sm text-brand hover:underline">Mark all read</button></form>
  </div>
  <div class="space-y-2">
    <?php foreach ($rows as $n): ?>
    <div class="bg-white/5 border <?= $n['is_read']?'border-white/5':'border-brand/40' ?> rounded-xl p-4">
      <div class="flex justify-between items-start gap-3">
        <div>
          <div class="font-semibold"><?= e($n['title']) ?></div>
          <div class="text-sm text-white/70 mt-1"><?= e($n['message']) ?></div>
          <div class="text-xs text-white/40 mt-1"><?= date('d M Y, H:i', strtotime($n['created_at'])) ?></div>
        </div>
        <?php if ($n['link']): ?><a href="<?= e($n['link']) ?>" class="text-brand text-sm whitespace-nowrap">View →</a><?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (!$rows): ?><div class="text-center py-10 text-white/50">No notifications.</div><?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>