<?php
// process.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/refunds/index.php'));
verify_csrf();
$id = (int)post('id', 0);
Database::execute("UPDATE refunds SET status='refunded' WHERE id=?", [$id]);
$r = Database::fetch("SELECT order_id FROM refunds WHERE id=?", [$id]);
if ($r) Database::execute("UPDATE orders SET payment_status='refunded' WHERE id=?", [(int)$r['order_id']]);
audit_log('refund.process', 'refund', $id);
flash_success('Refund processed.');
redirect(url('admin/refunds/index.php'));