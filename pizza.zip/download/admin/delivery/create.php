<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Add Delivery Area';
$errors = [];
if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name',''));
    if (!$name) $errors[] = 'Name required.';
    if (!$errors) {
        Database::insert('delivery_areas', [
            'name' => $name, 'city' => trim((string)post('city','')) ?: null,
            'delivery_fee' => (float)post('delivery_fee',0),
            'min_order' => (float)post('min_order',0),
            'estimated_minutes' => (int)post('estimated_minutes',30),
            'is_active' => post('is_active') ? 1 : 0,
        ]);
        flash_success('Area added.');
        redirect(url('admin/delivery/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl">
  <?php if ($errors): ?><div class="bg-red-50 text-red-700 px-4 py-3 rounded mb-4"><?php foreach($errors as $e_) echo '• '.e($e_).'<br>'; ?></div><?php endif; ?>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input name="name" required placeholder="Area name" class="w-full border rounded px-3 py-2">
    <input name="city" value="<?= e(setting('restaurant_city')) ?>" placeholder="City" class="w-full border rounded px-3 py-2">
    <input type="number" step="0.01" name="delivery_fee" placeholder="Delivery fee" required class="w-full border rounded px-3 py-2">
    <input type="number" step="0.01" name="min_order" value="0" class="w-full border rounded px-3 py-2">
    <input type="number" name="estimated_minutes" value="30" class="w-full border rounded px-3 py-2">
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" checked> Active</label>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Create</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>