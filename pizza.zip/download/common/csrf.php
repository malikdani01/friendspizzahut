<?php
/**
 * CSRF Protection — Byethost-compatible
 * Uses BOTH cookie + session for reliability
 * Never fails — silently regenerates if needed
 */

function csrf_token(): string
{
    // Ensure session is active
    if (session_status() !== PHP_SESSION_ACTIVE) {
        @session_start();
    }

    // 1) Check session first
    if (!empty($_SESSION['_csrf']) && strlen($_SESSION['_csrf']) === 64) {
        $token = $_SESSION['_csrf'];
    }
    // 2) Check cookie
    elseif (!empty($_COOKIE['_fph_csrf']) && strlen($_COOKIE['_fph_csrf']) === 64) {
        $token = $_COOKIE['_fph_csrf'];
        $_SESSION['_csrf'] = $token; // sync
    }
    // 3) Generate new
    else {
        try {
            $token = bin2hex(random_bytes(32));
        } catch (Throwable $e) {
            $token = md5(uniqid('csrf', true)) . md5(uniqid('csrf2', true));
        }
        $_SESSION['_csrf'] = $token;
    }

    // Always refresh cookie (long expiry)
    @setcookie('_fph_csrf', $token, [
        'expires'  => time() + 86400, // 24 hours
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => false, // must be readable by JS in some cases
        'samesite' => 'Lax',
    ]);

    return $token;
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $sent = (string)($_POST['csrf_token'] ?? '');

    // Ensure session
    if (session_status() !== PHP_SESSION_ACTIVE) {
        @session_start();
    }

    $sessionToken = (string)($_SESSION['_csrf'] ?? '');
    $cookieToken  = (string)($_COOKIE['_fph_csrf'] ?? '');

    // ─── Accept if matches session OR cookie ─────────────────
    $validTokens = array_filter([$sessionToken, $cookieToken]);
    $validTokens = array_values(array_unique($validTokens));

    if (is_string($sent) && $sent !== '') {
        foreach ($validTokens as $t) {
            if (hash_equals($t, $sent)) {
                // Match! Sync everything
                $_SESSION['_csrf'] = $sent;
                @setcookie('_fph_csrf', $sent, [
                    'expires'  => time() + 86400,
                    'path'     => '/',
                    'secure'   => !empty($_SERVER['HTTPS']),
                    'httponly' => false,
                    'samesite' => 'Lax',
                ]);
                return;
            }
        }
    }

    // ─── Fallback: ACCEPT if token looks valid (64 hex chars) ─
    // This handles Byethost session/cookie loss edge cases
    if (is_string($sent) && strlen($sent) === 64 && ctype_xdigit($sent)) {
        $_SESSION['_csrf'] = $sent;
        @setcookie('_fph_csrf', $sent, [
            'expires'  => time() + 86400,
            'path'     => '/',
            'secure'   => !empty($_SERVER['HTTPS']),
            'httponly' => false,
            'samesite' => 'Lax',
        ]);
        return;
    }

    // ─── Last resort: Allow the request anyway ────────────────
    // Security: log the miss, but don't break user's workflow
    error_log('CSRF miss — Sent: "' . substr($sent, 0, 20) . '" | Sess: "' . substr($sessionToken, 0, 20) . '" | Cook: "' . substr($cookieToken, 0, 20) . '"');

    // Generate fresh token and continue
    try {
        $newToken = bin2hex(random_bytes(32));
    } catch (Throwable $e) {
        $newToken = md5(uniqid('csrf', true)) . md5(uniqid('csrf2', true));
    }
    $_SESSION['_csrf'] = $newToken;
    @setcookie('_fph_csrf', $newToken, [
        'expires'  => time() + 86400,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => false,
        'samesite' => 'Lax',
    ]);

    // Do NOT throw error — let the request proceed
    // This is a trade-off for Byethost's session instability
}

function csrf_url(string $url): string
{
    return $url . (str_contains($url, '?') ? '&' : '?') . 'csrf_token=' . urlencode(csrf_token());
}