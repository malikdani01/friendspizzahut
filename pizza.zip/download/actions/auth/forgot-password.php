<?php
// actions/auth/forgot-password.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('forgot-password.php'));
verify_csrf();
$identifier = trim((string)post('identifier',''));
$user = Database::fetch("SELECT * FROM users WHERE phone=? OR email=? LIMIT 1", [$identifier, $identifier]);
if ($user) {
    $token = bin2hex(random_bytes(32));
    Database::insert('password_resets', [
        'user_type'=>'customer','user_id'=>(int)$user['id'],'token'=>$token,
        'expires_at'=>date('Y-m-d H:i:s', time()+3600),
    ]);
    $_SESSION['_reset_link'] = url('reset-password.php?token=' . $token);
}
flash_success('If an account exists, a reset link has been sent.');
redirect(url('forgot-password.php'));