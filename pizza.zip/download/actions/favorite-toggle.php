<?php
require_once __DIR__ . '/../common/bootstrap.php';
if (!customer_logged_in()) { flash_error('Login required.'); redirect(url('login.php')); }
if (!is_post()) redirect(url('menu.php'));
verify_csrf();
$pid = (int)post('product_id', 0);
$back = (string)post('back', url('menu.php'));
if ($pid) {
    if (wishlist_has((int)$_SESSION['user_id'], $pid)) {
        wishlist_remove((int)$_SESSION['user_id'], $pid);
        flash_info('Removed from wishlist.');
    } else {
        wishlist_add((int)$_SESSION['user_id'], $pid);
        flash_success('Added to wishlist.');
    }
}
redirect($back);