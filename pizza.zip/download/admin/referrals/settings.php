<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('referral_system')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Referral Settings';
if (is_post()) {
    verify_csrf();
    foreach (['referral_referrer_reward','referral_referred_reward'] as $k) update_setting($k, (string)post($k, '0'));
    flash_success('Saved.');
    redirect(url('admin/referrals/settings.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <div><label class="text-xs text-gray-500">Referrer Reward (Rs.)</label><input type="number" name="referral_referrer_reward" value="<?= e(setting('referral_referrer_reward','50')) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Referred User Reward (Rs.)</label><input type="number" name="referral_referred_reward" value="<?= e(setting('referral_referred_reward','50')) ?>" class="w-full border rounded px-3 py-2"></div>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>