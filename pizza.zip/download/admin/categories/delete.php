<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/categories/index.php'));
verify_csrf();
$id = (int)post('id', 0);
$cat = get_category($id);
if (!$cat) { flash_error('Not found.'); redirect(url('admin/categories/index.php')); }
$used = get_category_product_count($id);
if ($used > 0) {
    flash_error("Cannot delete: {$used} products in this category. Move or delete them first.");
    redirect(url('admin/categories/index.php'));
}
Database::execute("UPDATE products SET category_id = NULL WHERE category_id = ?", [$id]);
Database::execute("DELETE FROM categories WHERE id = ?", [$id]);
if ($cat['image'] && file_exists(UPLOAD_PATH . '/' . $cat['image'])) @unlink(UPLOAD_PATH . '/' . $cat['image']);
flash_success('Category deleted.');
redirect(url('admin/categories/index.php'));