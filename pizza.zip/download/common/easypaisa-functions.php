<?php
/**
 * Easypaisa Payment Gateway (Pakistan)
 * Merchant API — Hosted Checkout
 *
 * Setup:
 *   1. easypay.easypaisa.com.pk pe merchant account banao
 *   2. Store ID, Hash Key, Username, Password milenge
 *   3. Admin → Integrations → Payments mein daalo
 */

function easypaisa_is_enabled(): bool {
    return feature_enabled('easypaisa_payment')
        && setting('easypaisa_enabled', '0') === '1'
        && setting('easypaisa_store_id', '') !== '';
}

function easypaisa_is_sandbox(): bool {
    return setting('easypaisa_mode', 'sandbox') === 'sandbox';
}

function easypaisa_api_url(): string {
    return easypaisa_is_sandbox()
        ? 'https://easypaystg.easypaisa.com.pk/easypay/Index.jsf'
        : 'https://easypay.easypaisa.com.pk/easypay/Index.jsf';
}

/**
 * Generate Easypaisa hash — HMAC-SHA256 with sorted params
 */
function easypaisa_generate_hash(array $params, string $hashKey): string {
    ksort($params);
    $str = '';
    foreach ($params as $k => $v) {
        if ($k === 'hashKey' || $v === '' || $v === null) continue;
        $str .= '&' . $v;
    }
    // Remove leading &
    $str = ltrim($str, '&');
    return strtoupper(hash_hmac('sha256', $str, $hashKey));
}

/**
 * Build Easypaisa redirect URL (Hosted checkout via POST form)
 */
function easypaisa_build_form(array $order): array {
    $storeId = setting('easypaisa_store_id', '');
    $hashKey = setting('easypaisa_hash_key', '');

    $now = new DateTime('now', new DateTimeZone('Asia/Karachi'));

    $params = [
        'amount'              => number_format((float)$order['total'], 2, '.', ''),
        'autoRedirect'        => '1',
        'emailAddr'           => $order['customer_email'] ?: 'noreply@friendspizzahut.com',
        'mobileNum'           => preg_replace('/\D/', '', $order['customer_phone']),
        'orderRefNum'         => $order['order_number'],
        'paymentMethod'       => 'MA_PAYMENT_METHOD_WALLET',
        'postBackURL'         => url('payment/easypaisa-return.php'),
        'storeId'             => $storeId,
        'timeStamp'           => $now->format('Y-m-d H:i:s'),
        'expiryDate'          => $now->modify('+1 day')->format('Ymd His'),
    ];

    $params['merchantHashedReq'] = easypaisa_generate_hash($params, $hashKey);

    return [
        'action' => easypaisa_api_url(),
        'fields' => $params,
    ];
}

/**
 * Verify Easypaisa response hash
 */
function easypaisa_verify_response(array $post): bool {
    if (empty($post['merchantHashedReq'])) return false;
    $hashKey = setting('easypaisa_hash_key', '');
    $received = strtoupper((string)$post['merchantHashedReq']);
    $params = $post;
    unset($params['merchantHashedReq']);
    $computed = easypaisa_generate_hash($params, $hashKey);
    return hash_equals($computed, $received);
}

/**
 * EasyPaisa response code success check
 */
function easypaisa_response_success(string $code): bool {
    return in_array($code, ['0000', '000', '121', '200'], true);
}

function easypaisa_log(string $action, array $data): void {
    try {
        Database::insert('audit_logs', [
            'user_type'  => 'system',
            'action'     => 'easypaisa.' . $action,
            'entity'     => 'payment',
            'new_data'   => json_encode($data),
            'ip_address' => client_ip(),
            'user_agent' => 'Easypaisa Gateway',
        ]);
    } catch (Throwable $e) {
        error_log('easypaisa_log failed: ' . $e->getMessage());
    }
}