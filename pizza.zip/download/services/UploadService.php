<?php
// services/UploadService.php
class UploadService {
    public static function validate(array $f): array { return validate_upload($f); }
    public static function save(array $f, string $sub): array { return save_uploaded_image($f, $sub); }
    public static function delete(?string $path): void { delete_uploaded_file($path); }
}