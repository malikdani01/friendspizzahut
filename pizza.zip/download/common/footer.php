</main>

<footer style="background:#000;border-top:1px solid rgba(255,255,255,0.08);padding:40px 16px 100px;margin-top:40px;position:relative;overflow:hidden;">
  <div class="fph-container" style="max-width:1200px;margin:0 auto;">

    <div style="display:grid;grid-template-columns:1fr;gap:24px;" class="fph-footer-grid">
      <div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
          <span style="width:38px;height:38px;border-radius:50%;background:#dc2626;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px;">
            <i class="fa-solid fa-pizza-slice"></i>
          </span>
          <span style="display:flex;flex-direction:column;line-height:1;">
            <span style="font-weight:900;font-size:14px;letter-spacing:0.5px;color:#fff;">FRIENDS</span>
            <span style="font-weight:800;font-size:11px;color:#dc2626;letter-spacing:1.5px;margin-top:2px;">PIZZA HUT</span>
          </span>
        </div>
        <p style="color:rgba(249,250,251,0.6);font-size:13.5px;margin:0;">
          <?= e(setting('tagline', 'Hot • Fresh • Delicious')) ?>
        </p>
      </div>

      <div>
        <h4 style="color:#dc2626;font-size:13px;text-transform:uppercase;letter-spacing:1px;margin:0 0 12px;">Quick Links</h4>
        <ul style="list-style:none;padding:0;margin:0;font-size:13.5px;line-height:2;">
          <li><a href="<?= url('menu.php') ?>" style="color:rgba(249,250,251,0.7);text-decoration:none;">Menu</a></li>
          <li><a href="<?= url('offers.php') ?>" style="color:rgba(249,250,251,0.7);text-decoration:none;">Offers</a></li>
          <li><a href="<?= url('track-order.php') ?>" style="color:rgba(249,250,251,0.7);text-decoration:none;">Track Order</a></li>
          <li><a href="<?= url('contact.php') ?>" style="color:rgba(249,250,251,0.7);text-decoration:none;">Contact</a></li>
        </ul>
      </div>

      <div>
        <h4 style="color:#dc2626;font-size:13px;text-transform:uppercase;letter-spacing:1px;margin:0 0 12px;">Contact</h4>
        <ul style="list-style:none;padding:0;margin:0;font-size:13.5px;line-height:2;color:rgba(249,250,251,0.7);">
          <li><i class="fa-solid fa-location-dot" style="color:#dc2626;margin-right:6px;"></i> <?= e(setting('restaurant_address', 'City Tamman')) ?></li>
          <li><i class="fa-solid fa-phone" style="color:#dc2626;margin-right:6px;"></i> <?= e(setting('restaurant_phone', '')) ?></li>
        </ul>
      </div>
    </div>

    <div style="border-top:1px solid rgba(255,255,255,0.08);margin-top:24px;padding-top:16px;text-align:center;font-size:12px;color:rgba(249,250,251,0.4);">
      © <?= date('Y') ?> <?= e(setting('restaurant_name', 'Friends Pizza Hut')) ?>
    </div>
  </div>
</footer>

<style>
@media (min-width: 768px) {
  .fph-footer-grid { grid-template-columns: 2fr 1fr 1fr !important; }
}
</style>

<?php
// Include bottom navigation (with Cart replaced by Menu)
require __DIR__ . '/bottom-nav.php';
?>

<script src="<?= asset('js/mobile-ui.js') ?>" defer></script>
<script src="<?= asset('js/zoom-lock.js') ?>" defer></script>
<script src="<?= asset('js/theme-upgrade.js') ?>" defer></script>

<script>
(function() {
  // ─── Drawer / Search (safety net if mobile-ui.js fails) ────
  var drawer = document.getElementById('fphDrawer');
  var overlay = document.getElementById('fphDrawerOverlay');
  var menuBtn = document.getElementById('fphMenuBtn');
  var closeBtn = document.getElementById('fphDrawerClose');
  var searchOverlay = document.getElementById('fphSearchOverlay');
  var searchBtn = document.getElementById('fphSearchBtn');
  var searchClose = document.getElementById('fphSearchClose');

  function openDrawer() { if (drawer) { drawer.classList.add('open'); overlay && overlay.classList.add('open'); document.body.style.overflow='hidden'; } }
  function closeDrawer() { if (drawer) { drawer.classList.remove('open'); overlay && overlay.classList.remove('open'); document.body.style.overflow=''; } }
  function openSearch() { if (searchOverlay) { searchOverlay.classList.add('open'); setTimeout(function() { var inp = searchOverlay.querySelector('input'); if (inp) inp.focus(); }, 150); } }
  function closeSearch() { if (searchOverlay) searchOverlay.classList.remove('open'); }

  if (menuBtn) menuBtn.addEventListener('click', openDrawer);
  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  if (overlay) overlay.addEventListener('click', closeDrawer);
  if (searchBtn) searchBtn.addEventListener('click', openSearch);
  if (searchClose) searchClose.addEventListener('click', closeSearch);
  if (searchOverlay) searchOverlay.addEventListener('click', function(e) { if (e.target === searchOverlay) closeSearch(); });

  // ─── Deal countdown ────────────────────────────────────────
  document.querySelectorAll('.fph-deal-bar').forEach(function(bar) {
    var endTs = parseInt(bar.dataset.endTs, 10);
    var display = bar.querySelector('.fph-deal-countdown');
    if (!endTs || !display) return;
    function tick() {
      var diff = Math.max(0, endTs - Date.now());
      if (diff === 0) { bar.style.display = 'none'; return; }
      var h = Math.floor(diff/3600000); diff %= 3600000;
      var m = Math.floor(diff/60000); diff %= 60000;
      var s = Math.floor(diff/1000);
      display.textContent = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
    }
    tick();
    setInterval(tick, 1000);
  });

  // ─── Flash auto-dismiss ────────────────────────────────────
  setTimeout(function() {
    document.querySelectorAll('.fph-flash').forEach(function(el) {
      el.style.transition = 'opacity .4s, transform .4s';
      el.style.opacity = '0';
      el.style.transform = 'translateX(120%)';
      setTimeout(function() { el.remove(); }, 400);
    });
  }, 4000);
})();
</script>

</body>
</html>