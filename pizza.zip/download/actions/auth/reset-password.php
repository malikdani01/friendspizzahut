<?php
// actions/auth/reset-password.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('reset-password.php'));
verify_csrf();
$token = (string)post('token','');
$password = (string)post('password','');
if (strlen($password) < 6) { flash_error('Password 6+ chars.'); redirect(url('reset-password.php?token='.urlencode($token))); }
$row = Database::fetch("SELECT * FROM password_resets WHERE token=? AND used_at IS NULL AND expires_at > NOW()", [$token]);
if (!$row) { flash_error('Invalid/expired token.'); redirect(url('reset-password.php')); }
Database::execute("UPDATE users SET password_hash=? WHERE id=?", [password_hash($password, PASSWORD_DEFAULT), (int)$row['user_id']]);
Database::execute("UPDATE password_resets SET used_at=NOW() WHERE id=?", [(int)$row['id']]);
flash_success('Password updated. Login now.');
redirect(url('login.php'));