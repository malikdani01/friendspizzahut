<?php
/**
 * WhatsApp Business Cloud API integration (Meta official)
 * Feature-gated: whatsapp_business_api
 *
 * Setup:
 *   1. developers.facebook.com → Create App → Business
 *   2. Add WhatsApp product
 *   3. Get Phone Number ID + Access Token
 *   4. Add to Admin → Integrations → WhatsApp Business API
 */

function whatsapp_business_is_enabled(): bool {
    return feature_enabled('whatsapp_business_api')
        && setting('whatsapp_business_enabled', '0') === '1'
        && setting('whatsapp_phone_number_id', '') !== ''
        && setting('whatsapp_access_token', '') !== '';
}

function send_whatsapp_message(string $to, string $message, string $templateName = null, array $templateParams = []): bool {
    if (!whatsapp_business_is_enabled()) return false;

    $phoneNumberId = setting('whatsapp_phone_number_id', '');
    $accessToken   = setting('whatsapp_access_token', '');
    $apiVersion    = setting('whatsapp_api_version', 'v20.0');

    $to = whatsapp_normalize_phone($to);
    if (!$to) {
        whatsapp_log('Invalid phone', $to, false);
        return false;
    }

    $url = "https://graph.facebook.com/{$apiVersion}/{$phoneNumberId}/messages";

    if ($templateName) {
        // Template message (required for 24h+ delay)
        $payload = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'template',
            'template' => [
                'name' => $templateName,
                'language' => ['code' => 'en'],
                'components' => !empty($templateParams) ? [[
                    'type' => 'body',
                    'parameters' => array_map(fn($p) => ['type' => 'text', 'text' => $p], $templateParams),
                ]] : [],
            ],
        ];
    } else {
        // Simple text (works within 24h of user's last message)
        $payload = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'text',
            'text' => ['body' => mb_substr($message, 0, 4096)],
        ];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ],
    ]);
    $resp = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    $ok = ($httpCode >= 200 && $httpCode < 300);
    whatsapp_log($ok ? 'Sent' : "HTTP $httpCode $err", $to, $ok, $resp);
    return $ok;
}

function whatsapp_normalize_phone(string $phone): ?string {
    $digits = preg_replace('/\D/', '', $phone);
    if (preg_match('/^92\d{10}$/', $digits)) return $digits;
    if (preg_match('/^0\d{10}$/', $digits)) return '92' . substr($digits, 1);
    if (preg_match('/^3\d{9}$/', $digits)) return '92' . $digits;
    return null;
}

function whatsapp_log(string $status, string $to, bool $ok, ?string $raw = null): void {
    try {
        Database::insert('audit_logs', [
            'user_type' => 'system',
            'action' => $ok ? 'whatsapp.sent' : 'whatsapp.failed',
            'entity' => 'whatsapp',
            'new_data' => json_encode([
                'to' => $to,
                'status' => $status,
                'raw' => $raw ? mb_substr($raw, 0, 500) : null,
            ]),
            'ip_address' => client_ip(),
            'user_agent' => 'WhatsApp Cloud API',
        ]);
    } catch (Throwable $e) {}
}

/**
 * Notify customer about order status via WhatsApp
 */
function whatsapp_notify_order(int $orderId, string $status): bool {
    if (!whatsapp_business_is_enabled()) return false;

    $order = get_order($orderId);
    if (!$order) return false;

    $messages = [
        'confirmed' => "Aapka order {$order['order_number']} confirm ho gaya. Total: Rs. " . number_format($order['total'], 0) . "\n\nTrack: " . url('track-order.php?order=' . $order['order_number']),
        'preparing' => "Order {$order['order_number']} abhi ban raha hai.",
        'ready' => "Order {$order['order_number']} ready hai!",
        'out_for_delivery' => "Order {$order['order_number']} rider ke saath nikal gaya.",
        'delivered' => "Order {$order['order_number']} deliver ho gaya. Shukriya!",
        'cancelled' => "Order {$order['order_number']} cancel ho gaya.",
    ];

    if (!isset($messages[$status])) return false;

    return send_whatsapp_message($order['customer_phone'], $messages[$status]);
}