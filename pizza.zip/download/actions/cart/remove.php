<?php
// actions/cart/remove.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('cart.php'));
verify_csrf();
remove_cart_item((int)post('id',0));
flash_success('Item removed.');
redirect(url('cart.php'));