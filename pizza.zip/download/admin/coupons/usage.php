<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id', 0);
$c = Database::fetch("SELECT * FROM coupons WHERE id=?", [$id]);
if (!$c) { flash_error('Not found.'); redirect(url('admin/coupons/index.php')); }
$pageTitle = 'Coupon Usage: ' . $c['code'];
$rows = Database::fetchAll("SELECT cu.*, u.name AS user_name, o.order_number FROM coupon_usage cu
    LEFT JOIN users u ON u.id=cu.user_id LEFT JOIN orders o ON o.id=cu.order_id
    WHERE cu.coupon_id=? ORDER BY cu.id DESC", [$id]);
require __DIR__ . '/../common/header.php';
?>
<a href="<?= url('admin/coupons/index.php') ?>" class="text-sm text-gray-500 hover:text-brand mb-4 inline-block">← Coupons</a>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">User</th><th class="text-left px-4 py-3">Order</th><th class="text-right px-4 py-3">Discount</th><th class="text-left px-4 py-3">Date</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr class="border-t">
        <td class="px-4 py-3"><?= e($r['user_name'] ?? 'Guest') ?></td>
        <td class="px-4 py-3 font-mono text-xs"><?= e($r['order_number'] ?? '') ?></td>
        <td class="px-4 py-3 text-right font-semibold"><?= money($r['discount_amount']) ?></td>
        <td class="px-4 py-3 text-xs text-gray-500"><?= date('d M Y, H:i', strtotime($r['used_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="4" class="py-8 text-center text-gray-400">No usage yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>