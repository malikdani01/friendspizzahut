<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Send Notification';
if (is_post()) {
    verify_csrf();
    $title = trim((string)post('title',''));
    $msg = trim((string)post('message',''));
    $userId = (int)post('user_id', 0);
    if ($title && $msg) {
        if ($userId) {
            notify($userId, 'admin_message', $title, $msg, null, 'customer');
        } else {
            foreach (Database::fetchAll("SELECT id FROM users") as $u) {
                notify((int)$u['id'], 'admin_message', $title, $msg, null, 'customer');
            }
        }
        flash_success('Notification sent.');
    }
    redirect(url('admin/notifications/index.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-4">
    <?= csrf_field() ?>
    <input name="user_id" type="number" placeholder="User ID (blank = all)" class="w-full border rounded px-3 py-2">
    <input name="title" required placeholder="Title" class="w-full border rounded px-3 py-2">
    <textarea name="message" rows="4" required placeholder="Message" class="w-full border rounded px-3 py-2"></textarea>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Send</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>