<?php
require_once __DIR__ . '/../common/bootstrap.php';
admin_logout();
flash_info('You have been logged out.');
redirect(url('admin/login.php'));