<?php
/**
 * Database — PDO wrapper (prepared statements only)
 * + column_exists() helper
 */

class Database
{
    private static ?PDO $pdo = null;
    private static int $txDepth = 0;

    public static function connect(): PDO
    {
        if (self::$pdo !== null) return self::$pdo;

        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

        try {
            self::$pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            if (defined('APP_DEBUG') && APP_DEBUG) {
                die('DB connection failed: ' . $e->getMessage());
            }
            error_log('DB connect failed: ' . $e->getMessage());
            die('Database connection error. Please try again later.');
        }

        return self::$pdo;
    }

    public static function pdo(): PDO
    {
        return self::connect();
    }

    public static function fetch(string $sql, array $params = []): ?array
    {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public static function fetchAll(string $sql, array $params = []): array
    {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function execute(string $sql, array $params = []): int
    {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    public static function insert(string $table, array $data): int
    {
        $cols = array_keys($data);
        $placeholders = array_map(fn($c) => ':' . $c, $cols);
        $sql = 'INSERT INTO `' . $table . '` (`' . implode('`,`', $cols) . '`) VALUES (' . implode(',', $placeholders) . ')';
        $stmt = self::pdo()->prepare($sql);
        foreach ($data as $k => $v) $stmt->bindValue(':' . $k, $v);
        $stmt->execute();
        return (int) self::pdo()->lastInsertId();
    }

    public static function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $set = [];
        foreach (array_keys($data) as $c) $set[] = "`$c` = :$c";
        $sql = 'UPDATE `' . $table . '` SET ' . implode(', ', $set) . ' WHERE ' . $where;
        $stmt = self::pdo()->prepare($sql);
        foreach ($data as $k => $v) $stmt->bindValue(':' . $k, $v);
        foreach ($whereParams as $k => $v) $stmt->bindValue(':' . $k, $v);
        $stmt->execute();
        return $stmt->rowCount();
    }

    public static function delete(string $table, string $where, array $params = []): int
    {
        return self::execute("DELETE FROM `$table` WHERE $where", $params);
    }

    public static function beginTransaction(): void
    {
        if (self::$txDepth === 0) self::pdo()->beginTransaction();
        self::$txDepth++;
    }

    public static function commit(): void
    {
        if (self::$txDepth > 0) {
            self::$txDepth--;
            if (self::$txDepth === 0) self::pdo()->commit();
        }
    }

    public static function rollback(): void
    {
        if (self::$txDepth > 0) {
            self::$txDepth = 0;
            if (self::pdo()->inTransaction()) self::pdo()->rollBack();
        }
    }

    public static function lastInsertId(): int
    {
        return (int) self::pdo()->lastInsertId();
    }
}

/**
 * Check if a column exists in a table
 * Safe to call — returns false on error
 */
if (!function_exists('column_exists')) {
    function column_exists(string $table, string $column): bool {
        try {
            // Basic sanitization to prevent injection via table name
            $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
            if ($table === '') return false;

            $r = Database::fetch("SHOW COLUMNS FROM `$table` LIKE ?", [$column]);
            return !empty($r);
        } catch (Throwable $e) {
            return false;
        }
    }
}

/**
 * Check if a table exists in current database
 */
if (!function_exists('table_exists')) {
    function table_exists(string $table): bool {
        try {
            $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
            if ($table === '') return false;

            $r = Database::fetch("SHOW TABLES LIKE ?", [$table]);
            return !empty($r);
        } catch (Throwable $e) {
            return false;
        }
    }
}