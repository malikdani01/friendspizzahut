<?php
/**
 * Mobile fixed bottom navigation
 * Cart button replaced with Menu button
 */
$current = basename($_SERVER['SCRIPT_NAME'] ?? '');
$isHome  = in_array($current, ['index.php', ''], true);
$isMenu  = in_array($current, ['menu.php', 'category.php', 'search.php', 'product.php'], true);
$isDeals = ($current === 'deals.php' || $current === 'offers.php');
$isOrders = in_array($current, ['orders.php', 'order-detail.php', 'track-order.php'], true);
$isAcct  = in_array($current, ['account.php', 'login.php', 'register.php', 'profile.php'], true);
?>

<nav class="fph-bottom-nav" id="fphBottomNav" aria-label="Main navigation">
  <div class="fph-bn-glow"></div>

  <a href="<?= url('orders.php') ?>" class="fph-bn-item <?= $isOrders ? 'active' : '' ?>" aria-label="Orders">
    <i class="fa-solid fa-receipt"></i>
    <span>Orders</span>
  </a>

  <a href="<?= url('deals.php') ?>" class="fph-bn-item <?= $isDeals ? 'active' : '' ?>" aria-label="Deals">
    <i class="fa-solid fa-tags"></i>
    <span>Deals</span>
  </a>

  <a href="<?= url('index.php') ?>" class="fph-bn-home <?= $isHome ? 'active' : '' ?>" aria-label="Home">
    <div class="fph-bn-home-circle">
      <i class="fa-solid fa-house"></i>
    </div>
    <span>Home</span>
  </a>

  <a href="<?= url('menu.php') ?>" class="fph-bn-item <?= $isMenu ? 'active' : '' ?>" aria-label="Menu">
    <i class="fa-solid fa-utensils"></i>
    <span>Menu</span>
  </a>

  <a href="<?= customer_logged_in() ? url('account.php') : url('login.php') ?>" class="fph-bn-item <?= $isAcct ? 'active' : '' ?>" aria-label="Account">
    <i class="fa-solid fa-user"></i>
    <span>Account</span>
  </a>
</nav>