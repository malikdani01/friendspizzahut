<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('qr_menu')) {
    flash_error('QR Menu feature is disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'QR Code Generator';
$tables = get_active_tables();
require __DIR__ . '/../common/header.php';
?>

<div class="bg-white rounded-xl shadow-sm border p-6 mb-6">
  <p class="text-sm text-gray-600 mb-4">
    Har table ke liye QR code print karo. Customer scan kare → menu khule → order kare.
    Chhote QR stickers print karke table pe chipka do.
  </p>
  <a href="?print=1" target="_blank" class="inline-flex items-center gap-2 bg-brand text-white px-5 py-2.5 rounded-lg font-semibold">
    <i class="fa-solid fa-print"></i> Print All QR Codes
  </a>
</div>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4">
  <?php foreach ($tables as $t): ?>
  <div class="bg-white rounded-xl shadow-sm border p-5 text-center">
    <div class="text-2xl font-extrabold text-brand mb-3">Table <?= $t['number'] ?></div>
    <img src="<?= qr_image_url($t['url'], 220) ?>" alt="QR Table <?= $t['number'] ?>" class="mx-auto rounded">
    <div class="text-xs text-gray-500 mt-3 break-all"><?= e($t['url']) ?></div>
    <a href="<?= e($t['url']) ?>" target="_blank" class="text-xs text-brand hover:underline mt-2 inline-block">Test →</a>
  </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>