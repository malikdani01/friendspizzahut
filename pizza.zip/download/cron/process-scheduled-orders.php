<?php
require_once __DIR__ . '/../common/bootstrap.php';
// Run every 5 minutes: */5 * * * * php /path/cron/process-scheduled-orders.php

// Find scheduled orders within next 30 minutes
$now = date('Y-m-d H:i:s');
$threshold = date('Y-m-d H:i:s', time() + 30 * 60);

$orders = Database::fetchAll(
    "SELECT * FROM orders
     WHERE is_scheduled = 1
     AND order_status = 'pending'
     AND scheduled_at BETWEEN ? AND ?",
    [$now, $threshold]
);

foreach ($orders as $o) {
    // Notify admin that scheduled order is coming up
    Database::insert('notifications', [
        'user_type' => 'admin', 'user_id' => 1,
        'type' => 'scheduled_reminder',
        'title' => 'Scheduled Order Starting Soon',
        'message' => "Order {$o['order_number']} scheduled for " . date('h:i A', strtotime($o['scheduled_at'])),
        'link' => '/admin/orders/view.php?id=' . (int)$o['id'],
    ]);
}

echo "[" . date('c') . "] Checked " . count($orders) . " scheduled orders.\n";