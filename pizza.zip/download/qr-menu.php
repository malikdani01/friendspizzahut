<?php
require_once __DIR__ . '/common/bootstrap.php';
if (!feature_enabled('qr_menu')) {
    redirect(url('menu.php'));
}

$tableNumber = (int)get('table', 0);
$pageTitle = $tableNumber ? "Table $tableNumber Menu" : 'QR Menu';

// Set session so checkout knows the table number
if ($tableNumber > 0 && $tableNumber <= 100) {
    $_SESSION['qr_table_number'] = $tableNumber;
}

$categories = get_categories(true);
$featured = get_products(['featured' => 1, 'available' => 1, 'limit' => 12]);

require __DIR__ . '/common/header.php';
?>

<div class="max-w-7xl mx-auto px-4 py-8">
  <?php if ($tableNumber): ?>
  <div class="bg-brand/20 border border-brand/40 rounded-2xl p-5 mb-6 flex items-center gap-4">
    <i class="fa-solid fa-chair text-3xl text-brand"></i>
    <div>
      <div class="text-sm text-white/60">Aap yahan baithe hain</div>
      <div class="text-2xl font-extrabold">Table <?= $tableNumber ?></div>
    </div>
    <a href="<?= url('cart.php') ?>" class="ml-auto bg-brand px-5 py-2.5 rounded-lg font-bold">
      View Cart <i class="fa-solid fa-arrow-right ml-1"></i>
    </a>
  </div>
  <?php endif; ?>

  <h1 class="text-3xl md:text-4xl font-extrabold mb-2">Our Menu</h1>
  <p class="text-white/60 mb-8">Table se order karein, hum aapke paas layenge</p>

  <!-- Categories scroll -->
  <div class="overflow-x-auto -mx-4 px-4 mb-8">
    <div class="flex gap-2 min-w-max">
      <?php foreach ($categories as $c): ?>
      <a href="<?= url('qr-menu.php?table=' . $tableNumber . '&category=' . urlencode($c['slug'])) ?>"
         class="px-4 py-2.5 rounded-full bg-white/5 hover:bg-brand border border-white/10 hover:border-brand text-sm font-semibold whitespace-nowrap transition">
        <?= e($c['name']) ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Featured -->
  <?php if ($featured): ?>
  <h2 class="text-2xl font-extrabold mb-4">Popular Items</h2>
  <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
    <?php foreach ($featured as $p): require __DIR__ . '/common/components/product-card.php'; endforeach; ?>
  </div>
  <?php endif; ?>

  <div class="mt-8">
    <a href="<?= url('menu.php') ?>" class="inline-flex items-center gap-2 text-brand hover:underline">
      <i class="fa-solid fa-utensils"></i> Full Menu dekhein
    </a>
  </div>
</div>

<?php require __DIR__ . '/common/footer.php'; ?>