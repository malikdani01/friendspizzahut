<?php
/**
 * Add-on helper functions with size support
 */

function get_all_addons(bool $activeOnly = true): array {
    $sql = "SELECT * FROM addons";
    if ($activeOnly) $sql .= " WHERE is_active=1";
    $sql .= " ORDER BY category, sort_order, id";
    try {
        return Database::fetchAll($sql);
    } catch (Throwable $e) {
        return [];
    }
}

function get_addon(int $id): ?array {
    return Database::fetch("SELECT * FROM addons WHERE id=?", [$id]);
}

function get_product_addons(int $productId): array {
    try {
        return Database::fetchAll(
            "SELECT a.*, pa.is_required, pa.sort_order AS pa_sort
             FROM product_addons pa
             JOIN addons a ON a.id = pa.addon_id
             WHERE pa.product_id = ? AND a.is_active = 1
             ORDER BY pa.sort_order, a.sort_order",
            [$productId]
        );
    } catch (Throwable $e) {
        return [];
    }
}

function attach_addon(int $productId, int $addonId, int $sortOrder = 0): void {
    if (!Database::fetch("SELECT id FROM product_addons WHERE product_id=? AND addon_id=?", [$productId, $addonId])) {
        Database::insert('product_addons', ['product_id'=>$productId, 'addon_id'=>$addonId, 'sort_order'=>$sortOrder]);
    }
}

function detach_addon(int $productId, int $addonId): void {
    Database::execute("DELETE FROM product_addons WHERE product_id=? AND addon_id=?", [$productId, $addonId]);
}

/**
 * Get the price for an addon based on size
 * @param array $addon The addon row
 * @param string|null $size 'S', 'M', 'L' or null
 */
function addon_price_for_size(array $addon, ?string $size = null): float {
    if ((int)($addon['has_sizes'] ?? 0) === 1 && $size) {
        return match (strtoupper($size)) {
            'S' => (float)($addon['price_s'] ?? 0),
            'M' => (float)($addon['price_m'] ?? 0),
            'L' => (float)($addon['price_l'] ?? 0),
            default => (float)($addon['price_s'] ?? 0),
        };
    }
    return (float)($addon['price'] ?? 0);
}