<?php
// adjust.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('inventory_tracking')) redirect(url('admin/dashboard.php'));
if (!is_post()) redirect(url('admin/inventory/index.php'));
verify_csrf();
inventory_adjust((int)post('product_id'), (int)post('change'), (string)post('type','add'), (string)post('reason'), null);
audit_log('inventory.adjust', 'product', (int)post('product_id'));
flash_success('Stock adjusted.');
redirect(url('admin/inventory/index.php'));