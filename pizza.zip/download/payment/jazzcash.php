<?php
/**
 * JazzCash Payment — Redirect to Gateway
 * Customer checkout pe JazzCash select kare to yahan aayega.
 */
require_once __DIR__ . '/../common/bootstrap.php';

if (!jazzcash_is_enabled()) {
    flash_error('JazzCash payment is not available.');
    redirect(url('checkout.php'));
}

$orderNumber = (string) get('order', '');
$order = $orderNumber ? get_order_by_number($orderNumber) : null;

if (!$order) {
    flash_error('Order not found.');
    redirect(url('checkout.php'));
}

// Already paid — no double payment
if ($order['payment_status'] === 'paid') {
    flash_info('Ye order already paid hai.');
    redirect(url('order-success.php?order=' . urlencode($orderNumber)));
}

// Already cancelled — send back
if ($order['order_status'] === 'cancelled') {
    flash_error('Ye order cancel ho chuka hai.');
    redirect(url('order-detail.php?id=' . (int)$order['id']));
}

// Build redirect URL
$redirectUrl = jazzcash_build_redirect_url($order);

jazzcash_log('initiate', [
    'order_number' => $orderNumber,
    'total'        => $order['total'],
    'mode'         => jazzcash_is_sandbox() ? 'sandbox' : 'live',
]);

// Redirect customer to JazzCash
redirect($redirectUrl);