-- ═══════════════════════════════════════════════════════════════
-- FRIENDS PIZZA HUT — Seed Data (features, settings, categories, menu)
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── FEATURES ─────────────────────────────────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
-- CORE (locked ON)
('products','Products Management','core','Manage products catalog',1,1,1,0,1),
('categories','Categories','core','Product categories',1,1,1,0,2),
('cart','Shopping Cart','core','Customer cart',1,1,1,0,3),
('checkout','Checkout','core','Order checkout flow',1,1,1,0,4),
('orders','Orders','core','Order management',1,1,1,0,5),
('admin_auth','Admin Authentication','core','Admin login system',1,1,1,0,6),
('customer_auth','Customer Authentication','core','Customer login/register',1,1,1,0,7),
('payments_cod','Cash on Delivery','core','COD payment method',1,1,1,0,8),
('delivery_areas','Delivery Areas','core','Delivery zones',1,1,1,0,9),
('settings','Site Settings','core','Global settings',1,1,1,0,10),

-- ENABLED BY DEFAULT
('banners','Banners','marketing','Homepage banners',1,0,1,0,20),
('coupons','Coupons','marketing','Discount coupons',1,0,1,0,21),
('offers','Offers','marketing','Special offers',1,0,1,0,22),
('product_reviews','Product Reviews','customer','Customer reviews',1,0,1,0,23),
('wishlist','Wishlist','customer','Save favorite items',1,0,1,0,24),
('notifications','Notifications','customer','In-app notifications',1,0,1,0,25),
('order_tracking','Order Tracking','orders','Track orders',1,0,1,0,26),
('order_cancel','Order Cancellation','orders','Cancel orders',1,0,1,0,27),
('address_book','Address Book','customer','Multiple addresses',1,0,1,0,28),
('free_delivery_promotion','Free Delivery Promotion','marketing','Free delivery above amount',1,0,1,0,29),
('search','Search','customer','Product search',1,0,1,0,30),

-- DISABLED BY DEFAULT
('loyalty_points','Loyalty Points','customer','Earn and redeem points',0,0,0,0,40),
('referral_system','Referral System','marketing','Refer friends',0,0,0,0,41),
('gift_cards','Gift Cards','marketing','Buy and redeem gift cards',0,0,0,0,42),
('sms_notifications','SMS Notifications','notifications','Send SMS alerts',0,0,0,1,43),
('email_notifications','Email Notifications','notifications','Send email alerts',0,0,0,1,44),
('whatsapp_ordering','WhatsApp Ordering','integrations','Order via WhatsApp',0,0,0,1,45),
('kitchen_display','Kitchen Display','orders','Kitchen order screen',0,0,0,0,46),
('staff_roles','Staff & Roles','advanced','Staff accounts and permissions',0,0,0,0,47),
('inventory_tracking','Inventory Tracking','advanced','Stock management',0,0,0,0,48),
('refunds','Refunds','payments','Refund management',0,0,0,0,49),
('bank_transfer','Bank Transfer','payments','Bank transfer payment',0,0,0,1,50),
('online_payment','Online Payment','payments','Online payment gateway',0,0,0,1,51),
('table_reservation','Table Reservation','customer','Reserve table',0,0,0,0,52),
('combo_deals','Combo Deals','marketing','Product combos',0,0,0,0,53),
('first_order_offer','First Order Offer','marketing','Discount for first order',0,0,0,0,54),
('scheduled_orders','Scheduled Orders','orders','Schedule order for later',0,0,0,0,55),
('multi_language','Multi Language','advanced','Multiple languages',0,0,0,0,56),
('multi_currency','Multi Currency','advanced','Multiple currencies',0,0,0,0,57),
('tip_system','Tip System','advanced','Tip for delivery',0,0,0,0,58),
('rider_tracking','Rider Tracking','advanced','Live rider tracking',0,0,0,0,59),
('analytics_advanced','Advanced Analytics','advanced','Detailed analytics',0,0,0,0,60),
('customer_tiers','Customer Tiers','customer','Customer levels',0,0,0,0,61),
('abandoned_carts','Abandoned Carts','marketing','Recover abandoned carts',0,0,0,0,62),
('push_notifications','Push Notifications','notifications','Browser push notifications',0,0,0,1,63),
('pwa','Progressive Web App','advanced','Installable PWA',0,0,0,0,64),
('social_login','Social Login','integrations','Login with Google/Facebook',0,0,0,1,65),
('product_bundles','Product Bundles','marketing','Bundle products',0,0,0,0,66);

-- ─── SETTINGS ─────────────────────────────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('restaurant_name','Friends Pizza Hut','restaurant'),
('restaurant_owner','Hamid Jabbar','restaurant'),
('restaurant_phone','03001494249','restaurant'),
('restaurant_whatsapp','03001494249','restaurant'),
('restaurant_email','info@friendspizzahut.com','restaurant'),
('restaurant_address','City Tamman, near MCB Bank','restaurant'),
('restaurant_city','City Tamman','restaurant'),
('restaurant_status','open','restaurant'),
('opening_time','11:00','restaurant'),
('closing_time','02:00','restaurant'),
('currency','PKR','general'),
('currency_symbol','Rs.','general'),
('timezone','Asia/Karachi','general'),
('tax_percent','0','checkout'),
('service_fee','0','checkout'),
('packaging_fee','0','checkout'),
('minimum_order','300','checkout'),
('default_delivery_fee','100','delivery'),
('free_delivery_above','1500','delivery'),
('cod_enabled','1','payment'),
('bank_transfer_enabled','0','payment'),
('online_payment_enabled','0','payment'),
('scheduled_orders_enabled','0','ordering'),
('cancellation_window_minutes','5','ordering'),
('loyalty_earn_rate','1','loyalty'),
('loyalty_redeem_rate','100','loyalty'),
('primary_color','#dc2626','branding'),
('secondary_color','#0a0a0a','branding'),
('white_color','#ffffff','branding'),
('tagline','Hot • Fresh • Delicious','branding');

-- ─── DEFAULT ADMIN (password: Admin@123) ──────────────────────
INSERT INTO admins (name, username, email, password_hash) VALUES
('Hamid Jabbar','admin','admin@friendspizzahut.com','$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlCS4bZJ18JuywdB9pBjGXY8Q6XwqS');

-- ─── CATEGORIES ───────────────────────────────────────────────
INSERT INTO categories (name, slug, description, icon, sort_order, is_active) VALUES
('Pizza','pizza','Freshly baked pizzas','fa-pizza-slice',1,1),
('Burgers','burgers','Juicy burgers','fa-hamburger',2,1),
('Pasta','pasta','Creamy pasta','fa-utensils',3,1),
('Fries','fries','Crispy fries','fa-bowl-food',4,1),
('Sandwiches','sandwiches','Fresh sandwiches','fa-bread-slice',5,1),
('Side Orders','side-orders','Wings, nuggets, shawarma','fa-drumstick-bite',6,1),
('Drinks','drinks','Cold drinks','fa-mug-soda',7,1),
('Deals','deals','Value deals and combos','fa-tags',8,1),
('Desserts','desserts','Sweet treats','fa-ice-cream',9,1);

-- ─── VARIATION GROUPS ─────────────────────────────────────────
INSERT INTO variation_groups (id, name, display_name, type, is_required, min_selections, max_selections, sort_order) VALUES
(1,'pizza_size','Size','single',1,1,1,1),
(2,'pasta_size','Size','single',1,1,1,2),
(3,'wings_qty','Quantity','single',1,1,1,3),
(4,'drink_size','Size','single',1,1,1,4);

-- ─── VARIATION OPTIONS ────────────────────────────────────────
INSERT INTO variation_options (group_id, name, price_delta, absolute_price, sort_order, is_default) VALUES
(1,'Small',0,600,1,0),(1,'Medium',0,1050,2,1),(1,'Large',0,1399,3,0),(1,'X-Large',0,1599,4,0),
(2,'Small',0,400,1,0),(2,'Medium',0,750,2,1),
(3,'5 Pc',0,300,1,0),(3,'10 Pc',0,600,2,1),
(4,'Regular',0,90,1,0),(4,'Half Liter',0,120,2,0),(4,'1 Liter',0,180,3,1),(4,'1.5 Liter',0,210,4,0),(4,'2 Liter',0,250,5,0);

-- ─── PRODUCTS (from menu images) ──────────────────────────────
INSERT INTO products (category_id, name, slug, short_description, price, is_featured, is_bestseller, is_available, status, sort_order) VALUES
-- PIZZA (category_id 1)
(1,'Friends Special Pizza','friends-special-pizza','Loaded with chicken, cheese and fresh vegetables',600,1,1,1,'active',1),
(1,'Crown Crust Pizza','crown-crust-pizza','Cheese-stuffed crown crust with special toppings',1150,1,0,1,'active',2),
(1,'Behari Kabab Pizza','behari-kabab-pizza','Behari kabab chunks with onions and cheese',1150,0,1,1,'active',3),
(1,'Kabab Stuffer Pizza','kabab-stuffer-pizza','Stuffed with kabab and cheese',1250,1,0,1,'active',4),
(1,'Cheese Stuffer Pizza','cheese-stuffer-pizza','Extra cheese stuffed crust',1250,1,0,1,'active',5),
(1,'Double Kabab Pizza','double-kabab-pizza','Double kabab with double cheese',1299,0,0,1,'active',6),
(1,'Lazania Stuff Pizza','lazania-stuff-pizza','Lasagna-inspired stuffed pizza',1150,0,0,1,'active',7),
(1,'Bar B.Q Pizza','bar-b-q-pizza','Smoky BBQ chicken pizza',600,1,1,1,'active',8),
(1,'Special Pizza 4 Season','special-pizza-4-season','Four flavour combination pizza',1150,1,0,1,'active',9),
(1,'Tikka Boti Special','tikka-boti-special','Tikka boti with fresh veggies',600,1,1,1,'active',10),
(1,'Bonfire Pizza','bonfire-pizza','Spicy bonfire special',600,0,0,1,'active',11),
(1,'Traditional Chicken Fajita','traditional-chicken-fajita','Classic chicken fajita pizza',550,0,0,1,'active',12),
(1,'Traditional Chicken Tikka Boti','traditional-chicken-tikka-boti','Traditional chicken tikka boti',550,0,0,1,'active',13),
(1,'Traditional Cheese Lover','traditional-cheese-lover','Loaded with mozzarella cheese',550,0,0,1,'active',14),

-- BURGERS (category_id 2)
(2,'Zinger Burger','zinger-burger','Crispy chicken zinger burger',320,1,1,1,'active',1),
(2,'King Zinger Burger','king-zinger-burger','Double patty king size zinger',370,1,0,1,'active',2),
(2,'Patty Burger','patty-burger','Classic chicken patty burger',300,0,1,1,'active',3),
(2,'Tower Burger','tower-burger','Tall tower burger with layers',499,1,0,1,'active',4),
(2,'Double Taker Burger','double-taker-burger','Double patty double cheese burger',550,0,0,1,'active',5),

-- PASTA (category_id 3)
(3,'Special Pasta','special-pasta','Creamy special pasta',400,1,0,1,'active',1),
(3,'Crunchy Pasta','crunchy-pasta','Crunchy topped pasta',450,0,1,1,'active',2),
(3,'Alfredo Pasta','alfredo-pasta','Classic alfredo pasta',450,0,0,1,'active',3),

-- FRIES (category_id 4)
(4,'Regular Fries','regular-fries','Classic salted fries',200,1,1,1,'active',1),
(4,'Family Fries','family-fries','Family size fries pack',300,1,1,1,'active',2),
(4,'Loaded Fries','loaded-fries','Loaded with cheese and toppings',550,1,0,1,'active',3),
(4,'Chicken Fries','chicken-fries','Fries topped with chicken chunks',500,0,0,1,'active',4),

-- SANDWICHES (category_id 5)
(5,'Mexican Sandwich','mexican-sandwich','Spicy Mexican style sandwich',550,0,0,1,'active',1),
(5,'Jalapeno Sandwich','jalapeno-sandwich','Jalapeno loaded sandwich',600,0,0,1,'active',2),
(5,'Pizza Sandwich','pizza-sandwich','Pizza-flavoured sandwich',699,0,0,1,'active',3),

-- SIDE ORDERS (category_id 6)
(6,'Flaming Wings','flaming-wings','Spicy flaming wings',300,1,1,1,'active',1),
(6,'Hot Wings','hot-wings','Hot and crispy wings',300,1,1,1,'active',2),
(6,'Nuggets','nuggets','Chicken nuggets',300,0,1,1,'active',3),
(6,'Drum Stick','drum-stick','Crispy fried drumstick',250,0,0,1,'active',4),
(6,'Zinger Paratha','zinger-paratha','Zinger with paratha roll',350,0,0,1,'active',5),
(6,'Zinger Shawarma','zinger-shawarma','Zinger shawarma wrap',350,1,1,1,'active',6),
(6,'Chi. Cheese Shawarma','chi-cheese-shawarma','Chicken cheese shawarma',200,0,0,1,'active',7),
(6,'Tortile Wrape','tortile-wrape','Tortilla wrap with filling',450,0,0,1,'active',8),
(6,'Chicken Paratha','chicken-paratha','Chicken paratha roll',300,0,0,1,'active',9),
(6,'Chicken Popcorn','chicken-popcorn','Bite-sized chicken popcorn',500,0,0,1,'active',10),
(6,'Ice Cream Cup','ice-cream-cup','Ice cream cup',150,0,0,1,'active',11),
(6,'Spin Roll','spin-roll','Crispy spin roll',700,0,0,1,'active',12),

-- DRINKS (category_id 7)
(7,'Coke Regular','coke-regular','Regular Coke',90,0,0,1,'active',1),
(7,'Coke Half Liter','coke-half-liter','Half liter Coke',120,0,0,1,'active',2),
(7,'Coke 1 Liter','coke-1-liter','1 liter Coke',180,0,0,1,'active',3),
(7,'Coke 1.5 Liter','coke-15-liter','1.5 liter Coke',210,0,0,1,'active',4),
(7,'Coke 2 Liter','coke-2-liter','2 liter Coke',250,0,0,1,'active',5),
(7,'Water','water','Mineral water',70,0,0,1,'active',6),
(7,'Water 1.5','water-15','1.5 liter water',130,0,0,1,'active',7);

-- ─── ADD-ONS (Extra Toppings) ─────────────────────────────────
INSERT INTO addons (name, price, category, is_active, sort_order) VALUES
('Chicken Topping',50,'topping',1,1),
('Cheese Topping',50,'topping',1,2),
('Cheese Slice',50,'topping',1,3);

-- ─── COMBOS / DEALS ───────────────────────────────────────────
INSERT INTO combos (name, slug, description, fixed_price, is_active, sort_order) VALUES
('Deal 01','deal-01','4 Zinger Burger + Reg Fries + Liter Drink',1400,1,1),
('Deal 02','deal-02','2 Zinger Burger + Patty Burger + Hot Wings + Liter Drink',1499,1,2),
('Deal 03','deal-03','2 Friends Special Pizza (L) + Special Pasta + 1.5 Liter Drink',3250,1,3),
('Deal 04','deal-04','2 Friends Special Pizza (M) + Hot Wings + 1 Liter Drink',2499,1,4),
('Deal 05','deal-05','2 Friends Special Pizza (S) + Regular Fries + 600ml Drink',1450,1,5),
('Deal 06','deal-06','1 Tikka Boti Special Pizza (L) + 1 Zinger Burger Reg. + 1 Liter Drink',2350,1,6),
('Deal 07','deal-07','1 Special Pizza (L) + 1 Special Pizza (S) + 1 Zinger Burger + 1 Patty Burger + 1 Special Pasta + Regular Fries + 1.5 Liter Drink',3250,1,7),
('Deal 08','deal-08','1 Special Pizza (L) + Hot Wings + 1 Liter Drink',1999,1,8),
('Deal 09','deal-09','2 Zinger Burger + 1 Zinger Shawarma + Regular Fries + 1 Liter Drink',1750,1,9),
('Birthday Deal','birthday-deal','2 Tikka Boti Special (L) + Hot Wings + 10 Nuggets + Crunchy Pasta + 1 Pound Cake + 1.5 Liter Drink',4999,1,10),
('Deal 11','deal-11','1 Zinger Burger + Hot Wings + Regular Fries + 500ml Drink',670,1,11);

-- ─── HOMEPAGE SECTIONS ────────────────────────────────────────
INSERT INTO homepage_sections (section_key, title, subtitle, is_enabled, sort_order, desktop_columns, mobile_columns, initial_limit, load_more_count) VALUES
('recommended','Recommended','Handpicked for you',1,1,4,2,8,4),
('bestselling','Best Selling','Customer favorites',1,2,4,2,8,4),
('new_launch','New Launch','Fresh on the menu',1,3,4,2,8,4),
('coming_soon','Coming Soon','Sneak peek',0,4,4,2,4,4),
('limited_deals','Limited Time Deals','Grab them fast',1,5,4,2,8,4),
('reviews','Reviews','What customers say',1,6,3,1,6,3);