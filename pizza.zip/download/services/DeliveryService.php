<?php
// services/DeliveryService.php
class DeliveryService {
    public static function areas(bool $a = true): array { return get_delivery_areas($a); }
    public static function feeForArea(?int $id): float { return get_delivery_fee_for_area($id); }
}