<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('thermal_printer')) {
    flash_error('Thermal printer feature disabled.');
    redirect(url('admin/orders/index.php'));
}

$id = (int)get('id', 0);
$order = get_order($id);
if (!$order) { flash_error('Order not found.'); redirect(url('admin/orders/index.php')); }
$items = get_order_items($id);

$autoPrint = get('print') === '1';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Receipt <?= e($order['order_number']) ?></title>
<link rel="stylesheet" href="<?= asset('css/thermal.css') ?>">
</head>
<body class="thermal-print" <?= $autoPrint ? 'onload="window.print()"' : '' ?>>

<div class="center logo">🍕 FRIENDS PIZZA HUT</div>
<div class="center">The Magician of Taste</div>
<hr>

<div class="center"><?= e(setting('restaurant_address', '')) ?></div>
<div class="center">Tel: <?= e(setting('restaurant_phone', '')) ?></div>
<hr>

<table>
<tr><td class="bold">Order #:</td><td class="right"><?= e($order['order_number']) ?></td></tr>
<tr><td class="bold">Date:</td><td class="right"><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td></tr>
<tr><td class="bold">Type:</td><td class="right"><?= strtoupper($order['order_type']) ?></td></tr>
<?php if ($order['is_scheduled']): ?>
<tr><td class="bold">Scheduled:</td><td class="right"><?= date('d/m H:i', strtotime($order['scheduled_at'])) ?></td></tr>
<?php endif; ?>
</table>
<hr>

<div class="bold">CUSTOMER</div>
<div><?= e($order['customer_name']) ?></div>
<div>Tel: <?= e($order['customer_phone']) ?></div>
<?php if ($order['order_type'] === 'delivery' && $order['delivery_address_snapshot']): ?>
<div class="lg"><?= e($order['delivery_address_snapshot']) ?></div>
<?php if ($order['area']): ?><div>Area: <?= e($order['area']) ?></div><?php endif; ?>
<?php if ($order['landmark']): ?><div>Landmark: <?= e($order['landmark']) ?></div><?php endif; ?>
<?php endif; ?>
<hr>

<div class="bold center">ORDER ITEMS</div>
<hr>

<table>
<?php foreach ($items as $it): ?>
<tr>
  <td colspan="2" class="bold"><?= e($it['product_name']) ?></td>
</tr>
<tr>
  <td><?= (int)$it['quantity'] ?> x <?= number_format($it['unit_price'], 0) ?></td>
  <td class="right"><?= number_format($it['line_total'], 0) ?></td>
</tr>
<?php foreach ($it['options'] as $op): ?>
<tr><td colspan="2" style="padding-left:10px;font-size:10px;">- <?= e($op['variation_option_name']) ?></td></tr>
<?php endforeach; ?>
<?php foreach ($it['addons'] as $ad): ?>
<tr><td colspan="2" style="padding-left:10px;font-size:10px;">+ <?= e($ad['addon_name']) ?> (<?= number_format($ad['addon_price'], 0) ?>)</td></tr>
<?php endforeach; ?>
<?php if ($it['special_instructions']): ?>
<tr><td colspan="2" style="padding-left:10px;font-style:italic;font-size:10px;">Note: <?= e($it['special_instructions']) ?></td></tr>
<?php endif; ?>
<?php endforeach; ?>
</table>
<hr>

<table>
<tr><td>Subtotal</td><td class="right"><?= number_format($order['subtotal'], 0) ?></td></tr>
<?php if ((float)$order['discount_total'] > 0): ?>
<tr><td>Discount</td><td class="right">-<?= number_format($order['discount_total'], 0) ?></td></tr>
<?php endif; ?>
<?php if ((float)$order['delivery_fee'] > 0): ?>
<tr><td>Delivery</td><td class="right"><?= number_format($order['delivery_fee'], 0) ?></td></tr>
<?php endif; ?>
<?php if ((float)$order['tax_amount'] > 0): ?>
<tr><td>Tax</td><td class="right"><?= number_format($order['tax_amount'], 0) ?></td></tr>
<?php endif; ?>
<?php if ((float)$order['service_fee'] > 0): ?>
<tr><td>Service</td><td class="right"><?= number_format($order['service_fee'], 0) ?></td></tr>
<?php endif; ?>
<?php if ((float)$order['packaging_fee'] > 0): ?>
<tr><td>Packaging</td><td class="right"><?= number_format($order['packaging_fee'], 0) ?></td></tr>
<?php endif; ?>
</table>
<hr>

<table>
<tr>
  <td class="bold xl">TOTAL</td>
  <td class="right bold xl">Rs. <?= number_format($order['total'], 0) ?></td>
</tr>
</table>
<hr>

<table>
<tr><td class="bold">Payment:</td><td class="right"><?= strtoupper($order['payment_method']) ?></td></tr>
<tr><td class="bold">Status:</td><td class="right"><?= strtoupper($order['payment_status']) ?></td></tr>
</table>

<?php if ($order['customer_note']): ?>
<hr>
<div class="bold">Customer Note:</div>
<div><?= e($order['customer_note']) ?></div>
<?php endif; ?>

<hr>
<div class="center bold">Shukriya! Thank you!</div>
<div class="center" style="font-size:10px;">Visit again — <?= e(setting('restaurant_phone', '')) ?></div>
<div class="center" style="font-size:9px;margin-top:8px;"><?= date('d/m/Y H:i:s') ?></div>

<div class="no-print" style="margin-top:30px;text-align:center;">
  <button onclick="window.print()" style="padding:10px 20px;background:#dc2626;color:#fff;border:none;border-radius:5px;font-size:14px;cursor:pointer;">
    🖨️ Print Receipt
  </button>
  <a href="<?= url('admin/orders/view.php?id=' . (int)$order['id']) ?>" style="margin-left:10px;color:#666;">← Back</a>
</div>

</body>
</html>