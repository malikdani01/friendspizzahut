<?php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!customer_logged_in()) { flash_error('Login required.'); redirect(url('login.php')); }
if (!is_post()) redirect(url('orders.php'));
verify_csrf();
$orderId = (int)post('order_id', 0);
$order = get_order($orderId);
if (!$order || (int)$order['user_id'] !== (int)$_SESSION['user_id']) {
    flash_error('Order not found.'); redirect(url('orders.php'));
}
if (!can_customer_cancel_order($order)) {
    flash_error('This order cannot be cancelled.'); redirect(url('order-detail.php?id=' . $orderId));
}
cancel_order($orderId, 'Cancelled by customer', 'customer');
flash_success('Order cancelled.');
redirect(url('order-detail.php?id=' . $orderId));