<?php
// sales.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$from = (string)get('from', date('Y-m-01'));
$to = (string)get('to', date('Y-m-d'));
$data = report_sales($from, $to);
$pageTitle = 'Sales Report';
require __DIR__ . '/../common/header.php';
?>
<form class="flex gap-2 mb-5"><input type="date" name="from" value="<?= e($from) ?>" class="border rounded px-3 py-2"><input type="date" name="to" value="<?= e($to) ?>" class="border rounded px-3 py-2"><button class="bg-brand text-white px-4 py-2 rounded">Apply</button></form>
<div class="grid grid-cols-3 gap-4">
  <div class="bg-white rounded-xl p-5 border"><div class="text-xs text-gray-500">Orders</div><div class="text-2xl font-extrabold"><?= number_format((int)$data['orders']) ?></div></div>
  <div class="bg-white rounded-xl p-5 border"><div class="text-xs text-gray-500">Revenue</div><div class="text-2xl font-extrabold text-brand"><?= money($data['revenue']) ?></div></div>
  <div class="bg-white rounded-xl p-5 border"><div class="text-xs text-gray-500">Avg</div><div class="text-2xl font-extrabold"><?= money($data['avg']) ?></div></div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>