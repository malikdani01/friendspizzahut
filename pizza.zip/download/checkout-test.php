<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/common/bootstrap.php';

echo "<pre style='background:#0a0a0a;color:#0f0;padding:20px;font-family:monospace;font-size:13px;line-height:1.7;'>";
echo "═══ CHECKOUT INSERT TEST ═══\n\n";

// Get actual columns
$cols = Database::fetchAll("SHOW COLUMNS FROM orders");
$existingCols = array_column($cols, 'Field');
echo "Orders table columns (" . count($cols) . "):\n";
echo "  " . implode(", ", $existingCols) . "\n\n";

// Try FULL insert with all columns my checkout uses
$testData = [
    'order_number'              => 'TEST-' . date('YmdHis'),
    'user_id'                   => null,
    'customer_name'             => 'Test',
    'customer_phone'            => '03001234567',
    'customer_email'            => null,
    'order_type'                => 'delivery',
    'is_scheduled'              => 0,
    'delivery_address_snapshot' => 'Test Address',
    'city'                      => 'City Tamman',
    'area'                      => null,
    'landmark'                  => null,
    'delivery_notes'            => null,
    'customer_note'             => null,
    'admin_note'                => null,
    'subtotal'                  => 320,
    'discount_total'            => 0,
    'coupon_code'               => null,
    'delivery_fee'              => 50,
    'tax_amount'                => 0,
    'service_fee'               => 0,
    'packaging_fee'             => 0,
    'loyalty_discount'          => 0,
    'total'                     => 370,
    'payment_method'            => 'cod',
    'payment_status'            => 'pending',
    'order_status'              => 'pending',
    'is_first_order'            => 0,
    'ip_address'                => '127.0.0.1',
];

echo "Testing each column individually:\n";
$failed = [];

foreach ($testData as $col => $val) {
    if (!in_array($col, $existingCols, true)) {
        echo "  ❌ MISSING COLUMN: $col\n";
        $failed[] = "Column '$col' does not exist in orders table";
        continue;
    }
    echo "  ✅ $col exists\n";
}

if ($failed) {
    echo "\n═══ ROOT CAUSE FOUND ═══\n";
    echo "Missing columns:\n";
    foreach ($failed as $f) echo "  • $f\n";
    echo "\nFIX: Run SQL below in phpMyAdmin:\n\n";
    
    $sqlFixes = [
        'transaction_id' => "ALTER TABLE orders ADD COLUMN transaction_id VARCHAR(120) NULL;",
        'estimated_minutes' => "ALTER TABLE orders ADD COLUMN estimated_minutes INT NULL;",
        'eta_started_at' => "ALTER TABLE orders ADD COLUMN eta_started_at DATETIME NULL;",
        'eta_set_by' => "ALTER TABLE orders ADD COLUMN eta_set_by INT UNSIGNED NULL;",
        'is_recommended' => "ALTER TABLE orders ADD COLUMN is_recommended TINYINT(1) NOT NULL DEFAULT 0;",
    ];
    
    foreach ($failed as $f) {
        if (preg_match("/Column '(\w+)'/", $f, $m)) {
            $col = $m[1];
            if (isset($sqlFixes[$col])) echo $sqlFixes[$col] . "\n";
        }
    }
    echo "</pre>"; exit;
}

// Now try the actual insert
echo "\n═══ ACTUAL INSERT TEST ═══\n";
try {
    Database::beginTransaction();
    $id = Database::insert('orders', $testData);
    echo "✅ Order insert SUCCESS (ID: $id)\n";
    
    // Test order_items
    try {
        $itemData = [
            'order_id' => $id, 'product_id' => null, 'combo_id' => null,
            'product_name' => 'Test Item', 'product_sku' => null,
            'unit_price' => 320, 'quantity' => 1, 'addons_total' => 0,
            'line_total' => 320, 'special_instructions' => null,
        ];
        Database::insert('order_items', $itemData);
        echo "✅ order_items insert SUCCESS\n";
    } catch (Throwable $e) { echo "❌ order_items FAILED: " . $e->getMessage() . "\n"; }
    
    // Test payments
    try {
        Database::insert('payments', [
            'order_id' => $id, 'method' => 'cod', 'amount' => 370,
            'currency' => 'PKR', 'payment_status' => 'pending',
        ]);
        echo "✅ payments insert SUCCESS\n";
    } catch (Throwable $e) { echo "❌ payments FAILED: " . $e->getMessage() . "\n"; }
    
    // Test order_status_history
    try {
        Database::insert('order_status_history', [
            'order_id' => $id, 'old_status' => null,
            'new_status' => 'pending', 'note' => 'Test',
        ]);
        echo "✅ order_status_history insert SUCCESS\n";
    } catch (Throwable $e) { echo "❌ order_status_history FAILED: " . $e->getMessage() . "\n"; }
    
    // Test notifications
    try {
        Database::insert('notifications', [
            'user_type' => 'admin', 'user_id' => 1, 'type' => 'new_order',
            'title' => 'Test', 'message' => 'Test', 'link' => '/test',
        ]);
        echo "✅ notifications insert SUCCESS\n";
    } catch (Throwable $e) { echo "❌ notifications FAILED: " . $e->getMessage() . "\n"; }
    
    Database::rollback();
    echo "\n🔄 Rolled back\n";
    echo "\n═══ ALL INSERTS WORK — Checkout should work ═══\n";
} catch (Throwable $e) {
    Database::rollback();
    echo "\n❌ FULL INSERT FAILED:\n";
    echo "  Message: " . $e->getMessage() . "\n";
    echo "  File:    " . $e->getFile() . "\n";
    echo "  Line:    " . $e->getLine() . "\n";
}
echo "</pre>";