<?php
function get_combos(bool $activeOnly = true): array {
    $sql = "SELECT * FROM combos";
    if ($activeOnly) $sql .= " WHERE is_active=1";
    $sql .= " ORDER BY sort_order";
    return Database::fetchAll($sql);
}
function get_combo(int $id): ?array {
    return Database::fetch("SELECT * FROM combos WHERE id=?", [$id]);
}
function get_combo_items(int $comboId): array {
    return Database::fetchAll(
        "SELECT ci.*, p.name, p.price FROM combo_items ci
         LEFT JOIN products p ON p.id=ci.product_id
         WHERE ci.combo_id=? ORDER BY ci.sort_order",
        [$comboId]);
}