/**
 * Zoom Control — disables pinch-to-zoom and common keyboard zoom shortcuts
 * Respects normal scrolling & form interaction.
 */
(function() {
  'use strict';

  // ─── Disable Ctrl+Scroll (mouse wheel zoom) ─────────────────
  document.addEventListener('wheel', function(e) {
    if (e.ctrlKey) {
      e.preventDefault();
      return false;
    }
  }, { passive: false });

  // ─── Disable gesture events (Safari pinch) ─────────────────
  document.addEventListener('gesturestart', function(e) { e.preventDefault(); });
  document.addEventListener('gesturechange', function(e) { e.preventDefault(); });
  document.addEventListener('gestureend', function(e) { e.preventDefault(); });

  // ─── Disable double-tap zoom on mobile ─────────────────────
  var lastTouch = 0;
  document.addEventListener('touchend', function(e) {
    var now = Date.now();
    if (now - lastTouch <= 350) {
      e.preventDefault();
    }
    lastTouch = now;
  }, { passive: false });

  // ─── Disable keyboard zoom shortcuts ───────────────────────
  // Ctrl/Cmd + `+`, `-`, `0` (browser zoom)
  document.addEventListener('keydown', function(e) {
    if (!e.ctrlKey && !e.metaKey) return;
    var k = e.key;
    if (k === '+' || k === '=' || k === '-' || k === '_' || k === '0' || k === ')') {
      e.preventDefault();
      return false;
    }
  });

  // ─── Disable multi-touch pinch on mobile browsers ──────────
  document.addEventListener('touchmove', function(e) {
    if (e.touches.length > 1) {
      e.preventDefault();
    }
  }, { passive: false });

  // ─── Reset browser zoom on load (in case user already zoomed) ─
  function resetZoom() {
    // Set scale to 1 if it's not 1
    var meta = document.querySelector('meta[name="viewport"]');
    if (meta && /width=device-width/.test(meta.content)) {
      meta.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover');
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', resetZoom);
  } else {
    resetZoom();
  }
})();