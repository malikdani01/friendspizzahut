<?php
require_once __DIR__ . '/../common/bootstrap.php';
if (!feature_enabled('rider_module')) { redirect(url('index.php')); }
if (empty($_SESSION['rider_id'])) { redirect(url('rider/login.php')); }

$riderId = (int)$_SESSION['rider_id'];

if (is_post()) {
    verify_csrf();
    $action = post('action');
    $orderId = (int)post('order_id', 0);
    if ($action === 'mark_delivered') {
        update_order_status($orderId, 'delivered', null, null, 'Marked delivered by rider');
        flash_success('Order marked as delivered.');
    } elseif ($action === 'mark_picked_up') {
        update_order_status($orderId, 'out_for_delivery', null, null, 'Picked by rider');
        flash_success('Order picked up.');
    } elseif ($action === 'logout') {
        unset($_SESSION['rider_id'], $_SESSION['rider_name']);
        redirect(url('rider/login.php'));
    }
    redirect(url('rider/dashboard.php'));
}

$orders = rider_orders($riderId);
$name = $_SESSION['rider_name'] ?? 'Rider';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rider Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen font-sans">

<header class="bg-brand text-white p-4 flex items-center justify-between sticky top-0 z-30 shadow-lg">
  <div>
    <div class="text-xs opacity-80">Rider</div>
    <div class="font-bold"><?= e($name) ?></div>
  </div>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="logout">
    <button class="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm">
      <i class="fa-solid fa-right-from-bracket"></i> Logout
    </button>
  </form>
</header>

<main class="p-4">
  <h2 class="text-lg font-bold mb-3">My Orders (<?= count($orders) ?>)</h2>

  <?php if (!$orders): ?>
    <div class="bg-white rounded-2xl p-10 text-center text-gray-400">
      <i class="fa-solid fa-inbox text-4xl mb-3"></i>
      <p>Koi active order nahi.</p>
    </div>
  <?php else: foreach ($orders as $o): ?>
    <div class="bg-white rounded-2xl shadow-sm p-5 mb-4">
      <div class="flex justify-between items-start mb-3">
        <div>
          <div class="font-mono text-sm text-gray-500"><?= e($o['order_number']) ?></div>
          <div class="font-bold text-lg"><?= money($o['total']) ?></div>
        </div>
        <span class="text-xs px-3 py-1 rounded-full <?php
          echo match($o['order_status']) {
            'confirmed' => 'bg-blue-100 text-blue-800',
            'preparing' => 'bg-indigo-100 text-indigo-800',
            'ready' => 'bg-purple-100 text-purple-800',
            'out_for_delivery' => 'bg-orange-100 text-orange-800',
            default => 'bg-gray-100 text-gray-800',
          };
        ?>"><?= ucwords(str_replace('_', ' ', $o['order_status'])) ?></span>
      </div>

      <div class="border-t border-b py-3 my-3 space-y-1 text-sm">
        <div class="font-semibold"><?= e($o['customer_name']) ?></div>
        <div class="text-gray-600"><i class="fa-solid fa-phone mr-1"></i>
          <a href="tel:<?= e($o['customer_phone']) ?>" class="underline"><?= e($o['customer_phone']) ?></a>
        </div>
        <?php if ($o['order_type'] === 'delivery' && $o['delivery_address_snapshot']): ?>
        <div class="text-gray-600">
          <i class="fa-solid fa-location-dot mr-1"></i>
          <?= e($o['delivery_address_snapshot']) ?>
          <?php if ($o['area']): ?>, <?= e($o['area']) ?><?php endif; ?>
        </div>
        <?php endif; ?>
      </div>

      <div class="flex gap-2 mt-3">
        <?php if ($o['order_status'] === 'ready'): ?>
        <form method="post" class="flex-1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="mark_picked_up">
          <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
          <button class="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 rounded-lg font-bold">
            <i class="fa-solid fa-motorcycle mr-1"></i> Picked Up
          </button>
        </form>
        <?php elseif ($o['order_status'] === 'out_for_delivery'): ?>
        <form method="post" class="flex-1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="mark_delivered">
          <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
          <button class="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-bold">
            <i class="fa-solid fa-check mr-1"></i> Delivered
          </button>
        </form>
        <?php endif; ?>

        <a href="tel:<?= e($o['customer_phone']) ?>" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-3 rounded-lg font-bold">
          <i class="fa-solid fa-phone"></i>
        </a>
        <?php if ($o['order_type'] === 'delivery' && $o['landmark']): ?>
        <a href="https://www.google.com/maps/search/<?= urlencode($o['delivery_address_snapshot'] . ' ' . $o['landmark']) ?>" target="_blank" class="bg-gray-800 hover:bg-gray-900 text-white px-4 py-3 rounded-lg font-bold">
          <i class="fa-solid fa-map-location-dot"></i>
        </a>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; endif; ?>
</main>

</body>
</html>