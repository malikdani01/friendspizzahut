-- ═══════════════════════════════════════════════════════════════
-- Migration 024: Add-on Sizes (Small/Medium/Large)
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- Add columns to addons table
ALTER TABLE addons 
    ADD COLUMN IF NOT EXISTS has_sizes TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS price_s DECIMAL(12,2) NULL,
    ADD COLUMN IF NOT EXISTS price_m DECIMAL(12,2) NULL,
    ADD COLUMN IF NOT EXISTS price_l DECIMAL(12,2) NULL,
    ADD COLUMN IF NOT EXISTS size_labels VARCHAR(60) NOT NULL DEFAULT 'S,M,L';

-- Update existing 'Chicken Topping' and 'Cheese Topping' to have sizes
UPDATE addons SET has_sizes = 1, price_s = 50, price_m = 100, price_l = 150 
WHERE name LIKE '%Chicken%' AND category = 'topping';

UPDATE addons SET has_sizes = 1, price_s = 50, price_m = 100, price_l = 150 
WHERE name LIKE '%Cheese Topping%' AND category = 'topping';

-- Update existing cart/addon reference for order item to store size
ALTER TABLE cart_item_addons 
    ADD COLUMN IF NOT EXISTS addon_size VARCHAR(10) NULL AFTER addon_name,
    ADD COLUMN IF NOT EXISTS addon_price_s DECIMAL(12,2) NULL AFTER addon_size,
    ADD COLUMN IF NOT EXISTS addon_price_m DECIMAL(12,2) NULL AFTER addon_price_s,
    ADD COLUMN IF NOT EXISTS addon_price_l DECIMAL(12,2) NULL AFTER addon_price_m;

ALTER TABLE order_item_addons 
    ADD COLUMN IF NOT EXISTS addon_size VARCHAR(10) NULL AFTER addon_name;