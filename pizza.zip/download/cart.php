<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Your Cart';

$items = get_cart_items();
$subtotal = calculate_cart_subtotal();
$minOrderCheck = validate_minimum_order($subtotal);
$upsellProducts = upsell_get_products();
$upsellEnabled = upsell_is_enabled();

if (is_post()) {
    verify_csrf();
    $action = post('action');

    // ─── Update single item quantity ────────────────────────
    if ($action === 'set_qty') {
        $cartId = (int)post('id', 0);
        $qty    = (int)post('qty', 1);
        if ($cartId) {
            if ($qty < 1) remove_cart_item($cartId);
            else          update_cart_quantity($cartId, $qty);
        }
        redirect(url('cart.php'));
    }

    // ─── Increment / decrement ──────────────────────────────
    if ($action === 'adjust_qty') {
        $cartId = (int)post('id', 0);
        $delta  = (int)post('delta', 0);
        [$where, $params] = cart_query();
        $row = Database::fetch(
            "SELECT quantity FROM cart_items WHERE id = ? AND $where",
            array_merge([$cartId], $params)
        );
        if ($row) {
            $newQty = (int)$row['quantity'] + $delta;
            if ($newQty < 1) remove_cart_item($cartId);
            else             update_cart_quantity($cartId, $newQty);
        }
        redirect(url('cart.php'));
    }

    // ─── Remove item ────────────────────────────────────────
    if ($action === 'remove') {
        remove_cart_item((int)post('id', 0));
        flash_success('Item removed from cart.');
        redirect(url('cart.php'));
    }

    // ─── Clear entire cart ──────────────────────────────────
    if ($action === 'clear') {
        clear_cart();
        flash_info('Cart cleared.');
        redirect(url('cart.php'));
    }

    // ─── Upsell: add one ────────────────────────────────────
    if ($action === 'upsell_add') {
        $pid = (int)post('product_id', 0);
        if (upsell_get_price($pid) === null) {
            flash_error('Product not available.');
            redirect(url('cart.php'));
        }
        $r = add_to_cart($pid, 1, [], [], '');
        if (!$r['ok']) flash_error($r['error'] ?? 'Could not add.');
        redirect(url('cart.php'));
    }

    // ─── Upsell: remove one ─────────────────────────────────
    if ($action === 'upsell_remove') {
        $pid = (int)post('product_id', 0);
        [$where, $params] = cart_query();
        $row = Database::fetch(
            "SELECT ci.id, ci.quantity
             FROM cart_items ci
             WHERE ci.product_id = ? AND ci.$where
               AND NOT EXISTS (SELECT 1 FROM cart_item_options WHERE cart_item_id = ci.id)
               AND NOT EXISTS (SELECT 1 FROM cart_item_addons WHERE cart_item_id = ci.id)
             ORDER BY ci.id ASC LIMIT 1",
            array_merge([$pid], $params)
        );
        if ($row) {
            if ((int)$row['quantity'] > 1) {
                update_cart_quantity((int)$row['id'], (int)$row['quantity'] - 1);
            } else {
                remove_cart_item((int)$row['id']);
            }
        }
        redirect(url('cart.php'));
    }

    redirect(url('cart.php'));
}

$placeholder = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCBmaWxsPSIjMWExYTFhIiB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIvPjx0ZXh0IHg9IjEwMCIgeT0iMTE1IiBmb250LXNpemU9IjgwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj7wn42VPC90ZXh0Pjwvc3ZnPg==';

require __DIR__ . '/common/header.php';
?>

<style>
.cart-wrap { max-width: 800px; margin: 0 auto; padding: 16px 16px 140px; box-sizing: border-box; }
.cart-wrap * { box-sizing: border-box; }
.cart-title { font-size: 26px; font-weight: 900; color: #fff; margin: 0 0 20px; display: flex; align-items: center; gap: 10px; }
.cart-title i { color: #dc2626; font-size: 22px; }

/* Cart item card */
.ci {
  position: relative;
  display: flex; gap: 12px;
  padding: 14px;
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
  margin-bottom: 12px;
}
.ci-img {
  width: 76px; height: 76px; flex-shrink: 0;
  background: #111;
  border-radius: 12px;
  overflow: hidden;
  display: flex; align-items: center; justify-content: center;
}
.ci-img img { width: 100%; height: 100%; object-fit: cover; }
.ci-body { flex: 1; min-width: 0; padding-right: 36px; }
.ci-name { font-size: 15px; font-weight: 700; color: #fff; margin: 0 0 4px; line-height: 1.3; }
.ci-opt { font-size: 12px; color: rgba(255,255,255,0.5); margin: 2px 0; }
.ci-row {
  display: flex; align-items: center; justify-content: space-between;
  gap: 10px; margin-top: 12px; flex-wrap: wrap;
}
.ci-price { font-size: 16px; font-weight: 800; color: #dc2626; white-space: nowrap; margin-left: auto; }

/* Remove button */
.ci-remove {
  position: absolute; top: 8px; right: 8px;
  width: 32px; height: 32px; border-radius: 50%;
  background: rgba(220,38,38,0.15);
  border: 0; color: #f87171; font-size: 13px;
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all .15s;
}
.ci-remove:hover { background: #dc2626; color: #fff; }

/* Quantity control */
.qty-box {
  display: inline-flex; align-items: center;
  border: 1.5px solid rgba(255,255,255,0.15);
  border-radius: 10px;
  background: rgba(0,0,0,0.35);
  overflow: hidden;
}
.qty-box button {
  width: 36px; height: 36px;
  background: transparent; color: #fff;
  border: 0; cursor: pointer;
  font-size: 18px; font-weight: 800;
  display: flex; align-items: center; justify-content: center;
  transition: background .15s;
}
.qty-box button:active { background: rgba(255,255,255,0.1); }
.qty-box button.plus { color: #dc2626; }
.qty-box button.plus:hover { background: rgba(220,38,38,0.15); }
.qty-box button.minus:disabled { opacity: 0.3; cursor: not-allowed; }
.qty-box .num {
  min-width: 38px; text-align: center;
  font-size: 15px; font-weight: 800; color: #fff;
  padding: 0 6px;
  line-height: 36px;
}

/* Actions */
.cart-actions { display: flex; gap: 10px; margin: 16px 0 24px; flex-wrap: wrap; }
.cart-btn {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 10px 16px; border-radius: 10px; border: 0;
  font-weight: 700; font-size: 13px; cursor: pointer;
  background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.85);
}
.cart-btn:hover { background: rgba(255,255,255,0.15); }
.cart-btn-danger {
  background: rgba(220,38,38,0.15);
  color: #f87171;
  border: 1px solid rgba(220,38,38,0.3);
}

/* Summary */
.cart-summary {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
  padding: 20px;
}
.cart-summary h3 { font-size: 17px; font-weight: 800; color: #fff; margin: 0 0 14px; }
.summary-row { display: flex; justify-content: space-between; padding: 9px 0; font-size: 14px; color: rgba(255,255,255,0.72); }
.summary-row.total { border-top: 1.5px solid rgba(255,255,255,0.1); padding-top: 14px; margin-top: 6px; font-size: 17px; font-weight: 800; color: #fff; }
.summary-row.total span:last-child { color: #dc2626; font-size: 22px; }

.checkout-btn {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  width: 100%; margin-top: 18px; padding: 16px;
  background: #dc2626; color: #fff;
  border: 0; border-radius: 12px;
  font-size: 15px; font-weight: 800;
  text-align: center; text-decoration: none;
  box-shadow: 0 8px 20px rgba(220,38,38,0.35);
}
.checkout-btn:active { transform: scale(0.98); }
.checkout-btn.disabled { background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.4); box-shadow: none; pointer-events: none; }
.warn-box { background: rgba(234,179,8,0.12); border: 1px solid rgba(234,179,8,0.35); color: #fcd34d; padding: 12px 14px; border-radius: 10px; font-size: 13px; margin-top: 12px; }

/* Empty */
.cart-empty {
  text-align: center; padding: 60px 20px;
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
}
.cart-empty i { font-size: 56px; color: rgba(255,255,255,0.15); margin-bottom: 16px; display: block; }
.cart-empty p { color: rgba(255,255,255,0.6); font-size: 15px; margin: 0 0 20px; }
.cart-empty a { display: inline-block; background: #dc2626; color: #fff; padding: 12px 24px; border-radius: 12px; font-weight: 700; text-decoration: none; }

/* ═══ Complete Your Meal ═══ */
.upsell-section { margin-top: 32px; }
.upsell-head { margin-bottom: 14px; }
.upsell-head h3 { font-size: 20px; font-weight: 900; color: #fff; margin: 0 0 4px; display: flex; align-items: center; gap: 8px; }
.upsell-head p { font-size: 13px; color: rgba(255,255,255,0.55); margin: 0; }

.upsell-list { display: grid; grid-template-columns: 1fr; gap: 10px; }
@media (min-width: 640px) { .upsell-list { grid-template-columns: 1fr 1fr; } }

.upsell-item {
  display: flex; align-items: center; gap: 12px;
  padding: 12px;
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  transition: border-color .2s, background .2s;
}
.upsell-item.has-qty { border-color: rgba(220,38,38,0.4); background: rgba(220,38,38,0.05); }
.upsell-img {
  width: 60px; height: 60px; flex-shrink: 0;
  background: #111; border-radius: 10px;
  overflow: hidden;
  display: flex; align-items: center; justify-content: center;
}
.upsell-img img { width: 100%; height: 100%; object-fit: cover; }
.upsell-body { flex: 1; min-width: 0; }
.upsell-name { font-size: 13.5px; font-weight: 700; color: #fff; margin-bottom: 3px; line-height: 1.25; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.upsell-price { font-size: 13.5px; font-weight: 800; color: #dc2626; }
.upsell-price-old { font-size: 11px; color: rgba(255,255,255,0.35); text-decoration: line-through; margin-left: 5px; font-weight: 500; }
.upsell-qty {
  display: inline-flex; align-items: center;
  border: 1.5px solid rgba(255,255,255,0.15);
  border-radius: 10px;
  background: rgba(0,0,0,0.35);
  overflow: hidden;
  flex-shrink: 0;
}
.upsell-qty button {
  width: 34px; height: 34px;
  border: 0; background: transparent;
  color: #fff; font-size: 16px; font-weight: 800;
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: background .15s;
}
.upsell-qty button.plus { color: #dc2626; }
.upsell-qty button.plus:hover { background: rgba(220,38,38,0.15); }
.upsell-qty button.minus:disabled { opacity: 0.3; cursor: not-allowed; }
.upsell-qty .num {
  min-width: 30px; text-align: center;
  font-size: 14px; font-weight: 800; color: #fff;
  padding: 0 4px;
  line-height: 34px;
}
.upsell-item.has-qty .upsell-qty .num { color: #dc2626; }
</style>

<div class="cart-wrap">

  <h1 class="cart-title"><i class="fa-solid fa-cart-shopping"></i> Your Cart</h1>

  <?php if (!$items): ?>
    <div class="cart-empty">
      <i class="fa-solid fa-cart-shopping"></i>
      <p>Your cart is empty</p>
      <a href="<?= url('menu.php') ?>">Browse Menu</a>
    </div>
  <?php else: ?>

    <?php foreach ($items as $it):
      $img = !empty($it['image']) ? upload_url($it['image']) : $placeholder;
    ?>
      <div class="ci">
        <button type="button" class="ci-remove" title="Remove" onclick="cartRemove(<?= (int)$it['id'] ?>)">
          <i class="fa-solid fa-trash"></i>
        </button>
        <div class="ci-img">
          <img src="<?= e($img) ?>" onerror="this.onerror=null;this.src='<?= $placeholder ?>'" alt="<?= e($it['name']) ?>">
        </div>
        <div class="ci-body">
          <div class="ci-name"><?= e($it['name']) ?></div>
          <?php foreach ($it['options'] as $op): ?>
            <div class="ci-opt">• <?= e($op['option_name']) ?></div>
          <?php endforeach; ?>
          <?php foreach ($it['addons'] as $ad): ?>
            <div class="ci-opt">+ <?= e($ad['addon_name']) ?> (<?= money($ad['addon_price']) ?>)</div>
          <?php endforeach; ?>
          <?php if (!empty($it['special_instructions'])): ?>
            <div class="ci-opt"><em>Note: <?= e($it['special_instructions']) ?></em></div>
          <?php endif; ?>

          <div class="ci-row">
            <div class="qty-box">
              <button type="button" class="minus" onclick="cartAdjust(<?= (int)$it['id'] ?>, -1)">−</button>
              <span class="num"><?= (int)$it['quantity'] ?></span>
              <button type="button" class="plus" onclick="cartAdjust(<?= (int)$it['id'] ?>, 1)">+</button>
            </div>
            <div class="ci-price"><?= money($it['line_total']) ?></div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>

    <div class="cart-actions">
      <button type="button" class="cart-btn cart-btn-danger" onclick="cartClear()">
        <i class="fa-solid fa-trash"></i> Clear Cart
      </button>
    </div>

    <div class="cart-summary">
      <h3>Order Summary</h3>
      <div class="summary-row">
        <span>Subtotal</span>
        <span style="color:#fff;font-weight:700;"><?= money($subtotal) ?></span>
      </div>
      <div class="summary-row">
        <span>Delivery</span>
        <span style="color:rgba(255,255,255,0.4);font-size:12px;">calculated at checkout</span>
      </div>
      <div class="summary-row total">
        <span>Total (approx)</span>
        <span><?= money($subtotal) ?></span>
      </div>

      <?php if (!$minOrderCheck['ok']): ?>
        <div class="warn-box">⚠️ <?= e($minOrderCheck['error']) ?></div>
      <?php endif; ?>

      <a href="<?= $minOrderCheck['ok'] ? url('checkout.php') : '#' ?>" class="checkout-btn <?= !$minOrderCheck['ok'] ? 'disabled' : '' ?>">
        Proceed to Checkout <i class="fa-solid fa-arrow-right"></i>
      </a>
    </div>

    <?php if ($upsellEnabled && $upsellProducts): ?>
      <div class="upsell-section">
        <div class="upsell-head">
          <h3><?= e(setting('upsell_heading', 'Complete Your Meal 🍟')) ?></h3>
          <p><?= e(setting('upsell_subtitle', 'Make your order even better!')) ?></p>
        </div>

        <div class="upsell-list">
          <?php foreach ($upsellProducts as $up):
            $img = !empty($up['image']) ? upload_url($up['image']) : $placeholder;
            $hasQty = $up['qty_in_cart'] > 0;
          ?>
            <div class="upsell-item <?= $hasQty ? 'has-qty' : '' ?>">
              <div class="upsell-img">
                <img src="<?= e($img) ?>" onerror="this.onerror=null;this.src='<?= $placeholder ?>'" alt="<?= e($up['name']) ?>">
              </div>
              <div class="upsell-body">
                <div class="upsell-name"><?= e($up['name']) ?></div>
                <div class="upsell-price">
                  <?= money($up['price']) ?>
                  <?php if ($up['sale_price'] && $up['sale_price'] < $up['original_price']): ?>
                    <span class="upsell-price-old"><?= money($up['original_price']) ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <div class="upsell-qty">
                <button type="button"
                        class="minus"
                        <?= $up['qty_in_cart'] < 1 ? 'disabled' : '' ?>
                        onclick="upsellChange(<?= (int)$up['product_id'] ?>, -1)">−</button>
                <span class="num"><?= (int)$up['qty_in_cart'] ?></span>
                <button type="button"
                        class="plus"
                        onclick="upsellChange(<?= (int)$up['product_id'] ?>, 1)">+</button>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

  <?php endif; ?>
</div>

<!-- Hidden action form -->
<form method="post" id="cartActionForm" style="display:none;">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="" id="caf_action">
  <input type="hidden" name="id" value="" id="caf_id">
  <input type="hidden" name="delta" value="" id="caf_delta">
  <input type="hidden" name="product_id" value="" id="caf_pid">
</form>

<script>
function submitAction(action, data) {
  var f = document.getElementById('cartActionForm');
  document.getElementById('caf_action').value = action;
  document.getElementById('caf_id').value = data.id || '';
  document.getElementById('caf_delta').value = data.delta || '';
  document.getElementById('caf_pid').value = data.product_id || '';
  f.submit();
}

function cartAdjust(id, delta) {
  submitAction('adjust_qty', { id: id, delta: delta });
}

function cartRemove(id) {
  if (!confirm('Remove this item from cart?')) return;
  submitAction('remove', { id: id });
}

function cartClear() {
  if (!confirm('Clear entire cart?')) return;
  submitAction('clear', {});
}

function upsellChange(productId, delta) {
  if (delta > 0) {
    submitAction('upsell_add', { product_id: productId });
  } else {
    submitAction('upsell_remove', { product_id: productId });
  }
}
</script>

<?php require __DIR__ . '/common/footer.php'; ?>