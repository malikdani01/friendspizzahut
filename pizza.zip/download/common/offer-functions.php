<?php
function get_active_offers(): array {
    $now = date('Y-m-d H:i:s');
    return Database::fetchAll(
        "SELECT * FROM offers WHERE is_active=1 AND (start_date IS NULL OR start_date<=?) AND (end_date IS NULL OR end_date>=?) ORDER BY sort_order",
        [$now, $now]);
}
function get_offer(int $id): ?array { return Database::fetch("SELECT * FROM offers WHERE id=?", [$id]); }
function calculate_offer_discount(array $offer, float $subtotal): float {
    if ((float)$offer['min_order'] > 0 && $subtotal < (float)$offer['min_order']) return 0;
    $disc = 0;
    if ($offer['offer_type'] === 'percentage') {
        $disc = $subtotal * (float)$offer['discount_value'] / 100;
        if ($offer['max_discount'] && $disc > (float)$offer['max_discount']) $disc = (float)$offer['max_discount'];
    } elseif ($offer['offer_type'] === 'fixed') {
        $disc = (float)$offer['discount_value'];
    }
    return min($disc, $subtotal);
}