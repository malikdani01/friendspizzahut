<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('staff_roles')) redirect(url('admin/dashboard.php'));
$id = (int)get('id', 0);
$s = Database::fetch("SELECT * FROM staff WHERE id=?", [$id]);
if (!$s) { flash_error('Not found.'); redirect(url('admin/staff/index.php')); }
$pageTitle = 'Edit Staff';
$errors = [];
$roles = Database::fetchAll("SELECT * FROM roles ORDER BY name");
if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name',''));
    $username = trim((string)post('username',''));
    if (strlen($name) < 2) $errors[] = 'Name too short.';
    if (!$username) $errors[] = 'Username required.';
    if (Database::fetch("SELECT id FROM staff WHERE username=? AND id!=?", [$username, $id])) $errors[] = 'Username taken.';
    if (!$errors) {
        $data = [
            'name' => $name, 'username' => $username,
            'email' => trim((string)post('email','')) ?: null,
            'role_id' => (int)post('role_id') ?: null,
            'is_active' => post('is_active') ? 1 : 0,
        ];
        if ($pw = (string)post('password','')) {
            if (strlen($pw) < 6) $errors[] = 'Password 6+ chars.';
            else $data['password_hash'] = password_hash($pw, PASSWORD_DEFAULT);
        }
        if (!$errors) {
            Database::update('staff', $data, 'id=:id', ['id'=>$id]);
            flash_success('Updated.');
            redirect(url('admin/staff/index.php'));
        }
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl">
  <?php if ($errors): ?><div class="bg-red-50 text-red-700 px-4 py-3 rounded mb-4"><?php foreach($errors as $e_) echo '• '.e($e_).'<br>'; ?></div><?php endif; ?>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input name="name" required value="<?= e($s['name']) ?>" class="w-full border rounded px-3 py-2">
    <input name="username" required value="<?= e($s['username']) ?>" class="w-full border rounded px-3 py-2">
    <input type="email" name="email" value="<?= e($s['email']) ?>" class="w-full border rounded px-3 py-2">
    <input type="password" name="password" placeholder="New password (leave blank to keep)" class="w-full border rounded px-3 py-2">
    <select name="role_id" class="w-full border rounded px-3 py-2">
      <option value="">— No role —</option>
      <?php foreach ($roles as $r): ?><option value="<?= (int)$r['id'] ?>" <?= $s['role_id']==$r['id']?'selected':'' ?>><?= e($r['name']) ?></option><?php endforeach; ?>
    </select>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" <?= $s['is_active']?'checked':'' ?>> Active</label>
    <div class="flex gap-2">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
      <a href="<?= url('admin/staff/index.php') ?>" class="px-6 py-2.5 rounded-lg bg-gray-100">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>