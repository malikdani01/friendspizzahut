<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Payment Methods';

$testResult = null;

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        // COD toggle
        update_setting('cod_enabled', isset($_POST['cod_enabled']) ? '1' : '0');

        // Pickup
        update_setting('pickup_enabled', isset($_POST['pickup_enabled']) ? '1' : '0');

        // Bank transfer always OFF (removed)
        update_setting('bank_transfer_enabled', '0');

        // Easypaisa
        update_setting('easypaisa_enabled', isset($_POST['easypaisa_enabled']) ? '1' : '0');
        foreach (['easypaisa_mode','easypaisa_store_id','easypaisa_hash_key','easypaisa_username','easypaisa_password','easypaisa_mobile_number'] as $k) {
            update_setting($k, (string)post($k, ''));
        }

        // JazzCash
        update_setting('jazzcash_enabled', isset($_POST['jazzcash_enabled']) ? '1' : '0');
        foreach (['jazzcash_mode','jazzcash_merchant_id','jazzcash_password','jazzcash_integrity_salt'] as $k) {
            update_setting($k, (string)post($k, ''));
        }

        flash_success('Payment settings saved.');
        redirect(url('admin/integrations/payments.php'));

    } elseif ($action === 'test_easypaisa') {
        try {
            $testOrder = ['order_number' => 'TEST-' . time(), 'total' => 100, 'customer_email' => 'test@test.com', 'customer_phone' => '03001234567'];
            $form = easypaisa_build_form($testOrder);
            $testResult = ['ok' => true, 'msg' => 'Easypaisa form generated. Sandbox mein test karo.'];
        } catch (Throwable $e) {
            $testResult = ['ok' => false, 'msg' => 'Failed: ' . $e->getMessage()];
        }
    } elseif ($action === 'test_jazzcash') {
        try {
            $testOrder = ['order_number' => 'TEST-' . time(), 'total' => 100];
            $url = jazzcash_build_redirect_url($testOrder);
            $testResult = ['ok' => true, 'msg' => 'JazzCash URL generated.', 'url' => $url];
        } catch (Throwable $e) {
            $testResult = ['ok' => false, 'msg' => 'Failed: ' . $e->getMessage()];
        }
    }
}

require __DIR__ . '/../common/header.php';
?>

<div class="max-w-4xl space-y-5">

  <?php if ($testResult): ?>
    <div class="<?= $testResult['ok'] ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800' ?> border px-4 py-3 rounded-lg text-sm">
      <?= e($testResult['msg']) ?>
      <?php if (!empty($testResult['url'])): ?>
        <div class="mt-2"><a href="<?= e($testResult['url']) ?>" target="_blank" class="underline">Test URL →</a></div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <form method="post" class="space-y-5">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">

    <!-- Order Methods -->
    <div class="bg-white rounded-xl shadow-sm border p-6">
      <h3 class="font-bold mb-3 text-brand flex items-center gap-2">
        <i class="fa-solid fa-truck-fast"></i> Order Methods
      </h3>
      <div class="space-y-2">
        <label class="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:border-brand">
          <input type="checkbox" name="cod_enabled" value="1" <?= setting('cod_enabled') === '1' ? 'checked' : '' ?> class="w-4 h-4">
          <div>
            <div class="font-semibold">Cash on Delivery (COD)</div>
            <div class="text-xs text-gray-500">Customer pays when order delivered</div>
          </div>
        </label>
        <label class="flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:border-brand">
          <input type="checkbox" name="pickup_enabled" value="1" <?= setting('pickup_enabled', '1') === '1' ? 'checked' : '' ?> class="w-4 h-4">
          <div>
            <div class="font-semibold">Pickup</div>
            <div class="text-xs text-gray-500">Customer picks order from restaurant</div>
          </div>
        </label>
      </div>
    </div>

    <!-- Easypaisa -->
    <div class="bg-white rounded-xl shadow-sm border p-6">
      <h3 class="font-bold mb-3 text-brand flex items-center gap-2">
        <i class="fa-solid fa-mobile-screen"></i> Easypaisa
      </h3>

      <label class="flex items-center gap-2 mb-4 p-3 bg-green-50 rounded-lg border border-green-200">
        <input type="checkbox" name="easypaisa_enabled" value="1" <?= setting('easypaisa_enabled') === '1' ? 'checked' : '' ?> class="w-4 h-4">
        <span class="font-semibold">Enable Easypaisa</span>
      </label>

      <div class="grid md:grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-semibold mb-1">Mode</label>
          <select name="easypaisa_mode" class="w-full border rounded-lg px-3 py-2">
            <option value="sandbox" <?= setting('easypaisa_mode','sandbox') === 'sandbox' ? 'selected' : '' ?>>Sandbox (Testing)</option>
            <option value="live" <?= setting('easypaisa_mode') === 'live' ? 'selected' : '' ?>>Live (Production)</option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Mobile Number</label>
          <input name="easypaisa_mobile_number" value="<?= e(setting('easypaisa_mobile_number','')) ?>" placeholder="03XXXXXXXXX" class="w-full border rounded-lg px-3 py-2 font-mono text-sm">
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Store ID</label>
          <input name="easypaisa_store_id" value="<?= e(setting('easypaisa_store_id','')) ?>" placeholder="Store ID" class="w-full border rounded-lg px-3 py-2 font-mono text-sm">
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Hash Key</label>
          <input name="easypaisa_hash_key" value="<?= e(setting('easypaisa_hash_key','')) ?>" placeholder="Hash Key" class="w-full border rounded-lg px-3 py-2 font-mono text-sm">
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Username</label>
          <input name="easypaisa_username" value="<?= e(setting('easypaisa_username','')) ?>" class="w-full border rounded-lg px-3 py-2 font-mono text-sm">
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Password</label>
          <input type="password" name="easypaisa_password" value="<?= e(setting('easypaisa_password','')) ?>" class="w-full border rounded-lg px-3 py-2 font-mono text-sm">
        </div>
      </div>
    </div>

    <!-- JazzCash -->
    <div class="bg-white rounded-xl shadow-sm border p-6">
      <h3 class="font-bold mb-3 text-brand flex items-center gap-2">
        <i class="fa-solid fa-mobile-screen"></i> JazzCash
      </h3>

      <label class="flex items-center gap-2 mb-4 p-3 bg-red-50 rounded-lg border border-red-200">
        <input type="checkbox" name="jazzcash_enabled" value="1" <?= setting('jazzcash_enabled') === '1' ? 'checked' : '' ?> class="w-4 h-4">
        <span class="font-semibold">Enable JazzCash</span>
      </label>

      <div class="grid md:grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-semibold mb-1">Mode</label>
          <select name="jazzcash_mode" class="w-full border rounded-lg px-3 py-2">
            <option value="sandbox" <?= setting('jazzcash_mode','sandbox') === 'sandbox' ? 'selected' : '' ?>>Sandbox</option>
            <option value="live" <?= setting('jazzcash_mode') === 'live' ? 'selected' : '' ?>>Live</option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Merchant ID</label>
          <input name="jazzcash_merchant_id" value="<?= e(setting('jazzcash_merchant_id','')) ?>" class="w-full border rounded-lg px-3 py-2 font-mono text-sm">
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Password</label>
          <input type="password" name="jazzcash_password" value="<?= e(setting('jazzcash_password','')) ?>" class="w-full border rounded-lg px-3 py-2 font-mono text-sm">
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Integrity Salt</label>
          <input name="jazzcash_integrity_salt" value="<?= e(setting('jazzcash_integrity_salt','')) ?>" class="w-full border rounded-lg px-3 py-2 font-mono text-sm">
        </div>
      </div>
    </div>

    <button class="bg-brand hover:bg-red-700 text-white px-8 py-3 rounded-lg font-bold shadow-lg">
      <i class="fa-solid fa-save mr-2"></i> Save Payment Settings
    </button>
  </form>

  <!-- Tests -->
  <div class="grid md:grid-cols-2 gap-5">
    <div class="bg-white rounded-xl shadow-sm border p-6">
      <h3 class="font-bold mb-3">Test Easypaisa</h3>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="test_easypaisa">
        <button class="w-full bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg font-semibold">
          <i class="fa-solid fa-vial mr-1"></i> Generate Test Form
        </button>
      </form>
    </div>
    <div class="bg-white rounded-xl shadow-sm border p-6">
      <h3 class="font-bold mb-3">Test JazzCash</h3>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="test_jazzcash">
        <button class="w-full bg-red-600 hover:bg-red-700 text-white py-2.5 rounded-lg font-semibold">
          <i class="fa-solid fa-vial mr-1"></i> Generate Test URL
        </button>
      </form>
    </div>
  </div>

  <!-- Setup guides -->
  <div class="grid md:grid-cols-2 gap-5">
    <div class="bg-green-50 border border-green-200 rounded-xl p-5 text-sm text-green-900">
      <div class="font-bold mb-2"><i class="fa-solid fa-info-circle mr-1"></i> Easypaisa Setup</div>
      <ol class="list-decimal list-inside space-y-1 text-xs">
        <li>easypay.easypaisa.com.pk pe merchant registration</li>
        <li>Business documents submit karo</li>
        <li>Store ID + Hash Key milenge approval ke baad</li>
        <li>Sandbox test: easypaystg.easypaisa.com.pk</li>
        <li>Live ke liye production credentials</li>
      </ol>
    </div>
    <div class="bg-red-50 border border-red-200 rounded-xl p-5 text-sm text-red-900">
      <div class="font-bold mb-2"><i class="fa-solid fa-info-circle mr-1"></i> JazzCash Setup</div>
      <ol class="list-decimal list-inside space-y-1 text-xs">
        <li>jazzcash.com.pk → Become a Merchant</li>
        <li>CNIC + NTN + Bank account submit</li>
        <li>Merchant ID + Password + Salt milenge</li>
        <li>Sandbox: sandbox.jazzcash.com.pk</li>
        <li>Approval time: 3-7 din</li>
      </ol>
    </div>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>