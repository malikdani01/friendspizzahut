<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id', 0);
$cat = get_category($id);
if (!$cat) { flash_error('Category not found.'); redirect(url('admin/categories/index.php')); }

$pageTitle = 'Edit Category';
$errors = [];

if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name', ''));
    if (strlen($name) < 2) $errors[] = 'Name is required.';

    $image = $cat['image'];
    if (!empty($_FILES['image']['name'])) {
        $r = save_uploaded_image($_FILES['image'], 'categories');
        if (!$r['ok']) $errors[] = $r['error'];
        else {
            if ($cat['image'] && file_exists(UPLOAD_PATH . '/' . $cat['image'])) @unlink(UPLOAD_PATH . '/' . $cat['image']);
            $image = $r['path'];
        }
    }

    if (!$errors) {
        Database::update('categories', [
            'name' => $name,
            'slug' => generate_category_slug($name, $id),
            'description' => trim((string)post('description', '')) ?: null,
            'icon' => trim((string)post('icon', '')) ?: null,
            'image' => $image,
            'sort_order' => (int)post('sort_order', 0),
            'is_active' => post('is_active') ? 1 : 0,
        ], 'id = :id', ['id' => $id]);
        flash_success('Category updated.');
        redirect(url('admin/categories/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-2xl">
  <?php if ($errors): ?>
    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
      <?php foreach ($errors as $er) echo '• ' . e($er) . '<br>'; ?>
    </div>
  <?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
    <?= csrf_field() ?>
    <div>
      <label class="block text-sm font-semibold mb-1">Name *</label>
      <input name="name" required value="<?= e($cat['name']) ?>" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none">
    </div>
    <div>
      <label class="block text-sm font-semibold mb-1">Description</label>
      <textarea name="description" rows="2" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none"><?= e($cat['description']) ?></textarea>
    </div>
    <div class="grid grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-semibold mb-1">Icon</label>
        <input name="icon" value="<?= e($cat['icon']) ?>" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Sort Order</label>
        <input type="number" name="sort_order" value="<?= (int)$cat['sort_order'] ?>" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none">
      </div>
    </div>
    <div>
      <label class="block text-sm font-semibold mb-1">Image</label>
      <?php if ($cat['image']): ?>
        <div class="mb-2"><img src="<?= upload_url($cat['image']) ?>" class="w-24 h-24 object-cover rounded-lg border"></div>
      <?php endif; ?>
      <input type="file" name="image" accept="image/*" class="w-full border border-gray-300 rounded-lg px-3 py-2">
    </div>
    <label class="flex items-center gap-2 text-sm">
      <input type="checkbox" name="is_active" value="1" <?= $cat['is_active'] ? 'checked' : '' ?> class="w-4 h-4"> Active
    </label>
    <div class="flex gap-2 pt-2">
      <button class="bg-brand hover:bg-red-700 text-white px-6 py-2.5 rounded-lg font-semibold">Save Changes</button>
      <a href="<?= url('admin/categories/index.php') ?>" class="px-6 py-2.5 rounded-lg bg-gray-100 hover:bg-gray-200 font-semibold">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>