<?php
require_once __DIR__ . '/../common/bootstrap.php';

if (admin_logged_in()) redirect(url('admin/dashboard.php'));

$error = '';
if (is_post()) {
    verify_csrf();
    $result = admin_login((string)post('username', ''), (string)post('password', ''));
    if ($result['ok']) {
        flash_success('Welcome back, ' . $result['admin']['name'] . '!');
        redirect(url('admin/dashboard.php'));
    }
    $error = $result['error'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#0a0a0a">
<title>Admin Login — <?= e(setting('restaurant_name', 'Friends Pizza Hut')) ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
/* ═══════════════════════════════════════════════════════════════
   ADMIN LOGIN — Fully Standalone Dark Theme
   ═══════════════════════════════════════════════════════════════ */

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body {
  height: 100%;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  font-size: 15px;
  line-height: 1.5;
  background: #0a0a0a;
  color: #f9fafb;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  overflow-x: hidden;
}

/* ─── Animated background ────────────────────────────────────── */
.login-bg {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  position: relative;
  background: radial-gradient(circle at 20% 30%, rgba(220,38,38,0.15), transparent 50%),
              radial-gradient(circle at 80% 70%, rgba(220,38,38,0.1), transparent 50%),
              #0a0a0a;
  overflow: hidden;
}

/* Floating pizza decoration */
.login-bg::before,
.login-bg::after {
  content: '';
  position: absolute;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(220,38,38,0.15), transparent 70%);
  animation: loginFloat 12s ease-in-out infinite;
  pointer-events: none;
}
.login-bg::before {
  width: 400px; height: 400px;
  top: -150px; left: -150px;
}
.login-bg::after {
  width: 500px; height: 500px;
  bottom: -200px; right: -200px;
  animation-delay: -6s;
}
@keyframes loginFloat {
  0%, 100% { transform: translate(0, 0) scale(1); }
  50%      { transform: translate(30px, -30px) scale(1.1); }
}

/* ─── Card ───────────────────────────────────────────────────── */
.login-card {
  width: 100%;
  max-width: 440px;
  background: linear-gradient(180deg, #1a1a1a 0%, #141414 100%);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 24px;
  padding: 36px 32px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.6),
              inset 0 1px 0 rgba(255,255,255,0.05);
  position: relative;
  z-index: 2;
  animation: cardEnter 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
}
@keyframes cardEnter {
  from { opacity: 0; transform: translateY(20px) scale(0.95); }
  to   { opacity: 1; transform: translateY(0) scale(1); }
}

/* ─── Logo ───────────────────────────────────────────────────── */
.login-logo {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 28px;
  text-align: center;
}
.login-logo-icon {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 36px;
  color: #fff;
  margin-bottom: 16px;
  box-shadow: 0 12px 40px rgba(220,38,38,0.5),
              0 0 0 8px rgba(220,38,38,0.1);
  animation: logoPulse 3s ease-in-out infinite;
}
@keyframes logoPulse {
  0%, 100% { transform: scale(1); box-shadow: 0 12px 40px rgba(220,38,38,0.5), 0 0 0 8px rgba(220,38,38,0.1); }
  50%      { transform: scale(1.05); box-shadow: 0 12px 50px rgba(220,38,38,0.7), 0 0 0 12px rgba(220,38,38,0.05); }
}
.login-logo-title {
  font-size: 22px;
  font-weight: 900;
  letter-spacing: 1px;
  color: #fff;
  margin-bottom: 4px;
}
.login-logo-title .red { color: #dc2626; }
.login-logo-sub {
  font-size: 12px;
  font-weight: 600;
  color: rgba(255,255,255,0.4);
  text-transform: uppercase;
  letter-spacing: 2px;
}

/* ─── Error ──────────────────────────────────────────────────── */
.login-error {
  background: rgba(220,38,38,0.12);
  border: 1.5px solid rgba(220,38,38,0.4);
  color: #fca5a5;
  padding: 12px 16px;
  border-radius: 12px;
  font-size: 13.5px;
  font-weight: 600;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 10px;
  animation: shake 0.4s ease;
}
@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25%      { transform: translateX(-6px); }
  75%      { transform: translateX(6px); }
}
.login-error i { font-size: 16px; color: #ef4444; flex-shrink: 0; }

/* ─── Form ───────────────────────────────────────────────────── */
.login-form-group {
  margin-bottom: 18px;
}
.login-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12.5px;
  font-weight: 700;
  color: rgba(255,255,255,0.75);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 8px;
}
.login-label i { color: #dc2626; font-size: 12px; }

.login-input-wrap {
  position: relative;
}
.login-input {
  width: 100%;
  padding: 14px 16px 14px 46px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 12px;
  color: #fff;
  font-size: 15px;
  font-family: inherit;
  outline: none;
  transition: all .2s;
  -webkit-appearance: none;
  appearance: none;
}
.login-input:focus {
  border-color: #dc2626;
  background: rgba(0,0,0,0.6);
  box-shadow: 0 0 0 4px rgba(220,38,38,0.15);
}
.login-input::placeholder {
  color: rgba(255,255,255,0.3);
}
.login-input-icon {
  position: absolute;
  left: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: rgba(255,255,255,0.35);
  font-size: 15px;
  pointer-events: none;
  transition: color .2s;
}
.login-input:focus ~ .login-input-icon,
.login-input:not(:placeholder-shown) ~ .login-input-icon {
  color: #dc2626;
}

/* Password toggle */
.login-pass-toggle {
  position: absolute;
  right: 14px;
  top: 50%;
  transform: translateY(-50%);
  background: transparent;
  border: 0;
  color: rgba(255,255,255,0.4);
  cursor: pointer;
  font-size: 15px;
  padding: 6px;
  border-radius: 6px;
  transition: all .15s;
}
.login-pass-toggle:hover { color: #dc2626; background: rgba(255,255,255,0.05); }

/* ─── Submit ─────────────────────────────────────────────────── */
.login-submit {
  width: 100%;
  padding: 15px;
  background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
  color: #fff;
  border: 0;
  border-radius: 12px;
  font-size: 15px;
  font-weight: 800;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  margin-top: 24px;
  box-shadow: 0 8px 24px rgba(220,38,38,0.4);
  transition: all .25s;
  position: relative;
  overflow: hidden;
  font-family: inherit;
  letter-spacing: 0.3px;
}
.login-submit::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
  transition: left .6s;
}
.login-submit:hover::before { left: 100%; }
.login-submit:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 32px rgba(220,38,38,0.55);
}
.login-submit:active { transform: translateY(0) scale(0.98); }
.login-submit i { font-size: 15px; }

/* ─── Footer ─────────────────────────────────────────────────── */
.login-footer {
  text-align: center;
  margin-top: 24px;
  padding-top: 20px;
  border-top: 1px solid rgba(255,255,255,0.06);
}
.login-footer a {
  color: rgba(255,255,255,0.5);
  text-decoration: none;
  font-size: 12.5px;
  transition: color .15s;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.login-footer a:hover { color: #dc2626; }

.login-copyright {
  text-align: center;
  color: rgba(255,255,255,0.25);
  font-size: 11.5px;
  margin-top: 20px;
  letter-spacing: 0.3px;
}

/* ─── Mobile ─────────────────────────────────────────────────── */
@media (max-width: 480px) {
  .login-card {
    padding: 28px 22px;
    border-radius: 20px;
  }
  .login-logo-icon {
    width: 68px;
    height: 68px;
    font-size: 30px;
  }
  .login-logo-title { font-size: 19px; }
  .login-input { padding: 13px 14px 13px 42px; font-size: 14px; }
  .login-submit { padding: 14px; font-size: 14px; }
}

/* ─── Small phones ───────────────────────────────────────────── */
@media (max-width: 360px) {
  .login-card { padding: 24px 18px; }
  .login-logo-icon { width: 60px; height: 60px; font-size: 26px; }
}
</style>
</head>
<body>

<div class="login-bg">
  <div class="login-card">

    <!-- Logo -->
    <div class="login-logo">
      <div class="login-logo-icon">
        <i class="fa-solid fa-pizza-slice"></i>
      </div>
      <div class="login-logo-title">
        FRIENDS <span class="red">PIZZA HUT</span>
      </div>
      <div class="login-logo-sub">Admin Panel</div>
    </div>

    <!-- Error -->
    <?php if ($error): ?>
      <div class="login-error">
        <i class="fa-solid fa-circle-exclamation"></i>
        <span><?= e($error) ?></span>
      </div>
    <?php endif; ?>

    <!-- Form -->
    <form method="post" autocomplete="off">
      <?= csrf_field() ?>

      <div class="login-form-group">
        <label class="login-label">
          <i class="fa-solid fa-user"></i> Username or Email
        </label>
        <div class="login-input-wrap">
          <input type="text" name="username" required autofocus
                 value="<?= e(post('username', '')) ?>"
                 placeholder="Enter your username"
                 class="login-input"
                 autocomplete="username">
          <i class="fa-solid fa-user login-input-icon"></i>
        </div>
      </div>

      <div class="login-form-group">
        <label class="login-label">
          <i class="fa-solid fa-lock"></i> Password
        </label>
        <div class="login-input-wrap">
          <input type="password" name="password" id="loginPassword" required
                 placeholder="Enter your password"
                 class="login-input"
                 autocomplete="current-password">
          <i class="fa-solid fa-lock login-input-icon"></i>
          <button type="button" class="login-pass-toggle" onclick="togglePass()">
            <i class="fa-regular fa-eye" id="passIcon"></i>
          </button>
        </div>
      </div>

      <button type="submit" class="login-submit">
        <i class="fa-solid fa-right-to-bracket"></i>
        Sign In to Admin Panel
      </button>
    </form>

    <!-- Footer -->
    <div class="login-footer">
      <a href="<?= url('index.php') ?>">
        <i class="fa-solid fa-arrow-left"></i> Back to Website
      </a>
    </div>

    <div class="login-copyright">
      © <?= date('Y') ?> Friends Pizza Hut
    </div>

  </div>
</div>

<script>
function togglePass() {
  var input = document.getElementById('loginPassword');
  var icon = document.getElementById('passIcon');
  if (input.type === 'password') {
    input.type = 'text';
    icon.classList.remove('fa-eye');
    icon.classList.add('fa-eye-slash');
  } else {
    input.type = 'password';
    icon.classList.remove('fa-eye-slash');
    icon.classList.add('fa-eye');
  }
}

// Auto-hide error after 5s
document.addEventListener('DOMContentLoaded', function() {
  var err = document.querySelector('.login-error');
  if (err) {
    setTimeout(function() {
      err.style.transition = 'opacity .4s, transform .4s';
      err.style.opacity = '0';
      err.style.transform = 'translateY(-10px)';
      setTimeout(function() { err.remove(); }, 400);
    }, 5000);
  }
});
</script>

</body>
</html>