<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Homepage Manager';

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'toggle') {
        Database::execute("UPDATE homepage_sections SET is_enabled = 1 - is_enabled WHERE id = ?", [(int)post('id')]);
        flash_success('Section toggled.');
    } elseif ($action === 'save') {
        Database::update('homepage_sections', [
            'title' => (string)post('title'),
            'subtitle' => (string)post('subtitle'),
            'section_type' => (string)post('section_type', 'products'),
            'product_source' => (string)post('product_source', 'manual'),
            'desktop_columns' => (int)post('desktop_columns', 4),
            'mobile_columns' => (int)post('mobile_columns', 2),
            'initial_limit' => (int)post('initial_limit', 8),
        ], 'id = :id', ['id' => (int)post('id')]);
        flash_success('Section updated.');
    } elseif ($action === 'move') {
        $id = (int)post('id');
        $dir = post('dir');
        $s = Database::fetch("SELECT sort_order FROM homepage_sections WHERE id = ?", [$id]);
        if ($s) {
            $newOrder = $dir === 'up' ? max(0, (int)$s['sort_order'] - 10) : (int)$s['sort_order'] + 10;
            Database::execute("UPDATE homepage_sections SET sort_order = ? WHERE id = ?", [$newOrder, $id]);
            flash_success('Moved.');
        }
    } elseif ($action === 'create') {
        $key = slugify((string)post('section_key', ''));
        if ($key && !Database::fetch("SELECT id FROM homepage_sections WHERE section_key = ?", [$key])) {
            Database::insert('homepage_sections', [
                'section_key' => $key,
                'title' => trim((string)post('title', 'New Section')),
                'subtitle' => trim((string)post('subtitle', '')) ?: null,
                'is_enabled' => 1,
                'sort_order' => 999,
                'desktop_columns' => 4, 'mobile_columns' => 2,
                'initial_limit' => 8, 'load_more_count' => 4,
                'section_type' => 'products', 'product_source' => 'manual',
            ]);
            flash_success('Section created.');
        }
    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM homepage_section_products WHERE section_id = ?", [(int)post('id')]);
        Database::execute("DELETE FROM homepage_sections WHERE id = ?", [(int)post('id')]);
        flash_success('Section deleted.');
    }

    redirect(url('admin/homepage/index.php'));
}

$sections = Database::fetchAll("SELECT * FROM homepage_sections ORDER BY sort_order, id");
require __DIR__ . '/../common/header.php';
?>

<div class="space-y-4">

  <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-sm text-yellow-900">
    <i class="fa-solid fa-info-circle mr-1"></i>
    Use <strong>Move Up / Down</strong> to change homepage order. Toggle to enable/disable. Ya create a brand new section.
  </div>

  <div class="bg-white rounded-xl border p-5">
    <h3 class="font-bold mb-3">Add New Section</h3>
    <form method="post" class="grid md:grid-cols-4 gap-3 items-end">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <input name="section_key" required placeholder="key (e.g. trending)" class="border rounded px-3 py-2">
      <input name="title" required placeholder="Title" class="border rounded px-3 py-2">
      <input name="subtitle" placeholder="Subtitle (optional)" class="border rounded px-3 py-2">
      <button class="bg-brand text-white py-2 rounded font-semibold">Create</button>
    </form>
  </div>

  <div class="space-y-3">
    <?php foreach ($sections as $s): ?>
    <div class="bg-white rounded-xl border p-5">
      <form method="post" class="grid md:grid-cols-12 gap-3 items-end">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">

        <div class="md:col-span-3">
          <label class="text-xs text-gray-500 font-semibold">Title</label>
          <input name="title" value="<?= e($s['title']) ?>" class="w-full border rounded px-2 py-1.5 text-sm">
        </div>
        <div class="md:col-span-3">
          <label class="text-xs text-gray-500 font-semibold">Subtitle</label>
          <input name="subtitle" value="<?= e($s['subtitle']) ?>" class="w-full border rounded px-2 py-1.5 text-sm">
        </div>
        <div class="md:col-span-3">
          <label class="text-xs text-gray-500 font-semibold">Product Source</label>
          <select name="product_source" class="w-full border rounded px-2 py-1.5 text-sm">
            <?php foreach ([
              'manual' => 'Manual (pick products)',
              'flags' => 'Featured / Recommended',
              'flag_deal' => 'On Sale / Limited Deal',
              'flag_bestseller' => 'Bestseller flag',
              'flag_new' => 'New flag',
              'flag_coming_soon' => 'Coming Soon flag',
            ] as $k => $label): ?>
              <option value="<?= $k ?>" <?= $s['product_source'] === $k ? 'selected' : '' ?>><?= $label ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="md:col-span-1">
          <label class="text-xs text-gray-500 font-semibold">Limit</label>
          <input type="number" name="initial_limit" value="<?= (int)$s['initial_limit'] ?>" class="w-full border rounded px-2 py-1.5 text-sm">
        </div>
        <div class="md:col-span-2 flex gap-1 justify-end">
          <button class="bg-brand text-white px-3 py-1.5 rounded text-xs font-semibold">Save</button>
        </div>
      </form>

      <div class="flex flex-wrap gap-2 mt-3 pt-3 border-t">
        <form method="post" class="inline">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="move">
          <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
          <input type="hidden" name="dir" value="up">
          <button class="text-xs px-2 py-1 border rounded">↑ Up</button>
        </form>
        <form method="post" class="inline">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="move">
          <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
          <input type="hidden" name="dir" value="down">
          <button class="text-xs px-2 py-1 border rounded">↓ Down</button>
        </form>
        <form method="post" class="inline">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="toggle">
          <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
          <button class="text-xs px-2 py-1 rounded <?= $s['is_enabled'] ? 'bg-green-100 text-green-800' : 'bg-gray-200' ?>">
            <?= $s['is_enabled'] ? 'Enabled' : 'Disabled' ?>
          </button>
        </form>
        <a href="<?= url('admin/homepage/section-products.php?id=' . (int)$s['id']) ?>" class="text-xs px-2 py-1 border rounded hover:bg-gray-50">
          <i class="fa-solid fa-plus"></i> Manage Products
        </a>
        <form method="post" class="inline ml-auto" data-confirm="Delete this section?">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
          <button class="text-red-600 text-xs">Delete</button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>