<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Marketing Hub';
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-4">
  <?php
  $tools = [
      ['url' => 'admin/marketing/bulk-sms.php', 'icon' => 'fa-comment-sms', 'title' => 'Bulk SMS', 'desc' => 'Send SMS to customer segments', 'feature' => 'bulk_sms_marketing'],
      ['url' => 'admin/offers/index.php', 'icon' => 'fa-bolt', 'title' => 'Offers', 'desc' => 'Discount offers', 'feature' => null],
      ['url' => 'admin/coupons/index.php', 'icon' => 'fa-ticket', 'title' => 'Coupons', 'desc' => 'Coupon codes', 'feature' => null],
      ['url' => 'admin/banners/index.php', 'icon' => 'fa-image', 'title' => 'Banners', 'desc' => 'Homepage banners', 'feature' => null],
      ['url' => 'admin/settings/marketing.php', 'icon' => 'fa-bullhorn', 'title' => 'Tracking', 'desc' => 'Pixel + Analytics', 'feature' => null],
      ['url' => 'admin/tiers/index.php', 'icon' => 'fa-crown', 'title' => 'Customer Tiers', 'desc' => 'Loyalty tiers', 'feature' => 'customer_tiers'],
  ];
  foreach ($tools as $t):
      if ($t['feature'] && !feature_enabled($t['feature'])) continue;
  ?>
  <a href="<?= url($t['url']) ?>" class="bg-white rounded-xl border p-5 hover:border-brand hover:shadow-lg transition">
    <div class="w-12 h-12 rounded-full bg-brand/10 flex items-center justify-center mb-3">
      <i class="fa-solid <?= $t['icon'] ?> text-brand text-xl"></i>
    </div>
    <div class="font-bold mb-1"><?= e($t['title']) ?></div>
    <div class="text-sm text-gray-500"><?= e($t['desc']) ?></div>
  </a>
  <?php endforeach; ?>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>