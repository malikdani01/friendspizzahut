<?php
// customers.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Customers Report';
$from = (string)get('from', date('Y-m-01'));
$to = (string)get('to', date('Y-m-d'));
$rows = report_top_customers($from, $to, 50);
require __DIR__ . '/../common/header.php';
?>
<form class="flex gap-2 mb-5"><input type="date" name="from" value="<?= e($from) ?>" class="border rounded px-3 py-2"><input type="date" name="to" value="<?= e($to) ?>" class="border rounded px-3 py-2"><button class="bg-brand text-white px-4 py-2 rounded">Apply</button></form>
<div class="bg-white rounded-xl border overflow-hidden"><table class="w-full text-sm"><thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">Name</th><th class="text-left px-4 py-3">Phone</th><th class="text-right px-4 py-3">Orders</th><th class="text-right px-4 py-3">Spent</th></tr></thead>
<tbody><?php foreach ($rows as $r): ?><tr class="border-t"><td class="px-4 py-3"><?= e($r['customer_name']) ?></td><td class="px-4 py-3"><?= e($r['customer_phone']) ?></td><td class="px-4 py-3 text-right"><?= (int)$r['orders'] ?></td><td class="px-4 py-3 text-right font-semibold"><?= money($r['spent']) ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php require __DIR__ . '/../common/footer.php'; ?>