<?php
// section-products.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$sid = (int)get('id', 0);
$sec = Database::fetch("SELECT * FROM homepage_sections WHERE id=?", [$sid]);
if (!$sec) { flash_error('Section not found.'); redirect(url('admin/homepage/index.php')); }
$pageTitle = 'Products: ' . $sec['title'];

if (is_post()) {
    verify_csrf();
    Database::execute("DELETE FROM homepage_section_products WHERE section_id=?", [$sid]);
    foreach ((array)post('product_ids', []) as $i => $pid) {
        if (!$pid) continue;
        Database::insert('homepage_section_products', ['section_id'=>$sid, 'product_id'=>(int)$pid, 'sort_order'=>$i]);
    }
    flash_success('Products saved.');
    redirect(url('admin/homepage/section-products.php?id=' . $sid));
}

$all = Database::fetchAll("SELECT id, name FROM products WHERE status='active' ORDER BY name");
$assigned = array_column(Database::fetchAll("SELECT product_id FROM homepage_section_products WHERE section_id=?", [$sid]), 'product_id');
require __DIR__ . '/../common/header.php';
?>
<a href="<?= url('admin/homepage/index.php') ?>" class="text-sm text-gray-500 hover:text-brand mb-4 inline-block">← Homepage</a>
<form method="post" class="bg-white rounded-xl border p-6 max-w-3xl">
  <?= csrf_field() ?>
  <div class="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-96 overflow-y-auto mb-4">
    <?php foreach ($all as $p): ?>
      <label class="text-sm flex items-center gap-2 border rounded px-2 py-1"><input type="checkbox" name="product_ids[]" value="<?= (int)$p['id'] ?>" <?= in_array($p['id'], $assigned)?'checked':'' ?> class="w-4 h-4"> <?= e($p['name']) ?></label>
    <?php endforeach; ?>
  </div>
  <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
</form>
<?php require __DIR__ . '/../common/footer.php'; ?>