-- Rider module tables
CREATE TABLE IF NOT EXISTS riders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    pin_hash VARCHAR(255) NOT NULL,
    cnic VARCHAR(20) NULL,
    vehicle_type VARCHAR(40) NULL,
    vehicle_number VARCHAR(40) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_login DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add rider_id to orders (only if not exists)
ALTER TABLE orders ADD COLUMN IF NOT EXISTS rider_id INT UNSIGNED NULL AFTER cancelled_by;
CREATE INDEX idx_orders_rider ON orders(rider_id, order_status);