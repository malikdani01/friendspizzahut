<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('sms_notifications')) { flash_error('SMS module disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'SMS Settings';
if (is_post()) {
    verify_csrf();
    foreach (['sms_provider','sms_api_key','sms_api_secret','sms_sender_id'] as $k) {
        update_setting($k, (string)post($k, ''));
    }
    flash_success('SMS settings saved.');
    redirect(url('admin/settings/sms.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl shadow-sm border p-6">
  <form method="post" class="space-y-4">
    <?= csrf_field() ?>
    <div><label class="text-sm font-semibold">Provider</label>
      <select name="sms_provider" class="w-full border rounded px-3 py-2">
        <option value="">— None —</option>
        <option value="twilio" <?= setting('sms_provider')==='twilio'?'selected':'' ?>>Twilio</option>
        <option value="local" <?= setting('sms_provider')==='local'?'selected':'' ?>>Local Gateway</option>
      </select>
    </div>
    <div><label class="text-sm font-semibold">API Key</label><input name="sms_api_key" value="<?= e(setting('sms_api_key','')) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-sm font-semibold">API Secret</label><input type="password" name="sms_api_secret" value="<?= e(setting('sms_api_secret','')) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-sm font-semibold">Sender ID</label><input name="sms_sender_id" value="<?= e(setting('sms_sender_id','')) ?>" class="w-full border rounded px-3 py-2"></div>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save SMS Settings</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>