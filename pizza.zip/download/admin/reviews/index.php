<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Reviews';

if (is_post()) {
    verify_csrf();
    $action = post('action');
    $id = (int)post('id', 0);

    if ($action === 'approve') {
        review_approve($id);
        flash_success('Review approved.');
    } elseif ($action === 'reject') {
        review_reject($id);
        flash_success('Review rejected.');
    } elseif ($action === 'delete') {
        review_delete($id);
        flash_success('Review deleted.');
    } elseif ($action === 'reply') {
        Database::execute(
            "UPDATE reviews SET admin_reply = ? WHERE id = ?",
            [mb_substr((string)post('reply', ''), 0, 2000), $id]
        );
        flash_success('Reply saved.');
    }
    redirect(url('admin/reviews/index.php?tab=' . (string)post('tab', 'pending')));
}

$tab = (string)get('tab', 'pending');
if ($tab === 'approved') {
    $where = 'r.is_approved = 1';
} elseif ($tab === 'pending') {
    $where = 'r.is_approved = 0';
} else {
    $where = '1=1';
}

$rows = Database::fetchAll(
    "SELECT r.*, u.name AS user_name, u.phone AS user_phone, p.name AS product_name, p.slug AS product_slug
     FROM reviews r
     LEFT JOIN users u ON u.id = r.user_id
     LEFT JOIN products p ON p.id = r.product_id
     WHERE $where
     ORDER BY r.id DESC LIMIT 200"
);

$pendingCount = (int)(Database::fetch("SELECT COUNT(*) c FROM reviews WHERE is_approved = 0")['c'] ?? 0);
$approvedCount = (int)(Database::fetch("SELECT COUNT(*) c FROM reviews WHERE is_approved = 1")['c'] ?? 0);

require __DIR__ . '/../common/header.php';
?>

<div class="flex gap-2 mb-5">
  <a href="?tab=pending" class="px-4 py-2 rounded <?= $tab === 'pending' ? 'bg-brand text-white' : 'bg-white border' ?> text-sm">
    Pending (<?= $pendingCount ?>)
  </a>
  <a href="?tab=approved" class="px-4 py-2 rounded <?= $tab === 'approved' ? 'bg-brand text-white' : 'bg-white border' ?> text-sm">
    Approved (<?= $approvedCount ?>)
  </a>
  <a href="?tab=all" class="px-4 py-2 rounded <?= $tab === 'all' ? 'bg-brand text-white' : 'bg-white border' ?> text-sm">All</a>
</div>

<div class="space-y-3">
  <?php foreach ($rows as $r): ?>
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <div class="flex justify-between items-start gap-3 mb-3 flex-wrap">
      <div>
        <div class="font-semibold">
          <?= e($r['user_name'] ?? 'Customer') ?>
          <?php if ((int)$r['is_verified_purchase']): ?>
            <span class="text-xs text-green-600 ml-2"><i class="fa-solid fa-circle-check"></i> Verified</span>
          <?php endif; ?>
        </div>
        <div class="text-xs text-gray-500">
          <?= e($r['product_name'] ?? '') ?> • <?= date('d M Y, H:i', strtotime($r['created_at'])) ?>
        </div>
        <div class="text-yellow-500 text-sm mt-1">
          <?= str_repeat('★', (int)$r['rating']) ?><span class="text-gray-300"><?= str_repeat('★', 5 - (int)$r['rating']) ?></span>
          <span class="text-gray-400 text-xs ml-2">(<?= (int)$r['rating'] ?>/5)</span>
        </div>
      </div>
      <div class="flex gap-2 flex-wrap">
        <?php if (!$r['is_approved']): ?>
          <form method="post" class="inline">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="approve">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <input type="hidden" name="tab" value="<?= e($tab) ?>">
            <button class="text-xs bg-green-600 text-white px-3 py-1.5 rounded font-semibold">
              <i class="fa-solid fa-check"></i> Approve
            </button>
          </form>
        <?php else: ?>
          <form method="post" class="inline">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reject">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <input type="hidden" name="tab" value="<?= e($tab) ?>">
            <button class="text-xs bg-gray-300 text-gray-700 px-3 py-1.5 rounded font-semibold">
              <i class="fa-solid fa-xmark"></i> Unapprove
            </button>
          </form>
        <?php endif; ?>
        <form method="post" class="inline" onsubmit="return confirm('Delete this review?');">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
          <input type="hidden" name="tab" value="<?= e($tab) ?>">
          <button class="text-xs text-red-600 px-3 py-1.5 rounded border border-red-200">
            <i class="fa-solid fa-trash"></i> Delete
          </button>
        </form>
      </div>
    </div>

    <?php if ($r['title']): ?>
      <div class="font-semibold text-sm mb-1"><?= e($r['title']) ?></div>
    <?php endif; ?>
    <?php if ($r['comment']): ?>
      <p class="text-sm text-gray-700 mb-3"><?= nl2br(e($r['comment'])) ?></p>
    <?php endif; ?>

    <?php
    $likeCount = review_like_count((int)$r['id']);
    $replyCount = (int)(Database::fetch("SELECT COUNT(*) c FROM review_replies WHERE review_id = ?", [(int)$r['id']])['c'] ?? 0);
    ?>
    <div class="text-xs text-gray-500 mb-3">
      <i class="fa-solid fa-thumbs-up"></i> <?= $likeCount ?> likes
      &nbsp;·&nbsp;
      <i class="fa-solid fa-comment"></i> <?= $replyCount ?> replies
    </div>

    <?php if ($r['admin_reply']): ?>
      <div class="bg-gray-50 rounded p-3 mb-3 text-sm">
        <strong class="text-gray-700">Your reply:</strong>
        <div class="mt-1"><?= nl2br(e($r['admin_reply'])) ?></div>
      </div>
    <?php endif; ?>

    <form method="post" class="flex gap-2">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="reply">
      <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
      <input type="hidden" name="tab" value="<?= e($tab) ?>">
      <input name="reply" value="<?= e($r['admin_reply']) ?>" placeholder="Reply as restaurant owner..."
             class="flex-1 border rounded px-3 py-2 text-sm">
      <button class="bg-gray-800 text-white px-4 rounded text-sm">
        <i class="fa-solid fa-reply"></i> Reply
      </button>
    </form>
  </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?>
    <div class="text-center py-12 text-gray-400 bg-white rounded-xl border">No reviews in this tab.</div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>