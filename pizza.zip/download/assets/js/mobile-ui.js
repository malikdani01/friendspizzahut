/* ═══════════════════════════════════════════════════════════════
   FRIENDS PIZZA HUT — Mobile UI Interactions
   ═══════════════════════════════════════════════════════════════ */
(function() {
  'use strict';

  // ─── Drawer ────────────────────────────────────────────────
  const drawer = document.getElementById('fphDrawer');
  const overlay = document.getElementById('fphDrawerOverlay');
  const menuBtn = document.getElementById('fphMenuBtn');
  const closeBtn = document.getElementById('fphDrawerClose');

  function openDrawer() {
    if (!drawer || !overlay) return;
    drawer.classList.add('open');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeDrawer() {
    if (!drawer || !overlay) return;
    drawer.classList.remove('open');
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (menuBtn) menuBtn.addEventListener('click', openDrawer);
  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  if (overlay) overlay.addEventListener('click', closeDrawer);

  // ─── Search Overlay ────────────────────────────────────────
  const searchOverlay = document.getElementById('fphSearchOverlay');
  const searchBtn = document.getElementById('fphSearchBtn');
  const searchClose = document.getElementById('fphSearchClose');
  const searchInput = document.getElementById('fphSearchInput');

  if (searchBtn && searchOverlay) {
    searchBtn.addEventListener('click', () => {
      searchOverlay.classList.add('open');
      setTimeout(() => searchInput && searchInput.focus(), 150);
    });
  }
  if (searchClose && searchOverlay) {
    searchClose.addEventListener('click', () => searchOverlay.classList.remove('open'));
  }
  if (searchOverlay) {
    searchOverlay.addEventListener('click', (e) => {
      if (e.target === searchOverlay) searchOverlay.classList.remove('open');
    });
  }

  // ─── Deal Bar Countdown ────────────────────────────────────
  const countdownEls = document.querySelectorAll('.fph-deal-bar');
  countdownEls.forEach(bar => {
    const endTs = parseInt(bar.dataset.endTs, 10);
    const display = bar.querySelector('.fph-deal-countdown');
    if (!endTs || !display) return;

    function tick() {
      const now = Date.now();
      let diff = Math.max(0, endTs - now);
      if (diff === 0) {
        bar.style.display = 'none';
        return;
      }
      const h = Math.floor(diff / 3600000); diff %= 3600000;
      const m = Math.floor(diff / 60000); diff %= 60000;
      const s = Math.floor(diff / 1000);
      display.textContent = String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
    }
    tick();
    setInterval(tick, 1000);
  });

  // ─── Keyboard shortcuts ────────────────────────────────────
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeDrawer();
      if (searchOverlay) searchOverlay.classList.remove('open');
    }
  });

  // ─── Cart count sync ───────────────────────────────────────
  window.fphSetCartCount = function(count) {
    const el = document.getElementById('fphCartCount');
    const el2 = document.getElementById('fphBnCart');
    if (el) { el.textContent = count; el.style.display = count > 0 ? '' : 'none'; }
    if (el2) { el2.textContent = count; el2.style.display = count > 0 ? '' : 'none'; }
  };

  // ─── Init body class ───────────────────────────────────────
  document.body.classList.add('fph-has-bottom-nav');
})();