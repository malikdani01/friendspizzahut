<?php
function create_payment(int $orderId, string $method, float $amount): int {
    return Database::insert('payments', [
        'order_id' => $orderId, 'method' => $method,
        'amount' => $amount, 'currency' => 'PKR', 'payment_status' => 'pending',
    ]);
}
function get_payment(int $id): ?array { return Database::fetch("SELECT * FROM payments WHERE id=?", [$id]); }
function mark_payment_paid(int $paymentId, ?int $adminId = null, ?string $reference = null): void {
    Database::execute("UPDATE payments SET payment_status='paid', verified_by=?, verified_at=NOW(), transaction_reference=COALESCE(?, transaction_reference) WHERE id=?",
        [$adminId, $reference, $paymentId]);
    $p = get_payment($paymentId);
    if ($p) Database::execute("UPDATE orders SET payment_status='paid' WHERE id=?", [(int)$p['order_id']]);
}
function mark_payment_failed(int $paymentId, ?string $note = null): void {
    Database::execute("UPDATE payments SET payment_status='failed', notes=? WHERE id=?", [$note, $paymentId]);
    $p = get_payment($paymentId);
    if ($p) Database::execute("UPDATE orders SET payment_status='failed' WHERE id=?", [(int)$p['order_id']]);
}