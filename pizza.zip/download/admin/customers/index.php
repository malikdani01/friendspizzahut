<?php
// admin/customers/index.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Customers';
$search = trim((string)get('q',''));
$where = '1=1'; $params = [];
if ($search) { $where .= " AND (name LIKE ? OR phone LIKE ? OR email LIKE ?)";
               $params = ["%$search%","%$search%","%$search%"]; }
$rows = Database::fetchAll("SELECT u.*, (SELECT COUNT(*) FROM orders WHERE user_id=u.id) order_count,
    (SELECT COALESCE(SUM(total),0) FROM orders WHERE user_id=u.id AND order_status NOT IN ('cancelled','refunded')) spent
    FROM users u WHERE $where ORDER BY u.id DESC LIMIT 100", $params);
require __DIR__ . '/../common/header.php';
?>
<form class="mb-5 flex gap-2">
  <input name="q" value="<?= e($search) ?>" placeholder="Search customers..." class="border rounded px-3 py-2 text-sm flex-1">
  <button class="bg-gray-800 text-white px-4 py-2 rounded text-sm">Search</button>
</form>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr><th class="text-left px-4 py-3">Name</th><th class="text-left px-4 py-3">Phone</th><th class="text-left px-4 py-3">Orders</th><th class="text-left px-4 py-3">Spent</th><th class="text-left px-4 py-3">Status</th><th></th></tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $u): ?>
      <tr class="border-t hover:bg-gray-50">
        <td class="px-4 py-3 font-semibold"><?= e($u['name']) ?><div class="text-xs text-gray-500"><?= e($u['email']) ?></div></td>
        <td class="px-4 py-3"><?= e($u['phone']) ?></td>
        <td class="px-4 py-3"><?= (int)$u['order_count'] ?></td>
        <td class="px-4 py-3 font-semibold"><?= money($u['spent']) ?></td>
        <td class="px-4 py-3">
          <?php if ($u['is_blocked']): ?><span class="text-xs px-2 py-1 rounded bg-red-100 text-red-800">Blocked</span>
          <?php else: ?><span class="text-xs px-2 py-1 rounded bg-green-100 text-green-800">Active</span><?php endif; ?>
        </td>
        <td class="px-4 py-3 text-right"><a href="<?= url('admin/customers/view.php?id='.(int)$u['id']) ?>" class="text-brand text-xs">View →</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>