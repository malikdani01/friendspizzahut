<?php
// reply.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/messages/index.php'));
verify_csrf();
Database::execute("UPDATE contact_messages SET admin_reply=?, replied_at=NOW(), is_read=1 WHERE id=?",
    [mb_substr((string)post('reply',''),0,2000), (int)post('id')]);
flash_success('Reply saved.');
redirect(url('admin/messages/view.php?id=' . (int)post('id')));