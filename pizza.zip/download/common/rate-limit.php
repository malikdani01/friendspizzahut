<?php
function rate_limit_check(string $key, int $max = 20, int $window = 60): bool {
    $ip = client_ip();
    $cacheKey = "_rl_{$key}_" . md5($ip);
    $now = time();
    $data = $_SESSION[$cacheKey] ?? ['count' => 0, 'start' => $now];
    if ($now - $data['start'] > $window) $data = ['count' => 0, 'start' => $now];
    $data['count']++;
    $_SESSION[$cacheKey] = $data;
    return $data['count'] <= $max;
}