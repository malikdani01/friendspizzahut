-- ═══════════════════════════════════════════════════════════════
-- Migration 022: Chat / Messages System
-- Users can chat with Admin and Rider
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS chat_messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    order_id INT UNSIGNED NULL,
    sender_type ENUM('user','admin','rider') NOT NULL,
    sender_id INT UNSIGNED NULL,
    sender_name VARCHAR(120) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    read_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id, created_at),
    INDEX idx_order (order_id, created_at),
    INDEX idx_admin_unread (sender_type, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed: default welcome message from admin for each new user
-- (We'll do this programmatically in PHP)