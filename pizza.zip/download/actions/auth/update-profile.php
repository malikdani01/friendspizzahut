<?php
// actions/auth/update-profile.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('profile.php'));
verify_csrf();
$name = trim((string)post('name',''));
$email = trim((string)post('email',''));
$uid = (int)$_SESSION['user_id'];
if (strlen($name) < 2) { flash_error('Name too short.'); redirect(url('profile.php')); }
if ($email && !validate_email($email)) { flash_error('Invalid email.'); redirect(url('profile.php')); }
if ($email && Database::fetch("SELECT id FROM users WHERE email=? AND id!=?", [$email, $uid])) { flash_error('Email in use.'); redirect(url('profile.php')); }
Database::execute("UPDATE users SET name=?, email=? WHERE id=?", [$name, $email ?: null, $uid]);
flash_success('Profile updated.');
redirect(url('profile.php'));