<?php
// admin/loyalty/index.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Loyalty';
if (is_post()) {
    verify_csrf();
    if (post('action') === 'save_settings') {
        $exists = Database::fetch("SELECT id FROM loyalty_settings LIMIT 1");
        $data = [
            'earn_rate' => (float)post('earn_rate',1),
            'redeem_rate' => (float)post('redeem_rate',100),
            'min_redeem' => (int)post('min_redeem',100),
            'max_redeem_percent' => (int)post('max_redeem_percent',20),
            'is_active' => post('is_active') ? 1 : 0,
        ];
        if ($exists) Database::update('loyalty_settings', $data, 'id = :id', ['id' => (int)$exists['id']]);
        else Database::insert('loyalty_settings', $data);
        flash_success('Settings saved.');
    }
    redirect(url('admin/loyalty/index.php'));
}
$s = Database::fetch("SELECT * FROM loyalty_settings LIMIT 1") ?: ['earn_rate'=>1,'redeem_rate'=>100,'min_redeem'=>100,'max_redeem_percent'=>20,'is_active'=>1];
$recent = Database::fetchAll("SELECT lp.*, u.name FROM loyalty_points lp JOIN users u ON u.id=lp.user_id ORDER BY lp.id DESC LIMIT 30");
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <h3 class="font-bold mb-3">Settings</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save_settings">
      <div><label class="text-xs text-gray-500">Earn rate (points per Rs.100)</label><input type="number" step="0.01" name="earn_rate" value="<?= e($s['earn_rate']) ?>" class="w-full border rounded px-3 py-2"></div>
      <div><label class="text-xs text-gray-500">Redeem rate (points per Rs.1)</label><input type="number" step="0.01" name="redeem_rate" value="<?= e($s['redeem_rate']) ?>" class="w-full border rounded px-3 py-2"></div>
      <div><label class="text-xs text-gray-500">Min redeem</label><input type="number" name="min_redeem" value="<?= (int)$s['min_redeem'] ?>" class="w-full border rounded px-3 py-2"></div>
      <div><label class="text-xs text-gray-500">Max redeem %</label><input type="number" name="max_redeem_percent" value="<?= (int)$s['max_redeem_percent'] ?>" class="w-full border rounded px-3 py-2"></div>
      <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" <?= $s['is_active']?'checked':'' ?>> Active</label>
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Save</button>
    </form>
  </div>
  <div class="md:col-span-2 bg-white rounded-xl shadow-sm border p-5">
    <h3 class="font-bold mb-3">Recent Activity</h3>
    <table class="w-full text-sm">
      <thead class="text-xs text-gray-500 uppercase"><tr><th class="text-left py-2">Customer</th><th class="text-left">Type</th><th class="text-right">Points</th><th class="text-right">Date</th></tr></thead>
      <tbody>
        <?php foreach ($recent as $r): ?>
        <tr class="border-t">
          <td class="py-2"><?= e($r['name']) ?></td>
          <td class="capitalize"><?= e($r['type']) ?></td>
          <td class="text-right <?= $r['type']==='earn'?'text-green-600':'text-red-600' ?> font-semibold"><?= $r['type']==='earn'?'+':'-' ?><?= (int)$r['points'] ?></td>
          <td class="text-right text-xs text-gray-500"><?= date('d M', strtotime($r['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>