<?php /** @var array $columns @var array $rows @var string $empty */
$empty = $empty ?? 'No data.'; ?>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr><?php foreach ($columns as $c): ?><th class="text-left px-4 py-3"><?= e($c) ?></th><?php endforeach; ?></tr>
    </thead>
    <tbody>
      <?php if (!$rows): ?><tr><td colspan="<?= count($columns) ?>" class="py-8 text-center text-gray-400"><?= e($empty) ?></td></tr>
      <?php else: foreach ($rows as $r): ?>
        <tr class="border-t hover:bg-gray-50"><?php foreach (array_keys($columns) as $k): ?><td class="px-4 py-3"><?= $r[$k] ?? '' ?></td><?php endforeach; ?></tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>