<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Orders';

$page = max(1, (int)get('page', 1)); $per = 20; $offset = ($page-1)*$per;
$status = (string)get('status', '');
$search = trim((string)get('q', ''));

$where = "1=1"; $params = [];
if ($status) { $where .= " AND order_status = ?"; $params[] = $status; }
if ($search) { $where .= " AND (order_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ?)";
               $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }

$total = (int)(Database::fetch("SELECT COUNT(*) c FROM orders WHERE $where", $params)['c'] ?? 0);
$pages = max(1, (int)ceil($total/$per));
$orders = Database::fetchAll("SELECT * FROM orders WHERE $where ORDER BY id DESC LIMIT $per OFFSET $offset", $params);

$statuses = ['pending','confirmed','preparing','ready','ready_for_pickup','out_for_delivery','delivered','picked_up','completed','cancelled'];
require __DIR__ . '/../common/header.php';
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-5">
  <form class="flex flex-wrap gap-2">
    <input name="q" value="<?= e($search) ?>" placeholder="Search orders..." class="border rounded px-3 py-2 text-sm w-64">
    <select name="status" class="border rounded px-3 py-2 text-sm">
      <option value="">All Statuses</option>
      <?php foreach ($statuses as $s): ?>
        <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= order_status_label($s) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="bg-gray-800 text-white px-4 py-2 rounded text-sm">Filter</button>
  </form>
  <div class="text-sm text-gray-500"><?= $total ?> orders</div>
</div>

<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-gray-600 text-xs uppercase">
      <tr>
        <th class="text-left px-4 py-3">Order #</th>
        <th class="text-left px-4 py-3">Customer</th>
        <th class="text-left px-4 py-3">Type</th>
        <th class="text-left px-4 py-3">Total</th>
        <th class="text-left px-4 py-3">Payment</th>
        <th class="text-left px-4 py-3">Status</th>
        <th class="text-left px-4 py-3">Date</th>
        <th class="text-right px-4 py-3">View</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$orders): ?>
        <tr><td colspan="8" class="py-10 text-center text-gray-400">No orders found.</td></tr>
      <?php else: foreach ($orders as $o): ?>
        <tr class="border-t hover:bg-gray-50">
          <td class="px-4 py-3 font-mono text-xs"><?= e($o['order_number']) ?></td>
          <td class="px-4 py-3">
            <div class="font-semibold"><?= e($o['customer_name']) ?></div>
            <div class="text-xs text-gray-500"><?= e($o['customer_phone']) ?></div>
          </td>
          <td class="px-4 py-3 text-xs uppercase"><?= e($o['order_type']) ?></td>
          <td class="px-4 py-3 font-semibold"><?= money($o['total']) ?></td>
          <td class="px-4 py-3 text-xs">
            <span class="uppercase font-semibold"><?= e($o['payment_method']) ?></span><br>
            <span class="text-gray-500"><?= e($o['payment_status']) ?></span>
          </td>
          <td class="px-4 py-3"><?= status_badge($o['order_status']) ?></td>
          <td class="px-4 py-3 text-xs text-gray-500"><?= date('d M, H:i', strtotime($o['created_at'])) ?></td>
          <td class="px-4 py-3 text-right">
            <a href="<?= url('admin/orders/view.php?id=' . (int)$o['id']) ?>" class="text-brand text-xs font-semibold hover:underline">View →</a>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php if ($pages > 1): ?>
<div class="flex justify-center gap-2 mt-5">
  <?php for ($i=1; $i<=$pages; $i++): $qs = http_build_query(array_filter(['q'=>$search,'status'=>$status?:null,'page'=>$i])); ?>
    <a href="?<?= $qs ?>" class="px-3 py-1.5 rounded text-sm <?= $i===$page?'bg-brand text-white':'bg-white border' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../common/footer.php'; ?>