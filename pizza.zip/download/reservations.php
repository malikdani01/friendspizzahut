<?php
require_once __DIR__ . '/common/bootstrap.php';
if (!feature_enabled('table_reservation')) {
    flash_error('Table reservations are not available.');
    redirect(url('account.php'));
}
require_customer();

$pageTitle = 'My Reservations';
$uid = (int)$_SESSION['user_id'];
$reservations = reservation_user_list($uid);
$user = current_customer();

require __DIR__ . '/common/header.php';
?>
<div class="max-w-4xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-2">Table Reservations</h1>
  <p class="text-white/60 mb-8">Book a table at Friends Pizza Hut</p>

  <!-- Booking Form -->
  <div class="bg-white/5 border border-white/10 rounded-2xl p-6 mb-8">
    <h3 class="font-bold mb-4 flex items-center gap-2">
      <i class="fa-solid fa-calendar-plus text-brand"></i> New Reservation
    </h3>
    <form method="post" action="<?= url('actions/reservation/create.php') ?>" class="grid md:grid-cols-2 gap-4">
      <?= csrf_field() ?>
      <div>
        <label class="block text-sm text-white/70 mb-1">Full Name *</label>
        <input name="customer_name" required value="<?= e($user['name']) ?>" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 focus:border-brand outline-none">
      </div>
      <div>
        <label class="block text-sm text-white/70 mb-1">Phone *</label>
        <input name="customer_phone" required value="<?= e($user['phone']) ?>" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 focus:border-brand outline-none">
      </div>
      <div>
        <label class="block text-sm text-white/70 mb-1">Date *</label>
        <input type="date" name="reservation_date" required min="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d', strtotime('+30 days')) ?>" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 focus:border-brand outline-none">
      </div>
      <div>
        <label class="block text-sm text-white/70 mb-1">Time *</label>
        <input type="time" name="reservation_time" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 focus:border-brand outline-none">
      </div>
      <div>
        <label class="block text-sm text-white/70 mb-1">Party Size *</label>
        <input type="number" name="party_size" min="1" max="30" required value="2" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 focus:border-brand outline-none">
      </div>
      <div>
        <label class="block text-sm text-white/70 mb-1">Email (optional)</label>
        <input type="email" name="customer_email" value="<?= e($user['email']) ?>" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 focus:border-brand outline-none">
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm text-white/70 mb-1">Special Requests</label>
        <textarea name="special_requests" rows="2" placeholder="Birthday, cake, seating preference, etc." class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 focus:border-brand outline-none"></textarea>
      </div>
      <div class="md:col-span-2">
        <button class="w-full bg-brand hover:bg-red-700 py-3 rounded-lg font-bold">
          <i class="fa-solid fa-check mr-2"></i> Request Reservation
        </button>
        <p class="text-xs text-white/40 mt-2 text-center">We'll confirm within 30 minutes during business hours.</p>
      </div>
    </form>
  </div>

  <!-- My Reservations -->
  <h2 class="text-xl font-bold mb-4">My Reservations (<?= count($reservations) ?>)</h2>
  <?php if (!$reservations): ?>
    <div class="text-center py-12 bg-white/5 border border-white/10 rounded-2xl text-white/60">
      <i class="fa-solid fa-calendar-xmark text-4xl mb-3 opacity-40"></i>
      <p>No reservations yet.</p>
    </div>
  <?php else: ?>
    <div class="space-y-3">
      <?php foreach ($reservations as $r): ?>
      <div class="bg-white/5 border border-white/10 rounded-2xl p-5">
        <div class="flex flex-wrap justify-between items-start gap-3 mb-3">
          <div>
            <div class="font-mono text-xs text-white/50"><?= e($r['reservation_code']) ?></div>
            <div class="font-bold text-lg"><?= date('d M Y', strtotime($r['reservation_date'])) ?> — <?= date('h:i A', strtotime($r['reservation_time'])) ?></div>
            <div class="text-sm text-white/60"><?= (int)$r['party_size'] ?> guests</div>
          </div>
          <div><?= reservation_status_badge($r['status']) ?></div>
        </div>

        <?php if ($r['table_number']): ?>
          <div class="text-sm mb-2"><i class="fa-solid fa-chair text-brand mr-1"></i> Table: <strong><?= e($r['table_number']) ?></strong></div>
        <?php endif; ?>

        <?php if ($r['special_requests']): ?>
          <div class="text-xs text-white/60 mb-2"><strong>Requests:</strong> <?= e($r['special_requests']) ?></div>
        <?php endif; ?>

        <?php if ($r['admin_note']): ?>
          <div class="text-xs p-2 bg-brand/10 border border-brand/30 rounded text-brand">
            <strong>Note from restaurant:</strong> <?= e($r['admin_note']) ?>
          </div>
        <?php endif; ?>

        <?php if ($r['status'] === 'cancelled'): ?>
          <div class="text-xs text-red-400 mt-2">Cancelled: <?= e($r['cancel_reason']) ?></div>
        <?php endif; ?>

        <?php if (in_array($r['status'], ['pending','confirmed'], true)): ?>
          <form method="post" action="<?= url('actions/reservation/cancel.php') ?>" class="mt-3" data-confirm="Cancel this reservation?">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button class="text-red-400 hover:text-red-300 text-xs font-semibold">
              <i class="fa-solid fa-xmark mr-1"></i> Cancel Reservation
            </button>
          </form>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>