<?php
/** Central pricing engine — server is the ONLY source of truth */

function calculate_base_variation_price(array $product, array $optionIds): float {
    $base = (float)($product['sale_price'] ?: $product['price']);
    $absoluteFound = null;
    foreach ($optionIds as $optId) {
        $opt = Database::fetch("SELECT * FROM variation_options WHERE id = ?", [(int)$optId]);
        if (!$opt) continue;
        if (!empty($opt['absolute_price']) && (float)$opt['absolute_price'] > 0) {
            $absoluteFound = (float)$opt['absolute_price'];
        }
    }
    return $absoluteFound !== null ? $absoluteFound : $base;
}

function calculate_cart_subtotal(): float {
    $total = 0;
    foreach (get_cart_items() as $item) {
        $total += $item['line_total'];
    }
    return round($total, 2);
}

function calculate_delivery_fee(?int $areaId, float $subtotal, bool $isPickup): float {
    if ($isPickup) return 0;
    $freeAbove = (float) setting('free_delivery_above', 0);
    if ($freeAbove > 0 && $subtotal >= $freeAbove) return 0;

    if ($areaId) {
        $area = Database::fetch("SELECT delivery_fee FROM delivery_areas WHERE id = ? AND is_active = 1", [$areaId]);
        if ($area) return (float)$area['delivery_fee'];
    }
    return (float) setting('default_delivery_fee', 100);
}

function calculate_tax(float $base): float {
    $pct = (float) setting('tax_percent', 0);
    return round($base * $pct / 100, 2);
}

function calculate_service_fee(): float {
    return (float) setting('service_fee', 0);
}

function calculate_packaging_fee(): float {
    return (float) setting('packaging_fee', 0);
}

function calculate_final_total(array $parts): float {
    $sub   = (float)($parts['subtotal'] ?? 0);
    $disc  = (float)($parts['discount_total'] ?? 0);
    $del   = (float)($parts['delivery_fee'] ?? 0);
    $tax   = (float)($parts['tax_amount'] ?? 0);
    $svc   = (float)($parts['service_fee'] ?? 0);
    $pkg   = (float)($parts['packaging_fee'] ?? 0);
    $total = $sub - $disc + $del + $tax + $svc + $pkg;
    return max(0, round($total, 2));
}

function validate_minimum_order(float $subtotal): array {
    $min = (float) setting('minimum_order', 0);
    if ($min > 0 && $subtotal < $min) {
        return ['ok' => false, 'error' => 'Minimum order is ' . money($min) . '. Please add more items.'];
    }
    return ['ok' => true];
}