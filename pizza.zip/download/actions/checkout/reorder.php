<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('orders.php'));
verify_csrf();
$orderId = (int)post('order_id',0);
$order = get_order($orderId);
if (!$order || (int)$order['user_id'] !== (int)$_SESSION['user_id']) { flash_error('Not found.'); redirect(url('orders.php')); }
clear_cart();
foreach (get_order_items($orderId) as $it) {
    if ($it['product_id']) add_to_cart((int)$it['product_id'], (int)$it['quantity'], [], [], (string)($it['special_instructions'] ?? ''));
}
flash_success('Items added to cart.');
redirect(url('cart.php'));