<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$pageTitle = 'Profile';
$user = current_customer();
$errors = [];
$success = '';

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'update_profile') {
        $name = trim((string)post('name',''));
        $email = trim((string)post('email',''));
        if (strlen($name) < 2) $errors[] = 'Name too short.';
        if ($email && !validate_email($email)) $errors[] = 'Invalid email.';
        if ($email && Database::fetch("SELECT id FROM users WHERE email = ? AND id != ?", [$email, $user['id']])) {
            $errors[] = 'Email already in use.';
        }
        if (!$errors) {
            Database::execute("UPDATE users SET name=?, email=? WHERE id=?", [$name, $email ?: null, $user['id']]);
            flash_success('Profile updated.');
            redirect(url('profile.php'));
        }
    } elseif ($action === 'change_password') {
        $current = (string)post('current_password','');
        $new = (string)post('new_password','');
        if (!password_verify($current, $user['password_hash'])) $errors[] = 'Current password is incorrect.';
        elseif (strlen($new) < 6) $errors[] = 'New password must be 6+ characters.';
        if (!$errors) {
            Database::execute("UPDATE users SET password_hash=? WHERE id=?", [password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            flash_success('Password changed.');
            redirect(url('profile.php'));
        }
    }
}
require __DIR__ . '/common/header.php';
?>
<div class="max-w-2xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-8">Profile</h1>
  <?php if ($errors): ?>
    <div class="bg-red-500/20 border border-red-500/40 text-red-200 px-4 py-3 rounded-lg mb-4 text-sm">
      <?php foreach ($errors as $er) echo '• ' . e($er) . '<br>'; ?>
    </div>
  <?php endif; ?>

  <form method="post" class="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4 mb-6">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="update_profile">
    <h3 class="font-bold">Personal Info</h3>
    <input name="name" required value="<?= e($user['name']) ?>" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-brand">
    <input value="<?= e($user['phone']) ?>" disabled class="w-full bg-black/20 border border-white/10 rounded-lg px-3 py-2.5 text-white/50">
    <input type="email" name="email" placeholder="Email" value="<?= e($user['email']) ?>" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-brand">
    <button class="bg-brand hover:bg-red-700 px-6 py-2.5 rounded-lg font-bold">Save</button>
  </form>

  <form method="post" class="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="change_password">
    <h3 class="font-bold">Change Password</h3>
    <input type="password" name="current_password" required placeholder="Current password" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-brand">
    <input type="password" name="new_password" required minlength="6" placeholder="New password" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2.5 outline-none focus:border-brand">
    <button class="bg-brand hover:bg-red-700 px-6 py-2.5 rounded-lg font-bold">Update Password</button>
  </form>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>