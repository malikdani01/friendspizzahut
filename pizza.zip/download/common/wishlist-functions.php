<?php
function wishlist_has(int $userId, int $productId): bool {
    return (bool) Database::fetch("SELECT id FROM favorites WHERE user_id=? AND product_id=?", [$userId, $productId]);
}
function wishlist_add(int $userId, int $productId): void {
    if (!wishlist_has($userId, $productId)) {
        Database::insert('favorites', ['user_id' => $userId, 'product_id' => $productId]);
    }
}
function wishlist_remove(int $userId, int $productId): void {
    Database::execute("DELETE FROM favorites WHERE user_id=? AND product_id=?", [$userId, $productId]);
}
function wishlist_get(int $userId): array {
    return Database::fetchAll("SELECT p.*, c.name AS category_name FROM favorites f
        JOIN products p ON p.id=f.product_id LEFT JOIN categories c ON c.id=p.category_id
        WHERE f.user_id=? ORDER BY f.id DESC", [$userId]);
}