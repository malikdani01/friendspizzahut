<?php
/**
 * Mobile-first header — hamburger + centered logo + search + chat + cart + notif
 */
$cartCount = function_exists('get_cart_count') ? get_cart_count() : 0;
$notifCount = 0;
$chatUnread = 0;
if (customer_logged_in() && function_exists('unread_notification_count')) {
    $notifCount = unread_notification_count('customer', (int)$_SESSION['user_id']);
}
if (customer_logged_in() && function_exists('chat_unread_count')) {
    try {
        $chatUnread = chat_unread_count((int)$_SESSION['user_id'], 'user', null);
    } catch (Throwable $e) { $chatUnread = 0; }
}
$chatUrl = customer_logged_in() ? url('messages.php') : url('contact.php');
?>

<header class="fph-header" id="fphHeader">
  <div class="fph-header-inner">

    <!-- Left: Hamburger -->
    <button type="button" class="fph-icon-btn" id="fphMenuBtn" aria-label="Menu">
      <i class="fa-solid fa-bars"></i>
    </button>

    <!-- Center: Logo -->
    <a href="<?= url('index.php') ?>" class="fph-logo">
      <span class="fph-logo-icon"><i class="fa-solid fa-pizza-slice"></i></span>
      <span class="fph-logo-text">
        <span class="fph-logo-top">FRIENDS</span>
        <span class="fph-logo-bottom">PIZZA HUT</span>
      </span>
    </a>

    <!-- Right: Icons -->
    <div class="fph-header-actions">
      <button type="button" class="fph-icon-btn" id="fphSearchBtn" aria-label="Search">
        <i class="fa-solid fa-magnifying-glass"></i>
      </button>

      <!-- Support Chat (replaces Profile) -->
      <a href="<?= e($chatUrl) ?>" class="fph-icon-btn" aria-label="Support Chat">
        <i class="fa-solid fa-headset"></i>
        <span class="fph-badge" id="fphChatCount" <?= $chatUnread > 0 ? '' : 'style="display:none;"' ?>><?= $chatUnread ?></span>
      </a>

      <a href="<?= url('cart.php') ?>" class="fph-icon-btn fph-cart-btn" aria-label="Cart">
        <i class="fa-solid fa-cart-shopping"></i>
        <span class="fph-badge" id="fphCartCount" <?= $cartCount > 0 ? '' : 'style="display:none;"' ?>><?= $cartCount ?></span>
      </a>

      <a href="<?= url('notifications.php') ?>" class="fph-icon-btn fph-notif-btn" aria-label="Notifications">
        <i class="fa-solid fa-bell"></i>
        <span class="fph-badge" id="fphNotifCount" <?= $notifCount > 0 ? '' : 'style="display:none;"' ?>><?= $notifCount ?></span>
      </a>
    </div>
  </div>
</header>

<!-- Search overlay -->
<div class="fph-search-overlay" id="fphSearchOverlay">
  <div class="fph-search-panel">
    <form action="<?= url('search.php') ?>" method="get">
      <div class="fph-search-input-wrap">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" name="q" id="fphSearchInput" placeholder="Search for pizza, burger, deals..." autocomplete="off" required>
        <button type="button" class="fph-search-close" id="fphSearchClose"><i class="fa-solid fa-xmark"></i></button>
      </div>
    </form>
    <div class="fph-search-hint">Popular: <a href="<?= url('menu.php?category=pizza') ?>">Pizza</a> · <a href="<?= url('menu.php?category=burgers') ?>">Burgers</a> · <a href="<?= url('menu.php?category=deals') ?>">Deals</a></div>
  </div>
</div>