<?php
require_once __DIR__ . '/../../common/bootstrap.php';
// Full order-creation logic lives in checkout.php for transactional safety.
redirect(url('checkout.php'));