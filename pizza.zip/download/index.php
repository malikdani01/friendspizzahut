<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Home';

// Hero banners
$heroBanners = feature_enabled('banners')
    ? Database::fetchAll("SELECT * FROM banners WHERE is_active = 1 AND position = 'homepage'
        AND (start_date IS NULL OR start_date <= NOW())
        AND (end_date IS NULL OR end_date >= NOW())
        ORDER BY sort_order LIMIT 6")
    : [];

$categories = get_categories(true);

// Dynamic sections
$sections = feature_enabled('homepage_sections') === false || true
    ? get_homepage_sections()
    : [];

require __DIR__ . '/common/header.php';
?>

<!-- HERO SLIDER -->
<?php if ($heroBanners): ?>
<section class="fph-hero">
  <div class="fph-hero-track" id="fphHeroTrack">
    <?php foreach ($heroBanners as $b):
      $mediaType = $b['media_type'] ?? 'image';
      $imgUrl = !empty($b['image']) ? upload_url($b['image']) : '';
      $vidUrl = !empty($b['video']) ? upload_url($b['video']) : '';
      $posterUrl = !empty($b['video_poster']) ? upload_url($b['video_poster']) : $imgUrl;
      $isVideo = ($mediaType === 'video' && $vidUrl);
      $isImage = (!$isVideo && $imgUrl);
    ?>
      <div class="fph-hero-slide">
        <?php if ($isVideo): ?>
          <!-- VIDEO SLIDE -->
          <video
            class="fph-hero-video"
            <?= !empty($b['video_autoplay']) ? 'autoplay' : '' ?>
            <?= !empty($b['video_loop']) ? 'loop' : '' ?>
            <?= !empty($b['video_muted']) ? 'muted' : '' ?>
            playsinline
            preload="metadata"
            <?= $posterUrl ? 'poster="' . e($posterUrl) . '"' : '' ?>>
            <source src="<?= e($vidUrl) ?>" type="video/mp4">
            Your browser does not support video.
          </video>
        <?php elseif ($isImage): ?>
          <!-- IMAGE SLIDE -->
          <img src="<?= e($imgUrl) ?>" alt="<?= e($b['title'] ?? 'Banner') ?>" loading="<?= $b === reset($heroBanners) ? 'eager' : 'lazy' ?>">
        <?php else: ?>
          <!-- FALLBACK -->
          <div style="width:100%;height:100%;background:linear-gradient(135deg,#dc2626,#7f1d1d);display:flex;align-items:center;justify-content:center;">
            <i class="fa-solid fa-pizza-slice" style="font-size:80px;color:rgba(255,255,255,0.3);"></i>
          </div>
        <?php endif; ?>

        <?php if (!empty($b['title']) || !empty($b['subtitle']) || !empty($b['button_text'])): ?>
        <div class="fph-hero-overlay">
          <?php if (!empty($b['title'])): ?><h2 class="fph-hero-title"><?= e($b['title']) ?></h2><?php endif; ?>
          <?php if (!empty($b['subtitle'])): ?><p class="fph-hero-subtitle"><?= e($b['subtitle']) ?></p><?php endif; ?>
          <?php if (!empty($b['button_text']) && !empty($b['button_url'])): ?>
            <a href="<?= e($b['button_url']) ?>" class="fph-hero-cta"><?= e($b['button_text']) ?></a>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <?php if (count($heroBanners) > 1): ?>
  <div class="fph-hero-dots">
    <?php foreach ($heroBanners as $i => $b): ?>
      <button type="button" class="fph-hero-dot <?= $i === 0 ? 'active' : '' ?>" aria-label="Slide <?= $i+1 ?>"></button>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>
<?php else: ?>
<section class="relative overflow-hidden">
  <div class="absolute inset-0 bg-gradient-to-br from-black via-red-900/40 to-black"></div>
  <div class="relative max-w-7xl mx-auto px-4 py-12 md:py-20 text-center">
    <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand/20 text-brand text-xs font-semibold mb-3">
      <i class="fa-solid fa-fire"></i> THE MAGICIAN OF TASTE
    </span>
    <h1 class="text-4xl md:text-6xl font-extrabold leading-tight mb-3">
      HOT. FRESH.<br><span class="text-brand">DELICIOUS.</span>
    </h1>
    <p class="text-white/70 mb-6 max-w-lg mx-auto">Freshly baked pizzas, zinger burgers, wings and more.</p>
    <a href="<?= url('menu.php') ?>" class="inline-block bg-brand hover:bg-red-700 px-6 py-3 rounded-full font-bold shadow-lg shadow-brand/40">
      <i class="fa-solid fa-pizza-slice mr-2"></i> Order Now
    </a>
  </div>
</section>
<?php endif; ?>

<!-- CIRCULAR CATEGORIES -->
<?php if ($categories): ?>
<section class="fph-section pt-6">
  <div class="fph-section-head" style="text-align:center;justify-content:center;flex-direction:column;align-items:center;gap:4px;">
    <h2 class="fph-section-title" style="text-align:center;">Browse <span>Categories</span></h2>
    <div class="fph-section-sub" style="text-align:center;">Pick your craving</div>
  </div>

  <div class="fph-cat-scroll">
    <?php foreach ($categories as $c): ?>
      <a href="<?= url('category.php?slug=' . urlencode($c['slug'])) ?>" class="fph-cat-item">
        <div class="fph-cat-img-wrap">
          <div class="fph-cat-img-inner">
            <?php if ($c['image']): ?>
              <img src="<?= upload_url($c['image']) ?>"
                   alt="<?= e($c['name']) ?>"
                   loading="lazy"
                   onerror="this.style.display='none'; this.parentNode.innerHTML='<i class=\'fa-solid <?= e($c['icon'] ?: 'fa-utensils') ?>\' style=\'font-size:28px;color:#dc2626;\'></i>';">
            <?php else: ?>
              <i class="fa-solid <?= e($c['icon'] ?: 'fa-utensils') ?>"></i>
            <?php endif; ?>
          </div>
        </div>
        <div class="fph-cat-name"><?= e($c['name']) ?></div>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- DYNAMIC SECTIONS (admin-ordered) -->
<?php foreach ($sections as $sec):
    $products = get_section_products($sec, (int)($sec['initial_limit'] ?? 8));
    if (!$products) continue;
?>
<section class="fph-section">
  <div style="text-align:center;margin-bottom:14px;position:relative;padding:0 16px;">
    <h2 style="font-size:22px;font-weight:900;color:#fff;margin:0;display:inline-block;">
      <?= e($sec['title']) ?>
    </h2>
    <?php if ($sec['subtitle']): ?>
      <div style="font-size:12.5px;color:rgba(255,255,255,0.55);margin-top:4px;"><?= e($sec['subtitle']) ?></div>
    <?php endif; ?>
    <a href="<?= url('menu.php') ?>"
       style="position:absolute;right:16px;top:0;font-size:13px;font-weight:700;color:#dc2626;text-decoration:none;white-space:nowrap;padding-top:4px;">
      View More →
    </a>
  </div>
  <div class="fph-product-grid">
    <?php foreach ($products as $p): require __DIR__ . '/common/components/product-card.php'; endforeach; ?>
  </div>
</section>
<?php endforeach; ?>

<script src="<?= asset('js/homepage-ui.js') ?>" defer></script>

<?php require __DIR__ . '/common/footer.php'; ?>