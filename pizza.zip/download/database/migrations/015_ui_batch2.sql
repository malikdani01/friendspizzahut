-- ═══════════════════════════════════════════════════════════════
-- Migration 015: UI Batch 2 — Badges, Sections, Transaction ID
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── PRODUCT BADGES ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS product_badges (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    bg_color VARCHAR(20) NOT NULL DEFAULT '#dc2626',
    text_color VARCHAR(20) NOT NULL DEFAULT '#ffffff',
    icon VARCHAR(60) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO product_badges (name, bg_color, text_color, icon, sort_order) VALUES
('NEW', '#16a34a', '#ffffff', 'fa-star', 1),
('HOT', '#dc2626', '#ffffff', 'fa-fire', 2),
('POPULAR', '#f59e0b', '#ffffff', 'fa-thumbs-up', 3),
('SALE', '#8b5cf6', '#ffffff', 'fa-tag', 4),
('BEST SELLER', '#0ea5e9', '#ffffff', 'fa-trophy', 5),
('SPECIAL', '#ec4899', '#ffffff', 'fa-gem', 6),
('LIMITED', '#0a0a0a', '#ffffff', 'fa-hourglass-half', 7);

-- ─── PRODUCT <-> BADGE mapping ────────────────────────────────
CREATE TABLE IF NOT EXISTS product_badge_map (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_id INT UNSIGNED NOT NULL,
    badge_id INT UNSIGNED NOT NULL,
    UNIQUE KEY uq_product_badge (product_id, badge_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── PRODUCT ORDER BUTTON CONTROL ─────────────────────────────
ALTER TABLE products ADD COLUMN IF NOT EXISTS order_button_enabled TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE products ADD COLUMN IF NOT EXISTS order_button_text VARCHAR(60) NULL DEFAULT 'Add';
ALTER TABLE products ADD COLUMN IF NOT EXISTS badge_text_override VARCHAR(60) NULL;

-- ─── HOMEPAGE SECTION ENHANCEMENTS ────────────────────────────
ALTER TABLE homepage_sections ADD COLUMN IF NOT EXISTS section_type VARCHAR(40) NOT NULL DEFAULT 'products';
ALTER TABLE homepage_sections ADD COLUMN IF NOT EXISTS product_source VARCHAR(40) NOT NULL DEFAULT 'manual';
ALTER TABLE homepage_sections ADD COLUMN IF NOT EXISTS display_style VARCHAR(40) NOT NULL DEFAULT 'grid';

-- ─── ORDER TRANSACTION ID ─────────────────────────────────────
ALTER TABLE orders ADD COLUMN IF NOT EXISTS transaction_id VARCHAR(120) NULL AFTER payment_status;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS transaction_verified TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS transaction_note VARCHAR(255) NULL;
CREATE INDEX IF NOT EXISTS idx_orders_txn ON orders(transaction_id);

-- ─── PLATFORM FEE in settings ─────────────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('platform_fee',      '0',    'checkout'),
('platform_fee_type', 'fixed','checkout')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── HOMEPAGE SECTIONS default seed ───────────────────────────
INSERT INTO homepage_sections (section_key, title, subtitle, is_enabled, sort_order, desktop_columns, mobile_columns, initial_limit, load_more_count, section_type, product_source) VALUES
('recommended',   'Recommended',      'Handpicked for you',     1, 10, 4, 2, 8, 4, 'products', 'flags'),
('special_deals', 'Special Deals',    'Limited time offers',    1, 20, 4, 2, 8, 4, 'products', 'flag_deal'),
('best_selling',  'Best Selling',     'Customer favorites',     1, 30, 4, 2, 8, 4, 'products', 'flag_bestseller'),
('new_items',     'New Items',        'Fresh on the menu',      1, 40, 4, 2, 8, 4, 'products', 'flag_new'),
('coming_soon',   'Coming Soon',      'Sneak peek',             0, 50, 4, 2, 4, 4, 'products', 'flag_coming_soon')
ON DUPLICATE KEY UPDATE title = VALUES(title);