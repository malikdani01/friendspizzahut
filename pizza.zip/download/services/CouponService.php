<?php
// services/CouponService.php
class CouponService {
    public static function validate(string $c, float $s, ?int $u = null): array { return validate_coupon($c, $s, $u); }
    public static function record(int $cid, ?int $uid, int $oid, float $d): void { record_coupon_usage($cid, $uid, $oid, $d); }
}