<?php
/** @var array $p Product row */
$img = $p['image'] ? upload_url($p['image']) : asset('images/placeholder.png');
$price = (float)($p['sale_price'] ?: $p['price']);
$hasDiscount = !empty($p['sale_price']) && $p['sale_price'] < $p['price'];
$canOrder = (int)($p['order_button_enabled'] ?? 1) === 1 && $p['status'] === 'active' && (int)$p['is_available'] === 1;
$btnText = $p['order_button_text'] ?: 'Add';
if (!$canOrder) {
    $btnText = ($p['is_coming_soon'] ?? 0) ? 'Coming Soon' : 'Sold Out';
}
$rating = (float)($p['rating_avg'] ?? 0);
$reviewCount = (int)($p['review_count'] ?? 0);
?>
<div class="fph-pcard">
  <a href="<?= url('product.php?slug=' . urlencode($p['slug'])) ?>" class="block">
    <div class="fph-pcard-img">
      <?php
      $badges = function_exists('render_product_badges') ? render_product_badges((int)$p['id']) : '';
      if ($badges): ?><div class="fph-pcard-badges"><?= $badges ?></div><?php endif; ?>
      <?php if ($p['image']): ?>
        <img src="<?= e($img) ?>" alt="<?= e($p['name']) ?>" loading="lazy"
             onerror="this.onerror=null;this.src='<?= asset('images/placeholder.png') ?>'">
      <?php else: ?>
        <i class="fa-solid fa-pizza-slice fph-ph"></i>
      <?php endif; ?>
    </div>
    <div class="fph-pcard-body">
      <?php if (!empty($p['category_name'])): ?>
        <div class="fph-pcard-cat"><?= e($p['category_name']) ?></div>
      <?php endif; ?>
      <div class="fph-pcard-name"><?= e($p['name']) ?></div>

      <?php if ($rating > 0): ?>
        <div style="display:flex;align-items:center;gap:4px;margin:4px 0 6px;font-size:11.5px;">
          <span style="color:#fbbf24;letter-spacing:0.5px;">
            <?php for ($i = 1; $i <= 5; $i++): ?>
              <i class="fa-solid fa-star" style="opacity:<?= $i <= round($rating) ? '1' : '0.25' ?>;"></i>
            <?php endfor; ?>
          </span>
          <span style="color:#fff;font-weight:700;"><?= number_format($rating, 1) ?></span>
          <?php if ($reviewCount > 0): ?>
            <span style="color:rgba(255,255,255,0.4);">(<?= $reviewCount ?>)</span>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <div class="fph-pcard-row">
        <div>
          <span class="fph-pcard-price"><?= money($price) ?></span>
          <?php if ($hasDiscount): ?><span class="fph-pcard-price-old"><?= money($p['price']) ?></span><?php endif; ?>
        </div>
      </div>
    </div>
  </a>
  <?php if ($canOrder): ?>
    <form method="get" action="<?= url('product.php') ?>" style="padding: 0 12px 12px;">
      <input type="hidden" name="slug" value="<?= e($p['slug']) ?>">
      <button type="submit" class="fph-pcard-add"><?= e($btnText) ?></button>
    </form>
  <?php else: ?>
    <div style="padding: 0 12px 12px;">
      <button disabled class="fph-pcard-add" style="width:100%;"><?= e($btnText) ?></button>
    </div>
  <?php endif; ?>
</div>