<?php
// view.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id', 0);
$p = get_payment($id);
if (!$p) { flash_error('Not found.'); redirect(url('admin/payments/index.php')); }
$order = get_order((int)$p['order_id']);
$pageTitle = 'Payment #' . $id;
require __DIR__ . '/../common/header.php';
?>
<a href="<?= url('admin/payments/index.php') ?>" class="text-sm text-gray-500 hover:text-brand mb-4 inline-block">← Payments</a>
<div class="max-w-2xl bg-white rounded-xl shadow-sm border p-6 space-y-3 text-sm">
  <div><span class="text-gray-500">Order:</span> <span class="font-mono"><?= e($order['order_number'] ?? '') ?></span></div>
  <div><span class="text-gray-500">Method:</span> <strong><?= e(strtoupper($p['method'])) ?></strong></div>
  <div><span class="text-gray-500">Amount:</span> <strong class="text-brand"><?= money($p['amount']) ?></strong></div>
  <div><span class="text-gray-500">Status:</span> <?= status_badge($p['payment_status']) ?></div>
  <?php if ($p['transaction_reference']): ?><div><span class="text-gray-500">Ref:</span> <?= e($p['transaction_reference']) ?></div><?php endif; ?>
  <?php if ($p['customer_proof_image']): ?>
    <div><span class="text-gray-500">Proof:</span><br><img src="<?= upload_url($p['customer_proof_image']) ?>" class="max-w-xs rounded mt-2"></div>
  <?php endif; ?>
  <div class="flex gap-2 pt-3">
    <?php if ($p['payment_status'] === 'pending'): ?>
      <form method="post" action="<?= url('admin/payments/verify.php') ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="bg-green-600 text-white px-4 py-2 rounded font-semibold">Mark as Paid</button></form>
      <form method="post" action="<?= url('admin/payments/reject.php') ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="bg-red-600 text-white px-4 py-2 rounded font-semibold">Mark Failed</button></form>
    <?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>