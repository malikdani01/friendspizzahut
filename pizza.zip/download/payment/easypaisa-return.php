<?php
require_once __DIR__ . '/../common/bootstrap.php';

$data = $_POST ?: $_GET;

easypaisa_log('return_received', [
    'raw' => array_map(fn($v) => is_string($v) ? mb_substr($v, 0, 200) : $v, $data),
]);

if (empty($data['orderRefNum'])) {
    flash_error('Invalid payment response.');
    redirect(url('checkout.php'));
}

$orderNumber = (string) $data['orderRefNum'];
$order = get_order_by_number($orderNumber);

if (!$order) {
    flash_error('Order not found.');
    redirect(url('checkout.php'));
}

// ─── Verify hash ──────────────────────────────────────────────
if (!easypaisa_verify_response($data)) {
    easypaisa_log('hash_mismatch', ['order' => $orderNumber]);
    flash_error('Payment verification failed.');
    redirect(url('order-detail.php?id=' . (int)$order['id']));
}

$responseCode = (string) ($data['responseCode'] ?? '');
$responseMsg  = (string) ($data['responseDesc'] ?? '');
$txnRefNo     = (string) ($data['transactionId'] ?? $data['orderRefNum'] ?? '');
$amountPaid   = (float) ($data['amount'] ?? 0);

if (!easypaisa_response_success($responseCode)) {
    easypaisa_log('payment_failed', [
        'order' => $orderNumber, 'code' => $responseCode, 'msg' => $responseMsg,
    ]);
    $payment = Database::fetch("SELECT id FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1", [(int)$order['id']]);
    if ($payment) mark_payment_failed((int)$payment['id'], "Easypaisa: $responseCode — $responseMsg");
    flash_error('Payment fail ho gaya: ' . $responseMsg);
    redirect(url('order-detail.php?id=' . (int)$order['id']));
}

Database::beginTransaction();
try {
    $payment = Database::fetch("SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1", [(int)$order['id']]);
    if (!$payment) {
        $paymentId = create_payment((int)$order['id'], 'easypaisa', (float)$order['total']);
    } else {
        $paymentId = (int)$payment['id'];
        Database::execute("UPDATE payments SET method = 'easypaisa' WHERE id = ?", [$paymentId]);
    }

    mark_payment_paid($paymentId, null, $txnRefNo);

    Database::insert('payment_transactions', [
        'payment_id'   => $paymentId,
        'gateway'      => 'easypaisa',
        'reference'    => $txnRefNo,
        'amount'       => $amountPaid,
        'status'       => 'success',
        'raw_response' => json_encode($data),
    ]);

    if ($order['order_status'] === 'pending') {
        update_order_status((int)$order['id'], 'confirmed', null, null, 'Auto-confirmed after Easypaisa payment');
    }

    Database::insert('notifications', [
        'user_type' => 'admin', 'user_id' => 1,
        'type'      => 'payment_received',
        'title'     => 'Easypaisa Payment Received',
        'message'   => "Order {$orderNumber} — Rs. " . number_format($amountPaid, 0) . " paid via Easypaisa.",
        'link'      => '/admin/orders/view.php?id=' . (int)$order['id'],
    ]);

    Database::commit();
    easypaisa_log('payment_success', ['order' => $orderNumber, 'txn' => $txnRefNo, 'amount' => $amountPaid]);

    flash_success('Payment successful! Rs. ' . number_format($amountPaid, 0) . ' received.');
    redirect(url('order-success.php?order=' . urlencode($orderNumber)));

} catch (Throwable $e) {
    Database::rollback();
    error_log('Easypaisa return error: ' . $e->getMessage());
    flash_error('Payment received but order update failed. Contact support.');
    redirect(url('order-detail.php?id=' . (int)$order['id']));
}