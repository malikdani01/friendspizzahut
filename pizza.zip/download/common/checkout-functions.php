<?php
function get_checkout_summary(): array {
    $items = get_cart_items();
    $subtotal = calculate_cart_subtotal();
    return [
        'items' => $items,
        'subtotal' => $subtotal,
        'item_count' => array_sum(array_column($items, 'quantity')),
    ];
}
function build_order_number(): string {
    $prefix = 'FPH-' . date('Ymd') . '-';
    for ($i = 0; $i < 5; $i++) {
        $num = $prefix . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        if (!Database::fetch("SELECT id FROM orders WHERE order_number=?", [$num])) return $num;
    }
    return $prefix . time();
}