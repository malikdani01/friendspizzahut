<?php
// admin/customers/view.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id',0);
$u = Database::fetch("SELECT * FROM users WHERE id=?", [$id]);
if (!$u) { flash_error('Not found.'); redirect(url('admin/customers/index.php')); }
$pageTitle = 'Customer: ' . $u['name'];

if (is_post()) {
    verify_csrf();
    if (post('action') === 'block') {
        Database::execute("UPDATE users SET is_blocked=1, blocked_reason=? WHERE id=?", [mb_substr((string)post('reason',''),0,255), $id]);
        flash_success('Blocked.');
    } elseif (post('action') === 'unblock') {
        Database::execute("UPDATE users SET is_blocked=0, blocked_reason=NULL WHERE id=?", [$id]);
        flash_success('Unblocked.');
    }
    redirect(url('admin/customers/view.php?id='.$id));
}

$orders = Database::fetchAll("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 20", [$id]);
$spent = (float)(Database::fetch("SELECT COALESCE(SUM(total),0) s FROM orders WHERE user_id=? AND order_status NOT IN ('cancelled','refunded')", [$id])['s'] ?? 0);
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div class="space-y-5">
    <div class="bg-white rounded-xl shadow-sm border p-5">
      <h3 class="font-bold mb-3">Profile</h3>
      <div class="text-sm space-y-1">
        <div><span class="text-gray-500">Name:</span> <?= e($u['name']) ?></div>
        <div><span class="text-gray-500">Phone:</span> <?= e($u['phone']) ?></div>
        <div><span class="text-gray-500">Email:</span> <?= e($u['email'] ?: '—') ?></div>
        <div><span class="text-gray-500">Joined:</span> <?= date('d M Y', strtotime($u['created_at'])) ?></div>
        <div><span class="text-gray-500">Total Spent:</span> <strong class="text-brand"><?= money($spent) ?></strong></div>
      </div>
    </div>
    <div class="bg-white rounded-xl shadow-sm border p-5">
      <?php if ($u['is_blocked']): ?>
        <div class="bg-red-50 p-3 rounded mb-3 text-sm text-red-800">Blocked: <?= e($u['blocked_reason']) ?></div>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="unblock"><button class="w-full bg-green-600 text-white py-2 rounded">Unblock</button></form>
      <?php else: ?>
        <form method="post" class="space-y-2"><?= csrf_field() ?>
          <input type="hidden" name="action" value="block">
          <input name="reason" placeholder="Reason" class="w-full border rounded px-3 py-2 text-sm">
          <button class="w-full bg-red-600 text-white py-2 rounded">Block Customer</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
  <div class="md:col-span-2 bg-white rounded-xl shadow-sm border p-5">
    <h3 class="font-bold mb-3">Recent Orders</h3>
    <table class="w-full text-sm">
      <thead class="text-xs text-gray-500 uppercase"><tr><th class="text-left py-2">Order</th><th class="text-left">Total</th><th class="text-left">Status</th></tr></thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
        <tr class="border-t">
          <td class="py-2 font-mono text-xs"><?= e($o['order_number']) ?><div class="text-xs text-gray-500"><?= date('d M Y', strtotime($o['created_at'])) ?></div></td>
          <td class="font-semibold"><?= money($o['total']) ?></td>
          <td><?= status_badge($o['order_status']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$orders): ?><tr><td colspan="3" class="py-8 text-center text-gray-400">No orders.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>