-- ═══════════════════════════════════════════════════════════════
-- Migration 023: Order Estimated Time
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

ALTER TABLE orders ADD COLUMN IF NOT EXISTS estimated_minutes INT NULL AFTER is_first_order;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS eta_started_at DATETIME NULL AFTER estimated_minutes;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS eta_set_by INT UNSIGNED NULL AFTER eta_started_at;

CREATE INDEX IF NOT EXISTS idx_eta ON orders(estimated_minutes, eta_started_at);