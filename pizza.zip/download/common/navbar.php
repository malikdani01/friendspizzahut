<?php // Reusable navbar — included from header.php; standalone include for AJAX-free layout reuse ?>
<header class="sticky top-0 z-40 bg-ink/90 backdrop-blur border-b border-white/10">
  <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
    <a href="<?= url('index.php') ?>" class="flex items-center gap-3">
      <div class="w-11 h-11 rounded-full bg-brand flex items-center justify-center"><i class="fa-solid fa-pizza-slice text-white"></i></div>
      <div><div class="font-extrabold text-lg">FRIENDS</div><div class="text-brand text-sm font-bold">PIZZA HUT</div></div>
    </a>
    <nav class="hidden md:flex gap-6 text-sm">
      <a href="<?= url('index.php') ?>" class="hover:text-brand">Home</a>
      <a href="<?= url('menu.php') ?>" class="hover:text-brand">Menu</a>
      <a href="<?= url('deals.php') ?>" class="hover:text-brand">Deals</a>
      <a href="<?= url('contact.php') ?>" class="hover:text-brand">Contact</a>
    </nav>
    <a href="<?= url('cart.php') ?>" class="relative p-2"><i class="fa-solid fa-cart-shopping"></i></a>
  </div>
</header>