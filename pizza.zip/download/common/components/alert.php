<?php /** @var string $type @var string $message */
$type = $type ?? 'info';
$cls = ['success'=>'bg-green-500/20 border-green-500/40 text-green-200','error'=>'bg-red-500/20 border-red-500/40 text-red-200','warning'=>'bg-yellow-500/20 border-yellow-500/40 text-yellow-200','info'=>'bg-blue-500/20 border-blue-500/40 text-blue-200'][$type] ?? '';
?>
<div class="border px-4 py-3 rounded-lg text-sm <?= $cls ?>"><?= e($message) ?></div>