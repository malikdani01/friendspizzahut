-- ═══════════════════════════════════════════════════════════════
-- FRIENDS PIZZA HUT — Migration 003: Default Features Seed
-- Inserts all feature toggles with proper default states.
-- Run this on a fresh install to enable the Feature Manager.
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- Clear existing feature rows (safe re-run)
DELETE FROM features WHERE feature_key NOT IN ('__keep__');

-- ─── CORE (locked ON, cannot be disabled) ─────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('products',        'Products Management',  'core', 'Product catalog management', 1,1,1,0, 1),
('categories',      'Categories',           'core', 'Product categories', 1,1,1,0, 2),
('cart',            'Shopping Cart',        'core', 'Customer cart', 1,1,1,0, 3),
('checkout',        'Checkout',             'core', 'Order checkout flow', 1,1,1,0, 4),
('orders',          'Orders',               'core', 'Order management', 1,1,1,0, 5),
('admin_auth',      'Admin Authentication', 'core', 'Admin login', 1,1,1,0, 6),
('customer_auth',   'Customer Auth',        'core', 'Customer register/login', 1,1,1,0, 7),
('payments_cod',    'Cash on Delivery',     'core', 'COD payment', 1,1,1,0, 8),
('delivery_areas',  'Delivery Areas',       'core', 'Delivery zones', 1,1,1,0, 9),
('settings',        'Site Settings',        'core', 'Global settings', 1,1,1,0, 10);

-- ─── ENABLED BY DEFAULT (ready at launch) ─────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('banners',                  'Banners',                  'marketing',     'Homepage banners', 1,0,1,0, 20),
('coupons',                  'Coupons',                  'marketing',     'Discount coupons', 1,0,1,0, 21),
('offers',                   'Offers',                   'marketing',     'Special offers', 1,0,1,0, 22),
('product_reviews',          'Product Reviews',          'customer',      'Customer reviews', 1,0,1,0, 23),
('wishlist',                 'Wishlist',                 'customer',      'Save favorite items', 1,0,1,0, 24),
('notifications',            'Notifications',            'customer',      'In-app notifications', 1,0,1,0, 25),
('order_tracking',           'Order Tracking',           'orders',        'Track orders', 1,0,1,0, 26),
('order_cancel',             'Order Cancellation',       'orders',        'Cancel orders', 1,0,1,0, 27),
('address_book',             'Address Book',             'customer',      'Multiple addresses', 1,0,1,0, 28),
('free_delivery_promotion',  'Free Delivery Promotion',  'marketing',     'Free delivery above amount', 1,0,1,0, 29),
('search',                   'Search',                   'customer',      'Product search', 1,0,1,0, 30);

-- ─── DISABLED BY DEFAULT (owner enables from Feature Manager) ─
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('loyalty_points',       'Loyalty Points',        'customer',      'Earn and redeem points', 0,0,0,0, 40),
('referral_system',      'Referral System',       'marketing',     'Refer friends', 0,0,0,0, 41),
('gift_cards',           'Gift Cards',            'marketing',     'Buy and redeem gift cards', 0,0,0,0, 42),
('sms_notifications',    'SMS Notifications',     'notifications', 'Send SMS alerts', 0,0,0,1, 43),
('email_notifications',  'Email Notifications',   'notifications', 'Send email alerts', 0,0,0,1, 44),
('whatsapp_ordering',    'WhatsApp Ordering',     'integrations',  'Order via WhatsApp', 0,0,0,1, 45),
('kitchen_display',      'Kitchen Display',       'orders',        'Kitchen order screen', 0,0,0,0, 46),
('staff_roles',          'Staff & Roles',         'advanced',      'Staff accounts and permissions', 0,0,0,0, 47),
('inventory_tracking',   'Inventory Tracking',    'advanced',      'Stock management', 0,0,0,0, 48),
('refunds',              'Refunds',               'payments',      'Refund management', 0,0,0,0, 49),
('bank_transfer',        'Bank Transfer',         'payments',      'Bank transfer payment', 0,0,0,1, 50),
('online_payment',       'Online Payment',        'payments',      'Online payment gateway', 0,0,0,1, 51),
('table_reservation',    'Table Reservation',     'customer',      'Reserve table', 0,0,0,0, 52),
('combo_deals',          'Combo Deals',           'marketing',     'Product combos', 0,0,0,0, 53),
('first_order_offer',    'First Order Offer',     'marketing',     'Discount for first order', 0,0,0,0, 54),
('scheduled_orders',     'Scheduled Orders',      'orders',        'Schedule order for later', 0,0,0,0, 55),
('multi_language',       'Multi Language',        'advanced',      'Multiple languages', 0,0,0,0, 56),
('multi_currency',       'Multi Currency',        'advanced',      'Multiple currencies', 0,0,0,0, 57),
('tip_system',           'Tip System',            'advanced',      'Tip for delivery', 0,0,0,0, 58),
('rider_tracking',       'Rider Tracking',        'advanced',      'Live rider tracking', 0,0,0,0, 59),
('analytics_advanced',   'Advanced Analytics',    'advanced',      'Detailed analytics', 0,0,0,0, 60),
('customer_tiers',       'Customer Tiers',        'customer',      'Customer levels', 0,0,0,0, 61),
('abandoned_carts',      'Abandoned Carts',       'marketing',     'Recover abandoned carts', 0,0,0,0, 62),
('push_notifications',   'Push Notifications',    'notifications', 'Browser push notifications', 0,0,0,1, 63),
('pwa',                  'Progressive Web App',   'advanced',      'Installable PWA', 0,0,0,0, 64),
('social_login',         'Social Login',          'integrations',  'Login with Google/Facebook', 0,0,0,1, 65),
('product_bundles',      'Product Bundles',       'marketing',     'Bundle products', 0,0,0,0, 66);