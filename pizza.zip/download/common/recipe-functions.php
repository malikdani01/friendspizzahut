<?php
function get_recipe(int $productId): array {
    return Database::fetchAll(
        "SELECT ri.*, p.name AS ingredient_name, p.stock_quantity AS current_stock
         FROM recipe_ingredients ri
         LEFT JOIN products p ON p.id = ri.ingredient_product_id
         WHERE ri.product_id = ?",
        [$productId]
    );
}

function deduct_recipe_stock(int $productId, int $qty, ?int $orderId = null): void {
    if (!feature_enabled('recipe_tracking')) return;
    foreach (get_recipe($productId) as $r) {
        $deduct = (float)$r['quantity'] * $qty;
        inventory_adjust(
            (int)$r['ingredient_product_id'],
            -(int)ceil($deduct),
            'sale',
            'Recipe deduction for product #' . $productId,
            $orderId
        );
    }
}