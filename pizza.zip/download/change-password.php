<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
redirect(url('profile.php'));