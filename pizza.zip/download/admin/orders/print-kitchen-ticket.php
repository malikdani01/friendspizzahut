<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id', 0);
$o = get_order($id);
if (!$o) { flash_error('Not found.'); redirect(url('admin/orders/index.php')); }
$items = get_order_items($id);
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Kitchen Ticket</title>
<style>body{font-family:monospace;max-width:420px;margin:0 auto;padding:10px}h1{text-align:center;font-size:20px}hr{border:0;border-top:2px solid #000}table{width:100%}</style>
</head><body onload="window.print()">
<h1>KITCHEN — <?= e($o['order_number']) ?></h1>
<hr>
<div><?= date('d M Y, H:i', strtotime($o['created_at'])) ?></div>
<hr>
<?php foreach ($items as $it): ?>
<div style="font-size:18px;padding:6px 0"><strong><?= (int)$it['quantity'] ?>× <?= e($it['product_name']) ?></strong></div>
<?php foreach ($it['options'] as $op): ?><div style="padding-left:20px">→ <?= e($op['variation_option_name']) ?></div><?php endforeach; ?>
<?php foreach ($it['addons'] as $ad): ?><div style="padding-left:20px">+ <?= e($ad['addon_name']) ?></div><?php endforeach; ?>
<?php if ($it['special_instructions']): ?><div style="padding-left:20px;font-style:italic">Note: <?= e($it['special_instructions']) ?></div><?php endif; ?>
<hr>
<?php endforeach; ?>
</body></html>