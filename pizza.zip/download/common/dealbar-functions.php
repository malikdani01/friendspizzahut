<?php
/** Limited Time Deal Bar — with countdown */

function deal_bar_enabled(): bool {
    return feature_enabled('limited_deal_bar') && setting('deal_bar_enabled', '1') === '1';
}

function deal_bar_active_items(): array {
    if (!deal_bar_enabled()) return [];
    $now = date('Y-m-d H:i:s');
    return Database::fetchAll(
        "SELECT * FROM deal_bar_items
         WHERE is_active = 1 AND start_at <= ? AND end_at > ?
         ORDER BY sort_order, id",
        [$now, $now]
    );
}

function deal_bar_render(): string {
    $items = deal_bar_active_items();
    if (!$items) return '';

    $html = '<div class="fph-deal-bar-wrap">';
    foreach ($items as $d) {
        $endTs = strtotime($d['end_at']) * 1000; // JS milliseconds
        $url = $d['order_url'] ?: (
            $d['product_id'] ? url('product.php?id=' . (int)$d['product_id']) : (
                $d['combo_id'] ? url('deals.php') : url('menu.php')
            )
        );

        $html .= '<div class="fph-deal-bar" data-end-ts="' . $endTs . '" style="background:' . e($d['bg_color']) . ';color:' . e($d['text_color']) . ';">';
        $html .= '<div class="fph-deal-timer"><i class="fa-solid fa-clock"></i> <span class="fph-deal-countdown">--:--:--</span></div>';
        $html .= '<div class="fph-deal-info">';
        $html .= '<strong>' . e($d['deal_name']) . '</strong>';
        if (!empty($d['discount_text'])) {
            $html .= ' <span class="fph-deal-discount">' . e($d['discount_text']) . '</span>';
        }
        $html .= '</div>';
        $html .= '<a href="' . e($url) . '" class="fph-deal-btn">Order <i class="fa-solid fa-arrow-right"></i></a>';
        $html .= '</div>';
    }
    $html .= '</div>';
    return $html;
}