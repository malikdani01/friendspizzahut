# 🍕 Friends Pizza Hut — Online Ordering Platform

Production-ready PHP/MySQL restaurant ordering & management system for **Friends Pizza Hut**, City Tamman.

- **Owner:** Hamid Jabbar
- **Phone:** 03001494249
- **Location:** City Tamman, near MCB Bank

## ✨ Feature Toggle Architecture

Every advanced module is built-in but **disabled by default**.
Enable from **Admin → Feature Manager** — no code changes needed.

## 🚀 Installation

1. **Upload** all files to your web root (or subfolder).
2. Make sure `common/` and `uploads/` are writable (chmod 755 or 775).
3. Open `http://yoursite/setup.php` in a browser.
4. Fill in:
   - Database credentials (host, name, user, password)
   - Application URL (e.g. `http://localhost/friends-pizza-hut`)
   - Admin account (name, username, email, password)
5. Click **Install Now**.
6. **Delete `setup.php`** immediately after install.

## 🔑 Admin Access

Go to `/admin/login.php` and use the admin credentials you set during setup.

## 🎛️ Feature Manager

**Admin → Feature Manager** is the heart of the system.

- Toggle any optional feature ON/OFF instantly
- Core features are locked ON
- Categories: Core, Customer, Orders, Marketing, Payments, Notifications, Integrations, Advanced
- "Reset to Defaults" button restores MVP-ready state

## 📁 Project Structure

```
common/       → bootstrap, DB, helpers, auth, features, settings
database/     → schema.sql + seed.sql (full menu seeded)
admin/        → admin panel (login, dashboard, feature manager, ...)
assets/       → css + js
uploads/      → product/banner images (protected from PHP execution)
```

## 🛡️ Security

- PDO prepared statements only
- CSRF tokens on every POST
- `password_hash()` / `password_verify()`
- Session cookies: HttpOnly, SameSite=Lax, Secure on HTTPS
- Rate limiting on login (5 attempts / 15 min)
- Upload MIME validation (jpg/png/webp only, max 5 MB)
- `.htaccess` blocks direct access to `common/`, `database/`, `.sql`, `.log`

## 🗄️ Database

Full schema covers 40+ tables — features, settings, users, admins, staff, roles,
categories, products, variations, addons, combos/deals, offers, banners, coupons,
addresses, delivery areas, cart, orders, order items, order status history,
payments, refunds, reviews, favorites, notifications, loyalty, referrals,
gift cards, inventory, contact messages, homepage sections, audit logs,
login attempts, password resets.

## 🍕 Seeded Menu

The `seed.sql` includes the **complete menu** from the official Friends Pizza Hut
menu images:

- 14 Pizzas (with size variations: Small/Medium/Large/X-Large)
- 5 Burgers
- 3 Pasta (Small/Medium)
- 4 Fries
- 3 Sandwiches
- 12 Side Orders
- 7 Drinks (Regular/Half/1L/1.5L/2L)
- 3 Extra Toppings (Chicken, Cheese, Cheese Slice)
- 11 Deals (Deal 01–09, Birthday Deal, Deal 11)

All prices match the official menu exactly.

## 📌 Coming Next (Phases)

- Phase 2: Categories/Products/Variations/Add-ons admin CRUD
- Phase 3: Customer auth, Menu page, Product detail
- Phase 4: Cart, Checkout, Orders (COD)
- Phase 5: Order tracking, Payments, Bank Transfer
- Phase 6: Reviews, Wishlist, Notifications
- Phase 7: Reports, Analytics, Audit logs
- Phase 8+: Loyalty, Referrals, Kitchen Display, SMS, etc.

## 🧰 Requirements

- PHP 8.1+
- MySQL 5.7+ / MariaDB 10.3+
- Extensions: pdo_mysql, mbstring, fileinfo, json

## 🐛 Troubleshooting

- **"Not installed" redirect to setup.php**: `common/config.php` missing — run setup.
- **Blank page**: Enable `APP_DEBUG` in `common/config.php` to see errors.
- **Permission denied on uploads**: `chmod -R 755 uploads`.
- **CSRF error**: Clear cookies and try again.

---

© Friends Pizza Hut. All rights reserved.