<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Products';

$page = max(1, (int)get('page', 1));
$per = 15; $offset = ($page - 1) * $per;
$search = trim((string)get('q', ''));
$catId  = (int)get('category', 0);

$f = ['search' => $search, 'limit' => $per, 'offset' => $offset];
if ($catId) $f['category_id'] = $catId;
$rows = get_products($f);
$total = count_products(['search' => $search] + ($catId ? ['category_id' => $catId] : []));
$pages = max(1, (int)ceil($total / $per));
$cats = get_categories();

require __DIR__ . '/../common/header.php';
?>
<div class="flex flex-wrap items-center justify-between gap-3 mb-5">
  <form class="flex flex-wrap gap-2">
    <input name="q" value="<?= e($search) ?>" placeholder="Search products..." class="border border-gray-300 rounded-lg px-3 py-2 text-sm w-64">
    <select name="category" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
      <option value="">All Categories</option>
      <?php foreach ($cats as $c): ?>
        <option value="<?= (int)$c['id'] ?>" <?= $catId === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="bg-gray-800 text-white px-4 py-2 rounded-lg text-sm">Filter</button>
  </form>
  <a href="<?= url('admin/products/create.php') ?>" class="bg-brand hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-semibold">
    <i class="fa-solid fa-plus mr-1"></i> Add Product
  </a>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-gray-600 text-xs uppercase">
      <tr>
        <th class="text-left px-4 py-3">Image</th>
        <th class="text-left px-4 py-3">Name</th>
        <th class="text-left px-4 py-3">Category</th>
        <th class="text-left px-4 py-3">Price</th>
        <th class="text-left px-4 py-3">Status</th>
        <th class="text-left px-4 py-3">Flags</th>
        <th class="text-right px-4 py-3">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7" class="px-4 py-10 text-center text-gray-400">No products found.</td></tr>
      <?php else: foreach ($rows as $p): ?>
        <tr class="border-t border-gray-100 hover:bg-gray-50">
          <td class="px-4 py-3">
            <?php if ($p['image']): ?>
              <img src="<?= upload_url($p['image']) ?>" class="w-12 h-12 object-cover rounded">
            <?php else: ?>
              <div class="w-12 h-12 bg-gray-100 rounded flex items-center justify-center text-gray-400"><i class="fa-solid fa-box"></i></div>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3">
            <div class="font-semibold"><?= e($p['name']) ?></div>
            <div class="text-xs text-gray-400 font-mono"><?= e($p['slug']) ?></div>
          </td>
          <td class="px-4 py-3 text-gray-600"><?= e($p['category_name'] ?? '—') ?></td>
          <td class="px-4 py-3 font-semibold"><?= money($p['price']) ?></td>
          <td class="px-4 py-3">
            <?php $sc = ['active'=>'bg-green-100 text-green-800','inactive'=>'bg-gray-200 text-gray-700','archived'=>'bg-red-100 text-red-700'][$p['status']] ?? 'bg-gray-100'; ?>
            <span class="text-xs px-2 py-1 rounded font-semibold <?= $sc ?>"><?= e(ucfirst($p['status'])) ?></span>
          </td>
          <td class="px-4 py-3 text-xs space-x-1">
            <?php if ($p['is_featured']): ?><span class="px-1.5 py-0.5 rounded bg-yellow-100 text-yellow-800">★</span><?php endif; ?>
            <?php if ($p['is_bestseller']): ?><span class="px-1.5 py-0.5 rounded bg-blue-100 text-blue-800">BS</span><?php endif; ?>
            <?php if ($p['is_new']): ?><span class="px-1.5 py-0.5 rounded bg-purple-100 text-purple-800">N</span><?php endif; ?>
          </td>
          <td class="px-4 py-3 text-right whitespace-nowrap">
            <a href="<?= url('admin/products/edit.php?id=' . (int)$p['id']) ?>" class="text-blue-600 hover:underline text-xs mr-2">Edit</a>
            <form method="post" action="<?= url('admin/products/delete.php') ?>" class="inline" data-confirm="Delete this product?">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button class="text-red-600 hover:underline text-xs">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php if ($pages > 1): ?>
<div class="flex justify-center gap-2 mt-5">
  <?php for ($i = 1; $i <= $pages; $i++): 
    $qs = http_build_query(array_filter(['q'=>$search,'category'=>$catId?:null,'page'=>$i])); ?>
    <a href="?<?= $qs ?>" class="px-3 py-1.5 rounded text-sm <?= $i===$page ? 'bg-brand text-white' : 'bg-white border text-gray-700' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../common/footer.php'; ?>