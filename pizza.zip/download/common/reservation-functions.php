<?php
/**
 * Table Reservation functions
 * Feature-gated: table_reservation
 */

function reservation_generate_code(): string {
    $prefix = 'RES-' . date('Ymd') . '-';
    for ($i = 0; $i < 5; $i++) {
        $code = $prefix . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        if (!Database::fetch("SELECT id FROM reservations WHERE reservation_code = ?", [$code])) {
            return $code;
        }
    }
    return $prefix . time();
}

function reservation_create(array $data): array {
    // Validate
    $name = trim((string)($data['customer_name'] ?? ''));
    $phone = trim((string)($data['customer_phone'] ?? ''));
    $date = (string)($data['reservation_date'] ?? '');
    $time = (string)($data['reservation_time'] ?? '');
    $party = (int)($data['party_size'] ?? 0);

    if (strlen($name) < 2)                    return ['ok' => false, 'error' => 'Full name required.'];
    if (!validate_phone($phone))              return ['ok' => false, 'error' => 'Valid phone required.'];
    if (!$date || !strtotime($date))          return ['ok' => false, 'error' => 'Valid date required.'];
    if (!$time)                               return ['ok' => false, 'error' => 'Time required.'];
    if ($party < 1 || $party > 30)            return ['ok' => false, 'error' => 'Party size must be 1-30.'];

    // Date must be today or future
    $today = date('Y-m-d');
    if ($date < $today) {
        return ['ok' => false, 'error' => 'Date past mein nahi ho sakti.'];
    }

    // Max 30 days advance
    $maxDate = date('Y-m-d', strtotime('+30 days'));
    if ($date > $maxDate) {
        return ['ok' => false, 'error' => 'Maximum 30 days advance booking allowed.'];
    }

    // Check slot availability (same date+time+not-cancelled limit)
    $existing = (int)(Database::fetch(
        "SELECT COUNT(*) c FROM reservations
         WHERE reservation_date = ? AND reservation_time = ?
         AND status IN ('pending','confirmed','seated')",
        [$date, $time]
    )['c'] ?? 0);
    if ($existing >= 5) {
        return ['ok' => false, 'error' => 'Is time slot pe bohot reservations hain. Doosra time chunein.'];
    }

    $code = reservation_generate_code();

    $id = Database::insert('reservations', [
        'reservation_code' => $code,
        'user_id' => $data['user_id'] ?? null,
        'customer_name' => $name,
        'customer_phone' => $phone,
        'customer_email' => trim((string)($data['customer_email'] ?? '')) ?: null,
        'party_size' => $party,
        'reservation_date' => $date,
        'reservation_time' => $time,
        'duration_minutes' => 90,
        'special_requests' => trim((string)($data['special_requests'] ?? '')) ?: null,
        'status' => 'pending',
        'ip_address' => client_ip(),
    ]);

    // Notify admin
    Database::insert('notifications', [
        'user_type' => 'admin',
        'user_id' => 1,
        'type' => 'reservation_request',
        'title' => 'New Table Reservation',
        'message' => "$name — $party guests on " . date('d M', strtotime($date)) . " at $time (Code: $code)",
        'link' => '/admin/reservations/view.php?id=' . $id,
    ]);

    return ['ok' => true, 'id' => $id, 'code' => $code];
}

function reservation_get(int $id): ?array {
    return Database::fetch("SELECT * FROM reservations WHERE id = ?", [$id]);
}

function reservation_get_by_code(string $code): ?array {
    return Database::fetch("SELECT * FROM reservations WHERE reservation_code = ?", [$code]);
}

function reservation_user_list(int $userId, int $limit = 50): array {
    return Database::fetchAll(
        "SELECT * FROM reservations WHERE user_id = ? ORDER BY reservation_date DESC, reservation_time DESC LIMIT " . (int)$limit,
        [$userId]
    );
}

function reservation_admin_list(array $filters = []): array {
    $sql = "SELECT * FROM reservations WHERE 1=1";
    $params = [];
    if (!empty($filters['status'])) {
        $sql .= " AND status = ?";
        $params[] = $filters['status'];
    }
    if (!empty($filters['date'])) {
        $sql .= " AND reservation_date = ?";
        $params[] = $filters['date'];
    }
    if (!empty($filters['upcoming'])) {
        $sql .= " AND reservation_date >= CURDATE()";
    }
    if (!empty($filters['search'])) {
        $sql .= " AND (customer_name LIKE ? OR customer_phone LIKE ? OR reservation_code LIKE ?)";
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
        $params[] = '%' . $filters['search'] . '%';
    }
    $sql .= " ORDER BY reservation_date DESC, reservation_time DESC LIMIT 200";
    return Database::fetchAll($sql, $params);
}

function reservation_cancel(int $id, string $reason, string $by = 'customer'): array {
    $r = reservation_get($id);
    if (!$r) return ['ok' => false, 'error' => 'Reservation not found.'];
    if (in_array($r['status'], ['completed', 'cancelled', 'no_show'], true)) {
        return ['ok' => false, 'error' => 'Ye reservation cancel nahi ho sakti.'];
    }
    if ($by === 'customer' && $r['status'] === 'seated') {
        return ['ok' => false, 'error' => 'Seated reservation cancel nahi ho sakti. Restaurant se baat karein.'];
    }

    Database::execute(
        "UPDATE reservations SET status='cancelled', cancelled_at=NOW(), cancel_reason=?, cancelled_by=? WHERE id=?",
        [mb_substr($reason, 0, 255), $by, $id]
    );

    Database::insert('notifications', [
        'user_type' => 'admin', 'user_id' => 1,
        'type' => 'reservation_cancelled',
        'title' => 'Reservation Cancelled',
        'message' => "{$r['customer_name']} — {$r['reservation_code']} cancelled ($by)",
        'link' => '/admin/reservations/view.php?id=' . $id,
    ]);

    // Notify customer
    if ($r['user_id']) {
        Database::insert('notifications', [
            'user_type' => 'customer', 'user_id' => (int)$r['user_id'],
            'type' => 'reservation_cancelled',
            'title' => 'Reservation Cancelled',
            'message' => "Aapki reservation {$r['reservation_code']} cancel ho gayi hai.",
        ]);
    }

    return ['ok' => true];
}

function reservation_update_status(int $id, string $newStatus, ?int $adminId = null, ?string $note = null): array {
    $r = reservation_get($id);
    if (!$r) return ['ok' => false, 'error' => 'Reservation not found.'];

    $valid = ['pending','confirmed','seated','completed','cancelled','no_show'];
    if (!in_array($newStatus, $valid, true)) {
        return ['ok' => false, 'error' => 'Invalid status.'];
    }

    $updates = ['status' => $newStatus];
    if ($newStatus === 'confirmed') {
        $updates['confirmed_by'] = $adminId;
        $updates['confirmed_at'] = date('Y-m-d H:i:s');
    } elseif ($newStatus === 'seated') {
        $updates['seated_at'] = date('Y-m-d H:i:s');
    } elseif ($newStatus === 'completed') {
        $updates['completed_at'] = date('Y-m-d H:i:s');
    } elseif ($newStatus === 'cancelled') {
        $updates['cancelled_at'] = date('Y-m-d H:i:s');
        $updates['cancelled_by'] = 'admin';
        if ($note) $updates['cancel_reason'] = mb_substr($note, 0, 255);
    }
    if ($note && $newStatus !== 'cancelled') {
        $updates['admin_note'] = mb_substr($note, 0, 500);
    }

    Database::update('reservations', $updates, 'id = :id', ['id' => $id]);

    // Notify customer
    if ($r['user_id']) {
        $statusMsg = match ($newStatus) {
            'confirmed' => "Aapki reservation {$r['reservation_code']} confirm ho gayi. " . date('d M', strtotime($r['reservation_date'])) . " at " . date('h:i A', strtotime($r['reservation_time'])),
            'seated' => "Aap table pe seated hain. Enjoy!",
            'completed' => "Shukriya visit karne ke liye!",
            'cancelled' => "Aapki reservation admin ne cancel kar di.",
            'no_show' => "Aap time pe nahi aaye. Reservation close kar di.",
            default => "Reservation status update: " . ucfirst($newStatus),
        };
        Database::insert('notifications', [
            'user_type' => 'customer', 'user_id' => (int)$r['user_id'],
            'type' => 'reservation_status',
            'title' => 'Reservation Update',
            'message' => $statusMsg,
        ]);
    }

    return ['ok' => true];
}

function reservation_status_badge(string $status): string {
    $map = [
        'pending'   => 'bg-yellow-100 text-yellow-800',
        'confirmed' => 'bg-blue-100 text-blue-800',
        'seated'    => 'bg-purple-100 text-purple-800',
        'completed' => 'bg-green-100 text-green-800',
        'cancelled' => 'bg-gray-200 text-gray-700',
        'no_show'   => 'bg-red-100 text-red-800',
    ];
    $cls = $map[$status] ?? 'bg-gray-100 text-gray-700';
    return '<span class="inline-block px-2 py-1 text-xs font-semibold rounded ' . $cls . '">' . e(ucwords(str_replace('_', ' ', $status))) . '</span>';
}