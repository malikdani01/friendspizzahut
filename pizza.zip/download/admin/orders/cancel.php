<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/orders/index.php'));
verify_csrf();
$id = (int)post('id', 0);
$reason = trim((string)post('reason', 'Cancelled by admin'));
if ($id) {
    cancel_order($id, $reason, 'admin');
    audit_log('order.cancel', 'order', $id);
    flash_success('Order cancelled.');
}
redirect(url('admin/orders/view.php?id=' . $id));