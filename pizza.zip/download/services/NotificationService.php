<?php
// services/NotificationService.php
class NotificationService {
    public static function notify(...$args): void { notify(...$args); }
    public static function userList(int $u, int $l = 20): array { return get_user_notifications($u, $l); }
    public static function unreadCount(string $t, int $u): int { return unread_notification_count($t, $u); }
}