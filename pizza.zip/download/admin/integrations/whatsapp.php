<?php
// whatsapp.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('whatsapp_ordering')) redirect(url('admin/dashboard.php'));
$pageTitle = 'WhatsApp Settings';
if (is_post()) {
    verify_csrf();
    update_setting('restaurant_whatsapp', (string)post('whatsapp',''));
    flash_success('Saved.');
    redirect(url('admin/integrations/whatsapp.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <input name="whatsapp" value="<?= e(setting('restaurant_whatsapp','')) ?>" placeholder="WhatsApp number" class="w-full border rounded px-3 py-2">
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>