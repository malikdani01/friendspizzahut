<?php /** @var string $label @var string $name @var string $type @var string $value @var bool $required */
$type = $type ?? 'text'; $value = $value ?? ''; $required = $required ?? false; ?>
<div>
  <label class="block text-sm font-semibold mb-1"><?= e($label) ?><?= $required ? ' *' : '' ?></label>
  <input type="<?= e($type) ?>" name="<?= e($name) ?>" value="<?= e($value) ?>" <?= $required?'required':'' ?> class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none">
</div>