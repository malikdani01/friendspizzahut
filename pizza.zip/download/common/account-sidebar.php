<?php
$current = basename($_SERVER['SCRIPT_NAME']);
$links = [
    'account.php' => ['fa-gauge', 'Overview'],
    'orders.php' => ['fa-receipt', 'My Orders'],
    'wishlist.php' => ['fa-heart', 'Wishlist'],
    'addresses.php' => ['fa-location-dot', 'Addresses'],
    'notifications.php' => ['fa-bell', 'Notifications'],
    'messages.php' => ['fa-comments', 'Messages'],
    'profile.php' => ['fa-user', 'Profile'],
];
if (feature_enabled('loyalty_points')) $links['loyalty.php'] = ['fa-gift', 'Loyalty Points'];
if (feature_enabled('referral_system')) $links['referrals.php'] = ['fa-users', 'Referrals'];
if (feature_enabled('gift_cards')) $links['gift-cards.php'] = ['fa-gift', 'Gift Cards'];
if (feature_enabled('table_reservation')) $links['reservations.php'] = ['fa-calendar', 'Reservations'];
?>
<aside class="bg-white/5 border border-white/10 rounded-2xl p-3">
  <nav class="space-y-1 text-sm">
    <?php foreach ($links as $url => $info): $active = $current === $url; ?>
      <a href="<?= url($url) ?>" class="flex items-center gap-3 px-3 py-2 rounded-lg <?= $active ? 'bg-brand text-white' : 'text-white/70 hover:bg-white/5 hover:text-white' ?>">
        <i class="fa-solid <?= $info[0] ?> w-5"></i> <?= e($info[1]) ?>
        <?php if ($url === 'messages.php' && customer_logged_in() && feature_enabled('notifications') && function_exists('chat_unread_count')): ?>
          <?php $chatUnread = chat_unread_count((int)$_SESSION['user_id'], 'user', null); ?>
          <?php if ($chatUnread > 0): ?>
            <span style="margin-left:auto;background:#dc2626;color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:999px;"><?= $chatUnread ?></span>
          <?php endif; ?>
        <?php endif; ?>
      </a>
    <?php endforeach; ?>
  </nav>
</aside>