<?php
/**
 * Complete Your Meal (Upsell) — Helper Functions
 * Feature-gated: upsell_system
 */

function upsell_is_enabled(): bool {
    return feature_enabled('upsell_system') && setting('upsell_enabled', '1') === '1';
}

function upsell_get_products(): array {
    if (!upsell_is_enabled()) return [];

    $max = (int)setting('upsell_max_items', 8);
    if ($max < 1) $max = 8;

    $rows = Database::fetchAll(
        "SELECT up.id AS upsell_id, up.display_order, up.price_override, up.custom_price,
                up.override_start, up.override_end,
                p.*, c.name AS category_name
         FROM cart_upsell_products up
         JOIN products p ON p.id = up.product_id
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE up.is_enabled = 1
           AND p.status = 'active'
           AND p.is_available = 1
           AND (p.is_coming_soon = 0 OR p.is_coming_soon IS NULL)
         ORDER BY up.display_order ASC, p.name ASC
         LIMIT " . (int)$max
    );

    if (!$rows) return [];

    // Get cart quantities for these products (only simple items, no variations/addons)
    [$where, $params] = cart_query();
    $cartRows = Database::fetchAll(
        "SELECT ci.product_id, SUM(ci.quantity) AS qty
         FROM cart_items ci
         WHERE ci.$where
           AND NOT EXISTS (SELECT 1 FROM cart_item_options WHERE cart_item_id = ci.id)
           AND NOT EXISTS (SELECT 1 FROM cart_item_addons WHERE cart_item_id = ci.id)
         GROUP BY ci.product_id",
        $params
    );
    $cartByProduct = [];
    foreach ($cartRows as $cr) {
        $cartByProduct[(int)$cr['product_id']] = (int)$cr['qty'];
    }

    $result = [];
    foreach ($rows as $r) {
        $price = (float)($r['sale_price'] ?: $r['price']);

        if ((int)$r['price_override'] === 1 && $r['custom_price'] !== null) {
            $now = date('Y-m-d H:i:s');
            $inWindow = true;
            if ($r['override_start'] && $now < $r['override_start']) $inWindow = false;
            if ($r['override_end'] && $now > $r['override_end']) $inWindow = false;
            if ($inWindow) $price = (float)$r['custom_price'];
        }

        $result[] = [
            'product_id'    => (int)$r['id'],
            'name'          => $r['name'],
            'slug'          => $r['slug'],
            'image'         => $r['image'],
            'price'         => $price,
            'original_price'=> (float)$r['price'],
            'sale_price'    => $r['sale_price'] ? (float)$r['sale_price'] : null,
            'category_name' => $r['category_name'],
            'prep_time'     => (int)($r['prep_time_minutes'] ?? 0),
            'qty_in_cart'   => $cartByProduct[(int)$r['id']] ?? 0,
            'upsell_id'     => (int)$r['upsell_id'],
        ];
    }

    return $result;
}

function upsell_get_price(int $productId): ?float {
    $r = Database::fetch(
        "SELECT p.price, p.sale_price, p.status, p.is_available, p.is_coming_soon,
                up.price_override, up.custom_price, up.override_start, up.override_end
         FROM products p
         LEFT JOIN cart_upsell_products up ON up.product_id = p.id
         WHERE p.id = ?",
        [$productId]
    );
    if (!$r) return null;
    if ($r['status'] !== 'active' || (int)$r['is_available'] !== 1) return null;
    if ((int)($r['is_coming_soon'] ?? 0) === 1) return null;

    $price = (float)($r['sale_price'] ?: $r['price']);

    if ((int)($r['price_override'] ?? 0) === 1 && $r['custom_price'] !== null) {
        $now = date('Y-m-d H:i:s');
        $inWindow = true;
        if ($r['override_start'] && $now < $r['override_start']) $inWindow = false;
        if ($r['override_end'] && $now > $r['override_end']) $inWindow = false;
        if ($inWindow) $price = (float)$r['custom_price'];
    }

    return $price;
}