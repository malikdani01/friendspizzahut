<?php
// services/PaymentService.php
class PaymentService {
    public static function create(int $o, string $m, float $a): int { return create_payment($o, $m, $a); }
    public static function markPaid(int $id, ?int $a = null, ?string $r = null): void { mark_payment_paid($id, $a, $r); }
    public static function markFailed(int $id, ?string $n = null): void { mark_payment_failed($id, $n); }
}