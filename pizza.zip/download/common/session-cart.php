<?php
function cart_session_id(): string {
    if (empty($_SESSION['guest_sid'])) $_SESSION['guest_sid'] = bin2hex(random_bytes(16));
    return $_SESSION['guest_sid'];
}
function cart_reset_session(): void { unset($_SESSION['guest_sid']); }
function cart_persist_coupon(?string $code): void { $_SESSION['cart_coupon'] = $code; }
function cart_get_coupon(): ?string { return $_SESSION['cart_coupon'] ?? null; }
function cart_clear_coupon(): void { unset($_SESSION['cart_coupon']); }