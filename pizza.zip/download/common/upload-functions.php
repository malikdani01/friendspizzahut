<?php
function delete_uploaded_file(?string $path): void {
    if (!$path) return;
    $full = UPLOAD_PATH . '/' . ltrim($path, '/');
    if (file_exists($full) && is_file($full)) @unlink($full);
}
function upload_placeholder(): string { return asset('images/placeholder.png'); }
function product_image_url(?string $path): string {
    return $path ? upload_url($path) : upload_placeholder();
}