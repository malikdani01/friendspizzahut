<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$pageTitle = 'Favorites';
$items = feature_enabled('wishlist') ? wishlist_get((int)$_SESSION['user_id']) : [];
require __DIR__ . '/common/header.php';
?>
<div class="max-w-7xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-8">My Favorites</h1>
  <?php if (!$items): ?>
    <?php $icon='fa-heart'; $message='No favorites yet.'; $cta='Browse Menu'; $ctaUrl=url('menu.php'); require __DIR__ . '/common/components/empty-state.php'; ?>
  <?php else: ?>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      <?php foreach ($items as $p): require __DIR__ . '/common/components/product-card.php'; endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>