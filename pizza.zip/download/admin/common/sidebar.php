<?php
$current = basename($_SERVER['SCRIPT_NAME'] ?? '');
$currentDir = basename(dirname($_SERVER['SCRIPT_NAME'] ?? ''));

function admin_link_cls(bool $active): string {
    return $active ? 'admin-side-link admin-side-active' : 'admin-side-link';
}
function admin_is_dir(string $dir, string $currentDir): bool {
    return $dir === $currentDir;
}
function admin_is_file(string $file, string $current): bool {
    return $file === $current;
}
function fe(string $key): bool {
    return function_exists('feature_enabled') && feature_enabled($key);
}
?>

<style>
.admin-sidebar {
  grid-column: 1;
  background: linear-gradient(180deg, #0f0f0f 0%, #0a0a0a 100%);
  border-right: 1px solid var(--admin-border, rgba(255,255,255,0.08));
  padding: 0;
  overflow-y: auto;
  height: 100vh;
  position: sticky;
  top: 0;
  color: #fff;
}
@media (max-width: 1023px) {
  .admin-sidebar {
    position: fixed;
    top: 0; left: 0; bottom: 0;
    width: 280px; max-width: 85vw;
    z-index: 95;
    transform: translateX(-100%);
    transition: transform .3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 8px 0 40px rgba(0,0,0,0.6);
  }
  .admin-sidebar.open { transform: translateX(0); }
}

.admin-side-logo {
  padding: 20px 18px; display: flex; align-items: center; gap: 12px;
  border-bottom: 1px solid var(--admin-border, rgba(255,255,255,0.08));
  flex-shrink: 0;
}
.admin-side-logo-icon {
  width: 42px; height: 42px; border-radius: 50%;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 18px;
  box-shadow: 0 4px 12px rgba(220,38,38,0.4);
  flex-shrink: 0;
}
.admin-side-logo-text { line-height: 1.1; min-width: 0; }
.admin-side-logo-top { font-weight: 900; font-size: 12.5px; letter-spacing: 0.4px; color: #fff; white-space: nowrap; }
.admin-side-logo-sub { font-size: 10.5px; color: rgba(255,255,255,0.4); margin-top: 2px; }

.admin-side-nav { padding: 10px 10px 30px; }

.admin-side-sec {
  padding: 14px 14px 6px;
  font-size: 10px; font-weight: 800;
  text-transform: uppercase; letter-spacing: 1.2px;
  color: rgba(255,255,255,0.3);
}

.admin-side-link {
  display: flex; align-items: center; gap: 12px;
  padding: 10px 14px; border-radius: 10px;
  color: rgba(255,255,255,0.7); text-decoration: none;
  font-size: 13.5px; font-weight: 600;
  margin-bottom: 2px;
  transition: all .18s cubic-bezier(0.4, 0, 0.2, 1);
  border-left: 3px solid transparent;
}
.admin-side-link:hover {
  background: rgba(255,255,255,0.05);
  color: #fff; padding-left: 18px;
}
.admin-side-link i {
  width: 20px; text-align: center; font-size: 14px;
  color: rgba(255,255,255,0.5);
  transition: color .15s; flex-shrink: 0;
}
.admin-side-link:hover i { color: #dc2626; }

.admin-side-link.admin-side-active {
  background: linear-gradient(90deg, rgba(220,38,38,0.18), rgba(220,38,38,0.04));
  color: #fff;
  border-left-color: #dc2626;
  box-shadow: 0 2px 12px rgba(220,38,38,0.15);
}
.admin-side-link.admin-side-active i { color: #dc2626; }

.admin-side-link.danger { color: #f87171; }
.admin-side-link.danger i { color: #f87171; }
.admin-side-link.danger:hover { background: rgba(220,38,38,0.1); color: #fca5a5; }
</style>

<aside class="admin-sidebar" id="adminSidebar">

  <div class="admin-side-logo">
    <div class="admin-side-logo-icon"><i class="fa-solid fa-pizza-slice"></i></div>
    <div class="admin-side-logo-text">
      <div class="admin-side-logo-top">FRIENDS PIZZA HUT</div>
      <div class="admin-side-logo-sub">Admin Panel</div>
    </div>
  </div>

  <nav class="admin-side-nav">

    <!-- ═══ DASHBOARD ═══ -->
    <a href="<?= url('admin/dashboard.php') ?>" class="<?= admin_link_cls(admin_is_file('dashboard.php', $current)) ?>">
      <i class="fa-solid fa-gauge-high"></i> Dashboard
    </a>

    <!-- ═══ OPERATIONS ═══ -->
    <div class="admin-side-sec">Operations</div>
    <a href="<?= url('admin/orders/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('orders', $currentDir)) ?>">
      <i class="fa-solid fa-receipt"></i> Orders
    </a>
    <?php if (fe('kitchen_display')): ?>
    <a href="<?= url('admin/kitchen/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('kitchen', $currentDir)) ?>">
      <i class="fa-solid fa-fire-burner"></i> Kitchen
    </a>
    <?php endif; ?>
    <?php if (fe('rider_module')): ?>
    <a href="<?= url('admin/riders/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('riders', $currentDir)) ?>">
      <i class="fa-solid fa-motorcycle"></i> Riders
    </a>
    <?php endif; ?>

    <!-- ═══ CATALOG ═══ -->
    <div class="admin-side-sec">Catalog</div>
    <a href="<?= url('admin/products/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('products', $currentDir)) ?>">
      <i class="fa-solid fa-box"></i> Products
    </a>
    <a href="<?= url('admin/categories/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('categories', $currentDir)) ?>">
      <i class="fa-solid fa-layer-group"></i> Categories
    </a>
    <a href="<?= url('admin/variations/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('variations', $currentDir)) ?>">
      <i class="fa-solid fa-sliders"></i> Variations
    </a>
    <a href="<?= url('admin/addons/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('addons', $currentDir)) ?>">
      <i class="fa-solid fa-plus"></i> Add-ons
    </a>
    <?php if (fe('combo_deals')): ?>
    <a href="<?= url('admin/combos/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('combos', $currentDir)) ?>">
      <i class="fa-solid fa-tags"></i> Combos
    </a>
    <?php endif; ?>
    <?php if (fe('inventory_tracking')): ?>
    <a href="<?= url('admin/inventory/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('inventory', $currentDir)) ?>">
      <i class="fa-solid fa-warehouse"></i> Inventory
    </a>
    <?php endif; ?>

    <!-- ═══ MARKETING ═══ -->
    <div class="admin-side-sec">Marketing</div>
    <a href="<?= url('admin/marketing/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('marketing', $currentDir) && $current !== 'upsell.php' && $current !== 'bulk-sms.php') ?>">
      <i class="fa-solid fa-bullhorn"></i> Marketing Hub
    </a>
    <?php if (fe('offers')): ?>
    <a href="<?= url('admin/offers/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('offers', $currentDir)) ?>">
      <i class="fa-solid fa-bolt"></i> Offers
    </a>
    <?php endif; ?>
    <?php if (fe('coupons')): ?>
    <a href="<?= url('admin/coupons/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('coupons', $currentDir)) ?>">
      <i class="fa-solid fa-ticket"></i> Coupons
    </a>
    <?php endif; ?>
    <?php if (fe('customer_tiers')): ?>
    <a href="<?= url('admin/tiers/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('tiers', $currentDir)) ?>">
      <i class="fa-solid fa-crown"></i> Customer Tiers
    </a>
    <?php endif; ?>
    <?php if (fe('upsell_system')): ?>
    <a href="<?= url('admin/marketing/upsell.php') ?>" class="<?= admin_link_cls(admin_is_file('upsell.php', $current)) ?>">
      <i class="fa-solid fa-cart-plus"></i> Complete Your Meal
    </a>
    <?php endif; ?>
    <?php if (fe('bulk_sms_marketing')): ?>
    <a href="<?= url('admin/marketing/bulk-sms.php') ?>" class="<?= admin_link_cls(admin_is_file('bulk-sms.php', $current)) ?>">
      <i class="fa-solid fa-comment-sms"></i> Bulk SMS
    </a>
    <?php endif; ?>
    <?php if (fe('loyalty_points')): ?>
    <a href="<?= url('admin/loyalty/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('loyalty', $currentDir)) ?>">
      <i class="fa-solid fa-gift"></i> Loyalty
    </a>
    <?php endif; ?>
    <?php if (fe('referral_system')): ?>
    <a href="<?= url('admin/referrals/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('referrals', $currentDir)) ?>">
      <i class="fa-solid fa-users"></i> Referrals
    </a>
    <?php endif; ?>
    <?php if (fe('gift_cards')): ?>
    <a href="<?= url('admin/gift-cards/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('gift-cards', $currentDir)) ?>">
      <i class="fa-solid fa-gift"></i> Gift Cards
    </a>
    <?php endif; ?>

    <!-- ═══ CUSTOMERS ═══ -->
    <div class="admin-side-sec">Customers</div>
    <a href="<?= url('admin/customers/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('customers', $currentDir)) ?>">
      <i class="fa-solid fa-users"></i> Customers
    </a>
    <?php if (fe('product_reviews')): ?>
    <a href="<?= url('admin/reviews/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('reviews', $currentDir)) ?>">
      <i class="fa-solid fa-star"></i> Reviews
    </a>
    <?php endif; ?>
    <?php if (fe('customer_wallet')): ?>
    <a href="<?= url('admin/wallet/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('wallet', $currentDir)) ?>">
      <i class="fa-solid fa-wallet"></i> Wallets
    </a>
    <?php endif; ?>
    <?php $supportUnread = 0; try {
        $supportUnread = (int)(Database::fetch("SELECT COUNT(*) c FROM chat_messages WHERE sender_type = 'user' AND is_read = 0")['c'] ?? 0);
        $contactUnread = (int)(Database::fetch("SELECT COUNT(*) c FROM contact_messages WHERE is_read = 0")['c'] ?? 0);
        $supportUnread += $contactUnread;
    } catch (Throwable $e) { $supportUnread = 0; } ?>
    <a href="<?= url('admin/messages/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('messages', $currentDir)) ?>" style="position:relative;">
      <i class="fa-solid fa-headset"></i> Support Chat
      <?php if ($supportUnread > 0): ?>
        <span style="margin-left:auto;background:#dc2626;color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:999px;min-width:20px;text-align:center;"><?= $supportUnread ?></span>
      <?php endif; ?>
    </a>

    <!-- ═══ CONTENT ═══ -->
    <div class="admin-side-sec">Content</div>
    <a href="<?= url('admin/homepage/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('homepage', $currentDir)) ?>">
      <i class="fa-solid fa-house"></i> Homepage
    </a>
    <?php if (fe('banners')): ?>
    <a href="<?= url('admin/banners/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('banners', $currentDir)) ?>">
      <i class="fa-solid fa-image"></i> Banners
    </a>
    <?php endif; ?>

    <!-- ═══ PAYMENTS ═══ -->
    <div class="admin-side-sec">Payments</div>
    <a href="<?= url('admin/payments/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('payments', $currentDir)) ?>">
      <i class="fa-solid fa-credit-card"></i> Payments
    </a>
    <?php if (fe('refunds')): ?>
    <a href="<?= url('admin/refunds/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('refunds', $currentDir)) ?>">
      <i class="fa-solid fa-rotate-left"></i> Refunds
    </a>
    <?php endif; ?>

    <!-- ═══ DELIVERY ═══ -->
    <div class="admin-side-sec">Delivery</div>
    <a href="<?= url('admin/delivery/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('delivery', $currentDir)) ?>">
      <i class="fa-solid fa-truck"></i> Delivery Areas
    </a>

    <!-- ═══ REPORTS ═══ -->
    <div class="admin-side-sec">Reports</div>
    <a href="<?= url('admin/reports/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('reports', $currentDir)) ?>">
      <i class="fa-solid fa-chart-line"></i> Reports
    </a>
    <a href="<?= url('admin/analytics/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('analytics', $currentDir)) ?>">
      <i class="fa-solid fa-chart-pie"></i> Analytics
    </a>
    <?php if (fe('profit_loss_report')): ?>
    <a href="<?= url('admin/reports/profit-loss.php') ?>" class="admin-side-link">
      <i class="fa-solid fa-coins"></i> Profit & Loss
    </a>
    <?php endif; ?>
    <?php if (fe('daily_closing')): ?>
    <a href="<?= url('admin/reports/daily-closing.php') ?>" class="admin-side-link">
      <i class="fa-solid fa-cash-register"></i> Daily Closing
    </a>
    <?php endif; ?>
    <?php if (fe('peak_hours_heatmap')): ?>
    <a href="<?= url('admin/analytics/heatmap.php') ?>" class="admin-side-link">
      <i class="fa-solid fa-fire"></i> Peak Hours
    </a>
    <?php endif; ?>

    <!-- ═══ UI MANAGER ═══ -->
    <div class="admin-side-sec">UI Manager</div>
    <?php if (fe('alert_bar')): ?>
    <a href="<?= url('admin/ui/alert-bar.php') ?>" class="<?= admin_link_cls(admin_is_file('alert-bar.php', $current)) ?>">
      <i class="fa-solid fa-bullhorn"></i> Alert Bar
    </a>
    <?php endif; ?>
    <?php if (fe('limited_deal_bar')): ?>
    <a href="<?= url('admin/ui/deal-bar.php') ?>" class="<?= admin_link_cls(admin_is_file('deal-bar.php', $current)) ?>">
      <i class="fa-solid fa-clock"></i> Deal Bar
    </a>
    <?php endif; ?>
    <?php if (fe('qr_menu')): ?>
    <a href="<?= url('admin/qr-codes/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('qr-codes', $currentDir)) ?>">
      <i class="fa-solid fa-qrcode"></i> QR Codes
    </a>
    <?php endif; ?>

    <!-- ═══ INTEGRATIONS ═══ -->
    <?php if (fe('sms_notifications') || fe('email_notifications') || fe('whatsapp_business_api') || fe('whatsapp_ordering') || fe('facebook_pixel') || fe('google_analytics')): ?>
    <div class="admin-side-sec">Integrations</div>
    <?php if (fe('sms_notifications')): ?>
    <a href="<?= url('admin/integrations/sms.php') ?>" class="<?= admin_link_cls(admin_is_file('sms.php', $current)) ?>">
      <i class="fa-solid fa-comment-sms"></i> SMS
    </a>
    <?php endif; ?>
    <?php if (fe('email_notifications')): ?>
    <a href="<?= url('admin/settings/email.php') ?>" class="admin-side-link">
      <i class="fa-solid fa-envelope"></i> Email SMTP
    </a>
    <?php endif; ?>
    <?php if (fe('whatsapp_business_api')): ?>
    <a href="<?= url('admin/integrations/whatsapp-api.php') ?>" class="admin-side-link">
      <i class="fa-brands fa-whatsapp"></i> WhatsApp API
    </a>
    <?php endif; ?>
    <?php if (fe('facebook_pixel') || fe('google_analytics')): ?>
    <a href="<?= url('admin/settings/marketing.php') ?>" class="admin-side-link">
      <i class="fa-solid fa-chart-simple"></i> Tracking
    </a>
    <?php endif; ?>
    <?php endif; ?>

    <!-- ═══ STAFF ═══ -->
    <?php if (fe('staff_roles')): ?>
    <div class="admin-side-sec">Staff</div>
    <a href="<?= url('admin/staff/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('staff', $currentDir)) ?>">
      <i class="fa-solid fa-user-tie"></i> Staff
    </a>
    <a href="<?= url('admin/roles/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('roles', $currentDir)) ?>">
      <i class="fa-solid fa-shield-halved"></i> Roles
    </a>
    <?php endif; ?>

    <!-- ═══ SYSTEM ═══ -->
    <div class="admin-side-sec">System</div>
    <a href="<?= url('admin/features/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('features', $currentDir)) ?>">
      <i class="fa-solid fa-toggle-on"></i> Feature Manager
    </a>
    <a href="<?= url('admin/settings/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('settings', $currentDir)) ?>">
      <i class="fa-solid fa-gear"></i> Settings
    </a>
    <?php if (fe('backup_restore')): ?>
    <a href="<?= url('admin/system/backup.php') ?>" class="<?= admin_link_cls(admin_is_dir('system', $currentDir)) ?>">
      <i class="fa-solid fa-database"></i> Backup & Restore
    </a>
    <?php endif; ?>
    <a href="<?= url('admin/audit-logs/index.php') ?>" class="<?= admin_link_cls(admin_is_dir('audit-logs', $currentDir)) ?>">
      <i class="fa-solid fa-clock-rotate-left"></i> Audit Logs
    </a>
    <a href="<?= url('admin/logout.php') ?>" class="admin-side-link danger">
      <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>

  </nav>
</aside>