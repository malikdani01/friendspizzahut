<?php
require_once __DIR__ . '/../common/bootstrap.php';
require_admin();
redirect(url('admin/features/index.php'));