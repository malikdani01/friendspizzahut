/**
 * Friends Pizza Hut — Theme Upgrade Interactions
 * Scroll reveal, ripple effect, image lazy-load fade-in
 */
(function() {
  'use strict';

  // ─── SCROLL REVEAL ─────────────────────────────────────────
  var revealEls = document.querySelectorAll('.fph-reveal');
  if (revealEls.length && 'IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    revealEls.forEach(function(el) { observer.observe(el); });
  } else {
    revealEls.forEach(function(el) { el.classList.add('revealed'); });
  }

  // ─── RIPPLE EFFECT ON BUTTONS ──────────────────────────────
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('button, .fph-btn, .checkout-btn, .pd-add-btn, a.fph-btn');
    if (!btn || btn.disabled) return;
    if (!btn.classList.contains('fph-ripple')) return;
    // Ripple handled by CSS pseudo-element
  });

  // ─── IMAGE LAZY LOAD FADE-IN ───────────────────────────────
  function markLoaded(img) {
    img.classList.add('loaded');
  }
  document.querySelectorAll('img[loading="lazy"]').forEach(function(img) {
    if (img.complete) {
      markLoaded(img);
    } else {
      img.addEventListener('load', function() { markLoaded(img); });
      img.addEventListener('error', function() { markLoaded(img); });
    }
  });

  // ─── SMOOTH SCROLL FOR ANCHOR LINKS ────────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var target = document.querySelector(a.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // ─── ADD RIPPLE CLASS TO PRIMARY BUTTONS ───────────────────
  document.querySelectorAll('.fph-btn-primary, .checkout-btn, .pd-add-btn, .fph-bn-home-circle').forEach(function(el) {
    el.classList.add('fph-ripple');
  });

  // ─── HAPTIC FEEDBACK (mobile) ──────────────────────────────
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('button, .fph-btn, .qty-box button, .upsell-qty button');
    if (!btn) return;
    if ('vibrate' in navigator) {
      navigator.vibrate(10);
    }
  });

  // ─── PREVENT DOUBLE-TAP ZOOM ON BUTTONS ────────────────────
  var lastTouch = 0;
  document.querySelectorAll('button, .fph-btn').forEach(function(btn) {
    btn.addEventListener('touchend', function(e) {
      var now = Date.now();
      if (now - lastTouch < 300) {
        e.preventDefault();
      }
      lastTouch = now;
    }, { passive: false });
  });
})();