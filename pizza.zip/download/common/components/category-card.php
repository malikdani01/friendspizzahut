<?php /** @var array $cat */ ?>
<a href="<?= url('category.php?slug=' . urlencode($cat['slug'])) ?>"
   class="group bg-white/5 border border-white/10 hover:border-brand/40 rounded-2xl p-5 text-center transition">
  <div class="w-16 h-16 mx-auto rounded-full bg-brand/20 flex items-center justify-center mb-3 group-hover:scale-110 transition">
    <i class="fa-solid <?= e($cat['icon'] ?: 'fa-utensils') ?> text-brand text-2xl"></i>
  </div>
  <div class="font-bold"><?= e($cat['name']) ?></div>
  <div class="text-xs text-white/50 mt-1"><?= get_category_product_count((int)$cat['id']) ?> items</div>
</a>