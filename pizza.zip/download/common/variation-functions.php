<?php
function get_all_variation_groups(): array {
    $groups = Database::fetchAll("SELECT * FROM variation_groups WHERE is_active=1 ORDER BY sort_order");
    foreach ($groups as &$g) {
        $g['options'] = Database::fetchAll("SELECT * FROM variation_options WHERE group_id=? AND is_active=1 ORDER BY sort_order", [$g['id']]);
    }
    return $groups;
}
function get_variation_group(int $id): ?array {
    return Database::fetch("SELECT * FROM variation_groups WHERE id=?", [$id]);
}
function get_variation_options(int $groupId): array {
    return Database::fetchAll("SELECT * FROM variation_options WHERE group_id=? ORDER BY sort_order", [$groupId]);
}
function attach_variation_group(int $productId, int $groupId, int $sortOrder = 0): void {
    if (!Database::fetch("SELECT id FROM product_variation_groups WHERE product_id=? AND group_id=?", [$productId, $groupId])) {
        Database::insert('product_variation_groups', ['product_id'=>$productId, 'group_id'=>$groupId, 'sort_order'=>$sortOrder]);
    }
}
function detach_variation_group(int $productId, int $groupId): void {
    Database::execute("DELETE FROM product_variation_groups WHERE product_id=? AND group_id=?", [$productId, $groupId]);
}