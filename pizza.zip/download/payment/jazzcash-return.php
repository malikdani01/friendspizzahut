<?php
/**
 * JazzCash Payment — Return Handler
 * Customer payment ke baad JazzCash yahan wapas bhejta hai.
 * URL: https://yoursite.com/payment/jazzcash-return.php
 */
require_once __DIR__ . '/../common/bootstrap.php';

// JazzCash POST bhejta hai (kabhi GET bhi)
$data = $_POST ?: $_GET;

// Log raw return
jazzcash_log('return_received', [
    'raw' => array_map(fn($v) => is_string($v) ? mb_substr($v, 0, 200) : $v, $data),
]);

// ─── Validate reference ────────────────────────────────────────
if (empty($data['pp_BillReference'])) {
    flash_error('Invalid payment response — missing reference.');
    redirect(url('checkout.php'));
}

$orderNumber = (string) $data['pp_BillReference'];
$order = get_order_by_number($orderNumber);

if (!$order) {
    flash_error('Order not found: ' . $orderNumber);
    redirect(url('checkout.php'));
}

// ─── Verify hash ───────────────────────────────────────────────
if (!jazzcash_verify_response($data)) {
    jazzcash_log('hash_mismatch', [
        'order' => $orderNumber,
        'received_hash' => $data['pp_SecureHash'] ?? null,
    ]);
    flash_error('Payment verification failed (hash mismatch). Contact support.');
    redirect(url('order-detail.php?id=' . (int)$order['id']));
}

// ─── Extract response data ─────────────────────────────────────
$responseCode = (string) ($data['pp_ResponseCode'] ?? '');
$responseMsg  = (string) ($data['pp_ResponseMessage'] ?? '');
$txnRefNo     = (string) ($data['pp_TxnRefNo'] ?? '');
$amountPaid   = ((int)($data['pp_Amount'] ?? 0)) / 100; // paisa → rupees
$paymentMethod = (string) ($data['pp_PaymentMethod'] ?? 'MWALLET');

// ─── Handle failure ────────────────────────────────────────────
if (!jazzcash_response_success($responseCode)) {
    jazzcash_log('payment_failed', [
        'order' => $orderNumber,
        'code'  => $responseCode,
        'msg'   => $responseMsg,
    ]);

    // Mark payment failed (if exists)
    $payment = Database::fetch(
        "SELECT id FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1",
        [(int)$order['id']]
    );
    if ($payment) {
        mark_payment_failed((int)$payment['id'], "JazzCash: $responseCode — $responseMsg");
    }

    // User-friendly message based on code
    $userMsg = match($responseCode) {
        '124' => 'Payment timeout. Please try again.',
        '157' => 'Insufficient balance in JazzCash wallet.',
        '199' => 'Payment declined by bank.',
        ''    => 'Payment cancelled.',
        default => 'Payment failed: ' . ($responseMsg ?: 'Unknown error'),
    };

    flash_error($userMsg);
    redirect(url('order-detail.php?id=' . (int)$order['id']));
}

// ─── Idempotency: already paid? ────────────────────────────────
if ($order['payment_status'] === 'paid') {
    jazzcash_log('already_paid', ['order' => $orderNumber]);
    flash_success('Payment already received. Thank you!');
    redirect(url('order-success.php?order=' . urlencode($orderNumber)));
}

// ─── Payment SUCCESS — commit transaction ──────────────────────
Database::beginTransaction();
try {
    // Find or create payment record
    $payment = Database::fetch(
        "SELECT * FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1",
        [(int)$order['id']]
    );

    if (!$payment) {
        $paymentId = create_payment((int)$order['id'], 'jazzcash', (float)$order['total']);
    } else {
        $paymentId = (int)$payment['id'];
        Database::execute("UPDATE payments SET method = 'jazzcash' WHERE id = ?", [$paymentId]);
    }

    // Mark paid
    mark_payment_paid($paymentId, null, $txnRefNo);

    // Log transaction details
    Database::insert('payment_transactions', [
        'payment_id'   => $paymentId,
        'gateway'      => 'jazzcash',
        'reference'    => $txnRefNo,
        'amount'       => $amountPaid,
        'status'       => 'success',
        'raw_response' => json_encode($data),
    ]);

    // Auto-confirm order
    if ($order['order_status'] === 'pending') {
        update_order_status(
            (int)$order['id'],
            'confirmed',
            null,
            null,
            'Auto-confirmed after JazzCash payment'
        );
    }

    // Notify admin
    Database::insert('notifications', [
        'user_type' => 'admin',
        'user_id'   => 1,
        'type'      => 'payment_received',
        'title'     => 'JazzCash Payment Received',
        'message'   => "Order {$orderNumber} — Rs. " . number_format($amountPaid, 0) . " paid via JazzCash (Txn: {$txnRefNo}).",
        'link'      => '/admin/orders/view.php?id=' . (int)$order['id'],
    ]);

    // Notify customer (in-app)
    if (!empty($order['user_id'])) {
        Database::insert('notifications', [
            'user_type' => 'customer',
            'user_id'   => (int)$order['user_id'],
            'type'      => 'payment_received',
            'title'     => 'Payment Confirmed',
            'message'   => "Payment Rs. " . number_format($amountPaid, 0) . " received for order {$orderNumber}.",
            'link'      => '/order-detail.php?id=' . (int)$order['id'],
        ]);
    }

    // Optional: Send SMS confirmation
    if (feature_enabled('sms_notifications')) {
        try {
            send_sms(
                $order['customer_phone'],
                "Payment received: Rs. " . number_format($amountPaid, 0) . " for order {$orderNumber}. Thank you!"
            );
        } catch (Throwable $e) {
            error_log('SMS send failed: ' . $e->getMessage());
        }
    }

    Database::commit();

    jazzcash_log('payment_success', [
        'order'   => $orderNumber,
        'txn'     => $txnRefNo,
        'amount'  => $amountPaid,
        'method'  => $paymentMethod,
    ]);

    flash_success('Payment successful! Rs. ' . number_format($amountPaid, 0) . ' received.');
    redirect(url('order-success.php?order=' . urlencode($orderNumber)));

} catch (Throwable $e) {
    Database::rollback();
    error_log('JazzCash return error: ' . $e->getMessage());

    jazzcash_log('payment_error', [
        'order' => $orderNumber,
        'error' => $e->getMessage(),
    ]);

    flash_error('Payment received but order update failed. Please contact us with order number: ' . $orderNumber);
    redirect(url('order-detail.php?id=' . (int)$order['id']));
}