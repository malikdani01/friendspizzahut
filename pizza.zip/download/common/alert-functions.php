<?php
/** Alert Bar — scrolling promo messages */

function alert_bar_enabled(): bool {
    return feature_enabled('alert_bar') && setting('alert_bar_enabled', '1') === '1';
}

function alert_bar_items(): array {
    if (!alert_bar_enabled()) return [];
    return Database::fetchAll(
        "SELECT * FROM alert_bar_items WHERE is_active = 1 ORDER BY sort_order, id"
    );
}

function alert_bar_render(): string {
    $items = alert_bar_items();
    if (!$items) return '';

    $speed = max(10, (int)setting('alert_bar_speed', 30));
    $bg = setting('alert_bar_bg', '#0a0a0a');
    $fg = setting('alert_bar_text', '#ffffff');

    $html = '<div class="fph-alert-bar" style="background:' . e($bg) . ';color:' . e($fg) . ';">';
    $html .= '<div class="fph-alert-track" style="animation-duration:' . $speed . 's;">';

    // Duplicate items for seamless loop
    foreach ([1, 2] as $loop) {
        foreach ($items as $it) {
            $html .= '<span class="fph-alert-item">';
            if (!empty($it['icon'])) $html .= '<i class="fa-solid ' . e($it['icon']) . '"></i> ';
            if (!empty($it['link_url'])) {
                $html .= '<a href="' . e($it['link_url']) . '" style="color:inherit;text-decoration:underline;">' . e($it['text']) . '</a>';
            } else {
                $html .= e($it['text']);
            }
            if (!empty($it['link_text']) && !empty($it['link_url'])) {
                $html .= ' <a href="' . e($it['link_url']) . '" class="fph-alert-cta" style="color:inherit;">' . e($it['link_text']) . ' →</a>';
            }
            $html .= '</span>';
            $html .= '<span class="fph-alert-sep">•</span>';
        }
    }

    $html .= '</div></div>';
    return $html;
}