<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Reports';

$from = (string)get('from', date('Y-m-01'));
$to = (string)get('to', date('Y-m-d'));

$sales = Database::fetch(
    "SELECT COUNT(*) orders, COALESCE(SUM(total),0) revenue, COALESCE(AVG(total),0) avg
     FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND order_status NOT IN ('cancelled','refunded')",
    [$from, $to]);
$orderStatusCounts = Database::fetchAll(
    "SELECT order_status, COUNT(*) c FROM orders WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY order_status",
    [$from, $to]);
$topProducts = Database::fetchAll(
    "SELECT oi.product_name, SUM(oi.quantity) qty, SUM(oi.line_total) revenue
     FROM order_items oi JOIN orders o ON o.id=oi.order_id
     WHERE DATE(o.created_at) BETWEEN ? AND ? AND o.order_status NOT IN ('cancelled','refunded')
     GROUP BY oi.product_name ORDER BY qty DESC LIMIT 10",
    [$from, $to]);
$topCustomers = Database::fetchAll(
    "SELECT customer_name, customer_phone, COUNT(*) orders, SUM(total) spent
     FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND order_status NOT IN ('cancelled','refunded')
     GROUP BY customer_phone ORDER BY spent DESC LIMIT 10",
    [$from, $to]);

// CSV export
if (get('export') === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=sales-report-' . $from . '-to-' . $to . '.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Metric', 'Value']);
    fputcsv($out, ['Orders', $sales['orders']]);
    fputcsv($out, ['Revenue', $sales['revenue']]);
    fputcsv($out, ['Avg Order Value', $sales['avg']]);
    fputcsv($out, []);
    fputcsv($out, ['Top Products', 'Qty', 'Revenue']);
    foreach ($topProducts as $p) fputcsv($out, [$p['product_name'], $p['qty'], $p['revenue']]);
    fclose($out); exit;
}

require __DIR__ . '/../common/header.php';
?>
<form class="flex flex-wrap gap-2 mb-6">
  <input type="date" name="from" value="<?= e($from) ?>" class="border rounded px-3 py-2 text-sm">
  <input type="date" name="to" value="<?= e($to) ?>" class="border rounded px-3 py-2 text-sm">
  <button class="bg-gray-800 text-white px-4 py-2 rounded text-sm">Apply</button>
  <a href="?from=<?= e($from) ?>&to=<?= e($to) ?>&export=csv" class="bg-brand text-white px-4 py-2 rounded text-sm"><i class="fa-solid fa-download"></i> Export CSV</a>
</form>

<div class="grid grid-cols-3 gap-4 mb-6">
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <div class="text-xs text-gray-500 uppercase">Orders</div>
    <div class="text-2xl font-extrabold"><?= number_format((int)$sales['orders']) ?></div>
  </div>
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <div class="text-xs text-gray-500 uppercase">Revenue</div>
    <div class="text-2xl font-extrabold text-brand"><?= money($sales['revenue']) ?></div>
  </div>
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <div class="text-xs text-gray-500 uppercase">Avg Order</div>
    <div class="text-2xl font-extrabold"><?= money($sales['avg']) ?></div>
  </div>
</div>

<div class="grid md:grid-cols-2 gap-6">
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <h3 class="font-bold mb-3">Top Products</h3>
    <table class="w-full text-sm">
      <thead class="text-xs text-gray-500 uppercase"><tr><th class="text-left py-2">Product</th><th class="text-right">Qty</th><th class="text-right">Revenue</th></tr></thead>
      <tbody>
        <?php foreach ($topProducts as $p): ?>
          <tr class="border-t"><td class="py-2"><?= e($p['product_name']) ?></td><td class="text-right"><?= (int)$p['qty'] ?></td><td class="text-right font-semibold"><?= money($p['revenue']) ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <h3 class="font-bold mb-3">Top Customers</h3>
    <table class="w-full text-sm">
      <thead class="text-xs text-gray-500 uppercase"><tr><th class="text-left py-2">Customer</th><th class="text-right">Orders</th><th class="text-right">Spent</th></tr></thead>
      <tbody>
        <?php foreach ($topCustomers as $c): ?>
          <tr class="border-t"><td class="py-2"><?= e($c['customer_name']) ?><div class="text-xs text-gray-500"><?= e($c['customer_phone']) ?></div></td><td class="text-right"><?= (int)$c['orders'] ?></td><td class="text-right font-semibold"><?= money($c['spent']) ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>