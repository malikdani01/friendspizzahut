<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Track Order';

$num = (string)get('order', '');
$order = $num ? get_order_by_number($num) : null;

// Also allow logged-in user to open own order
if (!$order && customer_logged_in() && get('id')) {
    $tmp = get_order((int)get('id'));
    if ($tmp && (int)$tmp['user_id'] === (int)$_SESSION['user_id']) {
        $order = $tmp;
    }
}

$history = $order ? get_order_status_history((int)$order['id']) : [];
$items   = $order ? get_order_items((int)$order['id']) : [];

// ETA calculation
$etaSecondsLeft = null;
$etaTotalSeconds = null;
if ($order && $order['estimated_minutes'] && $order['eta_started_at']) {
    $etaStart = strtotime($order['eta_started_at']);
    $etaTotalSeconds = (int)$order['estimated_minutes'] * 60;
    $etaSecondsLeft = ($etaStart + $etaTotalSeconds) - time();
    if ($etaSecondsLeft < 0) $etaSecondsLeft = 0;
}

// Status flow — for progress bar
$deliveryFlow = ['pending','confirmed','preparing','ready','out_for_delivery','delivered','completed'];
$pickupFlow   = ['pending','confirmed','preparing','ready_for_pickup','picked_up','completed'];
$flow = $order && $order['order_type'] === 'pickup' ? $pickupFlow : $deliveryFlow;
$currentIdx = $order ? array_search($order['order_status'], $flow, true) : 0;
if ($currentIdx === false) $currentIdx = -1;
$totalSteps = count($flow);

$statusLabels = [
    'pending' => ['Pending', 'fa-clock', 'Order received'],
    'confirmed' => ['Confirmed', 'fa-circle-check', 'We accepted your order'],
    'preparing' => ['Preparing', 'fa-fire-burner', 'Chef is cooking'],
    'ready' => ['Ready', 'fa-bell', 'Your order is ready'],
    'ready_for_pickup' => ['Ready for Pickup', 'fa-bag-shopping', 'Ready to collect'],
    'out_for_delivery' => ['On the Way', 'fa-motorcycle', 'Rider is heading to you'],
    'delivered' => ['Delivered', 'fa-hand-holding-heart', 'Delivered successfully'],
    'picked_up' => ['Picked Up', 'fa-circle-check', 'Order collected'],
    'completed' => ['Completed', 'fa-trophy', 'Enjoy your meal!'],
    'cancelled' => ['Cancelled', 'fa-circle-xmark', 'Order was cancelled'],
];

require __DIR__ . '/common/header.php';
?>

<style>
.tr-wrap { max-width: 720px; margin: 0 auto; padding: 20px 16px 140px; }
.tr-title { font-size: 26px; font-weight: 900; color: #fff; margin: 0 0 6px; }
.tr-sub { font-size: 13.5px; color: rgba(255,255,255,0.5); margin-bottom: 20px; }

.tr-card { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 20px; margin-bottom: 16px; }
.tr-card-title { font-size: 15px; font-weight: 800; color: #fff; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }
.tr-card-title i { color: #dc2626; }

/* Search form */
.tr-search { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 22px; max-width: 460px; margin: 0 auto; }
.tr-search label { display: block; font-size: 13px; font-weight: 600; color: rgba(255,255,255,0.7); margin-bottom: 8px; }
.tr-search input { width: 100%; padding: 14px; background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 12px; color: #fff; font-size: 15px; outline: none; margin-bottom: 12px; }
.tr-search input:focus { border-color: #dc2626; }
.tr-search button { width: 100%; padding: 14px; background: linear-gradient(135deg, #dc2626, #b91c1c); color: #fff; border: 0; border-radius: 12px; font-weight: 800; font-size: 14px; cursor: pointer; box-shadow: 0 6px 18px rgba(220,38,38,0.35); }

/* Order header */
.tr-head { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; margin-bottom: 14px; }
.tr-head-order { font-size: 11.5px; color: rgba(255,255,255,0.5); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
.tr-head-num { font-family: ui-monospace, monospace; font-size: 17px; font-weight: 800; color: #fff; }
.tr-head-date { font-size: 12px; color: rgba(255,255,255,0.5); margin-top: 6px; }
.tr-badge { padding: 6px 14px; border-radius: 999px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; white-space: nowrap; }
.tr-badge-pending { background: rgba(234,179,8,0.18); color: #fcd34d; }
.tr-badge-confirmed { background: rgba(59,130,246,0.18); color: #93c5fd; }
.tr-badge-preparing { background: rgba(168,85,247,0.18); color: #d8b4fe; }
.tr-badge-ready, .tr-badge-ready_for_pickup { background: rgba(34,197,94,0.18); color: #4ade80; }
.tr-badge-out_for_delivery { background: rgba(249,115,22,0.18); color: #fdba74; }
.tr-badge-delivered, .tr-badge-completed, .tr-badge-picked_up { background: rgba(34,197,94,0.18); color: #4ade80; }
.tr-badge-cancelled { background: rgba(220,38,38,0.18); color: #fca5a5; }

.tr-head-total { display: flex; align-items: baseline; gap: 10px; margin-top: 14px; padding-top: 14px; border-top: 1px solid rgba(255,255,255,0.06); }
.tr-head-total-label { font-size: 12.5px; color: rgba(255,255,255,0.5); text-transform: uppercase; letter-spacing: 0.5px; }
.tr-head-total-value { font-size: 26px; font-weight: 900; color: #dc2626; margin-left: auto; }

/* ═══ ANIMATED TIMELINE ═══ */
.tr-timeline { position: relative; padding: 8px 0; }

.tr-step {
  display: flex;
  gap: 16px;
  position: relative;
  padding-bottom: 26px;
  opacity: 0;
  transform: translateY(10px);
  animation: tr-step-in 0.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}
.tr-step:last-child { padding-bottom: 0; }

.tr-step:nth-child(1) { animation-delay: .1s; }
.tr-step:nth-child(2) { animation-delay: .2s; }
.tr-step:nth-child(3) { animation-delay: .3s; }
.tr-step:nth-child(4) { animation-delay: .4s; }
.tr-step:nth-child(5) { animation-delay: .5s; }
.tr-step:nth-child(6) { animation-delay: .6s; }
.tr-step:nth-child(7) { animation-delay: .7s; }
.tr-step:nth-child(8) { animation-delay: .8s; }

@keyframes tr-step-in {
  to { opacity: 1; transform: translateY(0); }
}

/* Line */
.tr-step::before {
  content: '';
  position: absolute;
  left: 21px;
  top: 44px;
  bottom: -6px;
  width: 2px;
  background: rgba(255,255,255,0.08);
  border-radius: 2px;
}
.tr-step:last-child::before { display: none; }
.tr-step.done::before { background: linear-gradient(180deg, #16a34a, rgba(22,163,74,0.3)); }
.tr-step.current::before { background: linear-gradient(180deg, #dc2626, rgba(220,38,38,0.15)); animation: tr-line-pulse 1.5s ease-in-out infinite; }

@keyframes tr-line-pulse {
  0%, 100% { opacity: 1; }
  50%      { opacity: 0.5; }
}

/* Icon */
.tr-step-icon {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: #1a1a1a;
  border: 2px solid rgba(255,255,255,0.12);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  color: rgba(255,255,255,0.4);
  flex-shrink: 0;
  position: relative;
  z-index: 2;
  transition: all .3s;
}

/* Done step */
.tr-step.done .tr-step-icon {
  background: linear-gradient(135deg, #16a34a, #15803d);
  border-color: #16a34a;
  color: #fff;
  box-shadow: 0 4px 16px rgba(22,163,74,0.4);
}

/* Current step */
.tr-step.current .tr-step-icon {
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  border-color: #dc2626;
  color: #fff;
  box-shadow: 0 4px 20px rgba(220,38,38,0.55);
  animation: tr-icon-pulse 2s ease-in-out infinite;
}
.tr-step.current .tr-step-icon::after {
  content: '';
  position: absolute;
  inset: -6px;
  border-radius: 50%;
  border: 2px solid rgba(220,38,38,0.4);
  animation: tr-ring 2s ease-out infinite;
}

@keyframes tr-icon-pulse {
  0%, 100% { transform: scale(1); }
  50%      { transform: scale(1.08); }
}
@keyframes tr-ring {
  0%   { transform: scale(0.8); opacity: 1; }
  100% { transform: scale(1.5); opacity: 0; }
}

/* Cancelled */
.tr-step.cancelled .tr-step-icon {
  background: linear-gradient(135deg, #dc2626, #7f1d1d);
  border-color: #dc2626;
  color: #fff;
  box-shadow: 0 4px 16px rgba(220,38,38,0.4);
}

/* Body */
.tr-step-body { flex: 1; min-width: 0; padding-top: 4px; }
.tr-step-label {
  font-size: 15px;
  font-weight: 800;
  color: rgba(255,255,255,0.5);
  transition: color .3s;
}
.tr-step.done .tr-step-label { color: #fff; }
.tr-step.current .tr-step-label { color: #dc2626; }
.tr-step.cancelled .tr-step-label { color: #f87171; }

.tr-step-desc {
  font-size: 12px;
  color: rgba(255,255,255,0.4);
  margin-top: 3px;
  line-height: 1.5;
}
.tr-step.done .tr-step-desc { color: rgba(255,255,255,0.6); }

.tr-step-time {
  font-size: 11px;
  color: rgba(255,255,255,0.35);
  margin-top: 5px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: rgba(255,255,255,0.04);
  padding: 2px 8px;
  border-radius: 6px;
}
.tr-step.done .tr-step-time { color: rgba(255,255,255,0.55); }

/* Live dot */
.tr-step.current .tr-step-desc::after {
  content: '';
  display: inline-block;
  width: 6px;
  height: 6px;
  background: #dc2626;
  border-radius: 50%;
  margin-left: 6px;
  animation: tr-dot 1s ease-in-out infinite;
  vertical-align: middle;
}
@keyframes tr-dot {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%      { opacity: 0.4; transform: scale(0.7); }
}

/* ═══ COUNTDOWN TIMER ═══ */
.tr-eta {
  background: linear-gradient(135deg, rgba(220,38,38,0.15), rgba(220,38,38,0.03));
  border: 1.5px solid rgba(220,38,38,0.4);
  border-radius: 16px;
  padding: 22px 18px;
  margin-bottom: 16px;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.tr-eta::before {
  content: '';
  position: absolute;
  top: -50%; left: -50%;
  width: 200%; height: 200%;
  background: conic-gradient(from 0deg, transparent, rgba(220,38,38,0.15), transparent 30%);
  animation: tr-eta-spin 4s linear infinite;
}
@keyframes tr-eta-spin {
  to { transform: rotate(360deg); }
}
.tr-eta-inner { position: relative; z-index: 2; }
.tr-eta-label {
  font-size: 11px;
  text-transform: uppercase;
  font-weight: 800;
  letter-spacing: 1px;
  color: rgba(255,255,255,0.6);
  margin-bottom: 8px;
}
.tr-eta-time {
  font-family: ui-monospace, 'Courier New', monospace;
  font-size: 42px;
  font-weight: 900;
  color: #dc2626;
  line-height: 1;
  letter-spacing: 2px;
  text-shadow: 0 4px 20px rgba(220,38,38,0.4);
  animation: tr-eta-glow 2s ease-in-out infinite;
}
@keyframes tr-eta-glow {
  0%, 100% { text-shadow: 0 4px 20px rgba(220,38,38,0.3); }
  50%      { text-shadow: 0 4px 30px rgba(220,38,38,0.6); }
}
.tr-eta-sub {
  font-size: 12.5px;
  color: rgba(255,255,255,0.5);
  margin-top: 10px;
}
.tr-eta-done {
  font-size: 28px;
  font-weight: 900;
  color: #4ade80;
  animation: tr-eta-glow-done 2s ease-in-out infinite;
}
@keyframes tr-eta-glow-done {
  0%, 100% { text-shadow: 0 4px 20px rgba(34,197,94,0.3); }
  50%      { text-shadow: 0 4px 30px rgba(34,197,94,0.6); }
}

/* Items */
.tr-item {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 0;
  border-bottom: 1px solid rgba(255,255,255,0.05);
}
.tr-item:last-child { border-bottom: 0; }
.tr-item-name { font-size: 14px; font-weight: 700; color: #fff; }
.tr-item-meta { font-size: 11.5px; color: rgba(255,255,255,0.5); margin-top: 3px; }
.tr-item-price { font-size: 14px; font-weight: 800; color: #dc2626; white-space: nowrap; }

.tr-cancel-info {
  background: rgba(220,38,38,0.08);
  border-left: 3px solid #dc2626;
  padding: 12px 14px;
  border-radius: 8px;
  font-size: 13px;
  color: #fca5a5;
  margin-bottom: 16px;
}

/* Empty */
.tr-empty {
  text-align: center;
  padding: 40px 20px;
  color: rgba(255,255,255,0.5);
}
.tr-empty i { font-size: 44px; opacity: 0.3; display: block; margin-bottom: 12px; color: #dc2626; }

/* Live status indicator */
.tr-live {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  font-weight: 700;
  color: #4ade80;
  background: rgba(34,197,94,0.12);
  padding: 4px 10px;
  border-radius: 999px;
  margin-left: 8px;
}
.tr-live::before {
  content: '';
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #4ade80;
  animation: tr-live-pulse 1.5s ease-in-out infinite;
}
@keyframes tr-live-pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50%      { opacity: 0.4; transform: scale(0.7); }
}
</style>

<div class="tr-wrap">
  <h1 class="tr-title">📍 Track Your Order</h1>
  <p class="tr-sub">Real-time status updates and estimated time</p>

  <?php if (!$order): ?>
    <form class="tr-search" method="get">
      <label>Enter Order Number</label>
      <input type="text" name="order" placeholder="FPH-XXXXXXXX-XXXXXX" autocomplete="off" required>
      <button type="submit"><i class="fa-solid fa-magnifying-glass"></i> Track Order</button>
    </form>
  <?php else: ?>

    <!-- ORDER HEADER -->
    <div class="tr-card">
      <div class="tr-head">
        <div style="min-width:0;">
          <div class="tr-head-order">Order Number</div>
          <div class="tr-head-num"><?= e($order['order_number']) ?></div>
          <div class="tr-head-date">
            <i class="fa-regular fa-clock"></i>
            Placed on <?= date('d M Y, H:i', strtotime($order['created_at'])) ?>
            <?php if (!in_array($order['order_status'], ['delivered','completed','picked_up','cancelled'], true)): ?>
              <span class="tr-live">Live</span>
            <?php endif; ?>
          </div>
        </div>
        <span class="tr-badge tr-badge-<?= e($order['order_status']) ?>">
          <?= e($statusLabels[$order['order_status']][0] ?? ucfirst($order['order_status'])) ?>
        </span>
      </div>

      <div class="tr-head-total">
        <div class="tr-head-total-label">Total</div>
        <div class="tr-head-total-value"><?= money($order['total']) ?></div>
      </div>
    </div>

    <?php if ($order['order_status'] === 'cancelled'): ?>
      <div class="tr-cancel-info">
        <strong><i class="fa-solid fa-circle-xmark"></i> Order Cancelled</strong>
        <?php if (!empty($order['cancel_reason'])): ?>
          <div style="margin-top:4px;">Reason: <?= e($order['cancel_reason']) ?></div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <!-- ═══ COUNTDOWN TIMER (only for active orders) ═══ -->
    <?php if ($etaSecondsLeft !== null && !in_array($order['order_status'], ['delivered','completed','picked_up','cancelled'], true)): ?>
    <div class="tr-eta" id="etaBox" data-seconds="<?= (int)$etaSecondsLeft ?>" data-total="<?= (int)$etaTotalSeconds ?>">
      <div class="tr-eta-inner">
        <div class="tr-eta-label">
          <i class="fa-solid fa-hourglass-half"></i> Estimated Time Remaining
        </div>
        <div class="tr-eta-time" id="etaDisplay">--:--</div>
        <div class="tr-eta-sub" id="etaSub">
          Out of <?= (int)($etaTotalSeconds / 60) ?> minutes
        </div>
      </div>
    </div>
    <?php elseif ($order['estimated_minutes'] && in_array($order['order_status'], ['delivered','completed','picked_up'], true)): ?>
    <div class="tr-eta">
      <div class="tr-eta-inner">
        <div class="tr-eta-label"><i class="fa-solid fa-circle-check"></i> Order Completed</div>
        <div class="tr-eta-done">Delivered on Time!</div>
      </div>
    </div>
    <?php endif; ?>

    <!-- ═══ ANIMATED TIMELINE ═══ -->
    <div class="tr-card">
      <div class="tr-card-title">
        <i class="fa-solid fa-route"></i> Order Progress
      </div>

      <div class="tr-timeline">
        <?php
        // Build timeline: completed steps + current + remaining
        $cancelledOrder = $order['order_status'] === 'cancelled';
        $historyByStatus = [];
        foreach ($history as $h) {
            if (!isset($historyByStatus[$h['new_status']])) {
                $historyByStatus[$h['new_status']] = $h;
            }
        }

        foreach ($flow as $idx => $status):
            $info = $statusLabels[$status] ?? [ucfirst($status), 'fa-circle', ''];
            $stepTime = $historyByStatus[$status]['created_at'] ?? null;

            if ($cancelledOrder) {
                $cls = 'pending';
            } elseif ($idx < $currentIdx) {
                $cls = 'done';
            } elseif ($idx === $currentIdx) {
                $cls = 'current';
            } else {
                $cls = 'pending';
            }
        ?>
        <div class="tr-step <?= $cls ?>">
          <div class="tr-step-icon">
            <i class="fa-solid <?= e($info[1]) ?>"></i>
          </div>
          <div class="tr-step-body">
            <div class="tr-step-label"><?= e($info[0]) ?></div>
            <div class="tr-step-desc"><?= e($info[2]) ?></div>
            <?php if ($stepTime): ?>
              <div class="tr-step-time">
                <i class="fa-regular fa-clock"></i>
                <?= date('d M, H:i', strtotime($stepTime)) ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>

        <?php if ($cancelledOrder): ?>
        <div class="tr-step cancelled">
          <div class="tr-step-icon"><i class="fa-solid fa-circle-xmark"></i></div>
          <div class="tr-step-body">
            <div class="tr-step-label">Cancelled</div>
            <div class="tr-step-desc"><?= e($order['cancel_reason'] ?: 'Order was cancelled') ?></div>
            <?php if ($order['cancelled_at']): ?>
              <div class="tr-step-time"><i class="fa-regular fa-clock"></i> <?= date('d M, H:i', strtotime($order['cancelled_at'])) ?></div>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- ═══ ITEMS ═══ -->
    <div class="tr-card">
      <div class="tr-card-title">
        <i class="fa-solid fa-bag-shopping"></i> Items (<?= count($items) ?>)
      </div>
      <?php foreach ($items as $it): ?>
        <div class="tr-item">
          <div style="min-width:0;">
            <div class="tr-item-name"><?= e($it['product_name']) ?></div>
            <div class="tr-item-meta">Qty: <?= (int)$it['quantity'] ?> × <?= money($it['unit_price']) ?></div>
            <?php foreach ($it['options'] as $op): ?>
              <div class="tr-item-meta">↳ <?= e($op['variation_option_name']) ?></div>
            <?php endforeach; ?>
            <?php foreach ($it['addons'] as $ad): ?>
              <div class="tr-item-meta">+ <?= e($ad['addon_name']) ?> (<?= money($ad['addon_price']) ?>)</div>
            <?php endforeach; ?>
          </div>
          <div class="tr-item-price"><?= money($it['line_total']) ?></div>
        </div>
      <?php endforeach; ?>
    </div>

  <?php endif; ?>
</div>

<script>
(function() {
  var etaBox = document.getElementById('etaBox');
  if (!etaBox) return;

  var seconds = parseInt(etaBox.dataset.seconds, 10);
  var total = parseInt(etaBox.dataset.total, 10);
  var display = document.getElementById('etaDisplay');
  var sub = document.getElementById('etaSub');

  if (!display || isNaN(seconds)) return;

  // Add pulsing warning class when < 5 minutes
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function render() {
    if (seconds <= 0) {
      display.innerHTML = 'Ready!';
      display.style.fontSize = '34px';
      display.style.color = '#4ade80';
      sub.textContent = 'Your order should be ready now';
      return;
    }

    var m = Math.floor(seconds / 60);
    var s = seconds % 60;
    display.textContent = pad(m) + ':' + pad(s);

    if (seconds <= 300) {
      display.style.color = '#fbbf24';
      sub.textContent = 'Almost there — ' + m + ' min remaining';
    } else {
      display.style.color = '#dc2626';
      sub.textContent = 'Out of ' + Math.floor(total / 60) + ' minutes';
    }
  }

  render();

  var timer = setInterval(function() {
    seconds--;
    if (seconds < 0) seconds = 0;
    render();
    if (seconds === 0) clearInterval(timer);
  }, 1000);
})();
</script>

<?php require __DIR__ . '/common/footer.php'; ?>