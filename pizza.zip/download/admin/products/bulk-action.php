<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/products/index.php'));
verify_csrf();
$ids = array_map('intval', (array)post('ids', []));
$action = (string)post('bulk_action', '');
if (!$ids) { flash_error('No products selected.'); redirect(url('admin/products/index.php')); }
$in = implode(',', array_fill(0, count($ids), '?'));
switch ($action) {
    case 'activate':   Database::execute("UPDATE products SET status='active' WHERE id IN ($in)", $ids); break;
    case 'deactivate': Database::execute("UPDATE products SET status='inactive' WHERE id IN ($in)", $ids); break;
    case 'delete':
        foreach ($ids as $id) {
            $p = get_product($id);
            if ($p && $p['image'] && file_exists(UPLOAD_PATH . '/' . $p['image'])) @unlink(UPLOAD_PATH . '/' . $p['image']);
        }
        Database::execute("DELETE FROM products WHERE id IN ($in)", $ids);
        break;
    case 'feature':    Database::execute("UPDATE products SET is_featured=1 WHERE id IN ($in)", $ids); break;
    default: flash_error('Unknown action.');
}
flash_success('Bulk action completed.');
redirect(url('admin/products/index.php'));