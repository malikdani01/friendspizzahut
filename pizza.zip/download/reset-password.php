<?php
require_once __DIR__ . '/common/bootstrap.php';
if (customer_logged_in()) redirect(url('account.php'));
$pageTitle = 'Reset Password';
$token = (string)get('token', post('token',''));
$error = '';
$done = false;

if (is_post()) {
    verify_csrf();
    $password = (string)post('password','');
    if (strlen($password) < 6) $error = 'Password must be 6+ characters.';
    if (!$error) {
        $row = Database::fetch("SELECT * FROM password_resets WHERE token=?", [$token]);
        if (!$row || $row['used_at'] !== null || strtotime((string)$row['expires_at']) < time()) {
            $error = 'Invalid or expired reset link.';
        } else {
            // Check that the account is not blocked before allowing a password reset.
            $u = Database::fetch("SELECT is_blocked FROM users WHERE id = ?", [(int)$row['user_id']]);
            if (!$u || (int)$u['is_blocked'] === 1) {
                $error = 'Account is blocked.';
            } else {
                Database::execute("UPDATE users SET password_hash=? WHERE id=?", [password_hash($password, PASSWORD_DEFAULT), (int)$row['user_id']]);
                Database::execute("UPDATE password_resets SET used_at=NOW() WHERE id=?", [(int)$row['id']]);
                $done = true;
            }
        }
    }
}
require __DIR__ . '/common/header.php';
?>
<div class="max-w-md mx-auto py-12 px-4">
  <h1 class="text-3xl font-extrabold mb-2">Reset Password</h1>
  <?php if ($done): ?>
    <div class="bg-green-500/20 border border-green-500/40 text-green-200 px-4 py-3 rounded-lg">
      Password updated. <a href="<?= url('login.php') ?>" class="underline font-semibold">Login now →</a>
    </div>
  <?php else: ?>
    <?php if ($error): ?><div class="bg-red-500/20 border border-red-500/40 text-red-200 px-4 py-3 rounded-lg mb-4 text-sm"><?= e($error) ?></div><?php endif; ?>
    <?php if (!$token): ?>
      <div class="bg-yellow-500/20 border border-yellow-500/40 text-yellow-200 px-4 py-3 rounded-lg text-sm">Invalid reset link.</div>
    <?php else: ?>
      <form method="post" class="space-y-4 bg-white/5 border border-white/10 rounded-2xl p-6">
        <?= csrf_field() ?>
        <input type="hidden" name="token" value="<?= e($token) ?>">
        <input type="password" name="password" required minlength="6" placeholder="New password" class="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 outline-none focus:border-brand">
        <button class="w-full bg-brand hover:bg-red-700 py-3 rounded-lg font-bold">Reset Password</button>
      </form>
    <?php endif; ?>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>