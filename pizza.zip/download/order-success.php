<?php
require_once __DIR__ . '/common/bootstrap.php';
$num = (string)get('order', '');
$order = $num ? get_order_by_number($num) : null;
if (!$order) { flash_error('Order not found.'); redirect(url('index.php')); }
$pageTitle = 'Order Placed';
require __DIR__ . '/common/header.php';
?>
<div class="max-w-2xl mx-auto px-4 py-16 text-center">
  <div class="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-6">
    <i class="fa-solid fa-check text-4xl text-green-500"></i>
  </div>
  <h1 class="text-3xl font-extrabold mb-3">Order Placed!</h1>
  <p class="text-white/60 mb-6">Thank you, <?= e($order['customer_name']) ?>. We'll start preparing soon.</p>

  <div class="bg-white/5 border border-white/10 rounded-2xl p-6 text-left space-y-3">
    <div class="flex justify-between"><span class="text-white/60">Order Number</span><span class="font-mono font-bold"><?= e($order['order_number']) ?></span></div>
    <div class="flex justify-between"><span class="text-white/60">Type</span><span class="uppercase font-semibold"><?= e($order['order_type']) ?></span></div>
    <div class="flex justify-between">
  <span class="text-white/60">Payment</span>
  <span class="font-semibold">
    <?php
    $label = match($order['payment_method']) {
        'cod' => 'Cash on Delivery',
        'easypaisa' => 'Easypaisa',
        'jazzcash' => 'JazzCash',
        default => ucfirst($order['payment_method']),
    };
    echo e($label);
    ?>
  </span>
</div>

<div class="flex justify-between">
  <span class="text-white/60">Payment Status</span>
  <?= status_badge($order['payment_status']) ?>
</div>
    <div class="flex justify-between border-t border-white/10 pt-3"><span class="text-white/60">Total</span><span class="text-brand font-extrabold text-xl"><?= money($order['total']) ?></span></div>
  </div>

  <div class="flex gap-3 justify-center mt-8">
    <a href="<?= url('track-order.php?order=' . urlencode($order['order_number'])) ?>" class="bg-brand hover:bg-red-700 px-6 py-3 rounded-lg font-bold">Track Order</a>
    <a href="<?= url('menu.php') ?>" class="bg-white/10 hover:bg-white/20 px-6 py-3 rounded-lg font-bold">Continue Shopping</a>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>