<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('backup_restore')) {
    flash_error('Backup feature disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Backup & Restore';

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'create') {
        $r = backup_create();
        if ($r['ok']) {
            flash_success('Backup created: ' . $r['file'] . ' (' . backup_human_size($r['size']) . ')');
        } else {
            flash_error('Backup failed: ' . ($r['error'] ?? 'unknown'));
        }

    } elseif ($action === 'delete') {
        if (backup_delete((string)post('file', ''))) {
            flash_success('Backup deleted.');
        } else {
            flash_error('Could not delete.');
        }

    } elseif ($action === 'restore' && !empty($_FILES['backup_file']['tmp_name'])) {
        $file = $_FILES['backup_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($ext !== 'sql' || $file['size'] > 100 * 1024 * 1024) {
            flash_error('Only .sql files (max 100MB) allowed.');
        } else {
            $r = backup_restore($file['tmp_name']);
            if ($r['ok']) {
                flash_success('Restored ' . $r['statements'] . ' statements. Safety backup: ' . ($r['safety'] ?? '—'));
            } else {
                flash_error('Restore failed: ' . ($r['error'] ?? 'unknown'));
            }
        }

    } elseif ($action === 'restore_existing') {
        $file = (string)post('file', '');
        $path = backup_dir() . '/' . basename($file);
        if (file_exists($path)) {
            $r = backup_restore($path);
            if ($r['ok']) {
                flash_success('Restored ' . $r['statements'] . ' statements.');
            } else {
                flash_error('Restore failed: ' . ($r['error'] ?? 'unknown'));
            }
        } else {
            flash_error('Backup file not found.');
        }
    }

    redirect(url('admin/system/backup.php'));
}

$backups = backup_list();
require __DIR__ . '/../common/header.php';
?>

<div class="space-y-5">

  <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-5 text-sm text-yellow-900">
    <div class="font-bold mb-2"><i class="fa-solid fa-shield-halved mr-1"></i> Backup Zaroori Kyun Hai?</div>
    <ul class="list-disc list-inside space-y-1">
      <li>Agar server crash ho jaye — data safe</li>
      <li>Hosting band ho jaye — naye server pe restore kar lo</li>
      <li>Galti se delete ho gaya — wapas lao</li>
      <li>Restore se pehle system automatically safety backup banata hai</li>
    </ul>
  </div>

  <div class="grid md:grid-cols-2 gap-5">
    <div class="bg-white rounded-xl shadow-sm border p-6">
      <h3 class="font-bold mb-3 text-brand">Create Backup</h3>
      <p class="text-sm text-gray-600 mb-4">Poora database (.sql file) banata hai — orders, products, customers, settings, sab kuch.</p>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <button class="w-full bg-brand hover:bg-red-700 text-white py-3 rounded-lg font-bold">
          <i class="fa-solid fa-download mr-1"></i> Download Fresh Backup
        </button>
      </form>
    </div>

    <div class="bg-white rounded-xl shadow-sm border p-6">
      <h3 class="font-bold mb-3 text-brand">Restore from File</h3>
      <p class="text-sm text-gray-600 mb-4">Upload kiya hua .sql file restore karo. Warning: existing data overwrite ho jayega.</p>
      <form method="post" enctype="multipart/form-data" data-confirm="Ye operation saara existing data replace karega. Continue karein?">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="restore">
        <input type="file" name="backup_file" accept=".sql" required class="w-full border rounded px-3 py-2 mb-3 text-sm">
        <button class="w-full bg-gray-800 text-white py-3 rounded-lg font-bold">
          <i class="fa-solid fa-upload mr-1"></i> Restore
        </button>
      </form>
    </div>
  </div>

  <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
    <div class="px-5 py-4 border-b flex items-center justify-between">
      <h3 class="font-bold">Existing Backups (<?= count($backups) ?>)</h3>
    </div>
    <?php if (!$backups): ?>
      <div class="p-8 text-center text-gray-400">No backups yet. Create your first backup above.</div>
    <?php else: ?>
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
        <tr>
          <th class="text-left px-4 py-3">File</th>
          <th class="text-left px-4 py-3">Size</th>
          <th class="text-left px-4 py-3">Date</th>
          <th class="text-right px-4 py-3">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($backups as $b): ?>
        <tr class="border-t hover:bg-gray-50">
          <td class="px-4 py-3 font-mono text-xs"><?= e($b['name']) ?></td>
          <td class="px-4 py-3"><?= e($b['size_human']) ?></td>
          <td class="px-4 py-3 text-xs text-gray-500"><?= date('d M Y, H:i', strtotime($b['date'])) ?></td>
          <td class="px-4 py-3 text-right whitespace-nowrap">
            <a href="<?= url('admin/system/backup-download.php?file=' . urlencode($b['name'])) ?>" class="text-blue-600 text-xs mr-2" title="Download"><i class="fa-solid fa-download"></i></a>
            <form method="post" class="inline" data-confirm="Restore ye backup? Existing data overwrite hoga.">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="restore_existing">
              <input type="hidden" name="file" value="<?= e($b['name']) ?>">
              <button class="text-yellow-600 text-xs mr-2" title="Restore"><i class="fa-solid fa-rotate-left"></i></button>
            </form>
            <form method="post" class="inline" data-confirm="Delete this backup?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="file" value="<?= e($b['name']) ?>">
              <button class="text-red-600 text-xs" title="Delete"><i class="fa-solid fa-trash"></i></button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <div class="text-xs text-gray-500">
    <i class="fa-solid fa-info-circle mr-1"></i>
    Backups folder: <code class="bg-gray-100 px-1 rounded"><?= e(backup_dir()) ?></code> — has folder ko cPanel File Manager se download karke rakho.
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>