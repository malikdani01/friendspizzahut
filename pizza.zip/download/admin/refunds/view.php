<?php
// view.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('refunds')) redirect(url('admin/dashboard.php'));
$id = (int)get('id', 0);
$r = Database::fetch("SELECT r.*, o.order_number FROM refunds r LEFT JOIN orders o ON o.id=r.order_id WHERE r.id=?", [$id]);
if (!$r) { flash_error('Not found.'); redirect(url('admin/refunds/index.php')); }
$pageTitle = 'Refund #' . $id;
require __DIR__ . '/../common/header.php';
?>
<a href="<?= url('admin/refunds/index.php') ?>" class="text-sm text-gray-500 hover:text-brand mb-4 inline-block">← Refunds</a>
<div class="max-w-2xl bg-white rounded-xl shadow-sm border p-6 space-y-3 text-sm">
  <div><span class="text-gray-500">Order:</span> <?= e($r['order_number']) ?></div>
  <div><span class="text-gray-500">Amount:</span> <strong><?= money($r['amount']) ?></strong></div>
  <div><span class="text-gray-500">Reason:</span> <?= e($r['reason']) ?></div>
  <div><span class="text-gray-500">Status:</span> <?= status_badge($r['status']) ?></div>
  <?php if ($r['status'] === 'approved'): ?>
  <form method="post" action="<?= url('admin/refunds/process.php') ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="bg-blue-600 text-white px-4 py-2 rounded font-semibold">Mark as Refunded</button></form>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>