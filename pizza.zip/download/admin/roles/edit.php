<?php
// edit.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('staff_roles')) redirect(url('admin/dashboard.php'));
$id = (int)get('id',0);
$r = Database::fetch("SELECT * FROM roles WHERE id=?", [$id]);
if (!$r) { flash_error('Not found.'); redirect(url('admin/roles/index.php')); }
$pageTitle = 'Edit Role';
if (is_post()) {
    verify_csrf();
    Database::update('roles', ['name'=>trim((string)post('name','')), 'description'=>trim((string)post('description',''))], 'id=:id', ['id'=>$id]);
    flash_success('Updated.');
    redirect(url('admin/roles/index.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl shadow-sm border p-6">
  <form method="post" class="space-y-4">
    <?= csrf_field() ?>
    <input name="name" required value="<?= e($r['name']) ?>" class="w-full border rounded px-3 py-2">
    <input name="description" value="<?= e($r['description']) ?>" class="w-full border rounded px-3 py-2">
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>