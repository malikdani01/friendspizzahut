<?php
/**
 * Customer segmentation for bulk marketing
 * Feature-gated: bulk_sms_marketing
 */

function segment_all(): array {
    return Database::fetchAll("SELECT id, name, phone, email FROM users WHERE is_blocked = 0 AND phone IS NOT NULL AND phone != ''");
}

function segment_active_30d(): array {
    return Database::fetchAll(
        "SELECT DISTINCT u.id, u.name, u.phone, u.email FROM users u
         JOIN orders o ON o.user_id = u.id
         WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
         AND u.is_blocked = 0 AND u.phone IS NOT NULL AND u.phone != ''"
    );
}

function segment_inactive_60d(): array {
    return Database::fetchAll(
        "SELECT u.id, u.name, u.phone, u.email FROM users u
         WHERE u.is_blocked = 0 AND u.phone IS NOT NULL AND u.phone != ''
         AND u.id NOT IN (
             SELECT DISTINCT user_id FROM orders
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 60 DAY)
         )
         AND u.id IN (SELECT DISTINCT user_id FROM orders)"
    );
}

function segment_never_ordered(): array {
    return Database::fetchAll(
        "SELECT u.id, u.name, u.phone, u.email FROM users u
         WHERE u.is_blocked = 0 AND u.phone IS NOT NULL AND u.phone != ''
         AND u.id NOT IN (SELECT DISTINCT user_id FROM orders WHERE user_id IS NOT NULL)"
    );
}

function segment_high_value(): array {
    return Database::fetchAll(
        "SELECT u.id, u.name, u.phone, u.email
         FROM users u
         JOIN orders o ON o.user_id = u.id
         WHERE u.is_blocked = 0 AND u.phone IS NOT NULL
         AND o.order_status NOT IN ('cancelled','refunded')
         GROUP BY u.id HAVING SUM(o.total) >= 10000"
    );
}

function segment_birthday_month(): array {
    // Note: users table doesn't have DOB by default.
    // If DOB field added later, use it. For now return empty.
    return [];
}

function segment_by_custom_sql(string $where): array {
    $sql = "SELECT id, name, phone, email FROM users WHERE is_blocked = 0 AND phone IS NOT NULL AND phone != '' AND ($where)";
    try {
        return Database::fetchAll($sql);
    } catch (Throwable $e) {
        return [];
    }
}