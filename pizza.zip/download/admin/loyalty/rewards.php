<?php
// rewards.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('loyalty_points')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Loyalty Rewards';
if (is_post()) {
    verify_csrf();
    if (post('action') === 'create') {
        Database::insert('loyalty_rewards', ['name'=>(string)post('name',''),'description'=>(string)post('description',''),'points_required'=>(int)post('points_required',100),'reward_type'=>(string)post('reward_type','discount'),'reward_value'=>(float)post('reward_value',0),'is_active'=>1]);
        flash_success('Created.');
    } elseif (post('action') === 'delete') {
        Database::execute("DELETE FROM loyalty_rewards WHERE id=?", [(int)post('id')]);
        flash_success('Deleted.');
    }
    redirect(url('admin/loyalty/rewards.php'));
}
$rows = Database::fetchAll("SELECT * FROM loyalty_rewards ORDER BY points_required");
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl border p-5 h-fit">
    <h3 class="font-bold mb-3">Add Reward</h3>
    <form method="post" class="space-y-3"><?= csrf_field() ?><input type="hidden" name="action" value="create">
      <input name="name" required placeholder="Reward name" class="w-full border rounded px-3 py-2">
      <textarea name="description" rows="2" placeholder="Description" class="w-full border rounded px-3 py-2"></textarea>
      <input type="number" name="points_required" value="100" class="w-full border rounded px-3 py-2">
      <input name="reward_type" placeholder="Type" value="discount" class="w-full border rounded px-3 py-2">
      <input type="number" step="0.01" name="reward_value" value="0" class="w-full border rounded px-3 py-2">
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Create</button>
    </form>
  </div>
  <div class="md:col-span-2 bg-white rounded-xl border overflow-hidden">
    <table class="w-full text-sm"><thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">Name</th><th class="text-right px-4 py-3">Points</th><th></th></tr></thead>
    <tbody><?php foreach ($rows as $r): ?><tr class="border-t"><td class="px-4 py-3"><?= e($r['name']) ?></td><td class="px-4 py-3 text-right font-semibold"><?= (int)$r['points_required'] ?></td><td class="px-4 py-3 text-right"><form method="post" class="inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="text-red-600 text-xs">Delete</button></form></td></tr><?php endforeach; ?></tbody></table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>