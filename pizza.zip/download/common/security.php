<?php
/**
 * Security — session, rate limit, validation, uploads
 * Byethost-compatible version
 */

function secure_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;

    // Byethost + general hosting compatibility
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

    // Set custom session save path (helps on shared hosting)
    if (!ini_get('session.save_path') || !is_writable(ini_get('session.save_path'))) {
        $customPath = sys_get_temp_dir();
        if (is_writable($customPath)) {
            session_save_path($customPath);
        }
    }

    // Use custom session name
    @session_name(defined('SESSION_NAME') ? SESSION_NAME : 'fph_session');

    // Set cookie params BEFORE session_start
    @session_set_cookie_params([
        'lifetime' => defined('SESSION_LIFETIME') ? SESSION_LIFETIME : 604800,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    // Start session
    @session_start();

    // Ensure session token exists (used by CSRF)
    if (empty($_SESSION['_session_id'])) {
        try {
            $_SESSION['_session_id'] = bin2hex(random_bytes(16));
        } catch (Throwable $e) {
            $_SESSION['_session_id'] = uniqid('s', true);
        }
    }

    // Init tracking
    if (empty($_SESSION['_started'])) {
        $_SESSION['_started'] = time();
    }
}

function session_regenerate(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        @session_regenerate_id(true);
    }
}

function rate_limit_login(string $key, int $maxAttempts = 5, int $windowMinutes = 15): bool
{
    try {
        $ip = client_ip();
        $since = date('Y-m-d H:i:s', time() - $windowMinutes * 60);
        $row = Database::fetch(
            "SELECT COUNT(*) AS c FROM login_attempts WHERE ip_address = ? AND success = 0 AND created_at >= ?",
            [$ip, $since]
        );
        return (int)($row['c'] ?? 0) < $maxAttempts;
    } catch (Throwable $e) {
        return true; // Don't block login if DB fails
    }
}

function record_login_attempt(string $username, bool $success, string $type = 'customer'): void
{
    try {
        Database::insert('login_attempts', [
            'ip_address' => client_ip(),
            'username'   => mb_substr($username, 0, 180),
            'user_type'  => $type,
            'success'    => $success ? 1 : 0,
        ]);
    } catch (Throwable $e) { /* ignore */ }
}

function validate_email(string $email): bool
{
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

function validate_phone(string $phone): bool
{
    return (bool) preg_match('/^[0-9+\-\s()]{7,20}$/', $phone);
}

function validate_upload(array $file, int $maxBytes = 5242880): array
{
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return ['ok' => false, 'error' => 'No file uploaded.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'error' => 'Upload error code ' . $file['error']];
    }
    if ($file['size'] > $maxBytes) {
        return ['ok' => false, 'error' => 'File too large (max 5 MB).'];
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!in_array($mime, $allowed, true)) {
        return ['ok' => false, 'error' => 'Only JPG, PNG, WEBP allowed.'];
    }
    return ['ok' => true, 'mime' => $mime];
}

function save_uploaded_image(array $file, string $subdir): array
{
    $check = validate_upload($file);
    if (!$check['ok']) return $check;

    $ext = match ($check['mime']) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        default      => 'jpg',
    };

    $dir = (defined('UPLOAD_PATH') ? UPLOAD_PATH : __DIR__ . '/../uploads') . '/' . trim($subdir, '/');
    if (!is_dir($dir)) @mkdir($dir, 0755, true);

    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    $dest = $dir . '/' . $name;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return ['ok' => false, 'error' => 'Could not save file.'];
    }
    return ['ok' => true, 'path' => trim($subdir, '/') . '/' . $name];
}

function audit_log(string $action, ?string $entity = null, ?int $entityId = null, ?array $old = null, ?array $new = null): void
{
    try {
        Database::insert('audit_logs', [
            'user_type'  => ($_SESSION['admin_id'] ?? null) ? 'admin' : (($_SESSION['user_id'] ?? null) ? 'customer' : 'guest'),
            'user_id'    => $_SESSION['admin_id'] ?? $_SESSION['user_id'] ?? null,
            'action'     => $action,
            'entity'     => $entity,
            'entity_id'  => $entityId,
            'old_data'   => $old ? json_encode($old) : null,
            'new_data'   => $new ? json_encode($new) : null,
            'ip_address' => client_ip(),
            'user_agent' => mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250),
        ]);
    } catch (Throwable $e) {
        error_log('audit_log failed: ' . $e->getMessage());
    }
}