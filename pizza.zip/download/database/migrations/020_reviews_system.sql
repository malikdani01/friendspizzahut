-- ═══════════════════════════════════════════════════════════════
-- Migration 020: Review Replies + Likes + Section Order Fix
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── REVIEW REPLIES (nested replies) ──────────────────────────
CREATE TABLE IF NOT EXISTS review_replies (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    review_id INT UNSIGNED NOT NULL,
    parent_reply_id INT UNSIGNED NULL,
    user_id INT UNSIGNED NOT NULL,
    reply_text TEXT NOT NULL,
    is_approved TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_review (review_id, is_approved),
    INDEX idx_parent (parent_reply_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── REVIEW LIKES ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS review_likes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    review_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_review_user (review_id, user_id),
    INDEX idx_review (review_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── ENSURE reviews columns exist ─────────────────────────────
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS like_count INT NOT NULL DEFAULT 0;
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS reply_count INT NOT NULL DEFAULT 0;

-- ─── FIX homepage section order: Recommended → Best Selling → Coming Soon ─
UPDATE homepage_sections SET sort_order = 10 WHERE section_key = 'recommended';
UPDATE homepage_sections SET sort_order = 20 WHERE section_key = 'bestselling';
UPDATE homepage_sections SET sort_order = 30 WHERE section_key = 'coming_soon';
UPDATE homepage_sections SET sort_order = 40 WHERE section_key = 'special_deals';
UPDATE homepage_sections SET sort_order = 50 WHERE section_key = 'new_items';
UPDATE homepage_sections SET sort_order = 60 WHERE section_key = 'reviews';

-- Ensure sections are enabled
UPDATE homepage_sections SET is_enabled = 1 WHERE section_key IN ('recommended', 'bestselling', 'coming_soon');