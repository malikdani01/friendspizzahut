(function() {
  'use strict';

  // ─── HERO SLIDER ──────────────────────────────────────────
  const track = document.getElementById('fphHeroTrack');
  const dots = document.querySelectorAll('.fph-hero-dot');
  if (track) {
    const slides = track.children.length;
    let idx = 0;
    let timer = null;

    function go(i) {
      idx = (i + slides) % slides;
      track.style.transform = 'translateX(-' + (idx * 100) + '%)';
      dots.forEach((d, n) => d.classList.toggle('active', n === idx));
    }
    function next() { go(idx + 1); }
    function play() { stop(); if (slides > 1) timer = setInterval(next, 5000); }
    function stop() { if (timer) clearInterval(timer); timer = null; }

    dots.forEach((d, n) => d.addEventListener('click', () => { go(n); play(); }));

    // Touch swipe
    let startX = 0;
    track.addEventListener('touchstart', e => { startX = e.touches[0].clientX; stop(); }, { passive: true });
    track.addEventListener('touchend', e => {
      const dx = e.changedTouches[0].clientX - startX;
      if (Math.abs(dx) > 40) go(idx + (dx < 0 ? 1 : -1));
      play();
    });

    // Pause on hidden
    document.addEventListener('visibilitychange', () => document.hidden ? stop() : play());

    if (slides > 1) play();
  }

  // ─── PRODUCT DETAIL: REAL-TIME PRICE ──────────────────────
  const priceRoot = document.getElementById('fphProductConfig');
  if (priceRoot) {
    const qtyInput = document.getElementById('fphQtyInput');
    const totalEl = document.getElementById('fphTotalValue');
    const sizeInputs = priceRoot.querySelectorAll('input[name="variation[]"]');
    const addonInputs = priceRoot.querySelectorAll('input[name="addons[]"]');

    function recalc() {
      let base = parseFloat(priceRoot.dataset.basePrice || '0');

      // Find selected size (uses absolute_price if provided via data attributes)
      sizeInputs.forEach(inp => {
        if (inp.checked) {
          const abs = parseFloat(inp.dataset.absPrice || '0');
          const delta = parseFloat(inp.dataset.delta || '0');
          if (abs > 0) base = abs;
          else base = parseFloat(priceRoot.dataset.basePrice || '0') + delta;
        }
      });

      let addonsTotal = 0;
      addonInputs.forEach(inp => {
        if (inp.checked) {
          const price = parseFloat(inp.dataset.price || '0');
          addonsTotal += price;
        }
      });

      const qty = Math.max(1, parseInt(qtyInput?.value || '1', 10));
      const total = (base + addonsTotal) * qty;

      if (totalEl) {
        totalEl.textContent = 'Rs. ' + total.toLocaleString();
        totalEl.classList.add('bump');
        setTimeout(() => totalEl.classList.remove('bump'), 180);
      }
    }

    sizeInputs.forEach(inp => inp.addEventListener('change', () => {
      sizeInputs.forEach(i => i.closest('.fph-opt-btn')?.classList.toggle('selected', i.checked));
      recalc();
    }));
    addonInputs.forEach(inp => inp.addEventListener('change', () => {
      inp.closest('.fph-opt-btn')?.classList.toggle('selected', inp.checked);
      recalc();
    }));

    // Qty buttons
    document.querySelectorAll('.fph-qty-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const v = Math.max(1, Math.min(50, (parseInt(qtyInput.value || '1', 10)) + parseInt(btn.dataset.delta, 10)));
        qtyInput.value = v;
        recalc();
      });
    });
    qtyInput?.addEventListener('input', recalc);

    recalc();
  }

  // ─── PAYMENT METHOD SELECTION ─────────────────────────────
  document.querySelectorAll('.fph-pay-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.fph-pay-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      const radio = card.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;

      const method = card.dataset.method || '';
      const txnBlock = document.getElementById('fphTxnBlock');
      if (txnBlock) {
        const needsTxn = ['easypaisa', 'jazzcash'].includes(method);
        txnBlock.style.display = needsTxn ? '' : 'none';
        const txnInput = txnBlock.querySelector('input[name="transaction_id"]');
        if (txnInput) txnInput.required = needsTxn;
      }
    });
  });

})();