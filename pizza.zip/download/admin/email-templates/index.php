<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('email_templates_ui')) {
    flash_error('Templates editor disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Notification Templates';

if (is_post()) {
    verify_csrf();
    if (post('action') === 'save') {
        $id = (int)post('id', 0);
        Database::execute("UPDATE notification_templates SET subject = ?, body = ?, is_active = ? WHERE id = ?", [
            mb_substr((string)post('subject', ''), 0, 190),
            (string)post('body', ''),
            post('is_active') ? 1 : 0,
            $id,
        ]);
        flash_success('Template saved.');
    }
    redirect(url('admin/email-templates/index.php'));
}

$channel = (string)get('channel', 'email');
$rows = Database::fetchAll("SELECT * FROM notification_templates WHERE channel = ? ORDER BY tpl_key", [$channel]);
$editId = (int)get('edit', 0);
$edit = $editId ? Database::fetch("SELECT * FROM notification_templates WHERE id = ?", [$editId]) : null;

require __DIR__ . '/../common/header.php';
?>
<div class="flex gap-2 mb-5">
  <?php foreach (['email','sms','whatsapp','push'] as $ch): ?>
  <a href="?channel=<?= $ch ?>" class="px-4 py-2 rounded text-sm <?= $channel === $ch ? 'bg-brand text-white' : 'bg-white border' ?>"><?= ucfirst($ch) ?></a>
  <?php endforeach; ?>
</div>

<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl border overflow-hidden">
    <div class="px-4 py-3 bg-gray-50 text-xs uppercase font-bold text-gray-500">Templates</div>
    <ul>
      <?php foreach ($rows as $r): ?>
      <li class="border-t">
        <a href="?channel=<?= $channel ?>&edit=<?= (int)$r['id'] ?>" class="block px-4 py-3 hover:bg-gray-50 <?= $editId == $r['id'] ? 'bg-brand/10 border-l-4 border-brand' : '' ?>">
          <div class="font-semibold text-sm"><?= e($r['tpl_key']) ?></div>
          <div class="text-xs text-gray-500"><?= e($r['subject'] ?? '') ?></div>
        </a>
      </li>
      <?php endforeach; ?>
      <?php if (!$rows): ?><li class="p-4 text-center text-gray-400 text-sm">No templates.</li><?php endif; ?>
    </ul>
  </div>

  <div class="md:col-span-2 bg-white rounded-xl border p-6">
    <?php if (!$edit): ?>
      <div class="text-center py-10 text-gray-400">Select a template to edit.</div>
    <?php else: ?>
      <h3 class="font-bold mb-3">Edit: <?= e($edit['tpl_key']) ?></h3>
      <form method="post" class="space-y-4">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
        <div>
          <label class="block text-sm font-semibold mb-1">Subject</label>
          <input name="subject" value="<?= e($edit['subject'] ?? '') ?>" class="w-full border rounded px-3 py-2">
        </div>
        <div>
          <label class="block text-sm font-semibold mb-1">Body</label>
          <textarea name="body" rows="12" class="w-full border rounded px-3 py-2 font-mono text-sm"><?= e($edit['body']) ?></textarea>
        </div>
        <label class="flex items-center gap-2"><input type="checkbox" name="is_active" value="1" <?= $edit['is_active'] ? 'checked' : '' ?>> Active</label>
        <div class="text-xs text-gray-500">
          Variables: <code>{customer_name}</code> <code>{order_number}</code> <code>{total}</code> <code>{track_url}</code> <code>{restaurant_name}</code>
        </div>
        <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save Template</button>
      </form>
    <?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>