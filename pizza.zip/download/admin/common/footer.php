    </main>

    <footer style="padding:16px 24px;text-align:center;font-size:12px;color:rgba(255,255,255,0.4);background:#0f0f0f;border-top:1px solid rgba(255,255,255,0.06);">
      &copy; <?= date('Y') ?> <?= e(setting('restaurant_name', 'Friends Pizza Hut')) ?> — Admin Panel
    </footer>

  </div><!-- /admin-main-area -->

</div><!-- /admin-shell -->

<script>
(function() {
  // Auto-dismiss flash messages
  setTimeout(function() {
    document.querySelectorAll('.flash-item, .fph-flash').forEach(function(el) {
      el.style.transition = 'opacity .4s, transform .4s';
      el.style.opacity = '0';
      el.style.transform = 'translateX(120%)';
      setTimeout(function() { el.remove(); }, 400);
    });
  }, 4500);

  // Close drawer on link click (mobile)
  document.querySelectorAll('.admin-side-link').forEach(function(a) {
    a.addEventListener('click', function() {
      if (window.innerWidth < 1024) {
        var sb = document.getElementById('adminSidebar');
        var ov = document.getElementById('adminOverlay');
        if (sb) sb.classList.remove('open');
        if (ov) ov.classList.remove('open');
      }
    });
  });

  // Esc key closes drawer
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      var sb = document.getElementById('adminSidebar');
      var ov = document.getElementById('adminOverlay');
      if (sb) sb.classList.remove('open');
      if (ov) ov.classList.remove('open');
    }
  });
})();
</script>

</body>
</html>