-- ═══════════════════════════════════════════════════════════════
-- Migration 014: UI Upgrade — Alert Bar + Deal Bar
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── ALERT / PROMO SCROLLING BAR ──────────────────────────────
CREATE TABLE IF NOT EXISTS alert_bar_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    text VARCHAR(500) NOT NULL,
    icon VARCHAR(60) NULL DEFAULT 'fa-bullhorn',
    link_url VARCHAR(255) NULL,
    link_text VARCHAR(60) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── LIMITED TIME DEAL BAR ────────────────────────────────────
CREATE TABLE IF NOT EXISTS deal_bar_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    deal_name VARCHAR(190) NOT NULL,
    description VARCHAR(255) NULL,
    discount_text VARCHAR(60) NULL,      -- "30% OFF" ya "Rs. 999"
    bg_color VARCHAR(20) NOT NULL DEFAULT '#dc2626',
    text_color VARCHAR(20) NOT NULL DEFAULT '#ffffff',
    product_id INT UNSIGNED NULL,
    combo_id INT UNSIGNED NULL,
    order_url VARCHAR(255) NULL,
    start_at DATETIME NOT NULL,
    end_at DATETIME NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_active_dates (is_active, start_at, end_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── SETTINGS ─────────────────────────────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('alert_bar_enabled',   '1',  'ui'),
('alert_bar_speed',     '30', 'ui'),
('alert_bar_bg',        '#0a0a0a', 'ui'),
('alert_bar_text',      '#ffffff', 'ui'),
('deal_bar_enabled',    '1',  'ui'),
('mobile_bottom_nav',   '1',  'ui')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── FEATURE TOGGLES ──────────────────────────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('alert_bar',           'Scrolling Alert Bar',    'marketing', 'Top scrolling promo/announcement bar', 1, 0, 1, 0, 300),
('limited_deal_bar',    'Limited Time Deal Bar',  'marketing', 'Countdown deal bar below header',      1, 0, 1, 0, 301)
ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);

-- ─── SAMPLE DATA (aap admin se edit kar sakte ho) ─────────────
INSERT INTO alert_bar_items (text, icon, sort_order, is_active) VALUES
('🔥 Free delivery on orders above Rs. 1500 — City Tamman', 'fa-truck-fast', 1, 1),
('⭐ 20% off on your first order — Use code FIRST20', 'fa-percent', 2, 1),
('📞 Call us: 0300-1494249 for bulk orders', 'fa-phone', 3, 1)
ON DUPLICATE KEY UPDATE text = VALUES(text);