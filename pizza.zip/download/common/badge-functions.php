<?php
function get_all_badges(bool $activeOnly = true): array {
    $sql = "SELECT * FROM product_badges";
    if ($activeOnly) $sql .= " WHERE is_active = 1";
    $sql .= " ORDER BY sort_order, id";
    return Database::fetchAll($sql);
}

function get_product_badges(int $productId): array {
    return Database::fetchAll(
        "SELECT b.* FROM product_badge_map m
         JOIN product_badges b ON b.id = m.badge_id
         WHERE m.product_id = ? AND b.is_active = 1
         ORDER BY b.sort_order",
        [$productId]
    );
}

function set_product_badges(int $productId, array $badgeIds): void {
    Database::execute("DELETE FROM product_badge_map WHERE product_id = ?", [$productId]);
    foreach ($badgeIds as $bid) {
        if ($bid > 0) {
            Database::insert('product_badge_map', ['product_id' => $productId, 'badge_id' => (int)$bid]);
        }
    }
}

function render_product_badges(int $productId, bool $firstOnly = false): string {
    $badges = get_product_badges($productId);
    if (!$badges) return '';
    if ($firstOnly) $badges = [reset($badges)];

    $html = '';
    foreach ($badges as $b) {
        $icon = $b['icon'] ? '<i class="fa-solid ' . e($b['icon']) . '"></i> ' : '';
        $html .= '<span class="fph-badge-chip" style="background:' . e($b['bg_color']) . ';color:' . e($b['text_color']) . ';">' . $icon . e($b['name']) . '</span>';
    }
    return $html;
}