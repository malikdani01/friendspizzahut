<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Add Category';
$errors = [];

if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name', ''));
    if (strlen($name) < 2) $errors[] = 'Name is required.';

    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $r = save_uploaded_image($_FILES['image'], 'categories');
        if (!$r['ok']) $errors[] = $r['error'];
        else $image = $r['path'];
    }

    if (!$errors) {
        Database::insert('categories', [
            'name' => $name,
            'slug' => generate_category_slug($name),
            'description' => trim((string)post('description', '')) ?: null,
            'icon' => trim((string)post('icon', '')) ?: null,
            'image' => $image,
            'sort_order' => (int)post('sort_order', 0),
            'is_active' => post('is_active') ? 1 : 0,
        ]);
        flash_success('Category created.');
        redirect(url('admin/categories/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-2xl">
  <?php if ($errors): ?>
    <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
      <?php foreach ($errors as $er) echo '• ' . e($er) . '<br>'; ?>
    </div>
  <?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-4">
    <?= csrf_field() ?>
    <div>
      <label class="block text-sm font-semibold mb-1">Name *</label>
      <input name="name" required value="<?= old('name') ?>" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none">
    </div>
    <div>
      <label class="block text-sm font-semibold mb-1">Description</label>
      <textarea name="description" rows="2" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none"><?= old('description') ?></textarea>
    </div>
    <div class="grid grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-semibold mb-1">Font Awesome icon</label>
        <input name="icon" value="<?= old('icon', 'fa-utensils') ?>" placeholder="fa-pizza-slice" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Sort Order</label>
        <input type="number" name="sort_order" value="<?= old('sort_order', '0') ?>" class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:border-brand outline-none">
      </div>
    </div>
    <div>
      <label class="block text-sm font-semibold mb-1">Image (jpg/png/webp, max 5MB)</label>
      <input type="file" name="image" accept="image/*" class="w-full border border-gray-300 rounded-lg px-3 py-2">
    </div>
    <label class="flex items-center gap-2 text-sm">
      <input type="checkbox" name="is_active" value="1" checked class="w-4 h-4"> Active
    </label>
    <div class="flex gap-2 pt-2">
      <button class="bg-brand hover:bg-red-700 text-white px-6 py-2.5 rounded-lg font-semibold">Save Category</button>
      <a href="<?= url('admin/categories/index.php') ?>" class="px-6 py-2.5 rounded-lg bg-gray-100 hover:bg-gray-200 font-semibold">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>