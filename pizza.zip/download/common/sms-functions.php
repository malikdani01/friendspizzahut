<?php
/**
 * SMS helper — pluggable provider.
 * Feature-gated: sms_notifications
 */
function send_sms(string $phone, string $message): bool {
    if (!feature_enabled('sms_notifications')) return false;
    $provider = setting('sms_provider', ''); // twilio, etc
    if (!$provider) return false;

    // Log attempt regardless
    try {
        Database::insert('audit_logs', [
            'user_type' => 'system', 'action' => 'sms.attempt',
            'entity' => 'sms', 'new_data' => json_encode(['phone' => $phone, 'msg' => mb_substr($message,0,100)]),
        ]);
    } catch (Throwable $e) {}

    // Example stub — integrate real provider here
    return false;
}