<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('referral_system')) { flash_error('Referrals disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'Referrals';
$rows = Database::fetchAll("
    SELECT r.*, u1.name AS referrer_name, u2.name AS referred_name
    FROM referrals r
    LEFT JOIN users u1 ON u1.id=r.referrer_user_id
    LEFT JOIN users u2 ON u2.id=r.referred_user_id
    ORDER BY r.id DESC LIMIT 100
");
require __DIR__ . '/../common/header.php';
?>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr><th class="text-left px-4 py-3">Referrer</th><th class="text-left px-4 py-3">Referred</th><th class="text-left px-4 py-3">Code</th><th class="text-left px-4 py-3">Status</th><th class="text-left px-4 py-3">Date</th></tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr class="border-t"><td class="px-4 py-3"><?= e($r['referrer_name'] ?? '—') ?></td><td class="px-4 py-3"><?= e($r['referred_name'] ?? 'Pending') ?></td><td class="px-4 py-3 font-mono text-xs"><?= e($r['code']) ?></td><td class="px-4 py-3"><?= e(ucfirst($r['status'])) ?></td><td class="px-4 py-3 text-xs text-gray-500"><?= date('d M', strtotime($r['created_at'])) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="5" class="py-8 text-center text-gray-400">No referrals yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>