<?php
/**
 * Feature toggle system — the core of Friends Pizza Hut
 */

function feature_enabled(string $key): bool
{
    static $cache = [];
    if (array_key_exists($key, $cache)) return $cache[$key];
    try {
        $row = Database::fetch("SELECT is_enabled FROM features WHERE feature_key = ?", [$key]);
        $cache[$key] = $row ? (bool)$row['is_enabled'] : false;
    } catch (Throwable $e) {
        $cache[$key] = false;
    }
    return $cache[$key];
}

function feature_is_core(string $key): bool
{
    $row = Database::fetch("SELECT is_core FROM features WHERE feature_key = ?", [$key]);
    return $row ? (bool)$row['is_core'] : false;
}

function feature_exists(string $key): bool
{
    return (bool) Database::fetch("SELECT id FROM features WHERE feature_key = ?", [$key]);
}

function feature_requires_config(string $key): bool
{
    $row = Database::fetch("SELECT requires_config FROM features WHERE feature_key = ?", [$key]);
    return $row ? (bool)$row['requires_config'] : false;
}

function enable_feature(string $key): bool
{
    if (feature_is_core($key)) return false;
    $affected = Database::execute(
        "UPDATE features SET is_enabled = 1 WHERE feature_key = ? AND is_core = 0",
        [$key]
    );
    feature_clear_cache();
    return $affected > 0;
}

function disable_feature(string $key): bool
{
    if (feature_is_core($key)) return false;
    $affected = Database::execute(
        "UPDATE features SET is_enabled = 0 WHERE feature_key = ? AND is_core = 0",
        [$key]
    );
    feature_clear_cache();
    return $affected > 0;
}

function toggle_feature(string $key): bool
{
    if (feature_is_core($key)) return false;
    $current = feature_enabled($key);
    return $current ? disable_feature($key) : enable_feature($key);
}

function feature_clear_cache(): void
{
    // static cache inside feature_enabled is per-request; nothing else to clear.
    // When we later add persistent cache, clear here.
}

function get_all_features(): array
{
    return Database::fetchAll("SELECT * FROM features ORDER BY category, sort_order, feature_name");
}

function get_features_by_category(): array
{
    $rows = get_all_features();
    $grouped = [];
    foreach ($rows as $r) {
        $grouped[$r['category']][] = $r;
    }
    return $grouped;
}

function reset_features_to_defaults(): void
{
    Database::execute("UPDATE features SET is_enabled = default_state WHERE is_core = 0");
    feature_clear_cache();
}

function enable_all_in_category(string $category): int
{
    return Database::execute(
        "UPDATE features SET is_enabled = 1 WHERE category = ? AND is_core = 0",
        [$category]
    );
}

function disable_all_in_category(string $category): int
{
    return Database::execute(
        "UPDATE features SET is_enabled = 0 WHERE category = ? AND is_core = 0",
        [$category]
    );
}

function feature_category_label(string $category): string
{
    return match ($category) {
        'core'          => 'Core (always enabled)',
        'customer'      => 'Customer Experience',
        'orders'        => 'Orders & Kitchen',
        'marketing'     => 'Marketing & Promotions',
        'payments'      => 'Payments',
        'notifications' => 'Notifications',
        'integrations'  => 'Integrations',
        'advanced'      => 'Advanced Features',
        default         => ucfirst($category),
    };
}