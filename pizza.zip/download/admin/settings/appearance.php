<?php
// appearance.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Appearance';
if (is_post()) {
    verify_csrf();
    foreach (['primary_color','secondary_color','white_color'] as $k) update_setting($k, (string)post($k,''));
    flash_success('Saved.');
    redirect(url('admin/settings/appearance.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <?php foreach (['primary_color'=>'Primary Color','secondary_color'=>'Secondary Color','white_color'=>'White'] as $k=>$l): ?>
      <div><label class="text-xs text-gray-500"><?= $l ?></label><input type="color" name="<?= $k ?>" value="<?= e(setting($k,'#000000')) ?>" class="w-full border rounded px-3 py-2 h-10"></div>
    <?php endforeach; ?>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>