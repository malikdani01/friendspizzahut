<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('sms_notifications')) { flash_error('SMS module disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'SMS Integration';

if (is_post()) {
    verify_csrf();
    foreach (['sms_provider','sms_api_key','sms_api_secret','sms_sender_id','sms_sender_name'] as $k) {
        update_setting($k, (string)post($k, ''));
    }
    if (post('test_phone')) {
        send_sms((string)post('test_phone'), 'Test SMS from Friends Pizza Hut');
        flash_info('Test SMS triggered (check logs).');
    }
    flash_success('SMS settings saved.');
    redirect(url('admin/integrations/sms.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-2xl bg-white rounded-xl shadow-sm border p-6">
  <form method="post" class="space-y-4">
    <?= csrf_field() ?>
    <div>
      <label class="text-sm font-semibold">Provider</label>
      <select name="sms_provider" class="w-full border rounded px-3 py-2">
        <option value="">— None —</option>
        <option value="twilio" <?= setting('sms_provider')==='twilio'?'selected':'' ?>>Twilio</option>
        <option value="local" <?= setting('sms_provider')==='local'?'selected':'' ?>>Local Gateway</option>
      </select>
    </div>
    <div><label class="text-sm font-semibold">API Key / SID</label>
      <input name="sms_api_key" value="<?= e(setting('sms_api_key','')) ?>" class="w-full border rounded px-3 py-2">
    </div>
    <div><label class="text-sm font-semibold">API Secret / Token</label>
      <input type="password" name="sms_api_secret" value="<?= e(setting('sms_api_secret','')) ?>" class="w-full border rounded px-3 py-2">
    </div>
    <div><label class="text-sm font-semibold">Sender ID</label>
      <input name="sms_sender_id" value="<?= e(setting('sms_sender_id','')) ?>" class="w-full border rounded px-3 py-2">
    </div>
    <div><label class="text-sm font-semibold">Sender Name</label>
      <input name="sms_sender_name" value="<?= e(setting('sms_sender_name', setting('restaurant_name',''))) ?>" class="w-full border rounded px-3 py-2">
    </div>
    <div class="border-t pt-3">
      <label class="text-sm font-semibold">Test SMS to Number</label>
      <input name="test_phone" placeholder="03xxxxxxxxx" class="w-full border rounded px-3 py-2">
    </div>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save Settings</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>