<?php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!customer_logged_in()) { flash_error('Login required.'); redirect(url('login.php')); }
if (!is_post()) redirect(url('menu.php'));
verify_csrf();

$productId   = (int)post('product_id', 0);
$productSlug = (string)post('product_slug', '');
$rating      = (int)post('rating', 5);
$title       = trim((string)post('title', ''));
$comment     = trim((string)post('comment', ''));

if (!$productId) {
    flash_error('Invalid product.');
    redirect(url('menu.php'));
}

$r = submit_product_review(
    (int)$_SESSION['user_id'],
    $productId,
    $rating,
    $title ?: null,
    $comment ?: null
);

if ($r['ok']) {
    flash_success('Shukriya! Your review is awaiting approval. It will show up soon.');
} else {
    flash_error($r['error']);
}

redirect(url('product.php?slug=' . urlencode($productSlug)));