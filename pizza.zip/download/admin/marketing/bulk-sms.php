<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('bulk_sms_marketing')) {
    flash_error('Bulk SMS feature disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Bulk SMS Marketing';

$previewCount = 0;
$previewUsers = [];
$selectedSegment = (string)post('segment', 'active_30d');

if (is_post()) {
    verify_csrf();
    $action = post('action');

    $segmentMap = [
        'all' => 'segment_all',
        'active_30d' => 'segment_active_30d',
        'inactive_60d' => 'segment_inactive_60d',
        'never_ordered' => 'segment_never_ordered',
        'high_value' => 'segment_high_value',
    ];

    if (isset($segmentMap[$selectedSegment])) {
        $previewUsers = $segmentMap[$selectedSegment]();
    }
    $previewCount = count($previewUsers);

    if ($action === 'send' && !empty($previewUsers)) {
        $message = trim((string)post('message', ''));
        if (strlen($message) < 5) {
            flash_error('Message too short.');
            redirect(url('admin/marketing/bulk-sms.php'));
        }

        $sent = 0;
        $failed = 0;
        foreach ($previewUsers as $u) {
            if (send_sms($u['phone'], $message)) {
                $sent++;
            } else {
                $failed++;
            }
            // Rate limit — max 2 SMS per second
            usleep(500000);
        }

        audit_log('bulk_sms.sent', 'marketing', null, null, [
            'segment' => $selectedSegment,
            'sent' => $sent,
            'failed' => $failed,
        ]);

        flash_success("Sent: $sent | Failed: $failed");
        redirect(url('admin/marketing/bulk-sms.php'));
    }
}

require __DIR__ . '/../common/header.php';
?>

<div class="space-y-5">

  <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-5 text-sm text-yellow-900">
    <div class="font-bold mb-2"><i class="fa-solid fa-bullhorn mr-1"></i> Bulk SMS — Zaroori Tips</div>
    <ul class="list-disc list-inside space-y-1">
      <li>Pehle 1 test SMS khud ko bhejo</li>
      <li>Message 160 characters mein rakho (1 SMS unit)</li>
      <li>Best time: 12:00 PM - 1:00 PM (lunch) ya 6:00 PM - 8:00 PM (dinner)</li>
      <li>Hafta mein 2 se zyada SMS nahi bhejo (spam lagega)</li>
      <li>Har SMS ka cost — typically Rs. 1-12 per SMS provider pe depend karta hai</li>
    </ul>
  </div>

  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-4 text-brand">Step 1: Choose Segment</h3>
    <form method="post" id="segmentForm">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="preview">
      <div class="grid md:grid-cols-2 gap-3 mb-4">
        <?php
        $segments = [
            'all' => ['All Customers', 'fa-users', 'Everyone who signed up'],
            'active_30d' => ['Active (Last 30 Days)', 'fa-fire', 'Customers who ordered recently'],
            'inactive_60d' => ['Inactive (60+ Days)', 'fa-user-clock', 'Win-back campaign'],
            'never_ordered' => ['Never Ordered', 'fa-user-plus', 'Signed up but never bought'],
            'high_value' => ['High Value (Rs. 10k+)', 'fa-crown', 'VIP customers'],
        ];
        foreach ($segments as $key => $info): ?>
        <label class="cursor-pointer">
          <input type="radio" name="segment" value="<?= $key ?>" <?= $selectedSegment === $key ? 'checked' : '' ?> class="peer sr-only">
          <div class="border border-gray-200 peer-checked:border-brand peer-checked:bg-brand/5 rounded-xl p-4 transition">
            <div class="flex items-center gap-3">
              <i class="fa-solid <?= $info[1] ?> text-xl text-brand"></i>
              <div>
                <div class="font-bold"><?= $info[0] ?></div>
                <div class="text-xs text-gray-500"><?= $info[2] ?></div>
              </div>
            </div>
          </div>
        </label>
        <?php endforeach; ?>
      </div>
      <button class="bg-gray-800 text-white px-6 py-2.5 rounded-lg font-semibold">
        <i class="fa-solid fa-eye mr-1"></i> Preview Recipients
      </button>
    </form>
  </div>

  <?php if ($previewCount > 0): ?>
  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-4 text-brand">Step 2: Compose Message</h3>
    <div class="bg-blue-50 border border-blue-200 rounded p-3 mb-4 text-sm">
      <i class="fa-solid fa-info-circle mr-1"></i>
      <strong><?= number_format($previewCount) ?></strong> recipients selected.
    </div>
    <form method="post" data-confirm="Send SMS to <?= $previewCount ?> customers?">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="send">
      <input type="hidden" name="segment" value="<?= e($selectedSegment) ?>">
      <textarea name="message" rows="4" maxlength="160" required placeholder="Dear customer, 20% off aaj! Code: SAVE20. Order: friendspizza.pk" class="w-full border rounded-lg px-3 py-2 mb-2" oninput="document.getElementById('charCount').textContent = this.value.length"></textarea>
      <div class="flex justify-between text-xs text-gray-500 mb-4">
        <span id="charCount">0</span> / 160 characters
        <span>Approx cost: Rs. <?= number_format($previewCount * 2, 0) ?> - <?= number_format($previewCount * 12, 0) ?></span>
      </div>

      <button class="bg-brand hover:bg-red-700 text-white px-6 py-3 rounded-lg font-bold">
        <i class="fa-solid fa-paper-plane mr-1"></i> Send to <?= number_format($previewCount) ?> Customers
      </button>
    </form>
  </div>
  <?php elseif (is_post()): ?>
  <div class="bg-white rounded-xl border p-6">
    <div class="text-center text-gray-500 py-6">Is segment mein koi customer nahi mila.</div>
  </div>
  <?php endif; ?>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>