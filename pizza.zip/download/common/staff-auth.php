<?php
function staff_logged_in(): bool { return !empty($_SESSION['staff_id']); }
function current_staff(): ?array {
    if (!staff_logged_in()) return null;
    return Database::fetch("SELECT s.*, r.name AS role_name FROM staff s LEFT JOIN roles r ON r.id=s.role_id WHERE s.id=? AND s.is_active=1", [(int)$_SESSION['staff_id']]);
}
function require_staff(): void {
    if (!staff_logged_in()) { flash_error('Staff login required.'); redirect(url('admin/login.php')); }
}