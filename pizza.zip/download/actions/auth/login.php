<?php
// actions/auth/login.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('login.php'));
verify_csrf();
$r = login_customer((string)post('identifier',''), (string)post('password',''));
if ($r['ok']) {
    merge_guest_cart_after_login((int)$r['user']['id']);
    flash_success('Welcome back!');
    redirect($_SESSION['_redirect_after_login'] ?? url('account.php'));
}
flash_error($r['error']);
redirect(url('login.php'));