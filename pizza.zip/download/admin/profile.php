<?php
require_once __DIR__ . '/../common/bootstrap.php';
require_admin();
$pageTitle = 'My Profile';
$a = current_admin();
$errors = [];
if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'update') {
        $name = trim((string)post('name',''));
        $email = trim((string)post('email',''));
        if (strlen($name) < 2) $errors[] = 'Name too short.';
        if (!validate_email($email)) $errors[] = 'Invalid email.';
        if (!$errors) {
            Database::execute("UPDATE admins SET name=?, email=? WHERE id=?", [$name, $email, $a['id']]);
            audit_log('admin.profile.update');
            flash_success('Profile updated.');
            redirect(url('admin/profile.php'));
        }
    } elseif ($action === 'password') {
        $cur = (string)post('current_password','');
        $new = (string)post('new_password','');
        if (!password_verify($cur, $a['password_hash'])) $errors[] = 'Current password incorrect.';
        elseif (strlen($new) < 6) $errors[] = 'New password 6+ chars.';
        if (!$errors) {
            Database::execute("UPDATE admins SET password_hash=? WHERE id=?", [password_hash($new, PASSWORD_DEFAULT), $a['id']]);
            audit_log('admin.password.change');
            flash_success('Password changed.');
            redirect(url('admin/profile.php'));
        }
    }
}
require __DIR__ . '/common/header.php';
?>
<div class="max-w-2xl space-y-6">
  <?php if ($errors): ?><div class="bg-red-50 text-red-700 px-4 py-3 rounded"><?php foreach($errors as $e_) echo '• '.e($e_).'<br>'; ?></div><?php endif; ?>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="update">
    <h3 class="font-bold">Profile</h3>
    <input name="name" value="<?= e($a['name']) ?>" required class="w-full border rounded px-3 py-2">
    <input value="<?= e($a['username']) ?>" disabled class="w-full border rounded px-3 py-2 bg-gray-100">
    <input type="email" name="email" value="<?= e($a['email']) ?>" required class="w-full border rounded px-3 py-2">
    <button class="bg-brand text-white px-6 py-2 rounded font-semibold">Save</button>
  </form>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="password">
    <h3 class="font-bold">Change Password</h3>
    <input type="password" name="current_password" required placeholder="Current password" class="w-full border rounded px-3 py-2">
    <input type="password" name="new_password" required minlength="6" placeholder="New password" class="w-full border rounded px-3 py-2">
    <button class="bg-brand text-white px-6 py-2 rounded font-semibold">Change Password</button>
  </form>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>