<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * Friends Pizza Hut — Setup Installer (v2.1 — Full Migrations)
 * 
 * Ye installer ab:
 *   1. schema.sql import karta hai (base tables)
 *   2. seed.sql import karta hai (default data + features)
 *   3. database/migrations/*.sql — sab ko numeric order mein run karta hai
 *      (jo missing tables/features add karta hai)
 * 
 * Fresh installation ab 100% complete hoga — koi table missing nahi.
 * ═══════════════════════════════════════════════════════════════
 */

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');

$ROOT       = __DIR__;
$configFile = $ROOT . '/common/config.php';
$lockFile   = $ROOT . '/install.lock';

$step   = $_GET['step'] ?? '1';
$errors = [];

// ─── Requirements check ─────────────────────────────────────────
$requirements = [
    'PHP >= 8.1'        => version_compare(PHP_VERSION, '8.1.0', '>='),
    'PDO MySQL'         => extension_loaded('pdo_mysql'),
    'mbstring'          => extension_loaded('mbstring'),
    'fileinfo'          => extension_loaded('fileinfo'),
    'JSON'              => extension_loaded('json'),
    'cURL'              => extension_loaded('curl'),
    'uploads writable'  => is_writable($ROOT) || @is_writable($ROOT . '/uploads'),
    'common/ writable'  => is_writable($ROOT . '/common'),
];
$reqOk = !in_array(false, $requirements, true);

if (file_exists($configFile) && $step !== 'done') {
    $step = 'already';
}

/**
 * Split SQL file into individual statements safely.
 * Handles semicolons inside strings, comments, etc.
 */
function split_sql_statements(string $sql): array {
    $statements = [];
    $current = '';
    $inString = false;
    $stringChar = '';
    $len = strlen($sql);
    $i = 0;

    while ($i < $len) {
        $c = $sql[$i];
        $next = $i + 1 < $len ? $sql[$i + 1] : '';

        // Handle line comments
        if (!$inString && $c === '-' && $next === '-') {
            // Skip to end of line
            while ($i < $len && $sql[$i] !== "\n") $i++;
            continue;
        }

        // Handle block comments
        if (!$inString && $c === '/' && $next === '*') {
            $i += 2;
            while ($i < $len - 1 && !($sql[$i] === '*' && $sql[$i + 1] === '/')) $i++;
            $i += 2;
            continue;
        }

        $current .= $c;

        if ($inString) {
            if ($c === '\\') {
                // Escaped char
                $i++;
                if ($i < $len) $current .= $sql[$i];
            } elseif ($c === $stringChar) {
                // Check for doubled quote (SQL escape)
                if ($next === $stringChar) {
                    $current .= $next;
                    $i++;
                } else {
                    $inString = false;
                }
            }
        } else {
            if ($c === '"' || $c === "'" || $c === '`') {
                $inString = true;
                $stringChar = $c;
            } elseif ($c === ';') {
                $trimmed = trim($current);
                if ($trimmed !== '' && $trimmed !== ';') {
                    $statements[] = rtrim(substr($current, 0, -1));
                }
                $current = '';
            }
        }

        $i++;
    }

    $remaining = trim($current);
    if ($remaining !== '') $statements[] = $remaining;

    return $statements;
}

/**
 * Execute a SQL file against the DB
 */
function run_sql_file(PDO $pdo, string $filePath, array &$log): int {
    if (!file_exists($filePath)) {
        $log[] = "⚠️  SKIP (file not found): " . basename($filePath);
        return 0;
    }

    $sql = file_get_contents($filePath);
    if ($sql === false) {
        $log[] = "❌ READ FAILED: " . basename($filePath);
        return 0;
    }

    $statements = split_sql_statements($sql);
    $executed = 0;
    $failed = 0;

    foreach ($statements as $stmt) {
        $stmt = trim($stmt);
        if ($stmt === '') continue;
        try {
            $pdo->exec($stmt);
            $executed++;
        } catch (PDOException $e) {
            $failed++;
            $msg = $e->getMessage();

            // Ignore known benign errors on re-run
            $benign = [
                'already exists',
                'Duplicate entry',
                'Duplicate column',
                'check that column/key exists',
                'check that column/key',
            ];
            $isBenign = false;
            foreach ($benign as $b) {
                if (stripos($msg, $b) !== false) { $isBenign = true; break; }
            }

            if (!$isBenign) {
                $log[] = "⚠️  " . basename($filePath) . ": " . substr($msg, 0, 200);
            }
        }
    }

    $log[] = "✅ " . basename($filePath) . " — $executed statements executed" . ($failed ? ", $failed skipped" : "");
    return $executed;
}

// ─── Handle POST install ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === '2') {
    $host       = trim($_POST['db_host'] ?? 'localhost');
    $name       = trim($_POST['db_name'] ?? '');
    $user       = trim($_POST['db_user'] ?? '');
    $pass       = (string)($_POST['db_pass'] ?? '');
    $adminName  = trim($_POST['admin_name'] ?? '');
    $adminUser  = trim($_POST['admin_user'] ?? 'admin');
    $adminEmail = trim($_POST['admin_email'] ?? '');
    $adminPass  = (string)($_POST['admin_pass'] ?? '');
    $appUrl     = rtrim(trim($_POST['app_url'] ?? ''), '/');

    if ($name === '')           $errors[] = 'Database name required.';
    if ($user === '')           $errors[] = 'Database user required.';
    if (strlen($adminPass) < 6) $errors[] = 'Admin password must be 6+ chars.';
    if (!filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) $errors[] = 'Admin email invalid.';
    if ($appUrl === '')         $errors[] = 'App URL required (e.g. http://localhost/friends-pizza-hut).';
    if (strlen($adminName) < 2) $errors[] = 'Admin name required.';
    if (strlen($adminUser) < 2) $errors[] = 'Admin username required.';

    if (!$errors) {
        $sqlLog = [];
        try {
            // ─── Connect ──────────────────────────────────────
            $pdo = new PDO(
                "mysql:host=$host;dbname=$name;charset=utf8mb4",
                $user, $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );

            // ─── 1. Base schema ───────────────────────────────
            run_sql_file($pdo, $ROOT . '/database/schema.sql', $sqlLog);

            // ─── 2. Seed data (features + defaults) ───────────
            run_sql_file($pdo, $ROOT . '/database/seed.sql', $sqlLog);

            // ─── 3. All migrations in numeric order ───────────
            $migrationFiles = glob($ROOT . '/database/migrations/*.sql');
            if ($migrationFiles) {
                sort($migrationFiles, SORT_STRING); // 001, 002, ... 010, 011, 012
                foreach ($migrationFiles as $migFile) {
                    run_sql_file($pdo, $migFile, $sqlLog);
                }
            } else {
                $sqlLog[] = "ℹ️  No migration files found (or migrations folder empty).";
            }

            // ─── 4. Set admin credentials ─────────────────────
            $newHash = password_hash($adminPass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE admins SET name = ?, username = ?, email = ?, password_hash = ? WHERE id = 1");
            $stmt->execute([$adminName, $adminUser, $adminEmail, $newHash]);

            // If no admin existed (edge case), insert one
            $count = (int)($pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn() ?: 0);
            if ($count === 0) {
                $stmt = $pdo->prepare("INSERT INTO admins (name, username, email, password_hash, is_active) VALUES (?, ?, ?, ?, 1)");
                $stmt->execute([$adminName, $adminUser, $adminEmail, $newHash]);
            }

            // ─── 5. Create upload folders ─────────────────────
            $folders = ['products','categories','banners','offers','combos','reviews','restaurant','avatars','payments','products/gallery'];
            foreach ($folders as $dir) {
                $full = $ROOT . '/uploads/' . $dir;
                if (!is_dir($full)) @mkdir($full, 0755, true);
            }
            // Ensure backups dir
            if (!is_dir($ROOT . '/backups')) @mkdir($ROOT . '/backups', 0755, true);

            // ─── 6. Write config file ─────────────────────────
            $config  = "<?php\n";
            $config .= "// Auto-generated by setup.php on " . date('Y-m-d H:i:s') . "\n";
            $config .= "// DO NOT commit this file to git / share publicly.\n\n";
            $config .= "define('DB_HOST', " . var_export($host, true) . ");\n";
            $config .= "define('DB_NAME', " . var_export($name, true) . ");\n";
            $config .= "define('DB_USER', " . var_export($user, true) . ");\n";
            $config .= "define('DB_PASS', " . var_export($pass, true) . ");\n";
            $config .= "define('DB_CHARSET', 'utf8mb4');\n\n";
            $config .= "define('APP_NAME', 'Friends Pizza Hut');\n";
            $config .= "define('APP_URL', " . var_export($appUrl, true) . ");\n";
            $config .= "define('APP_DEBUG', false);\n";
            $config .= "define('APP_TIMEZONE', 'Asia/Karachi');\n\n";
            $config .= "define('SESSION_NAME', 'fph_session');\n";
            $config .= "define('SESSION_LIFETIME', 604800);\n\n";
            $config .= "define('ROOT_PATH', dirname(__DIR__));\n";
            $config .= "define('UPLOAD_PATH', ROOT_PATH . '/uploads');\n";
            $config .= "define('UPLOAD_URL', APP_URL . '/uploads');\n";

            if (!is_writable($ROOT . '/common')) {
                throw new Exception('common/ directory not writable.');
            }
            file_put_contents($configFile, $config);
            file_put_contents($lockFile, date('c'));

            // Save SQL log for review on success page
            $_SESSION['install_log'] = $sqlLog;

            header('Location: setup.php?step=done');
            exit;

        } catch (Throwable $ex) {
            $errors[] = 'Install failed: ' . $ex->getMessage();
            // Show log too
            $_SESSION['install_log'] = $sqlLog ?? [];
        }
    }
}

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$installLog = $_SESSION['install_log'] ?? [];
unset($_SESSION['install_log']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Install — Friends Pizza Hut</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="bg-gray-950 text-white min-h-screen flex items-center justify-center p-6 font-sans">
<div class="w-full max-w-2xl bg-gray-900 rounded-2xl shadow-2xl border border-white/10 overflow-hidden">
  <div class="bg-red-600 px-6 py-5 flex items-center gap-3">
    <i class="fa-solid fa-pizza-slice text-2xl"></i>
    <div>
      <h1 class="font-bold text-xl">Friends Pizza Hut — Setup</h1>
      <p class="text-xs text-white/80">Complete installer (schema + seed + migrations)</p>
    </div>
  </div>

  <div class="p-6">
    <?php if ($step === 'already'): ?>
      <div class="bg-yellow-500/20 border border-yellow-500/40 text-yellow-200 p-4 rounded-lg">
        <strong>Already installed.</strong> If you want to reinstall, delete <code>common/config.php</code> and <code>install.lock</code>.
      </div>

    <?php elseif ($step === 'done'): ?>
      <div class="text-center py-6">
        <i class="fa-solid fa-circle-check text-green-500 text-5xl mb-4"></i>
        <h2 class="text-2xl font-bold mb-2">Installation Complete!</h2>
        <p class="text-white/70 mb-6">Friends Pizza Hut platform is ready.</p>

        <?php if ($installLog): ?>
        <div class="bg-black/40 border border-white/10 rounded-lg p-4 mb-6 text-left text-xs font-mono max-h-60 overflow-y-auto">
          <div class="text-brand font-bold mb-2">Installation Log:</div>
          <?php foreach ($installLog as $line): ?>
            <div class="text-white/70"><?= h($line) ?></div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="bg-red-500/10 border border-red-500/30 text-red-200 p-4 rounded-lg mb-6 text-left text-sm">
          <strong>⚠️ IMPORTANT:</strong> Delete <code>setup.php</code> from your server now for security.
        </div>
        <a href="admin/login.php" class="inline-block bg-red-600 hover:bg-red-700 px-6 py-3 rounded-lg font-semibold">Go to Admin →</a>
      </div>

    <?php else: ?>
      <div class="mb-6">
        <h2 class="text-lg font-bold mb-3">System Requirements</h2>
        <ul class="space-y-2 text-sm">
          <?php foreach ($requirements as $label => $ok): ?>
            <li class="flex items-center gap-2">
              <i class="fa-solid <?= $ok ? 'fa-circle-check text-green-500' : 'fa-circle-xmark text-red-500' ?>"></i>
              <span class="<?= $ok ? '' : 'text-red-400' ?>"><?= h($label) ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <?php if (!$reqOk): ?>
        <div class="bg-red-500/20 border border-red-500/40 text-red-200 p-4 rounded-lg">
          Fix the requirements above before continuing.
        </div>
      <?php else: ?>
        <?php if ($errors): ?>
          <div class="bg-red-500/20 border border-red-500/40 text-red-200 p-4 rounded-lg mb-4 space-y-1 text-sm">
            <?php foreach ($errors as $er): ?><div>• <?= h($er) ?></div><?php endforeach; ?>
          </div>
          <?php if ($installLog): ?>
            <div class="bg-black/40 border border-white/10 rounded-lg p-4 mb-4 text-xs font-mono max-h-40 overflow-y-auto">
              <?php foreach ($installLog as $line): ?><div class="text-white/60"><?= h($line) ?></div><?php endforeach; ?>
            </div>
          <?php endif; ?>
        <?php endif; ?>

        <form method="post" action="setup.php?step=2" class="space-y-5">
          <div>
            <h3 class="font-bold text-red-400 mb-3">Database</h3>
            <div class="grid md:grid-cols-2 gap-3">
              <input name="db_host" placeholder="DB Host" value="<?= h($_POST['db_host'] ?? 'localhost') ?>" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
              <input name="db_name" placeholder="DB Name" value="<?= h($_POST['db_name'] ?? 'friends_pizza_hut') ?>" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
              <input name="db_user" placeholder="DB User" value="<?= h($_POST['db_user'] ?? 'root') ?>" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
              <input name="db_pass" placeholder="DB Password" type="password" class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
            </div>
          </div>

          <div>
            <h3 class="font-bold text-red-400 mb-3">Application URL</h3>
            <input name="app_url" placeholder="http://localhost/friends-pizza-hut" value="<?= h($_POST['app_url'] ?? ('http://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/'))) ?>" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
          </div>

          <div>
            <h3 class="font-bold text-red-400 mb-3">Admin Account</h3>
            <div class="grid md:grid-cols-2 gap-3">
              <input name="admin_name"  placeholder="Full Name" value="<?= h($_POST['admin_name'] ?? 'Hamid Jabbar') ?>" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
              <input name="admin_user"  placeholder="Username" value="<?= h($_POST['admin_user'] ?? 'admin') ?>" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
              <input name="admin_email" placeholder="Email" type="email" value="<?= h($_POST['admin_email'] ?? 'admin@friendspizzahut.com') ?>" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
              <input name="admin_pass"  placeholder="Password (6+ chars)" type="password" required class="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 focus:border-red-500 outline-none">
            </div>
          </div>

          <button type="submit" class="w-full bg-red-600 hover:bg-red-700 py-3 rounded-lg font-bold transition">
            <i class="fa-solid fa-rocket mr-2"></i> Install Now
          </button>

          <p class="text-xs text-white/40 text-center">
            schema.sql + seed.sql + all migrations will run automatically.
          </p>
        </form>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</div>
</body>
</html>