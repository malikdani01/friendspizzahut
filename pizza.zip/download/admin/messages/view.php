<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();

$threadId = (int)get('id', 0);
$thread = Database::fetch("SELECT * FROM contact_messages WHERE id = ? AND id = thread_id", [$threadId]);
if (!$thread) { flash_error('Thread not found.'); redirect(url('admin/messages/index.php')); }

$pageTitle = 'Message: ' . ($thread['subject'] ?: 'Inquiry');

// Mark as read
message_mark_read($threadId);

// Handle reply
if (is_post()) {
    verify_csrf();
    if (post('action') === 'reply') {
        $text = (string)post('reply_text', '');
        $r = message_add_reply($threadId, 'admin', $text, null, [
            'name' => setting('restaurant_name', 'Friends Pizza Hut'),
            'phone' => setting('restaurant_phone', ''),
        ]);
        if ($r['ok']) flash_success('Reply sent.');
        else flash_error($r['error']);
        redirect(url('admin/messages/view.php?id=' . $threadId));
    }
}

$messages = message_get_thread($threadId);

require __DIR__ . '/../common/header.php';
?>

<style>
.mv-wrap { max-width: 900px; margin: 0 auto; }
.mv-head {
  background: #171717; border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px; padding: 18px; margin-bottom: 16px;
}
.mv-subject { font-size: 18px; font-weight: 800; color: #fff; margin-bottom: 8px; }
.mv-meta { font-size: 13px; color: rgba(255,255,255,0.6); line-height: 1.7; }
.mv-meta strong { color: #fff; }
.mv-meta a { color: #dc2626; text-decoration: none; }

.mv-messages {
  background: #171717; border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px; padding: 20px; margin-bottom: 16px;
}
.mv-msg {
  padding: 14px 16px; border-radius: 14px;
  margin-bottom: 12px; max-width: 85%;
  font-size: 14px; line-height: 1.55;
}
.mv-msg-user {
  background: rgba(220,38,38,0.15);
  border: 1px solid rgba(220,38,38,0.25);
  margin-right: auto; margin-left: 0;
  border-bottom-left-radius: 4px;
}
.mv-msg-admin {
  background: rgba(59,130,246,0.12);
  border: 1px solid rgba(59,130,246,0.25);
  margin-left: auto; margin-right: 0;
  border-bottom-right-radius: 4px;
}
.mv-msg-head {
  display: flex; justify-content: space-between; align-items: center;
  gap: 8px; margin-bottom: 6px;
}
.mv-msg-sender {
  font-size: 11.5px; font-weight: 800; text-transform: uppercase;
  letter-spacing: 0.5px;
}
.mv-msg-user .mv-msg-sender { color: #fca5a5; }
.mv-msg-admin .mv-msg-sender { color: #93c5fd; }
.mv-msg-time { font-size: 11px; color: rgba(255,255,255,0.4); }
.mv-msg-body { color: #f9fafb; }

.mv-reply-card {
  background: #171717; border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px; padding: 20px;
}
.mv-reply-card h3 {
  font-size: 14px; font-weight: 800; color: #dc2626;
  margin: 0 0 14px; text-transform: uppercase; letter-spacing: 0.5px;
}
.mv-textarea {
  width: 100%; min-height: 110px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 10px; color: #fff;
  font-size: 14px; font-family: inherit;
  padding: 12px 14px; outline: none;
  resize: vertical; margin-bottom: 12px;
}
.mv-textarea:focus {
  border-color: #dc2626;
  box-shadow: 0 0 0 3px rgba(220,38,38,0.15);
}
.mv-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 12px 24px; border-radius: 10px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff; border: 0; cursor: pointer;
  font-size: 14px; font-weight: 800;
  box-shadow: 0 4px 14px rgba(220,38,38,0.3);
  transition: all .15s; text-decoration: none;
}
.mv-btn:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(220,38,38,0.45); }
.mv-back {
  display: inline-flex; align-items: center; gap: 6px;
  color: rgba(255,255,255,0.6); text-decoration: none;
  font-size: 13px; margin-bottom: 16px;
  transition: color .15s;
}
.mv-back:hover { color: #dc2626; }
</style>

<div class="mv-wrap">
  <a href="<?= url('admin/messages/index.php') ?>" class="mv-back">
    <i class="fa-solid fa-arrow-left"></i> Back to Messages
  </a>

  <div class="mv-head">
    <div class="mv-subject"><?= e($thread['subject'] ?: 'General Inquiry') ?></div>
    <div class="mv-meta">
      <strong><?= e($thread['name']) ?></strong>
      · <a href="tel:<?= e($thread['phone']) ?>"><?= e($thread['phone']) ?></a>
      <?php if ($thread['email']): ?> · <a href="mailto:<?= e($thread['email']) ?>"><?= e($thread['email']) ?></a><?php endif; ?>
      · Started <?= date('d M Y, H:i', strtotime($thread['created_at'])) ?>
      <?php if ($thread['ip_address']): ?> · IP: <?= e($thread['ip_address']) ?><?php endif; ?>
    </div>
  </div>

  <div class="mv-messages">
    <?php foreach ($messages as $m):
      $isAdmin = $m['sender_type'] === 'admin';
    ?>
      <div class="mv-msg <?= $isAdmin ? 'mv-msg-admin' : 'mv-msg-user' ?>">
        <div class="mv-msg-head">
          <div class="mv-msg-sender"><?= $isAdmin ? 'You (Admin)' : e($m['name']) ?></div>
          <div class="mv-msg-time"><?= date('d M Y, H:i', strtotime($m['created_at'])) ?></div>
        </div>
        <div class="mv-msg-body"><?= nl2br(e($m['message'])) ?></div>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="mv-reply-card">
    <h3><i class="fa-solid fa-reply"></i> Reply to <?= e($thread['name']) ?></h3>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="reply">
      <textarea name="reply_text" required class="mv-textarea" placeholder="Type your reply..."></textarea>
      <button type="submit" class="mv-btn">
        <i class="fa-solid fa-paper-plane"></i> Send Reply
      </button>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>