-- ═══════════════════════════════════════════════════════════════
-- FRIENDS PIZZA HUT — Migration 013
-- Table Reservation System — Complete
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS reservations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reservation_code VARCHAR(40) NOT NULL UNIQUE,
    user_id INT UNSIGNED NULL,
    customer_name VARCHAR(120) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_email VARCHAR(190) NULL,
    party_size INT NOT NULL DEFAULT 2,
    reservation_date DATE NOT NULL,
    reservation_time TIME NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 90,
    table_number VARCHAR(20) NULL,
    special_requests TEXT NULL,
    status ENUM('pending','confirmed','seated','completed','cancelled','no_show') NOT NULL DEFAULT 'pending',
    admin_note VARCHAR(500) NULL,
    confirmed_by INT UNSIGNED NULL,
    confirmed_at DATETIME NULL,
    seated_at DATETIME NULL,
    completed_at DATETIME NULL,
    cancelled_at DATETIME NULL,
    cancel_reason VARCHAR(255) NULL,
    cancelled_by ENUM('customer','admin') NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_date (reservation_date),
    INDEX idx_status (status),
    INDEX idx_user (user_id),
    INDEX idx_code (reservation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Update feature toggle to enabled by default since it's now complete
UPDATE features SET is_enabled = 0, default_state = 0 WHERE feature_key = 'table_reservation';