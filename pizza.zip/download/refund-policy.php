<?php
// refund-policy.php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Refund Policy';
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-16">
  <h1 class="text-4xl font-extrabold mb-6">Refund Policy</h1>
  <div class="space-y-4 text-white/70 text-sm leading-relaxed">
    <p>Customer satisfaction is our priority. If something isn't right, we'll make it right.</p>
    <h3 class="text-white font-bold text-lg mt-6">Eligibility</h3>
    <p>Refunds may be issued if: order was not delivered, items were missing or incorrect, or food quality was below standard.</p>
    <h3 class="text-white font-bold text-lg mt-6">How to Request</h3>
    <p>Call us at <?= e(setting('restaurant_phone')) ?> within 24 hours of your order. Provide your order number and details.</p>
    <h3 class="text-white font-bold text-lg mt-6">Processing</h3>
    <p>Approved refunds are processed within 3-5 business days via the original payment method.</p>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>