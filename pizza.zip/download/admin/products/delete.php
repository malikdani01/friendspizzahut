<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/products/index.php'));
verify_csrf();
$id = (int)post('id', 0);
$p = get_product($id);
if (!$p) { flash_error('Not found.'); redirect(url('admin/products/index.php')); }
Database::execute("DELETE FROM cart_items WHERE product_id = ?", [$id]);
Database::execute("DELETE FROM product_variation_groups WHERE product_id = ?", [$id]);
Database::execute("DELETE FROM product_addons WHERE product_id = ?", [$id]);
Database::execute("DELETE FROM product_images WHERE product_id = ?", [$id]);
Database::execute("DELETE FROM products WHERE id = ?", [$id]);
if ($p['image'] && file_exists(UPLOAD_PATH . '/' . $p['image'])) @unlink(UPLOAD_PATH . '/' . $p['image']);
flash_success('Product deleted.');
redirect(url('admin/products/index.php'));