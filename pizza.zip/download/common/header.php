<?php
$pageTitle = $pageTitle ?? setting('restaurant_name', 'Friends Pizza Hut');
$pageDescription = $pageDescription ?? setting('tagline', 'Hot • Fresh • Delicious');
$cartCount = function_exists('get_cart_count') ? get_cart_count() : 0;
$notifCount = 0;
$chatUnread = 0;
$currentFile = basename($_SERVER['SCRIPT_NAME'] ?? '');
if (customer_logged_in() && function_exists('unread_notification_count')) {
    try { $notifCount = unread_notification_count('customer', (int)$_SESSION['user_id']); } catch (Throwable $e) {}
}
if (customer_logged_in() && function_exists('chat_unread_count')) {
    try { $chatUnread = chat_unread_count((int)$_SESSION['user_id'], 'user', null); } catch (Throwable $e) {}
}
$chatUrl = customer_logged_in() ? url('messages.php') : url('contact.php');
$user = customer_logged_in() ? current_customer() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#0a0a0a">
<title><?= e($pageTitle) ?> — <?= e(setting('restaurant_name', 'Friends Pizza Hut')) ?></title>
<meta name="description" content="<?= e($pageDescription) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
/* ═══════════════════════════════════════════════════════════════
   ALL-IN-ONE INLINE CSS
   ═══════════════════════════════════════════════════════════════ */

/* RESET */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { -webkit-text-size-adjust: 100%; font-size: 16px; scroll-behavior: smooth; }
body {
  min-height: 100vh;
  padding: 0 0 90px 0;
  background: #0a0a0a;
  color: #f9fafb;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  font-size: 15px;
  line-height: 1.55;
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
}
img, svg, video { max-width: 100%; height: auto; display: block; }
button { font-family: inherit; cursor: pointer; border: 0; background: transparent; color: inherit; }
input, textarea, select { font-family: inherit; font-size: 16px; }
h1, h2, h3, h4, h5, h6 { margin: 0 0 12px; line-height: 1.2; font-weight: 800; }
h1 { font-size: 28px; }
h2 { font-size: 22px; }
h3 { font-size: 18px; }
p { margin: 0 0 12px; }
a { color: #dc2626; text-decoration: none; }
a:hover { text-decoration: underline; }

/* ─── TAILWIND COMPAT ────────────────────────────────────── */
.block{display:block!important}.inline-block{display:inline-block!important}.inline{display:inline!important}
.flex{display:flex!important}.inline-flex{display:inline-flex!important}.grid{display:grid!important}.hidden{display:none!important}
.flex-1{flex:1 1 0%!important}.flex-col{flex-direction:column!important}.flex-row{flex-direction:row!important}.flex-wrap{flex-wrap:wrap!important}
.items-start{align-items:flex-start!important}.items-center{align-items:center!important}.items-end{align-items:flex-end!important}.items-baseline{align-items:baseline!important}
.justify-start{justify-content:flex-start!important}.justify-center{justify-content:center!important}.justify-end{justify-content:flex-end!important}.justify-between{justify-content:space-between!important}
.shrink-0{flex-shrink:0!important}.min-w-0{min-width:0!important}
.grid-cols-1{grid-template-columns:repeat(1,minmax(0,1fr))!important}.grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))!important}
.grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))!important}.grid-cols-4{grid-template-columns:repeat(4,minmax(0,1fr))!important}
.gap-1{gap:4px!important}.gap-2{gap:8px!important}.gap-3{gap:12px!important}.gap-4{gap:16px!important}.gap-5{gap:20px!important}.gap-6{gap:24px!important}
.p-0{padding:0!important}.p-1{padding:4px!important}.p-2{padding:8px!important}.p-3{padding:12px!important}.p-4{padding:16px!important}.p-5{padding:20px!important}.p-6{padding:24px!important}.p-8{padding:32px!important}
.px-2{padding-left:8px!important;padding-right:8px!important}.px-3{padding-left:12px!important;padding-right:12px!important}
.px-4{padding-left:16px!important;padding-right:16px!important}.px-5{padding-left:20px!important;padding-right:20px!important}.px-6{padding-left:24px!important;padding-right:24px!important}
.py-1{padding-top:4px!important;padding-bottom:4px!important}.py-2{padding-top:8px!important;padding-bottom:8px!important}
.py-2\.5{padding-top:10px!important;padding-bottom:10px!important}.py-3{padding-top:12px!important;padding-bottom:12px!important}
.py-4{padding-top:16px!important;padding-bottom:16px!important}.py-5{padding-top:20px!important;padding-bottom:20px!important}
.py-6{padding-top:24px!important;padding-bottom:24px!important}.py-8{padding-top:32px!important;padding-bottom:32px!important}
.py-10{padding-top:40px!important;padding-bottom:40px!important}.py-12{padding-top:48px!important;padding-bottom:48px!important}
.py-16{padding-top:64px!important;padding-bottom:64px!important}
.pt-2{padding-top:8px!important}.pt-3{padding-top:12px!important}.pt-4{padding-top:16px!important}.pt-6{padding-top:24px!important}
.pb-2{padding-bottom:8px!important}.pb-3{padding-bottom:12px!important}.pb-4{padding-bottom:16px!important}
.pl-2{padding-left:8px!important}.pl-3{padding-left:12px!important}.pl-4{padding-left:16px!important}
.pr-2{padding-right:8px!important}.pr-3{padding-right:12px!important}.pr-4{padding-right:16px!important}
.m-0{margin:0!important}.m-auto{margin:auto!important}.mx-auto{margin-left:auto!important;margin-right:auto!important}
.mx-2{margin-left:8px!important;margin-right:8px!important}.mx-4{margin-left:16px!important;margin-right:16px!important}
.my-2{margin-top:8px!important;margin-bottom:8px!important}.my-3{margin-top:12px!important;margin-bottom:12px!important}
.my-4{margin-top:16px!important;margin-bottom:16px!important}.my-6{margin-top:24px!important;margin-bottom:24px!important}
.mt-0{margin-top:0!important}.mt-1{margin-top:4px!important}.mt-2{margin-top:8px!important}.mt-3{margin-top:12px!important}
.mt-4{margin-top:16px!important}.mt-5{margin-top:20px!important}.mt-6{margin-top:24px!important}.mt-8{margin-top:32px!important}
.mt-10{margin-top:40px!important}.mt-12{margin-top:48px!important}
.mb-0{margin-bottom:0!important}.mb-1{margin-bottom:4px!important}.mb-2{margin-bottom:8px!important}.mb-3{margin-bottom:12px!important}
.mb-4{margin-bottom:16px!important}.mb-5{margin-bottom:20px!important}.mb-6{margin-bottom:24px!important}.mb-8{margin-bottom:32px!important}
.ml-1{margin-left:4px!important}.ml-2{margin-left:8px!important}.ml-3{margin-left:12px!important}.ml-4{margin-left:16px!important}.ml-auto{margin-left:auto!important}
.mr-1{margin-right:4px!important}.mr-2{margin-right:8px!important}.mr-3{margin-right:12px!important}.mr-4{margin-right:16px!important}
.space-y-1>*+*{margin-top:4px!important}.space-y-2>*+*{margin-top:8px!important}.space-y-3>*+*{margin-top:12px!important}
.space-y-4>*+*{margin-top:16px!important}.space-y-5>*+*{margin-top:20px!important}.space-y-6>*+*{margin-top:24px!important}
.w-full{width:100%!important}.w-auto{width:auto!important}
.w-4{width:16px!important}.w-5{width:20px!important}.w-6{width:24px!important}.w-8{width:32px!important}
.w-10{width:40px!important}.w-11{width:44px!important}.w-12{width:48px!important}.w-16{width:64px!important}
.w-20{width:80px!important}.w-24{width:96px!important}.w-32{width:128px!important}
.h-full{height:100%!important}.h-4{height:16px!important}.h-5{height:20px!important}.h-6{height:24px!important}
.h-8{height:32px!important}.h-10{height:40px!important}.h-11{height:44px!important}.h-12{height:48px!important}
.h-14{height:56px!important}.h-16{height:64px!important}
.min-h-screen{min-height:100vh!important}
.max-w-xs{max-width:320px!important}.max-w-sm{max-width:384px!important}.max-w-md{max-width:448px!important}
.max-w-lg{max-width:512px!important}.max-w-xl{max-width:576px!important}.max-w-2xl{max-width:672px!important}
.max-w-3xl{max-width:768px!important}.max-w-4xl{max-width:896px!important}.max-w-6xl{max-width:1152px!important}
.max-w-7xl{max-width:1280px!important}.max-w-full{max-width:100%!important}
.aspect-square{aspect-ratio:1/1!important}
.bg-black{background-color:#000!important}.bg-white{background-color:#fff!important}.bg-transparent{background-color:transparent!important}
.bg-brand{background-color:#dc2626!important}.bg-red-500{background-color:#ef4444!important}.bg-red-600{background-color:#dc2626!important}
.bg-red-700{background-color:#b91c1c!important}.bg-green-500{background-color:#22c55e!important}.bg-green-600{background-color:#16a34a!important}
.bg-yellow-500{background-color:#eab308!important}.bg-blue-500{background-color:#3b82f6!important}.bg-blue-600{background-color:#2563eb!important}
.bg-orange-500{background-color:#f97316!important}.bg-gray-50{background-color:#f9fafb!important}.bg-gray-100{background-color:#f3f4f6!important}
.bg-gray-200{background-color:#e5e7eb!important}.bg-gray-300{background-color:#d1d5db!important}.bg-gray-800{background-color:#1f2937!important}
.bg-gray-900{background-color:#111827!important}.bg-ink{background-color:#0a0a0a!important}
.bg-black\/40{background-color:rgba(0,0,0,0.4)!important}.bg-black\/60{background-color:rgba(0,0,0,0.6)!important}
.bg-black\/90{background-color:rgba(0,0,0,0.9)!important}
.bg-white\/5{background-color:rgba(255,255,255,0.05)!important}.bg-white\/10{background-color:rgba(255,255,255,0.10)!important}
.bg-white\/20{background-color:rgba(255,255,255,0.20)!important}
.bg-brand\/10{background-color:rgba(220,38,38,0.10)!important}.bg-brand\/20{background-color:rgba(220,38,38,0.20)!important}
.bg-green-500\/20{background-color:rgba(34,197,94,0.20)!important}.bg-red-500\/20{background-color:rgba(239,68,68,0.20)!important}
.bg-yellow-500\/20{background-color:rgba(234,179,8,0.20)!important}
.text-white{color:#fff!important}.text-black{color:#000!important}.text-brand{color:#dc2626!important}
.text-red-400{color:#f87171!important}.text-red-500{color:#ef4444!important}.text-red-600{color:#dc2626!important}
.text-green-400{color:#4ade80!important}.text-green-500{color:#22c55e!important}.text-green-600{color:#16a34a!important}
.text-yellow-400{color:#facc15!important}.text-yellow-500{color:#eab308!important}
.text-blue-500{color:#3b82f6!important}.text-orange-500{color:#f97316!important}
.text-gray-300{color:#d1d5db!important}.text-gray-400{color:#9ca3af!important}.text-gray-500{color:#6b7280!important}
.text-gray-600{color:#4b5563!important}.text-gray-700{color:#374151!important}.text-gray-900{color:#111827!important}
.text-white\/40{color:rgba(255,255,255,0.4)!important}.text-white\/50{color:rgba(255,255,255,0.5)!important}
.text-white\/60{color:rgba(255,255,255,0.6)!important}.text-white\/70{color:rgba(255,255,255,0.7)!important}
.text-white\/80{color:rgba(255,255,255,0.8)!important}.text-white\/90{color:rgba(255,255,255,0.9)!important}
.border{border:1px solid rgba(255,255,255,0.1)!important}.border-0{border:0!important}
.border-2{border:2px solid rgba(255,255,255,0.1)!important}
.border-t{border-top:1px solid rgba(255,255,255,0.1)!important}.border-b{border-bottom:1px solid rgba(255,255,255,0.1)!important}
.border-l{border-left:1px solid rgba(255,255,255,0.1)!important}.border-r{border-right:1px solid rgba(255,255,255,0.1)!important}
.border-brand{border-color:#dc2626!important}.border-red-500{border-color:#ef4444!important}.border-green-500{border-color:#22c55e!important}
.border-yellow-500{border-color:#eab308!important}.border-white{border-color:#fff!important}
.border-gray-100{border-color:#f3f4f6!important}.border-gray-200{border-color:#e5e7eb!important}.border-gray-300{border-color:#d1d5db!important}
.border-white\/10{border-color:rgba(255,255,255,0.1)!important}.border-white\/20{border-color:rgba(255,255,255,0.2)!important}
.border-brand\/30{border-color:rgba(220,38,38,0.3)!important}.border-brand\/40{border-color:rgba(220,38,38,0.4)!important}
.border-green-500\/40{border-color:rgba(34,197,94,0.4)!important}.border-red-500\/40{border-color:rgba(239,68,68,0.4)!important}
.border-yellow-500\/40{border-color:rgba(234,179,8,0.4)!important}
.rounded{border-radius:4px!important}.rounded-md{border-radius:6px!important}.rounded-lg{border-radius:8px!important}
.rounded-xl{border-radius:12px!important}.rounded-2xl{border-radius:16px!important}.rounded-3xl{border-radius:24px!important}.rounded-full{border-radius:9999px!important}
.shadow-sm{box-shadow:0 1px 2px rgba(0,0,0,0.15)!important}.shadow{box-shadow:0 4px 6px rgba(0,0,0,0.2)!important}
.shadow-md{box-shadow:0 4px 12px rgba(0,0,0,0.2)!important}.shadow-lg{box-shadow:0 8px 24px rgba(0,0,0,0.3)!important}
.shadow-xl{box-shadow:0 12px 32px rgba(0,0,0,0.4)!important}
.text-xs{font-size:12px!important;line-height:1.5!important}.text-sm{font-size:14px!important;line-height:1.5!important}
.text-base{font-size:16px!important;line-height:1.5!important}.text-lg{font-size:18px!important;line-height:1.4!important}
.text-xl{font-size:20px!important;line-height:1.4!important}.text-2xl{font-size:24px!important;line-height:1.3!important}
.text-3xl{font-size:30px!important;line-height:1.2!important}.text-4xl{font-size:36px!important;line-height:1.1!important}
.font-medium{font-weight:500!important}.font-semibold{font-weight:600!important}.font-bold{font-weight:700!important}
.font-extrabold{font-weight:800!important}.font-black{font-weight:900!important}
.text-left{text-align:left!important}.text-center{text-align:center!important}.text-right{text-align:right!important}
.uppercase{text-transform:uppercase!important}.lowercase{text-transform:lowercase!important}.capitalize{text-transform:capitalize!important}
.italic{font-style:italic!important}.underline{text-decoration:underline!important}.line-through{text-decoration:line-through!important}.no-underline{text-decoration:none!important}
.tracking-wide{letter-spacing:0.025em!important}.tracking-wider{letter-spacing:0.05em!important}.tracking-widest{letter-spacing:0.1em!important}
.leading-tight{line-height:1.25!important}.leading-none{line-height:1!important}.leading-relaxed{line-height:1.625!important}
.truncate{overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}
.whitespace-nowrap{white-space:nowrap!important}
.relative{position:relative!important}.absolute{position:absolute!important}.fixed{position:fixed!important}.sticky{position:sticky!important}
.top-0{top:0!important}.top-2{top:8px!important}.top-4{top:16px!important}
.right-0{right:0!important}.right-2{right:8px!important}.right-4{right:16px!important}
.bottom-0{bottom:0!important}.bottom-4{bottom:16px!important}
.left-0{left:0!important}.left-4{left:16px!important}.inset-0{top:0;right:0;bottom:0;left:0}
.z-10{z-index:10!important}.z-20{z-index:20!important}.z-30{z-index:30!important}.z-40{z-index:40!important}.z-50{z-index:50!important}
.overflow-hidden{overflow:hidden!important}.overflow-auto{overflow:auto!important}
.overflow-x-auto{overflow-x:auto!important}.overflow-y-auto{overflow-y:auto!important}.overflow-x-hidden{overflow-x:hidden!important}
.opacity-0{opacity:0!important}.opacity-30{opacity:0.3!important}.opacity-40{opacity:0.4!important}.opacity-50{opacity:0.5!important}
.opacity-60{opacity:0.6!important}.opacity-70{opacity:0.7!important}.opacity-80{opacity:0.8!important}.opacity-100{opacity:1!important}
.cursor-pointer{cursor:pointer!important}.cursor-not-allowed{cursor:not-allowed!important}
.transition{transition:all 0.2s ease!important}.transition-colors{transition:color 0.2s,background-color 0.2s,border-color 0.2s!important}
.hover\:bg-red-700:hover{background-color:#b91c1c!important}.hover\:bg-brand:hover{background-color:#dc2626!important}
.hover\:bg-white\/10:hover{background-color:rgba(255,255,255,0.10)!important}
.hover\:text-brand:hover{color:#dc2626!important}.hover\:text-white:hover{color:#fff!important}
.hover\:underline:hover{text-decoration:underline!important}
.focus\:outline-none:focus{outline:none!important}.focus\:border-brand:focus{border-color:#dc2626!important}
.disabled\:opacity-50:disabled{opacity:0.5!important}.disabled\:cursor-not-allowed:disabled{cursor:not-allowed!important}
@media(min-width:640px){
.sm\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))!important}.sm\:flex{display:flex!important}.sm\:hidden{display:none!important}}
@media(min-width:768px){
.md\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))!important}.md\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))!important}
.md\:grid-cols-4{grid-template-columns:repeat(4,minmax(0,1fr))!important}.md\:flex{display:flex!important}.md\:hidden{display:none!important}
.md\:inline-flex{display:inline-flex!important}.md\:text-lg{font-size:18px!important}.md\:text-xl{font-size:20px!important}
.md\:text-2xl{font-size:24px!important}.md\:text-3xl{font-size:30px!important}.md\:text-4xl{font-size:36px!important}
.md\:p-6{padding:24px!important}.md\:px-4{padding-left:16px!important;padding-right:16px!important}
.md\:px-6{padding-left:24px!important;padding-right:24px!important}.md\:py-12{padding-top:48px!important;padding-bottom:48px!important}
.md\:py-20{padding-top:80px!important;padding-bottom:80px!important}.md\:gap-4{gap:16px!important}}
@media(min-width:1024px){
.lg\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))!important}.lg\:grid-cols-4{grid-template-columns:repeat(4,minmax(0,1fr))!important}
.lg\:col-span-2{grid-column:span 2!important}.lg\:hidden{display:none!important}}

/* ─── FORCE DARK FORMS ────────────────────────────────────── */
body input:not([type="checkbox"]):not([type="radio"]):not([type="color"]):not([type="file"]):not([type="submit"]):not([type="button"]):not([type="range"]),
body textarea, body select {
  background: rgba(0,0,0,0.4) !important;
  border: 1.5px solid rgba(255,255,255,0.1) !important;
  border-radius: 10px !important;
  color: #fff !important;
  padding: 11px 14px !important;
  font-size: 15px !important;
  min-height: 44px !important;
  width: 100% !important;
  font-family: inherit !important;
  outline: none !important;
  -webkit-appearance: none !important;
  transition: border-color .15s, box-shadow .15s !important;
}
body input:focus, body textarea:focus, body select:focus {
  border-color: #dc2626 !important;
  box-shadow: 0 0 0 3px rgba(220,38,38,0.15) !important;
}
body input::placeholder, body textarea::placeholder { color: rgba(255,255,255,0.35) !important; }
body select option { background: #171717 !important; color: #fff !important; }
body label { color: rgba(255,255,255,0.85) !important; }
body input[type="checkbox"], body input[type="radio"] { accent-color: #dc2626 !important; width: 16px !important; height: 16px !important; }

/* ═══════════════════════════════════════════════════════════
   HEADER — Adaptive (Mobile + Desktop)
   ═══════════════════════════════════════════════════════════ */
.fph-header {
  position: sticky; top: 0; z-index: 60;
  background: rgba(10,10,10,0.96);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(255,255,255,0.08);
  padding-top: env(safe-area-inset-top, 0);
}
.fph-header-inner {
  height: 64px; max-width: 1400px; margin: 0 auto;
  padding: 0 16px;
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
}

/* Mobile header layout */
.fph-mobile-header { display: flex; align-items: center; justify-content: space-between; width: 100%; gap: 6px; }
.fph-desktop-header { display: none; }

@media (min-width: 1024px) {
  .fph-mobile-header { display: none !important; }
  .fph-desktop-header { display: flex !important; align-items: center; width: 100%; gap: 24px; }
}

.fph-icon-btn {
  width: 42px; height: 42px; flex: 0 0 42px;
  display: inline-flex; align-items: center; justify-content: center;
  background: transparent; color: #fff; border: 0;
  border-radius: 12px; font-size: 18px;
  position: relative; transition: background .2s;
  text-decoration: none; cursor: pointer;
}
.fph-icon-btn:hover, .fph-icon-btn:active { background: rgba(255,255,255,0.1); }

.fph-logo { display: flex; align-items: center; gap: 10px; color: #fff; text-decoration: none; flex-shrink: 0; }
.fph-logo-icon {
  width: 40px; height: 40px; border-radius: 50%; background: #dc2626;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 18px; flex-shrink: 0;
  box-shadow: 0 4px 12px rgba(220,38,38,.4);
}
.fph-logo-text { display: flex; flex-direction: column; line-height: 1; }
.fph-logo-top { font-weight: 800; font-size: 14px; letter-spacing: .5px; color: #fff; }
.fph-logo-bottom { font-weight: 700; font-size: 11px; color: #dc2626; letter-spacing: 1.5px; margin-top: 2px; }

/* Desktop navigation */
.fph-desktop-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1;
  justify-content: center;
}
.fph-desktop-nav a {
  padding: 8px 16px;
  border-radius: 10px;
  color: rgba(255,255,255,0.7);
  font-size: 14px;
  font-weight: 600;
  text-decoration: none;
  transition: all .2s;
}
.fph-desktop-nav a:hover, .fph-desktop-nav a.active {
  color: #fff;
  background: rgba(220,38,38,0.15);
  text-decoration: none;
}

/* Desktop search bar */
.fph-desktop-search {
  flex: 0 1 340px;
  min-width: 220px;
  position: relative;
}
.fph-desktop-search form {
  display: flex;
  align-items: center;
  background: rgba(255,255,255,0.05);
  border: 1.5px solid rgba(255,255,255,0.08);
  border-radius: 12px;
  padding: 0 4px 0 16px;
  transition: all .2s;
}
.fph-desktop-search form:focus-within {
  border-color: #dc2626;
  background: rgba(255,255,255,0.08);
  box-shadow: 0 0 0 3px rgba(220,38,38,0.15);
}
.fph-desktop-search i {
  color: rgba(255,255,255,0.4);
  font-size: 14px;
}
.fph-desktop-search input {
  flex: 1;
  background: transparent !important;
  border: 0 !important;
  color: #fff !important;
  font-size: 14px !important;
  padding: 12px 10px !important;
  min-height: auto !important;
  box-shadow: none !important;
  outline: none !important;
}
.fph-desktop-search input::placeholder { color: rgba(255,255,255,0.4) !important; }

.fph-desktop-actions { display: flex; align-items: center; gap: 4px; flex-shrink: 0; }

.fph-user-chip {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 14px 6px 6px;
  background: rgba(255,255,255,0.05);
  border-radius: 999px;
  color: #fff;
  text-decoration: none;
  font-size: 13px;
  font-weight: 700;
  transition: all .2s;
}
.fph-user-chip:hover { background: rgba(220,38,38,0.2); text-decoration: none; }
.fph-user-avatar {
  width: 30px; height: 30px; border-radius: 50%;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 13px; font-weight: 800;
}

.fph-login-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 10px 20px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff; text-decoration: none;
  border-radius: 10px;
  font-size: 13.5px; font-weight: 700;
  box-shadow: 0 4px 14px rgba(220,38,38,0.35);
  transition: all .2s;
}
.fph-login-btn:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(220,38,38,0.5); text-decoration: none; }

.fph-badge-count {
  position: absolute; top: 4px; right: 4px;
  background: #dc2626; color: #fff; font-size: 10px; font-weight: 800;
  min-width: 18px; height: 18px; padding: 0 5px; border-radius: 999px;
  display: inline-flex; align-items: center; justify-content: center;
  border: 2px solid #0a0a0a; line-height: 1;
}

/* ─── SEARCH OVERLAY (mobile) ──────────────────────────────── */
.fph-search-overlay {
  position: fixed; inset: 0; z-index: 100;
  background: rgba(0,0,0,0.9);
  opacity: 0; visibility: hidden;
  transition: opacity .25s, visibility .25s;
  padding: 20px;
}
.fph-search-overlay.open { opacity: 1; visibility: visible; }
.fph-search-panel { max-width: 640px; margin: 40px auto 0; }
.fph-search-input-wrap {
  display: flex; align-items: center; gap: 10px;
  background: #1a1a1a; border: 2px solid rgba(255,255,255,0.15);
  border-radius: 16px; padding: 8px 8px 8px 16px;
}
.fph-search-input-wrap i { color: #dc2626; font-size: 18px; }
.fph-search-input-wrap input {
  flex: 1; background: transparent !important; border: 0 !important;
  color: #fff !important; font-size: 16px !important;
  padding: 10px 0 !important; min-height: auto !important; box-shadow: none !important;
}
.fph-search-close {
  width: 38px; height: 38px; border-radius: 10px;
  background: rgba(255,255,255,0.1); color: #fff;
  display: flex; align-items: center; justify-content: center;
}
.fph-search-hint { text-align: center; margin-top: 20px; color: rgba(255,255,255,0.5); font-size: 13px; }
.fph-search-hint a { color: #dc2626; }

/* ─── ALERT BAR ─────────────────────────────────────────────── */
.fph-alert-bar { height: 32px; overflow: hidden; background: #0a0a0a; border-bottom: 1px solid rgba(255,255,255,0.08); display: flex; align-items: center; position: relative; }
.fph-alert-track { display: inline-flex; align-items: center; white-space: nowrap; animation: fph-marquee 35s linear infinite; padding-left: 100%; font-size: 13px; font-weight: 500; }
.fph-alert-item { padding: 0 16px; display: inline-flex; align-items: center; gap: 8px; }
.fph-alert-item i { color: #f59e0b; }
.fph-alert-sep { opacity: 0.4; padding: 0 4px; }
@keyframes fph-marquee { from { transform: translateX(0); } to { transform: translateX(-100%); } }

/* ─── DEAL BAR ──────────────────────────────────────────────── */
.fph-deal-bar-wrap { display: flex; flex-direction: column; }
.fph-deal-bar { display: flex; align-items: center; gap: 10px; padding: 8px 12px; font-size: 13px; font-weight: 600; }
.fph-deal-timer { display: inline-flex; align-items: center; gap: 5px; background: rgba(0,0,0,0.35); padding: 4px 8px; border-radius: 6px; font-family: monospace; font-weight: 700; white-space: nowrap; }
.fph-deal-info { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.fph-deal-discount { background: rgba(0,0,0,0.3); padding: 2px 6px; border-radius: 4px; font-weight: 800; }
.fph-deal-btn { background: rgba(255,255,255,0.2); color: inherit; text-decoration: none; padding: 5px 12px; border-radius: 6px; font-weight: 700; white-space: nowrap; font-size: 12px; }

/* ─── DRAWER ────────────────────────────────────────────────── */
.fph-drawer-overlay { position: fixed; inset: 0; z-index: 90; background: rgba(0,0,0,0.7); opacity: 0; visibility: hidden; transition: opacity .25s, visibility .25s; }
.fph-drawer-overlay.open { opacity: 1; visibility: visible; }
.fph-drawer {
  position: fixed; top: 0; left: 0; bottom: 0;
  width: 82%; max-width: 340px; z-index: 95;
  background: #0f0f0f; color: #fff;
  transform: translateX(-100%);
  transition: transform .3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex; flex-direction: column; overflow-y: auto;
  box-shadow: 8px 0 40px rgba(0,0,0,0.6);
}
.fph-drawer.open { transform: translateX(0); }
.fph-drawer-head { padding: 16px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.08); flex-shrink: 0; }
.fph-drawer-logo { display: flex; align-items: center; gap: 10px; }
.fph-drawer-logo > i { width: 38px; height: 38px; border-radius: 50%; background: #dc2626; display: flex; align-items: center; justify-content: center; }
.fph-drawer-close { width: 36px; height: 36px; border-radius: 10px; background: rgba(255,255,255,0.06); color: #fff; font-size: 16px; display: flex; align-items: center; justify-content: center; }
.fph-drawer-user { padding: 16px; display: flex; align-items: center; gap: 12px; background: rgba(220,38,38,0.1); border-bottom: 1px solid rgba(255,255,255,0.06); }
.fph-drawer-avatar { width: 44px; height: 44px; border-radius: 50%; background: #dc2626; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.fph-drawer-name { font-weight: 700; font-size: 15px; }
.fph-drawer-phone { font-size: 12px; color: rgba(255,255,255,0.6); }
.fph-drawer-nav { flex: 1; padding: 8px 0; }
.fph-drawer-nav a { display: flex; align-items: center; gap: 14px; padding: 12px 20px; color: #fff; text-decoration: none; font-size: 15px; font-weight: 500; }
.fph-drawer-nav a:hover, .fph-drawer-nav a:active { background: rgba(255,255,255,0.06); }
.fph-drawer-nav a i { width: 20px; text-align: center; color: #dc2626; flex-shrink: 0; }
.fph-drawer-sep { padding: 12px 20px 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,0.35); }
.fph-drawer-logout { color: #f87171 !important; }
.fph-drawer-logout i { color: #f87171 !important; }

/* ─── BOTTOM NAV (mobile only) ─────────────────────────────── */
.fph-bottom-nav {
  position: fixed; bottom: 0; left: 0; right: 0;
  height: calc(68px + env(safe-area-inset-bottom, 0px));
  padding-bottom: env(safe-area-inset-bottom, 0px);
  background: #000; z-index: 70;
  display: flex; align-items: center; justify-content: space-around;
  box-shadow: 0 -8px 24px rgba(0,0,0,0.5);
  border-top: 2px solid #f59e0b;
}
.fph-bn-item { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px; color: rgba(255,255,255,0.65); text-decoration: none; font-size: 10.5px; font-weight: 600; padding: 8px 4px; position: relative; }
.fph-bn-item i { font-size: 20px; }
.fph-bn-item.active { color: #fff; }
.fph-bn-item.active i { color: #dc2626; }
.fph-bn-home { flex: 0 0 72px; display: flex; flex-direction: column; align-items: center; position: relative; margin-top: -22px; text-decoration: none; }
.fph-bn-home-circle {
  width: 56px; height: 56px; border-radius: 50%; background: #dc2626;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-size: 22px;
  box-shadow: 0 6px 20px rgba(220,38,38,0.5), 0 0 0 4px #000;
  position: relative;
}
.fph-bn-home-circle::after { content: ''; position: absolute; inset: -5px; border-radius: 50%; border: 2px solid #f59e0b; animation: fph-home-pulse 2.5s ease-in-out infinite; }
.fph-bn-home span { margin-top: 2px; font-size: 10.5px; font-weight: 700; color: #fff; }
@keyframes fph-home-pulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.15); opacity: 0.4; } }

/* ─── CONTAINER ─────────────────────────────────────────────── */
.fph-container { width: 100%; max-width: 1280px; margin: 0 auto; padding-left: 16px; padding-right: 16px; }

/* ─── FLASH ─────────────────────────────────────────────────── */
.fph-flash-container {
  position: fixed; top: 80px; left: 16px; right: 16px; z-index: 100;
  display: flex; flex-direction: column; gap: 8px; pointer-events: none;
}
@media (min-width: 768px) { .fph-flash-container { left: auto; max-width: 400px; } }
.fph-flash { padding: 12px 16px; border-radius: 12px; font-size: 14px; font-weight: 600; box-shadow: 0 8px 24px rgba(0,0,0,0.4); pointer-events: auto; display: flex; align-items: center; gap: 8px; }
.fph-flash-success { background: #16a34a; color: #fff; }
.fph-flash-error { background: #dc2626; color: #fff; }
.fph-flash-warning { background: #f59e0b; color: #000; }
.fph-flash-info { background: #0ea5e9; color: #fff; }

/* ─── CATEGORIES ────────────────────────────────────────────── */
.fph-section { padding: 12px 0 16px; }
.fph-section-head {
  display: flex !important; flex-direction: column !important;
  align-items: center !important; justify-content: center !important;
  text-align: center !important; padding: 0 16px 14px !important;
  gap: 4px; position: relative;
}
.fph-section-title { font-size: 22px !important; font-weight: 900 !important; margin: 0 !important; line-height: 1.15; text-align: center !important; color: #fff !important; }
.fph-section-title span { color: #dc2626 !important; }
.fph-section-sub { font-size: 12.5px !important; color: rgba(255,255,255,.55) !important; text-align: center !important; margin-top: 2px; }
.fph-section-more { font-size: 12.5px !important; font-weight: 700 !important; color: #dc2626 !important; white-space: nowrap; position: absolute !important; right: 16px !important; top: 4px !important; }

.fph-cat-scroll { display: flex !important; gap: 16px !important; overflow-x: auto !important; overflow-y: hidden !important; padding: 8px 16px 20px !important; -webkit-overflow-scrolling: touch; scrollbar-width: none; align-items: flex-start; }
.fph-cat-scroll::-webkit-scrollbar { display: none; }
.fph-cat-item { flex: 0 0 88px !important; display: flex !important; flex-direction: column !important; align-items: center !important; text-align: center !important; text-decoration: none !important; color: inherit; gap: 8px; }
.fph-cat-img-wrap {
  position: relative !important;
  width: 76px !important; height: 76px !important;
  min-width: 76px !important; min-height: 76px !important;
  border-radius: 50% !important; padding: 3px !important;
  background: linear-gradient(135deg, #dc2626, #f59e0b) !important;
  background-size: 200% 200% !important;
  animation: fph-cat-border 4s ease-in-out infinite;
  box-shadow: 0 4px 12px rgba(0,0,0,.25);
  display: flex !important; align-items: center !important; justify-content: center !important;
  overflow: hidden !important; flex-shrink: 0;
}
.fph-cat-img-inner {
  width: 100% !important; height: 100% !important;
  border-radius: 50% !important; background: #1a1a1a !important;
  display: flex !important; align-items: center !important; justify-content: center !important;
  color: #dc2626 !important; font-size: 28px !important;
  overflow: hidden !important;
}
.fph-cat-img-inner img { width: 100% !important; height: 100% !important; object-fit: cover !important; border-radius: 50% !important; display: block !important; }
.fph-cat-name { margin-top: 0 !important; font-size: 12px !important; font-weight: 600 !important; text-align: center !important; width: 100% !important; display: block !important; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 88px; color: #fff; }
@keyframes fph-cat-border { 0%, 100% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } }

/* ─── PRODUCT GRID + CARD ───────────────────────────────────── */
.fph-product-grid {
  display: grid !important;
  grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
  gap: 12px !important; padding: 0 16px !important;
}
@media (min-width: 480px) { .fph-product-grid { grid-template-columns: repeat(3, minmax(0,1fr)) !important; } }
@media (min-width: 768px) { .fph-product-grid { grid-template-columns: repeat(4, minmax(0,1fr)) !important; gap: 16px !important; padding: 0 24px !important; } }

.fph-pcard { display: block; background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.08); border-radius: 16px; overflow: hidden; text-decoration: none; color: inherit; transition: transform .2s, border-color .2s, box-shadow .2s; height: 100%; }
.fph-pcard:hover { border-color: rgba(220,38,38,.4); box-shadow: 0 8px 28px rgba(220,38,38,.2); }
.fph-pcard-img { aspect-ratio: 1/1; background: #111; display: flex; align-items: center; justify-content: center; overflow: hidden; position: relative; }
.fph-pcard-img img { width: 100%; height: 100%; object-fit: cover; display: block; }
.fph-pcard-img .fph-ph { font-size: 38px; color: rgba(255,255,255,.15); }
.fph-pcard-badges { position: absolute; top: 8px; left: 8px; display: flex; gap: 4px; flex-wrap: wrap; z-index: 2; max-width: calc(100% - 16px); }
.fph-badge-chip { font-size: 9px; font-weight: 800; padding: 3px 7px; border-radius: 999px; letter-spacing: .3px; text-transform: uppercase; white-space: nowrap; }
.fph-pcard-body { padding: 10px 12px 12px; }
.fph-pcard-cat { font-size: 10px; font-weight: 700; color: #dc2626; text-transform: uppercase; letter-spacing: .5px; }
.fph-pcard-name { font-size: 13.5px; font-weight: 700; margin: 3px 0; line-height: 1.25; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; min-height: 34px; color: #fff; }
.fph-pcard-row { display: flex; align-items: center; justify-content: space-between; margin-top: 6px; gap: 6px; }
.fph-pcard-price { font-weight: 800; color: #dc2626; font-size: 14px; }
.fph-pcard-price-old { font-size: 11px; color: rgba(255,255,255,.4); text-decoration: line-through; margin-left: 4px; font-weight: 500; }
.fph-pcard-rating { font-size: 11px; color: #fbbf24; display: inline-flex; align-items: center; gap: 2px; }
.fph-pcard-add { display: block; width: 100%; margin-top: 8px; background: #dc2626; color: #fff; border: 0; border-radius: 10px; padding: 8px; font-weight: 700; font-size: 12.5px; cursor: pointer; text-align: center; transition: background .2s; font-family: inherit; }
.fph-pcard-add:hover { background: #b91c1c; }
.fph-pcard-add:disabled { background: rgba(255,255,255,.1); color: rgba(255,255,255,.4); cursor: not-allowed; }

/* ─── FOOTER GRID ───────────────────────────────────────────── */
.fph-footer-grid { display: grid !important; grid-template-columns: 1fr; gap: 24px; }
@media (min-width: 768px) { .fph-footer-grid { grid-template-columns: 2fr 1fr 1fr !important; } }

/* ─── DESKTOP ───────────────────────────────────────────────── */
@media (min-width: 1024px) {
  .fph-bottom-nav { display: none !important; }
  body { padding-bottom: 0 !important; }
  #fphMenuBtn { display: none !important; }
}

/* ─── SCROLLBAR ─────────────────────────────────────────────── */
::-webkit-scrollbar { width: 10px; height: 10px; }
::-webkit-scrollbar-track { background: rgba(255,255,255,0.02); }
::-webkit-scrollbar-thumb { background: rgba(220,38,38,0.4); border-radius: 999px; }
::-webkit-scrollbar-thumb:hover { background: rgba(220,38,38,0.6); }
::selection { background: rgba(220,38,38,0.4); color: #fff; }
/* ─── HERO SLIDER VIDEO SUPPORT ─────────────────────────────── */
.fph-hero-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  background: #000;
}



/* ═══════════════════════════════════════════════════════════════
   SECTION DIVIDER — Animated Glowing Line
   ═══════════════════════════════════════════════════════════════ */
.fph-divider {
  position: relative;
  height: 2px;
  margin: 32px auto;
  max-width: 500px;
  background: linear-gradient(90deg, transparent, rgba(220,38,38,0.6), rgba(245,158,11,0.8), rgba(220,38,38,0.6), transparent);
  background-size: 200% 100%;
  animation: fphDividerFlow 3s linear infinite;
  border-radius: 999px;
}
.fph-divider::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 8px;
  height: 8px;
  background: #dc2626;
  border-radius: 50%;
  box-shadow: 0 0 12px #dc2626, 0 0 24px rgba(220,38,38,0.6);
  animation: fphDividerPulse 1.5s ease-in-out infinite;
}
.fph-divider::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: 1px solid rgba(220,38,38,0.4);
  animation: fphDividerRing 2s ease-out infinite;
}
@keyframes fphDividerFlow {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
@keyframes fphDividerPulse {
  0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
  50% { transform: translate(-50%, -50%) scale(1.3); opacity: 0.8; }
}
@keyframes fphDividerRing {
  0% { transform: translate(-50%, -50%) scale(0.5); opacity: 1; }
  100% { transform: translate(-50%, -50%) scale(1.5); opacity: 0; }
}

/* Small decorative dots at sides */
.fph-divider .fph-divider-dot {
  position: absolute;
  top: 50%;
  width: 6px;
  height: 6px;
  background: #f59e0b;
  border-radius: 50%;
  transform: translateY(-50%);
  box-shadow: 0 0 8px #f59e0b;
  animation: fphDotShimmer 2s ease-in-out infinite;
}
.fph-divider .fph-divider-dot.left { left: 0; animation-delay: 0s; }
.fph-divider .fph-divider-dot.right { right: 0; animation-delay: 1s; }
@keyframes fphDotShimmer {
  0%, 100% { transform: translateY(-50%) scale(1); opacity: 0.6; }
  50% { transform: translateY(-50%) scale(1.4); opacity: 1; }
}

</style>
</head>
<body>

<!-- ═══════════════════════════════════════════════════════════
     HEADER — Adaptive (Mobile + Desktop)
     ═══════════════════════════════════════════════════════════ -->
<header class="fph-header" id="fphHeader">
  <div class="fph-header-inner">

    <!-- ═══ MOBILE HEADER ═══ -->
    <div class="fph-mobile-header">
      <button type="button" class="fph-icon-btn" id="fphMenuBtn" aria-label="Menu">
        <i class="fa-solid fa-bars"></i>
      </button>

      <a href="<?= url('index.php') ?>" class="fph-logo">
        <span class="fph-logo-icon"><i class="fa-solid fa-pizza-slice"></i></span>
        <span class="fph-logo-text">
          <span class="fph-logo-top">FRIENDS</span>
          <span class="fph-logo-bottom">PIZZA HUT</span>
        </span>
      </a>

      <div style="display:flex;align-items:center;gap:2px;">
        <button type="button" class="fph-icon-btn" id="fphSearchBtn" aria-label="Search">
          <i class="fa-solid fa-magnifying-glass"></i>
        </button>
        <a href="<?= e($chatUrl) ?>" class="fph-icon-btn" aria-label="Support">
          <i class="fa-solid fa-headset"></i>
          <?php if ($chatUnread > 0): ?><span class="fph-badge-count"><?= $chatUnread ?></span><?php endif; ?>
        </a>
        <a href="<?= url('cart.php') ?>" class="fph-icon-btn" aria-label="Cart">
          <i class="fa-solid fa-cart-shopping"></i>
          <?php if ($cartCount > 0): ?><span class="fph-badge-count"><?= $cartCount ?></span><?php endif; ?>
        </a>
        <a href="<?= url('notifications.php') ?>" class="fph-icon-btn" aria-label="Notifications">
          <i class="fa-solid fa-bell"></i>
          <?php if ($notifCount > 0): ?><span class="fph-badge-count"><?= $notifCount ?></span><?php endif; ?>
        </a>
      </div>
    </div>

    <!-- ═══ DESKTOP HEADER ═══ -->
    <div class="fph-desktop-header">
      <!-- Logo -->
      <a href="<?= url('index.php') ?>" class="fph-logo">
        <span class="fph-logo-icon"><i class="fa-solid fa-pizza-slice"></i></span>
        <span class="fph-logo-text">
          <span class="fph-logo-top">FRIENDS</span>
          <span class="fph-logo-bottom">PIZZA HUT</span>
        </span>
      </a>

      <!-- Nav Links -->
      <nav class="fph-desktop-nav">
        <a href="<?= url('index.php') ?>" class="<?= $currentFile === 'index.php' ? 'active' : '' ?>">Home</a>
        <a href="<?= url('menu.php') ?>" class="<?= $currentFile === 'menu.php' ? 'active' : '' ?>">Menu</a>
        <a href="<?= url('deals.php') ?>" class="<?= $currentFile === 'deals.php' ? 'active' : '' ?>">Deals</a>
        <a href="<?= url('offers.php') ?>" class="<?= $currentFile === 'offers.php' ? 'active' : '' ?>">Offers</a>
        <a href="<?= url('contact.php') ?>" class="<?= $currentFile === 'contact.php' ? 'active' : '' ?>">Contact</a>
      </nav>

      <!-- Search Bar -->
      <div class="fph-desktop-search">
        <form action="<?= url('search.php') ?>" method="get">
          <i class="fa-solid fa-magnifying-glass"></i>
          <input type="text" name="q" placeholder="Search for pizzas, burgers, deals..." autocomplete="off">
        </form>
      </div>

      <!-- Actions -->
      <div class="fph-desktop-actions">
        <a href="<?= url('cart.php') ?>" class="fph-icon-btn" aria-label="Cart">
          <i class="fa-solid fa-cart-shopping"></i>
          <?php if ($cartCount > 0): ?><span class="fph-badge-count"><?= $cartCount ?></span><?php endif; ?>
        </a>
        <a href="<?= url('notifications.php') ?>" class="fph-icon-btn" aria-label="Notifications">
          <i class="fa-solid fa-bell"></i>
          <?php if ($notifCount > 0): ?><span class="fph-badge-count"><?= $notifCount ?></span><?php endif; ?>
        </a>

        <?php if ($user): ?>
          <a href="<?= url('account.php') ?>" class="fph-user-chip">
            <span class="fph-user-avatar"><?= e(strtoupper(mb_substr($user['name'], 0, 1))) ?></span>
            <span><?= e(explode(' ', $user['name'])[0]) ?></span>
          </a>
        <?php else: ?>
          <a href="<?= url('login.php') ?>" class="fph-login-btn">
            <i class="fa-solid fa-right-to-bracket"></i> Login
          </a>
        <?php endif; ?>
      </div>
    </div>

  </div>
</header>

<?php if (function_exists('alert_bar_render')) echo alert_bar_render(); ?>
<?php if (function_exists('deal_bar_render')) echo deal_bar_render(); ?>

<!-- Mobile Drawer -->
<div class="fph-drawer-overlay" id="fphDrawerOverlay"></div>
<aside class="fph-drawer" id="fphDrawer">
  <div class="fph-drawer-head">
    <div class="fph-drawer-logo">
      <i class="fa-solid fa-pizza-slice"></i>
      <div>
        <div class="fph-logo-top">FRIENDS</div>
        <div class="fph-logo-bottom">PIZZA HUT</div>
      </div>
    </div>
    <button type="button" class="fph-drawer-close" id="fphDrawerClose"><i class="fa-solid fa-xmark"></i></button>
  </div>

  <?php if ($user): ?>
  <div class="fph-drawer-user">
    <div class="fph-drawer-avatar"><i class="fa-solid fa-user"></i></div>
    <div>
      <div class="fph-drawer-name"><?= e($user['name']) ?></div>
      <div class="fph-drawer-phone"><?= e($user['phone']) ?></div>
    </div>
  </div>
  <?php endif; ?>

  <nav class="fph-drawer-nav">
    <a href="<?= url('index.php') ?>"><i class="fa-solid fa-house"></i> Home</a>
    <a href="<?= url('menu.php') ?>"><i class="fa-solid fa-utensils"></i> Menu</a>
    <a href="<?= url('deals.php') ?>"><i class="fa-solid fa-tags"></i> Deals</a>
    <a href="<?= url('orders.php') ?>"><i class="fa-solid fa-receipt"></i> My Orders</a>
    <a href="<?= url('cart.php') ?>"><i class="fa-solid fa-cart-shopping"></i> Cart</a>
    <?php if ($user): ?>
      <a href="<?= url('messages.php') ?>"><i class="fa-solid fa-headset"></i> Support Chat</a>
    <?php endif; ?>
    <div class="fph-drawer-sep">Categories</div>
    <?php if (function_exists('get_categories')): foreach (get_categories(true) as $c): ?>
      <a href="<?= url('menu.php?category=' . urlencode($c['slug'])) ?>">
        <i class="fa-solid <?= e($c['icon'] ?: 'fa-utensils') ?>"></i> <?= e($c['name']) ?>
      </a>
    <?php endforeach; endif; ?>
    <div class="fph-drawer-sep">Account</div>
    <?php if ($user): ?>
      <a href="<?= url('account.php') ?>"><i class="fa-solid fa-user"></i> My Account</a>
      <a href="<?= url('notifications.php') ?>"><i class="fa-solid fa-bell"></i> Notifications</a>
      <a href="<?= url('logout.php') ?>" class="fph-drawer-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    <?php else: ?>
      <a href="<?= url('login.php') ?>"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
      <a href="<?= url('register.php') ?>"><i class="fa-solid fa-user-plus"></i> Register</a>
    <?php endif; ?>
    <div class="fph-drawer-sep">Info</div>
    <a href="<?= url('contact.php') ?>"><i class="fa-solid fa-envelope"></i> Contact</a>
    <a href="tel:<?= e(setting('restaurant_phone')) ?>"><i class="fa-solid fa-phone"></i> <?= e(setting('restaurant_phone')) ?></a>
  </nav>
</aside>

<!-- Mobile Search Overlay -->
<div class="fph-search-overlay" id="fphSearchOverlay">
  <div class="fph-search-panel">
    <form action="<?= url('search.php') ?>" method="get">
      <div class="fph-search-input-wrap">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" name="q" placeholder="Search for pizza, burger, deals..." autocomplete="off" required>
        <button type="button" class="fph-search-close" id="fphSearchClose"><i class="fa-solid fa-xmark"></i></button>
      </div>
    </form>
    <div class="fph-search-hint">Popular: <a href="<?= url('menu.php?category=pizza') ?>">Pizza</a> · <a href="<?= url('menu.php?category=burgers') ?>">Burgers</a> · <a href="<?= url('menu.php?category=deals') ?>">Deals</a></div>
  </div>
</div>

<?= function_exists('flash_render') ? flash_render() : '' ?>

<main>