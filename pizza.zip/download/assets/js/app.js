/* Friends Pizza Hut — minimal vanilla JS (UI only, no data writes) */

// Auto-dismiss flash messages
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.flash-item').forEach(el => {
    setTimeout(() => {
      el.style.transition = 'opacity .4s, transform .4s';
      el.style.opacity = '0';
      el.style.transform = 'translateX(120%)';
      setTimeout(() => el.remove(), 400);
    }, 4000);
  });

  // Confirm dialogs for data-action forms
  document.querySelectorAll('form[data-confirm]').forEach(f => {
    f.addEventListener('submit', e => {
      if (!confirm(f.dataset.confirm)) e.preventDefault();
    });
  });
});

// Close mobile sidebar when clicking outside on small screens
document.addEventListener('click', e => {
  const sb = document.getElementById('adminSidebar');
  if (!sb) return;
  if (window.innerWidth <= 768 && !sb.classList.contains('-translate-x-full')) {
    const btn = e.target.closest('button');
    if (!sb.contains(e.target) && !btn) {
      sb.classList.add('-translate-x-full');
    }
  }
});