<?php
// admin/offers/index.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Offers';
if (is_post()) {
    verify_csrf();
    if (post('action') === 'delete') {
        Database::execute("DELETE FROM offers WHERE id=?", [(int)post('id')]);
        flash_success('Deleted.');
    } elseif (post('action') === 'toggle') {
        Database::execute("UPDATE offers SET is_active = 1 - is_active WHERE id=?", [(int)post('id')]);
        flash_success('Updated.');
    }
    redirect(url('admin/offers/index.php'));
}
$rows = Database::fetchAll("SELECT * FROM offers ORDER BY sort_order, id DESC");
require __DIR__ . '/../common/header.php';
?>
<div class="flex justify-between items-center mb-5">
  <p class="text-sm text-gray-600"><?= count($rows) ?> offers</p>
  <a href="<?= url('admin/offers/create.php') ?>" class="bg-brand text-white px-4 py-2 rounded-lg text-sm font-semibold"><i class="fa-solid fa-plus mr-1"></i> Add Offer</a>
</div>
<div class="grid md:grid-cols-3 gap-4">
  <?php foreach ($rows as $o): ?>
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <div class="font-bold text-lg"><?= e($o['title']) ?></div>
    <div class="text-sm text-gray-500 mt-1"><?= e($o['description']) ?></div>
    <div class="mt-3 text-sm">
      <span class="px-2 py-1 rounded bg-brand/10 text-brand font-semibold"><?= e($o['offer_type']) ?></span>
      <span class="ml-2"><?= $o['offer_type']=='percentage' ? $o['discount_value'].'% off' : money($o['discount_value']).' off' ?></span>
    </div>
    <div class="flex gap-2 mt-4">
      <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><button class="text-xs px-2 py-1 rounded <?= $o['is_active']?'bg-green-100 text-green-800':'bg-gray-200' ?>"><?= $o['is_active']?'Active':'Inactive' ?></button></form>
      <form method="post" class="inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><button class="text-xs text-red-600">Delete</button></form>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>