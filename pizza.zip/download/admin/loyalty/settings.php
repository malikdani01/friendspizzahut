<?php
// settings.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('loyalty_points')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Loyalty Settings';
if (is_post()) {
    verify_csrf();
    $exists = Database::fetch("SELECT id FROM loyalty_settings LIMIT 1");
    $data = ['earn_rate'=>(float)post('earn_rate',1),'redeem_rate'=>(float)post('redeem_rate',100),'min_redeem'=>(int)post('min_redeem',100),'max_redeem_percent'=>(int)post('max_redeem_percent',20),'is_active'=>post('is_active')?1:0];
    if ($exists) Database::update('loyalty_settings', $data, 'id=:id', ['id'=>$exists['id']]);
    else Database::insert('loyalty_settings', $data);
    flash_success('Saved.');
    redirect(url('admin/loyalty/settings.php'));
}
$s = Database::fetch("SELECT * FROM loyalty_settings LIMIT 1") ?: ['earn_rate'=>1,'redeem_rate'=>100,'min_redeem'=>100,'max_redeem_percent'=>20,'is_active'=>1];
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3">
    <?= csrf_field() ?>
    <div><label class="text-xs text-gray-500">Earn rate (points per Rs.100)</label><input type="number" step="0.01" name="earn_rate" value="<?= e($s['earn_rate']) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Redeem rate</label><input type="number" step="0.01" name="redeem_rate" value="<?= e($s['redeem_rate']) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Min redeem</label><input type="number" name="min_redeem" value="<?= (int)$s['min_redeem'] ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Max redeem %</label><input type="number" name="max_redeem_percent" value="<?= (int)$s['max_redeem_percent'] ?>" class="w-full border rounded px-3 py-2"></div>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" <?= $s['is_active']?'checked':'' ?>> Active</label>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>