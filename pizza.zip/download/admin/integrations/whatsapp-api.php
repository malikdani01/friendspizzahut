<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('whatsapp_business_api')) {
    flash_error('WhatsApp Business API disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'WhatsApp Business API';

$testResult = null;

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        update_setting('whatsapp_business_enabled', isset($_POST['whatsapp_business_enabled']) ? '1' : '0');
        foreach (['whatsapp_phone_number_id','whatsapp_access_token','whatsapp_api_version','whatsapp_business_number'] as $k) {
            update_setting($k, (string)post($k, ''));
        }
        flash_success('Settings saved.');
        redirect(url('admin/integrations/whatsapp-api.php'));

    } elseif ($action === 'test') {
        $to = trim((string)post('test_phone', ''));
        $msg = trim((string)post('test_message', 'Test WhatsApp from Friends Pizza Hut'));
        if (!whatsapp_normalize_phone($to)) {
            $testResult = ['ok' => false, 'msg' => 'Invalid Pakistani phone. Use 03XXXXXXXXX.'];
        } else {
            $sent = send_whatsapp_message($to, $msg);
            $testResult = ['ok' => $sent, 'msg' => $sent ? 'Test message sent!' : 'Failed — check logs.'];
        }
    }
}

require __DIR__ . '/../common/header.php';
?>

<div class="max-w-3xl space-y-5">

  <?php if ($testResult): ?>
    <div class="<?= $testResult['ok'] ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800' ?> border px-4 py-3 rounded-lg">
      <?= e($testResult['msg']) ?>
    </div>
  <?php endif; ?>

  <div class="bg-white rounded-xl border p-6">
    <form method="post" class="space-y-4">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">

      <label class="flex items-center gap-2">
        <input type="checkbox" name="whatsapp_business_enabled" value="1" <?= setting('whatsapp_business_enabled') === '1' ? 'checked' : '' ?> class="w-4 h-4">
        <span>Enable WhatsApp Business API</span>
      </label>

      <div>
        <label class="block text-sm font-semibold mb-1">Business Phone Number</label>
        <input name="whatsapp_business_number" value="<?= e(setting('whatsapp_business_number', setting('restaurant_whatsapp'))) ?>" placeholder="+92 300 0000000" class="w-full border rounded px-3 py-2 font-mono text-sm">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-1">Phone Number ID</label>
        <input name="whatsapp_phone_number_id" value="<?= e(setting('whatsapp_phone_number_id','')) ?>" placeholder="1234567890123456" class="w-full border rounded px-3 py-2 font-mono text-sm">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-1">Permanent Access Token</label>
        <textarea name="whatsapp_access_token" rows="3" placeholder="EAAG..." class="w-full border rounded px-3 py-2 font-mono text-xs"><?= e(setting('whatsapp_access_token','')) ?></textarea>
      </div>

      <div>
        <label class="block text-sm font-semibold mb-1">API Version</label>
        <input name="whatsapp_api_version" value="<?= e(setting('whatsapp_api_version','v20.0')) ?>" class="w-full border rounded px-3 py-2 font-mono text-sm">
      </div>

      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">
        <i class="fa-solid fa-save mr-1"></i> Save Credentials
      </button>
    </form>
  </div>

  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-3">Send Test</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="test">
      <input name="test_phone" required placeholder="03XXXXXXXXX" class="w-full border rounded px-3 py-2">
      <input name="test_message" value="Test message from Friends Pizza Hut" class="w-full border rounded px-3 py-2">
      <button class="bg-gray-800 text-white px-6 py-2.5 rounded-lg font-semibold">Send Test</button>
    </form>
  </div>

  <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-5 text-sm text-yellow-900">
    <div class="font-bold mb-2"><i class="fa-solid fa-info-circle mr-1"></i> WhatsApp Business API Setup (Free 1000/month)</div>
    <ol class="list-decimal list-inside space-y-1">
      <li>developers.facebook.com pe jao → Create App</li>
      <li>App type: Business → Add WhatsApp product</li>
      <li>Test number milega initially — us se test karo</li>
      <li>Phone Number ID copy karo (Basic Setup section mein)</li>
      <li>System User banao → Permanent Token generate karo</li>
      <li>Meta Business verification complete karo (live ke liye)</li>
      <li>Meta approved templates banwao: order_confirmed, order_delivered</li>
    </ol>
    <div class="mt-3 text-xs"><strong>Free tier:</strong> 1000 conversation/month free. Uske baad ~Rs. 15 per conversation.</div>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>