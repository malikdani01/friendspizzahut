<?php
/**
 * Admin authentication
 */

function admin_logged_in(): bool
{
    return !empty($_SESSION['admin_id']);
}

function current_admin(): ?array
{
    if (!admin_logged_in()) return null;
    static $a = null;
    if ($a === null) {
        $a = Database::fetch("SELECT * FROM admins WHERE id = ? AND is_active = 1", [(int)$_SESSION['admin_id']]);
    }
    return $a;
}

function require_admin(): void
{
    if (!admin_logged_in()) {
        flash_error('Please login to access admin.');
        redirect(url('admin/login.php'));
    }
}

function admin_login(string $username, string $password): array
{
    if (!rate_limit_login('admin')) {
        return ['ok' => false, 'error' => 'Too many attempts. Try again later.'];
    }
    $username = trim($username);
    $admin = Database::fetch(
        "SELECT * FROM admins WHERE (username = ? OR email = ?) AND is_active = 1 LIMIT 1",
        [$username, $username]
    );
    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        record_login_attempt($username, false, 'admin');
        return ['ok' => false, 'error' => 'Invalid admin credentials.'];
    }
    session_regenerate();
    $_SESSION['admin_id']   = (int)$admin['id'];
    $_SESSION['admin_name'] = $admin['name'];
    Database::execute("UPDATE admins SET last_login = NOW() WHERE id = ?", [$admin['id']]);
    record_login_attempt($username, true, 'admin');
    audit_log('admin.login', 'admin', (int)$admin['id']);
    return ['ok' => true, 'admin' => $admin];
}

function admin_logout(): void
{
    unset($_SESSION['admin_id'], $_SESSION['admin_name']);
}