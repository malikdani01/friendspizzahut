<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'UI Manager';
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-4">
  <a href="<?= url('admin/ui/alert-bar.php') ?>" class="bg-white rounded-xl border p-5 hover:border-brand hover:shadow-lg transition">
    <i class="fa-solid fa-bullhorn text-3xl text-brand mb-3"></i>
    <div class="font-bold mb-1">Alert Bar</div>
    <div class="text-sm text-gray-500">Scrolling promo messages</div>
  </a>
  <a href="<?= url('admin/ui/deal-bar.php') ?>" class="bg-white rounded-xl border p-5 hover:border-brand hover:shadow-lg transition">
    <i class="fa-solid fa-clock text-3xl text-brand mb-3"></i>
    <div class="font-bold mb-1">Deal Bar</div>
    <div class="text-sm text-gray-500">Limited time deals with countdown</div>
  </a>
  <a href="<?= url('admin/homepage/index.php') ?>" class="bg-white rounded-xl border p-5 hover:border-brand hover:shadow-lg transition">
    <i class="fa-solid fa-house text-3xl text-brand mb-3"></i>
    <div class="font-bold mb-1">Homepage</div>
    <div class="text-sm text-gray-500">Manage homepage sections</div>
  </a>
  <a href="<?= url('admin/banners/index.php') ?>" class="bg-white rounded-xl border p-5 hover:border-brand hover:shadow-lg transition">
    <i class="fa-solid fa-image text-3xl text-brand mb-3"></i>
    <div class="font-bold mb-1">Banners</div>
    <div class="text-sm text-gray-500">Hero slider banners</div>
  </a>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>