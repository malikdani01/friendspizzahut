<?php
function send_email(string $to, string $subject, string $body): bool {
    if (!feature_enabled('email_notifications')) return false;
    try {
        Database::insert('audit_logs', [
            'user_type' => 'system', 'action' => 'email.attempt',
            'entity' => 'email', 'new_data' => json_encode(['to'=>$to, 'subject'=>$subject]),
        ]);
    } catch (Throwable $e) {}
    // Real mail() call if SMTP configured — plug in PHPMailer or similar
    return false;
}