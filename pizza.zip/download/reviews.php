<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$pageTitle = 'My Reviews';
$uid = (int)$_SESSION['user_id'];
$rows = Database::fetchAll("SELECT r.*, p.name AS product_name, p.slug FROM reviews r LEFT JOIN products p ON p.id=r.product_id WHERE r.user_id=? ORDER BY r.id DESC", [$uid]);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-6">My Reviews</h1>
  <?php if (!$rows): ?>
    <div class="text-center py-16 text-white/60 bg-white/5 rounded-2xl border border-white/10">
      <i class="fa-solid fa-star text-4xl mb-3 opacity-40"></i>
      <p>You haven't written any reviews yet.</p>
    </div>
  <?php else: ?>
    <div class="space-y-3">
      <?php foreach ($rows as $r): ?>
      <div class="bg-white/5 border border-white/10 rounded-xl p-5">
        <div class="flex justify-between items-start mb-2">
          <div>
            <div class="font-bold"><?= e($r['product_name'] ?? '') ?></div>
            <div class="text-yellow-400 text-sm"><?= str_repeat('★', (int)$r['rating']) ?><span class="text-white/20"><?= str_repeat('★', 5-(int)$r['rating']) ?></span></div>
          </div>
          <div class="text-xs px-2 py-1 rounded <?= $r['is_approved']?'bg-green-100 text-green-800':'bg-yellow-100 text-yellow-800' ?>"><?= $r['is_approved']?'Published':'Pending' ?></div>
        </div>
        <?php if ($r['comment']): ?><p class="text-sm text-white/70"><?= nl2br(e($r['comment'])) ?></p><?php endif; ?>
        <?php if ($r['admin_reply']): ?>
          <div class="mt-3 p-3 bg-brand/10 border border-brand/30 rounded text-sm">
            <div class="text-xs text-brand font-semibold mb-1">Reply from Friends Pizza Hut</div>
            <?= nl2br(e($r['admin_reply'])) ?>
          </div>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>