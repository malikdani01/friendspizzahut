<?php
/**
 * Admin notification alert — shows "New order" banner
 * Auto-removes when admin views the order
 */
if (!admin_logged_in()) return;

$pendingOrders = Database::fetchAll(
    "SELECT id, order_number FROM orders WHERE order_status = 'pending' ORDER BY id DESC LIMIT 5"
);

$pendingCount = count($pendingOrders);
?>

<?php if ($pendingCount > 0): ?>
<div id="newOrderBanner" class="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-red-600 to-red-700 text-white px-5 py-3 rounded-full shadow-2xl flex items-center gap-3 fph-new-order-banner">
  <i class="fa-solid fa-bell text-xl animate-bounce"></i>
  <span class="font-bold text-sm"><?= $pendingCount ?> new order<?= $pendingCount > 1 ? 's' : '' ?>!</span>
  <a href="<?= url('admin/orders/index.php?status=pending') ?>" class="bg-white text-red-600 px-3 py-1 rounded-full text-xs font-bold hover:bg-red-50 transition">
    View →
  </a>
</div>

<style>
.fph-new-order-banner {
  animation: bannerSlideIn .4s cubic-bezier(0.34, 1.56, 0.64, 1);
}
@keyframes bannerSlideIn {
  from { opacity: 0; transform: translate(-50%, -20px); }
  to { opacity: 1; transform: translate(-50%, 0); }
}
</style>

<?php if (feature_enabled('admin_sound_alerts')): ?>
<audio id="orderAlert" autoplay style="display:none;">
  <source src="<?= asset('audio/order-alert.mp3') ?>" type="audio/mpeg">
</audio>
<script>
(function() {
  var audio = document.getElementById('orderAlert');
  if (audio) audio.play().catch(function(e) { console.log('Autoplay blocked:', e); });
})();
</script>
<?php endif; ?>

<?php endif; ?>