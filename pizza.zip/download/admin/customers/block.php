<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/customers/index.php'));
verify_csrf();
$id = (int)post('id', 0);
$reason = trim((string)post('reason', 'Blocked by admin'));
Database::execute("UPDATE users SET is_blocked=1, blocked_reason=? WHERE id=?", [$reason, $id]);
audit_log('customer.block', 'user', $id);
flash_success('Customer blocked.');
redirect(url('admin/customers/view.php?id=' . $id));