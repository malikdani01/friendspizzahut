<?php
// history.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('inventory_tracking')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Inventory History';
$pid = (int)get('product_id', 0);
$where = $pid ? "WHERE ia.product_id=?" : "";
$params = $pid ? [$pid] : [];
$rows = Database::fetchAll("SELECT ia.*, p.name AS product_name FROM inventory_adjustments ia LEFT JOIN products p ON p.id=ia.product_id $where ORDER BY ia.id DESC LIMIT 200", $params);
require __DIR__ . '/../common/header.php';
?>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">When</th><th class="text-left px-4 py-3">Product</th><th class="text-left px-4 py-3">Type</th><th class="text-right px-4 py-3">Before</th><th class="text-right px-4 py-3">Change</th><th class="text-right px-4 py-3">After</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr class="border-t">
        <td class="px-4 py-3 text-xs"><?= date('d M Y H:i', strtotime($r['created_at'])) ?></td>
        <td class="px-4 py-3"><?= e($r['product_name'] ?? '') ?></td>
        <td class="px-4 py-3 capitalize"><?= e($r['adjustment_type']) ?></td>
        <td class="px-4 py-3 text-right"><?= (int)$r['quantity_before'] ?></td>
        <td class="px-4 py-3 text-right font-semibold <?= $r['quantity_change'] >= 0 ? 'text-green-600':'text-red-600' ?>"><?= $r['quantity_change'] >= 0 ? '+' : '' ?><?= (int)$r['quantity_change'] ?></td>
        <td class="px-4 py-3 text-right"><?= (int)$r['quantity_after'] ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="6" class="py-8 text-center text-gray-400">No history.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>