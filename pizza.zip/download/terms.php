<?php
// terms.php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Terms & Conditions';
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-16">
  <h1 class="text-4xl font-extrabold mb-6">Terms & Conditions</h1>
  <div class="space-y-4 text-white/70 text-sm leading-relaxed">
    <p>By using Friends Pizza Hut, you agree to the following terms.</p>
    <h3 class="text-white font-bold text-lg mt-6">Orders</h3>
    <p>All orders are subject to availability and confirmation. Prices are as displayed at checkout and may change without notice.</p>
    <h3 class="text-white font-bold text-lg mt-6">Delivery</h3>
    <p>Delivery times are estimates. Delays may occur due to weather, traffic, or volume. Free delivery applies to orders above Rs.1500 within serviced areas.</p>
    <h3 class="text-white font-bold text-lg mt-6">Cancellation</h3>
    <p>Orders can be cancelled within 5 minutes of placement, before they enter preparation.</p>
    <h3 class="text-white font-bold text-lg mt-6">Payment</h3>
    <p>We accept Cash on Delivery (COD) and other methods when enabled. All prices are in Pakistani Rupees.</p>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>