<?php
/**
 * Customer tiers (Bronze/Silver/Gold/Platinum)
 * Feature-gated: customer_tiers
 */

function customer_total_spent(int $userId): float {
    $row = Database::fetch(
        "SELECT COALESCE(SUM(total), 0) s FROM orders
         WHERE user_id = ? AND order_status NOT IN ('cancelled','refunded')",
        [$userId]
    );
    return (float)($row['s'] ?? 0);
}

function get_customer_tier(int $userId): ?array {
    if (!feature_enabled('customer_tiers')) return null;
    $spent = customer_total_spent($userId);
    return Database::fetch(
        "SELECT * FROM customer_tiers
         WHERE is_active = 1 AND min_spent <= ?
         ORDER BY min_spent DESC LIMIT 1",
        [$spent]
    );
}

function get_next_tier(array $currentTier): ?array {
    return Database::fetch(
        "SELECT * FROM customer_tiers
         WHERE is_active = 1 AND min_spent > ?
         ORDER BY min_spent ASC LIMIT 1",
        [(float)$currentTier['min_spent']]
    );
}

function tier_discount_percent(int $userId): float {
    if (!feature_enabled('customer_tiers')) return 0;
    $tier = get_customer_tier($userId);
    return $tier ? (float)$tier['discount_percent'] : 0;
}

function tier_free_delivery(int $userId): bool {
    if (!feature_enabled('customer_tiers')) return false;
    $tier = get_customer_tier($userId);
    return $tier && (int)$tier['free_delivery'] === 1;
}

function tier_loyalty_multiplier(int $userId): float {
    if (!feature_enabled('customer_tiers') || !feature_enabled('loyalty_points')) return 1.0;
    $tier = get_customer_tier($userId);
    return $tier ? (float)$tier['bonus_loyalty_multiplier'] : 1.0;
}