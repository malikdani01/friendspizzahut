<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('customer_tiers')) {
    flash_error('Customer tiers disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Customer Tiers';

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        $id = (int)post('id', 0);
        $data = [
            'name' => (string)post('name', ''),
            'slug' => slugify((string)post('name', '')),
            'color' => (string)post('color', '#6b7280'),
            'icon' => (string)post('icon', 'fa-medal'),
            'min_spent' => (float)post('min_spent', 0),
            'discount_percent' => (float)post('discount_percent', 0),
            'free_delivery' => post('free_delivery') ? 1 : 0,
            'bonus_loyalty_multiplier' => (float)post('bonus_loyalty_multiplier', 1),
            'sort_order' => (int)post('sort_order', 0),
            'is_active' => post('is_active') ? 1 : 0,
        ];
        if ($id) {
            Database::update('customer_tiers', $data, 'id = :id', ['id' => $id]);
            flash_success('Tier updated.');
        } else {
            Database::insert('customer_tiers', $data);
            flash_success('Tier created.');
        }
    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM customer_tiers WHERE id = ?", [(int)post('id')]);
        flash_success('Deleted.');
    }

    redirect(url('admin/tiers/index.php'));
}

$tiers = Database::fetchAll("SELECT * FROM customer_tiers ORDER BY sort_order, min_spent");
$editId = (int)get('edit', 0);
$edit = $editId ? Database::fetch("SELECT * FROM customer_tiers WHERE id = ?", [$editId]) : null;

// Tier distribution
$distribution = Database::fetchAll(
    "SELECT t.name, t.color, COUNT(u.id) c
     FROM customer_tiers t
     LEFT JOIN users u ON u.id IN (
         SELECT user_id FROM orders WHERE order_status NOT IN ('cancelled','refunded')
         GROUP BY user_id
         HAVING SUM(total) >= t.min_spent
     )
     WHERE t.is_active = 1
     GROUP BY t.id ORDER BY t.sort_order"
);

require __DIR__ . '/../common/header.php';
?>

<div class="grid md:grid-cols-3 gap-6">

  <div class="bg-white rounded-xl border p-5 h-fit">
    <h3 class="font-bold mb-3"><?= $edit ? 'Edit Tier' : 'Add Tier' ?></h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= $edit ? (int)$edit['id'] : 0 ?>">

      <input name="name" required placeholder="Name" value="<?= e($edit['name'] ?? '') ?>" class="w-full border rounded px-3 py-2">
      <input type="color" name="color" value="<?= e($edit['color'] ?? '#6b7280') ?>" class="w-full border rounded px-3 py-1 h-10">
      <input name="icon" placeholder="fa-medal" value="<?= e($edit['icon'] ?? 'fa-medal') ?>" class="w-full border rounded px-3 py-2 text-sm">
      <input type="number" step="0.01" name="min_spent" placeholder="Min total spent" value="<?= e($edit['min_spent'] ?? 0) ?>" class="w-full border rounded px-3 py-2">
      <input type="number" step="0.01" name="discount_percent" placeholder="Discount %" value="<?= e($edit['discount_percent'] ?? 0) ?>" class="w-full border rounded px-3 py-2">
      <input type="number" step="0.01" name="bonus_loyalty_multiplier" placeholder="Loyalty multiplier" value="<?= e($edit['bonus_loyalty_multiplier'] ?? 1) ?>" class="w-full border rounded px-3 py-2">
      <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="free_delivery" value="1" <?= !empty($edit['free_delivery']) ? 'checked' : '' ?>> Free delivery</label>
      <input type="number" name="sort_order" value="<?= e($edit['sort_order'] ?? 0) ?>" class="w-full border rounded px-3 py-2">
      <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" <?= !$edit || !empty($edit['is_active']) ? 'checked' : '' ?>> Active</label>

      <button class="w-full bg-brand text-white py-2 rounded font-semibold">
        <?= $edit ? 'Save' : 'Create' ?>
      </button>
      <?php if ($edit): ?>
        <a href="<?= url('admin/tiers/index.php') ?>" class="block text-center text-sm text-gray-500 hover:text-brand">Cancel</a>
      <?php endif; ?>
    </form>
  </div>

  <div class="md:col-span-2 space-y-4">

    <div class="bg-white rounded-xl border p-5">
      <h3 class="font-bold mb-3">Tier Distribution</h3>
      <?php foreach ($distribution as $d): ?>
      <div class="flex items-center justify-between py-2">
        <span class="flex items-center gap-2">
          <span class="w-3 h-3 rounded-full" style="background: <?= e($d['color']) ?>"></span>
          <?= e($d['name']) ?>
        </span>
        <span class="font-bold"><?= (int)$d['c'] ?> customers</span>
      </div>
      <?php endforeach; ?>
      <?php if (!$distribution): ?><div class="text-sm text-gray-400">No data.</div><?php endif; ?>
    </div>

    <div class="bg-white rounded-xl border overflow-hidden">
      <table class="w-full text-sm">
        <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
          <tr>
            <th class="text-left px-4 py-3">Tier</th>
            <th class="text-right px-4 py-3">Min Spend</th>
            <th class="text-right px-4 py-3">Discount</th>
            <th class="text-right px-4 py-3">Loyalty</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($tiers as $t): ?>
          <tr class="border-t hover:bg-gray-50">
            <td class="px-4 py-3">
              <span class="inline-flex items-center gap-2">
                <i class="fa-solid <?= e($t['icon']) ?>" style="color: <?= e($t['color']) ?>"></i>
                <span class="font-semibold"><?= e($t['name']) ?></span>
              </span>
            </td>
            <td class="px-4 py-3 text-right"><?= money($t['min_spent']) ?></td>
            <td class="px-4 py-3 text-right"><?= (float)$t['discount_percent'] ?>%<?= $t['free_delivery'] ? ' + Free Del' : '' ?></td>
            <td class="px-4 py-3 text-right">×<?= (float)$t['bonus_loyalty_multiplier'] ?></td>
            <td class="px-4 py-3 text-right whitespace-nowrap">
              <a href="?edit=<?= (int)$t['id'] ?>" class="text-blue-600 text-xs mr-2">Edit</a>
              <form method="post" class="inline" data-confirm="Delete?">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                <button class="text-red-600 text-xs">Delete</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>