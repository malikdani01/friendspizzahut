<?php
require_once __DIR__ . '/../common/bootstrap.php';

$orderNumber = (string) get('order', '');
$order = $orderNumber ? get_order_by_number($orderNumber) : null;

if ($order) {
    $payment = Database::fetch("SELECT id FROM payments WHERE order_id = ? ORDER BY id DESC LIMIT 1", [(int)$order['id']]);
    if ($payment) mark_payment_failed((int)$payment['id'], 'Customer cancelled on Easypaisa page');
    easypaisa_log('cancelled', ['order' => $orderNumber]);
}

flash_warning('Payment cancel ho gaya. Phir se try kar sakte hain.');
redirect($order ? url('order-detail.php?id=' . (int)$order['id']) : url('checkout.php'));