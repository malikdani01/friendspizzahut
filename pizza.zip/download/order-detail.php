<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$id = (int)get('id', 0);
$order = get_order($id);
if (!$order || (int)$order['user_id'] !== (int)$_SESSION['user_id']) {
    flash_error('Order not found.'); redirect(url('orders.php'));
}
$pageTitle = 'Order ' . $order['order_number'];
$items = get_order_items($id);
$history = get_order_status_history($id);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-4xl mx-auto px-4 py-10">
  <a href="<?= url('orders.php') ?>" class="text-sm text-white/60 hover:text-brand mb-4 inline-block">← My Orders</a>
  <div class="bg-white/5 border border-white/10 rounded-2xl p-6 mb-6">
    <div class="flex justify-between items-start flex-wrap gap-3 mb-4">
      <div>
        <div class="text-xs text-white/50">Order Number</div>
        <div class="font-mono font-bold text-lg"><?= e($order['order_number']) ?></div>
        <div class="text-xs text-white/50 mt-1"><?= date('d M Y, H:i', strtotime($order['created_at'])) ?></div>
      </div>
      <?= status_badge($order['order_status']) ?>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm pt-4 border-t border-white/10">
      <div><div class="text-white/50 text-xs">Type</div><div class="font-semibold uppercase"><?= e($order['order_type']) ?></div></div>
      <div><div class="text-white/50 text-xs">Payment</div><div class="font-semibold uppercase"><?= e($order['payment_method']) ?></div></div>
      <div><div class="text-white/50 text-xs">Payment Status</div><div class="font-semibold capitalize"><?= e($order['payment_status']) ?></div></div>
      <div><div class="text-white/50 text-xs">Total</div><div class="font-bold text-brand"><?= money($order['total']) ?></div></div>
    </div>
  </div>

  <div class="bg-white/5 border border-white/10 rounded-2xl p-6 mb-6">
    <h3 class="font-bold mb-4">Items</h3>
    <?php foreach ($items as $it): ?>
      <div class="border-b border-white/5 py-3 last:border-0">
        <div class="flex justify-between">
          <div>
            <div class="font-semibold"><?= e($it['product_name']) ?></div>
            <div class="text-xs text-white/50">Qty: <?= (int)$it['quantity'] ?> × <?= money($it['unit_price']) ?></div>
            <?php foreach ($it['options'] as $op): ?>
              <div class="text-xs text-white/60">↳ <?= e($op['variation_option_name']) ?></div>
            <?php endforeach; ?>
            <?php foreach ($it['addons'] as $ad): ?>
              <div class="text-xs text-white/60">+ <?= e($ad['addon_name']) ?> (<?= money($ad['addon_price']) ?>)</div>
            <?php endforeach; ?>
          </div>
          <div class="font-bold"><?= money($it['line_total']) ?></div>
        </div>
      </div>
    <?php endforeach; ?>
    <div class="pt-4 space-y-1 text-sm">
      <div class="flex justify-between"><span class="text-white/60">Subtotal</span><span><?= money($order['subtotal']) ?></span></div>
      <?php if ((float)$order['discount_total'] > 0): ?><div class="flex justify-between text-green-400"><span>Discount</span><span>-<?= money($order['discount_total']) ?></span></div><?php endif; ?>
      <div class="flex justify-between"><span class="text-white/60">Delivery</span><span><?= money($order['delivery_fee']) ?></span></div>
      <?php if ((float)$order['tax_amount'] > 0): ?><div class="flex justify-between"><span class="text-white/60">Tax</span><span><?= money($order['tax_amount']) ?></span></div><?php endif; ?>
      <div class="flex justify-between font-bold text-lg border-t border-white/10 pt-2 mt-2"><span>Total</span><span class="text-brand"><?= money($order['total']) ?></span></div>
    </div>
  </div>

  <div class="bg-white/5 border border-white/10 rounded-2xl p-6">
    <h3 class="font-bold mb-4">Status Timeline</h3>
    <ol class="relative border-l-2 border-white/10 ml-3 space-y-4">
      <?php foreach ($history as $h): ?>
      <li class="ml-4">
        <div class="absolute -left-[7px] w-3 h-3 rounded-full bg-brand"></div>
        <div class="font-semibold"><?= order_status_label($h['new_status']) ?></div>
        <div class="text-xs text-white/50"><?= date('d M Y, H:i', strtotime($h['created_at'])) ?></div>
      </li>
      <?php endforeach; ?>
    </ol>
  </div>

  <?php if (can_customer_cancel_order($order)): ?>
    <form method="post" action="<?= url('actions/checkout/cancel-order.php') ?>" class="mt-6" data-confirm="Cancel this order?">
      <?= csrf_field() ?>
      <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
      <button class="bg-red-600 hover:bg-red-700 px-6 py-3 rounded-lg font-bold">Cancel Order</button>
    </form>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>