<?php
/**
 * Database backup / restore engine
 * Feature-gated: backup_restore
 */

function backup_dir(): string {
    $dir = ROOT_PATH . '/backups';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}

function backup_list(): array {
    $dir = backup_dir();
    $files = [];
    if (is_dir($dir)) {
        foreach (glob($dir . '/*.sql') as $f) {
            $files[] = [
                'name' => basename($f),
                'size' => filesize($f),
                'size_human' => backup_human_size(filesize($f)),
                'date' => date('Y-m-d H:i:s', filemtime($f)),
                'path' => $f,
            ];
        }
    }
    usort($files, fn($a, $b) => strcmp($b['date'], $a['date']));
    return $files;
}

function backup_human_size(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

/**
 * Create a database backup using pure PHP PDO (no mysqldump required).
 * Works on shared hosting without shell access.
 */
function backup_create(): array {
    try {
        $pdo = Database::pdo();

        // Get all tables
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        if (!$tables) {
            return ['ok' => false, 'error' => 'No tables found.'];
        }

        $filename = 'backup-' . date('Y-m-d-His') . '.sql';
        $path = backup_dir() . '/' . $filename;
        $fh = fopen($path, 'w');
        if (!$fh) {
            return ['ok' => false, 'error' => 'Could not create backup file.'];
        }

        // Header
        fwrite($fh, "-- Friends Pizza Hut — Database Backup\n");
        fwrite($fh, "-- Generated: " . date('Y-m-d H:i:s') . "\n");
        fwrite($fh, "-- Database: " . DB_NAME . "\n\n");
        fwrite($fh, "SET NAMES utf8mb4;\n");
        fwrite($fh, "SET FOREIGN_KEY_CHECKS = 0;\n\n");

        foreach ($tables as $table) {
            // Table structure
            $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch();
            fwrite($fh, "-- Table structure: `$table`\n");
            fwrite($fh, "DROP TABLE IF EXISTS `$table`;\n");
            fwrite($fh, $create['Create Table'] . ";\n\n");

            // Data
            fwrite($fh, "-- Data for: `$table`\n");
            $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
            if ($rows) {
                $columns = array_keys($rows[0]);
                $colList = '`' . implode('`, `', $columns) . '`';

                // Chunk inserts to avoid huge lines
                $chunks = array_chunk($rows, 100);
                foreach ($chunks as $chunk) {
                    $values = [];
                    foreach ($chunk as $row) {
                        $vals = [];
                        foreach ($row as $v) {
                            if ($v === null) {
                                $vals[] = 'NULL';
                            } else {
                                $vals[] = $pdo->quote((string)$v);
                            }
                        }
                        $values[] = '(' . implode(', ', $vals) . ')';
                    }
                    fwrite($fh, "INSERT INTO `$table` ($colList) VALUES\n" . implode(",\n", $values) . ";\n");
                }
            }
            fwrite($fh, "\n");
        }

        fwrite($fh, "SET FOREIGN_KEY_CHECKS = 1;\n");
        fclose($fh);

        // Audit
        try {
            audit_log('backup.create', 'system', null, null, [
                'file' => $filename, 'size' => filesize($path),
            ]);
        } catch (Throwable $e) {}

        return ['ok' => true, 'file' => $filename, 'size' => filesize($path)];

    } catch (Throwable $e) {
        error_log('Backup error: ' . $e->getMessage());
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Restore database from uploaded .sql file
 */
function backup_restore(string $sqlPath): array {
    try {
        if (!file_exists($sqlPath)) {
            return ['ok' => false, 'error' => 'File not found.'];
        }

        $sql = file_get_contents($sqlPath);
        if ($sql === false) {
            return ['ok' => false, 'error' => 'Could not read file.'];
        }

        // Safety: automatic backup before restore
        $preBackup = backup_create();
        if (!$preBackup['ok']) {
            return ['ok' => false, 'error' => 'Could not create safety backup before restore. ' . ($preBackup['error'] ?? '')];
        }

        $pdo = Database::pdo();
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

        // Split by semicolon at end of line
        $statements = backup_split_sql($sql);
        $executed = 0;
        foreach ($statements as $stmt) {
            $stmt = trim($stmt);
            if ($stmt === '' || str_starts_with($stmt, '--')) continue;
            try {
                $pdo->exec($stmt);
                $executed++;
            } catch (Throwable $e) {
                error_log('Restore statement failed: ' . $e->getMessage());
                // Continue on non-critical errors
            }
        }

        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

        try {
            audit_log('backup.restore', 'system', null, null, [
                'statements' => $executed,
                'safety_backup' => $preBackup['file'] ?? null,
            ]);
        } catch (Throwable $e) {}

        return ['ok' => true, 'statements' => $executed, 'safety' => $preBackup['file'] ?? null];

    } catch (Throwable $e) {
        error_log('Restore error: ' . $e->getMessage());
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Split SQL into statements (handles semicolons inside strings)
 */
function backup_split_sql(string $sql): array {
    $statements = [];
    $current = '';
    $inString = false;
    $stringChar = '';
    $len = strlen($sql);
    for ($i = 0; $i < $len; $i++) {
        $c = $sql[$i];
        $current .= $c;

        if ($inString) {
            if ($c === '\\') { $i++; if ($i < $len) $current .= $sql[$i]; continue; }
            if ($c === $stringChar) { $inString = false; }
        } else {
            if ($c === '"' || $c === "'") { $inString = true; $stringChar = $c; }
            elseif ($c === ';') {
                $statements[] = rtrim($current);
                $current = '';
            }
        }
    }
    if (trim($current)) $statements[] = $current;
    return $statements;
}

function backup_delete(string $filename): bool {
    $safe = basename($filename);
    $path = backup_dir() . '/' . $safe;
    if (file_exists($path) && str_starts_with($path, backup_dir())) {
        return @unlink($path);
    }
    return false;
}