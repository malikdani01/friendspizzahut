<?php
/**
 * JazzCash Payment — Cancel Handler
 * Customer "Cancel" click kare ya timeout ho to yahan aayega.
 * URL: https://yoursite.com/payment/jazzcash-cancel.php?order=FPH-XXXX
 */
require_once __DIR__ . '/../common/bootstrap.php';

// Accept from GET (redirect) or POST (gateway callback)
$data = $_POST ?: $_GET;

// Log cancellation
jazzcash_log('cancel_received', [
    'data' => array_map(fn($v) => is_string($v) ? mb_substr($v, 0, 200) : $v, $data),
]);

// Get order number
$orderNumber = (string) (
    $data['pp_BillReference']
    ?? $data['order']
    ?? $data['order_number']
    ?? ''
);

if (!$orderNumber) {
    flash_warning('Payment cancel ho gaya.');
    redirect(url('checkout.php'));
}

$order = get_order_by_number($orderNumber);
if (!$order) {
    flash_warning('Payment cancel ho gaya, lekin order nahi mila.');
    redirect(url('checkout.php'));
}

// ─── Idempotency: agar already paid ho chuka hai to cancel mat karo ─
if ($order['payment_status'] === 'paid') {
    jazzcash_log('cancel_but_already_paid', ['order' => $orderNumber]);
    flash_info('Payment already received. Order confirmed hai.');
    redirect(url('order-success.php?order=' . urlencode($orderNumber)));
}

// ─── Mark pending payment as failed ────────────────────────────
try {
    $payment = Database::fetch(
        "SELECT * FROM payments WHERE order_id = ? AND payment_status = 'pending' ORDER BY id DESC LIMIT 1",
        [(int)$order['id']]
    );

    if ($payment) {
        mark_payment_failed(
            (int)$payment['id'],
            'Cancelled by customer on JazzCash page'
        );

        // Log transaction
        Database::insert('payment_transactions', [
            'payment_id'   => (int)$payment['id'],
            'gateway'      => 'jazzcash',
            'reference'    => null,
            'amount'       => (float)$order['total'],
            'status'       => 'cancelled',
            'raw_response' => json_encode($data),
        ]);
    }

    jazzcash_log('cancel_success', [
        'order' => $orderNumber,
        'payment_id' => $payment['id'] ?? null,
    ]);

} catch (Throwable $e) {
    error_log('JazzCash cancel handler error: ' . $e->getMessage());
}

// ─── User-friendly message ─────────────────────────────────────
flash_warning('Payment cancel ho gaya. Aap phir se try kar sakte hain ya COD use kar sakte hain.');

// ─── Smart redirect ────────────────────────────────────────────
// Agar order pending hai, order detail pe bhejo taake customer retry kar sake
if ($order['order_status'] === 'pending') {
    redirect(url('order-detail.php?id=' . (int)$order['id']));
}

// Agar order already confirmed ho gaya (unusual), track page pe bhejo
redirect(url('track-order.php?order=' . urlencode($orderNumber)));