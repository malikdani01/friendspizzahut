<?php
function referral_get_code(int $userId): string {
    $r = Database::fetch("SELECT code FROM referral_codes WHERE user_id=?", [$userId]);
    if ($r) return $r['code'];
    $code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    Database::insert('referral_codes', ['user_id' => $userId, 'code' => $code]);
    return $code;
}
function referral_stats(int $userId): array {
    $total = (int)(Database::fetch("SELECT COUNT(*) c FROM referrals WHERE referrer_user_id=?", [$userId])['c'] ?? 0);
    $rewarded = (int)(Database::fetch("SELECT COUNT(*) c FROM referrals WHERE referrer_user_id=? AND status='rewarded'", [$userId])['c'] ?? 0);
    return ['total' => $total, 'rewarded' => $rewarded];
}