<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$gid = (int)get('group_id', 0);
$group = Database::fetch("SELECT * FROM variation_groups WHERE id=?", [$gid]);
if (!$group) { flash_error('Group not found.'); redirect(url('admin/variations/groups.php')); }
$pageTitle = 'Options: ' . $group['display_name'];

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'create') {
        Database::insert('variation_options', [
            'group_id' => $gid,
            'name' => (string)post('name',''),
            'price_delta' => (float)post('price_delta',0),
            'absolute_price' => post('absolute_price') !== '' ? (float)post('absolute_price') : null,
            'sort_order' => (int)post('sort_order',0),
            'is_default' => post('is_default') ? 1 : 0,
        ]);
        flash_success('Option added.');
    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM variation_options WHERE id=?", [(int)post('id')]);
        flash_success('Deleted.');
    }
    redirect(url('admin/variations/options.php?group_id=' . $gid));
}

$options = Database::fetchAll("SELECT * FROM variation_options WHERE group_id=? ORDER BY sort_order", [$gid]);
require __DIR__ . '/../common/header.php';
?>
<a href="<?= url('admin/variations/groups.php') ?>" class="text-sm text-gray-500 hover:text-brand mb-4 inline-block">← Groups</a>
<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl shadow-sm border p-5 h-fit">
    <h3 class="font-bold mb-3">Add Option</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?><input type="hidden" name="action" value="create">
      <input name="name" placeholder="Option name" required class="w-full border rounded px-3 py-2">
      <input type="number" step="0.01" name="price_delta" placeholder="Price delta" value="0" class="w-full border rounded px-3 py-2">
      <input type="number" step="0.01" name="absolute_price" placeholder="Absolute price (optional)" class="w-full border rounded px-3 py-2">
      <input type="number" name="sort_order" value="0" class="w-full border rounded px-3 py-2">
      <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_default" value="1"> Default</label>
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Add</button>
    </form>
  </div>
  <div class="md:col-span-2 bg-white rounded-xl shadow-sm border overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">Name</th><th class="text-right px-4 py-3">Delta</th><th class="text-right px-4 py-3">Absolute</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($options as $o): ?>
        <tr class="border-t">
          <td class="px-4 py-3 font-semibold"><?= e($o['name']) ?><?= $o['is_default']?' <span class="text-xs text-brand">(default)</span>':'' ?></td>
          <td class="px-4 py-3 text-right"><?= money($o['price_delta']) ?></td>
          <td class="px-4 py-3 text-right"><?= $o['absolute_price'] ? money($o['absolute_price']) : '—' ?></td>
          <td class="px-4 py-3 text-right"><form method="post" class="inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><button class="text-red-600 text-xs">Delete</button></form></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>