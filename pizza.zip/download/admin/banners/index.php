<?php
// admin/banners/index.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Banners';
if (is_post()) {
    verify_csrf();
    if (post('action') === 'delete') {
        $b = Database::fetch("SELECT image FROM banners WHERE id=?", [(int)post('id')]);
        if ($b && $b['image'] && file_exists(UPLOAD_PATH.'/'.$b['image'])) @unlink(UPLOAD_PATH.'/'.$b['image']);
        Database::execute("DELETE FROM banners WHERE id=?", [(int)post('id')]);
        flash_success('Banner deleted.');
    } elseif (post('action') === 'toggle') {
        Database::execute("UPDATE banners SET is_active = 1 - is_active WHERE id=?", [(int)post('id')]);
        flash_success('Updated.');
    }
    redirect(url('admin/banners/index.php'));
}
$rows = Database::fetchAll("SELECT * FROM banners ORDER BY sort_order");
require __DIR__ . '/../common/header.php';
?>
<div class="flex justify-between items-center mb-5">
  <p class="text-sm text-gray-600"><?= count($rows) ?> banners</p>
  <a href="<?= url('admin/banners/create.php') ?>" class="bg-brand text-white px-4 py-2 rounded-lg text-sm font-semibold"><i class="fa-solid fa-plus mr-1"></i> Add Banner</a>
</div>
<div class="grid md:grid-cols-3 gap-4">
  <?php foreach ($rows as $b): ?>
  <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
    <img src="<?= upload_url($b['image']) ?>" class="w-full h-40 object-cover">
    <div class="p-4">
      <div class="font-semibold"><?= e($b['title']) ?></div>
      <div class="text-xs text-gray-500 mb-3"><?= e($b['subtitle']) ?> • <?= e($b['position']) ?></div>
      <div class="flex gap-2">
        <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><button class="text-xs px-2 py-1 rounded <?= $b['is_active']?'bg-green-100 text-green-800':'bg-gray-200' ?>"><?= $b['is_active']?'Active':'Inactive' ?></button></form>
        <form method="post" class="inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><button class="text-xs text-red-600">Delete</button></form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>