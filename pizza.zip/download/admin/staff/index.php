<?php
// admin/staff/index.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('staff_roles')) { flash_error('Staff module is disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'Staff';

if (is_post()) {
    verify_csrf();
    if (post('action') === 'delete') {
        Database::execute("DELETE FROM staff WHERE id=?", [(int)post('id')]);
        flash_success('Staff removed.');
    } elseif (post('action') === 'toggle') {
        Database::execute("UPDATE staff SET is_active = 1 - is_active WHERE id=?", [(int)post('id')]);
        flash_success('Updated.');
    }
    redirect(url('admin/staff/index.php'));
}

$rows = Database::fetchAll("SELECT s.*, r.name AS role_name FROM staff s LEFT JOIN roles r ON r.id=s.role_id ORDER BY s.id DESC");
require __DIR__ . '/../common/header.php';
?>
<div class="flex justify-between items-center mb-5">
  <p class="text-sm text-gray-600"><?= count($rows) ?> staff members</p>
  <a href="<?= url('admin/staff/create.php') ?>" class="bg-brand text-white px-4 py-2 rounded-lg text-sm font-semibold"><i class="fa-solid fa-plus mr-1"></i> Add Staff</a>
</div>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr><th class="text-left px-4 py-3">Name</th><th class="text-left px-4 py-3">Username</th><th class="text-left px-4 py-3">Role</th><th class="text-left px-4 py-3">Status</th><th></th></tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $s): ?>
      <tr class="border-t hover:bg-gray-50">
        <td class="px-4 py-3 font-semibold"><?= e($s['name']) ?><div class="text-xs text-gray-500"><?= e($s['email']) ?></div></td>
        <td class="px-4 py-3"><?= e($s['username']) ?></td>
        <td class="px-4 py-3"><?= e($s['role_name'] ?? '—') ?></td>
        <td class="px-4 py-3">
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="text-xs px-2 py-1 rounded <?= $s['is_active']?'bg-green-100 text-green-800':'bg-gray-200' ?>"><?= $s['is_active']?'Active':'Inactive' ?></button></form>
        </td>
        <td class="px-4 py-3 text-right">
          <form method="post" class="inline" data-confirm="Remove?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="text-red-600 text-xs">Delete</button></form>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="5" class="py-8 text-center text-gray-400">No staff yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>