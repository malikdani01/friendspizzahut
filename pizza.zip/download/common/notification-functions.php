<?php
function notify(int $userId, string $type, string $title, string $message, ?string $link = null, string $userType = 'customer'): void {
    Database::insert('notifications', [
        'user_type' => $userType, 'user_id' => $userId,
        'type' => $type, 'title' => $title, 'message' => $message, 'link' => $link,
    ]);
}
function get_user_notifications(int $userId, int $limit = 20): array {
    return Database::fetchAll("SELECT * FROM notifications WHERE user_type='customer' AND user_id=? ORDER BY id DESC LIMIT " . (int)$limit, [$userId]);
}
function get_admin_notifications(int $limit = 20): array {
    return Database::fetchAll("SELECT * FROM notifications WHERE user_type='admin' ORDER BY id DESC LIMIT " . (int)$limit);
}
function unread_notification_count(string $userType, int $userId): int {
    $r = Database::fetch("SELECT COUNT(*) c FROM notifications WHERE user_type=? AND user_id=? AND is_read=0", [$userType, $userId]);
    return (int)($r['c'] ?? 0);
}