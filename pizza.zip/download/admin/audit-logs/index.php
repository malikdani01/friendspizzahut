<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Audit Logs';
$page = max(1, (int)get('page',1)); $per = 50; $offset = ($page-1)*$per;
$total = (int)(Database::fetch("SELECT COUNT(*) c FROM audit_logs")['c'] ?? 0);
$pages = max(1, (int)ceil($total/$per));
$rows = Database::fetchAll("SELECT * FROM audit_logs ORDER BY id DESC LIMIT $per OFFSET $offset");
require __DIR__ . '/../common/header.php';
?>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr><th class="text-left px-4 py-3">When</th><th class="text-left px-4 py-3">User</th><th class="text-left px-4 py-3">Action</th><th class="text-left px-4 py-3">Entity</th><th class="text-left px-4 py-3">IP</th></tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr class="border-t hover:bg-gray-50">
        <td class="px-4 py-2 text-xs"><?= date('d M Y, H:i:s', strtotime($r['created_at'])) ?></td>
        <td class="px-4 py-2 text-xs"><?= e($r['user_type'] ?? '—') ?> #<?= (int)$r['user_id'] ?></td>
        <td class="px-4 py-2 font-mono text-xs"><?= e($r['action']) ?></td>
        <td class="px-4 py-2 text-xs"><?= e($r['entity'] ?? '') ?> <?= $r['entity_id'] ? '#'.$r['entity_id'] : '' ?></td>
        <td class="px-4 py-2 text-xs text-gray-500"><?= e($r['ip_address']) ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="5" class="py-8 text-center text-gray-400">No logs yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php if ($pages > 1): ?>
<div class="flex justify-center gap-2 mt-5">
  <?php for ($i=1; $i<=$pages; $i++): ?>
    <a href="?page=<?= $i ?>" class="px-3 py-1.5 rounded text-sm <?= $i===$page?'bg-brand text-white':'bg-white border' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../common/footer.php'; ?>