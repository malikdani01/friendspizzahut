<?php
function get_categories(bool $activeOnly = false): array {
    $sql = "SELECT * FROM categories";
    if ($activeOnly) $sql .= " WHERE is_active = 1";
    $sql .= " ORDER BY sort_order, name";
    return Database::fetchAll($sql);
}

function get_category(int $id): ?array {
    return Database::fetch("SELECT * FROM categories WHERE id = ?", [$id]);
}

function get_category_by_slug(string $slug): ?array {
    return Database::fetch("SELECT * FROM categories WHERE slug = ?", [$slug]);
}

function get_category_product_count(int $categoryId): int {
    $r = Database::fetch("SELECT COUNT(*) c FROM products WHERE category_id = ? AND status='active'", [$categoryId]);
    return (int)($r['c'] ?? 0);
}

function generate_category_slug(string $name, int $excludeId = 0): string {
    $base = slugify($name);
    $slug = $base;
    $i = 2;
    while (Database::fetch("SELECT id FROM categories WHERE slug = ? AND id != ?", [$slug, $excludeId])) {
        $slug = $base . '-' . $i++;
    }
    return $slug;
}