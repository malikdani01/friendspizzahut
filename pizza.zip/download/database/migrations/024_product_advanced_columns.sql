-- ═══════════════════════════════════════════════════════════════
-- FRIENDS PIZZA HUT — Migration 024
-- Advanced Product Columns (Sizes, Button, Add-ons)
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ═══ ADDONS: Size support ═══
ALTER TABLE `addons` ADD COLUMN `has_sizes` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `addons` ADD COLUMN `price_s` DECIMAL(12,2) NULL;
ALTER TABLE `addons` ADD COLUMN `price_m` DECIMAL(12,2) NULL;
ALTER TABLE `addons` ADD COLUMN `price_l` DECIMAL(12,2) NULL;
ALTER TABLE `addons` ADD COLUMN `size_labels` VARCHAR(60) NOT NULL DEFAULT 'S,M,L';

-- ═══ PRODUCTS: Sizes + Button + Extra columns ═══
ALTER TABLE `products` ADD COLUMN `has_sizes` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `products` ADD COLUMN `price_s` DECIMAL(12,2) NULL;
ALTER TABLE `products` ADD COLUMN `price_m` DECIMAL(12,2) NULL;
ALTER TABLE `products` ADD COLUMN `price_l` DECIMAL(12,2) NULL;
ALTER TABLE `products` ADD COLUMN `size_labels` VARCHAR(60) NOT NULL DEFAULT 'Small,Medium,Large';
ALTER TABLE `products` ADD COLUMN `button_mode` VARCHAR(30) NOT NULL DEFAULT 'add_to_cart';
ALTER TABLE `products` ADD COLUMN `order_button_text` VARCHAR(60) NULL DEFAULT 'Add to Cart';
ALTER TABLE `products` ADD COLUMN `order_button_enabled` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `products` ADD COLUMN `button_bg_color` VARCHAR(20) NULL;
ALTER TABLE `products` ADD COLUMN `button_text_color` VARCHAR(20) NULL;
ALTER TABLE `products` ADD COLUMN `prep_time_minutes` INT NULL DEFAULT 15;
ALTER TABLE `products` ADD COLUMN `prep_time_min` INT NULL;
ALTER TABLE `products` ADD COLUMN `prep_time_max` INT NULL;
ALTER TABLE `products` ADD COLUMN `spice_level` VARCHAR(20) NULL;
ALTER TABLE `products` ADD COLUMN `dietary_info` VARCHAR(190) NULL;
ALTER TABLE `products` ADD COLUMN `allergens` VARCHAR(500) NULL;
ALTER TABLE `products` ADD COLUMN `serving_info` VARCHAR(120) NULL;
ALTER TABLE `products` ADD COLUMN `calories` INT NULL;
ALTER TABLE `products` ADD COLUMN `is_recommended` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `products` ADD COLUMN `is_limited_deal` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `products` ADD COLUMN `is_coming_soon` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `products` ADD COLUMN `meta_title` VARCHAR(190) NULL;
ALTER TABLE `products` ADD COLUMN `meta_description` VARCHAR(500) NULL;

-- ═══ CART ITEM ADDONS: Size support ═══
ALTER TABLE `cart_item_addons` ADD COLUMN `addon_size` VARCHAR(10) NULL;
ALTER TABLE `cart_item_addons` ADD COLUMN `addon_price_s` DECIMAL(12,2) NULL;
ALTER TABLE `cart_item_addons` ADD COLUMN `addon_price_m` DECIMAL(12,2) NULL;
ALTER TABLE `cart_item_addons` ADD COLUMN `addon_price_l` DECIMAL(12,2) NULL;

-- ═══ ORDER ITEM ADDONS: Size support ═══
ALTER TABLE `order_item_addons` ADD COLUMN `addon_size` VARCHAR(10) NULL;

-- ═══ ORDERS: Transaction + ETA ═══
ALTER TABLE `orders` ADD COLUMN `transaction_id` VARCHAR(120) NULL;
ALTER TABLE `orders` ADD COLUMN `estimated_minutes` INT NULL;
ALTER TABLE `orders` ADD COLUMN `eta_started_at` DATETIME NULL;
ALTER TABLE `orders` ADD COLUMN `eta_set_by` INT UNSIGNED NULL;

-- ═══ DELIVERY AREAS: Free delivery ═══
ALTER TABLE `delivery_areas` ADD COLUMN `free_delivery_enabled` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `delivery_areas` ADD COLUMN `free_delivery_above` DECIMAL(12,2) NULL;

-- ═══ SMS / EMAIL SETTINGS ═══
INSERT INTO `settings` (setting_key, setting_value, setting_group) VALUES
('sms_provider', 'sms_provider', 'sms_provider', 'notifications'),
('sms_api_key', 'sms_api_key', 'sms_api_key', 'notifications'),
('sms_api_secret', 'sms_api_secret', 'sms_api_secret', 'notifications'),
('sms_sender_id', 'sms_sender_id', 'sms_sender_id', 'notifications')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);