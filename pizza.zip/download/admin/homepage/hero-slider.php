<?php
// hero-slider.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
redirect(url('admin/banners/index.php'));