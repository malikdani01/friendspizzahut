// Close mobile admin sidebar on outside click
document.addEventListener('click', e => {
  const sb = document.getElementById('adminSidebar');
  if (!sb) return;
  if (window.innerWidth <= 768 && !sb.classList.contains('-translate-x-full')
      && !sb.contains(e.target) && !e.target.closest('button')) {
    sb.classList.add('-translate-x-full');
  }
});