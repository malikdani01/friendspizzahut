<?php
/**
 * Customer Reservation — Create Action
 * Ye file reservations.php ke form se call hoti hai.
 * Uses: reservation_create() from common/reservation-functions.php
 */
require_once __DIR__ . '/../../common/bootstrap.php';

if (!feature_enabled('table_reservation')) {
    flash_error('Table reservations are not available.');
    redirect(url('index.php'));
}
require_customer();

if (!is_post()) {
    redirect(url('reservations.php'));
}
verify_csrf();

$result = reservation_create([
    'user_id'          => (int)$_SESSION['user_id'],
    'customer_name'    => (string)post('customer_name', ''),
    'customer_phone'   => (string)post('customer_phone', ''),
    'customer_email'   => (string)post('customer_email', ''),
    'party_size'       => (int)post('party_size', 2),
    'reservation_date' => (string)post('reservation_date', ''),
    'reservation_time' => (string)post('reservation_time', ''),
    'special_requests' => (string)post('special_requests', ''),
]);

if (!$result['ok']) {
    flash_error($result['error']);
    redirect(url('reservations.php'));
}

flash_success('Reservation confirm! Code: ' . $result['code'] . '. Hum 30 minute mein confirmation bhejenge.');
redirect(url('reservations.php'));