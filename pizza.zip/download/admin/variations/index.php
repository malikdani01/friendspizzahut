<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Variations';
$errors = [];

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'create_group') {
        $name = trim((string)post('name',''));
        $display = trim((string)post('display_name',''));
        if ($name && $display) {
            Database::insert('variation_groups', [
                'name' => $name, 'display_name' => $display,
                'type' => post('type','single'),
                'is_required' => post('is_required') ? 1 : 0,
                'min_selections' => (int)post('min_selections',1),
                'max_selections' => (int)post('max_selections',1),
                'sort_order' => (int)post('sort_order',0),
            ]);
            flash_success('Variation group created.');
        }
    } elseif ($action === 'create_option') {
        $gid = (int)post('group_id', 0);
        $name = trim((string)post('name',''));
        if ($gid && $name) {
            Database::insert('variation_options', [
                'group_id' => $gid, 'name' => $name,
                'price_delta' => (float)post('price_delta',0),
                'absolute_price' => post('absolute_price') !== '' ? (float)post('absolute_price') : null,
                'sort_order' => (int)post('sort_order',0),
            ]);
            flash_success('Option added.');
        }
    } elseif ($action === 'delete_option') {
        Database::execute("DELETE FROM variation_options WHERE id = ?", [(int)post('id')]);
        flash_success('Option deleted.');
    } elseif ($action === 'delete_group') {
        $gid = (int)post('id');
        Database::execute("DELETE FROM variation_options WHERE group_id = ?", [$gid]);
        Database::execute("DELETE FROM product_variation_groups WHERE group_id = ?", [$gid]);
        Database::execute("DELETE FROM variation_groups WHERE id = ?", [$gid]);
        flash_success('Group deleted.');
    }
    redirect(url('admin/variations/index.php'));
}

$groups = Database::fetchAll("SELECT * FROM variation_groups ORDER BY sort_order, id");
foreach ($groups as &$g) {
    $g['options'] = Database::fetchAll("SELECT * FROM variation_options WHERE group_id = ? ORDER BY sort_order", [$g['id']]);
}
require __DIR__ . '/../common/header.php';
?>
<div class="grid lg:grid-cols-2 gap-6">
  <div>
    <div class="bg-white rounded-xl shadow-sm border p-5 mb-5">
      <h3 class="font-bold mb-3">Add Variation Group</h3>
      <form method="post" class="space-y-3">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create_group">
        <input name="name" placeholder="Internal name (e.g. pizza_size)" required class="w-full border rounded px-3 py-2">
        <input name="display_name" placeholder="Display name (e.g. Size)" required class="w-full border rounded px-3 py-2">
        <div class="grid grid-cols-2 gap-2">
          <select name="type" class="border rounded px-3 py-2">
            <option value="single">Single select</option>
            <option value="multiple">Multi select</option>
          </select>
          <input type="number" name="sort_order" placeholder="Sort order" value="0" class="border rounded px-3 py-2">
        </div>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_required" value="1" checked> Required</label>
        <button class="bg-brand text-white px-4 py-2 rounded font-semibold w-full">Create Group</button>
      </form>
    </div>
  </div>

  <div class="space-y-4">
    <?php foreach ($groups as $g): ?>
    <div class="bg-white rounded-xl shadow-sm border p-5">
      <div class="flex justify-between items-center mb-3">
        <div>
          <div class="font-bold"><?= e($g['display_name']) ?></div>
          <div class="text-xs text-gray-500"><?= e($g['name']) ?> • <?= e($g['type']) ?></div>
        </div>
        <form method="post" onsubmit="return confirm('Delete group and its options?')">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete_group">
          <input type="hidden" name="id" value="<?= (int)$g['id'] ?>">
          <button class="text-red-600 text-xs hover:underline">Delete Group</button>
        </form>
      </div>
      <table class="w-full text-sm mb-3">
        <thead class="text-xs text-gray-500 uppercase"><tr><th class="text-left">Option</th><th class="text-right">Price</th><th></th></tr></thead>
        <tbody>
          <?php foreach ($g['options'] as $o): ?>
          <tr class="border-t">
            <td class="py-1.5"><?= e($o['name']) ?></td>
            <td class="text-right">
              <?php if (!empty($o['absolute_price'])) echo money($o['absolute_price']);
                    elseif ((float)$o['price_delta'] !== 0.0) echo ($o['price_delta']>0?'+':'') . money($o['price_delta']);
                    else echo '—'; ?>
            </td>
            <td class="text-right">
              <form method="post" class="inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete_option">
                <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
                <button class="text-red-500 text-xs hover:underline">✕</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <form method="post" class="grid grid-cols-4 gap-2 border-t pt-3">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create_option">
        <input type="hidden" name="group_id" value="<?= (int)$g['id'] ?>">
        <input name="name" placeholder="Option name" required class="col-span-2 border rounded px-2 py-1.5 text-sm">
        <input name="absolute_price" type="number" step="0.01" placeholder="Price" class="border rounded px-2 py-1.5 text-sm">
        <button class="bg-gray-800 text-white rounded text-sm">Add</button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>