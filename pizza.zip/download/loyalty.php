<?php
// loyalty.php
require_once __DIR__ . '/common/bootstrap.php';
if (!feature_enabled('loyalty_points')) { flash_error('Loyalty is not available.'); redirect(url('account.php')); }
require_customer();
$pageTitle = 'Loyalty Points';
$uid = (int)$_SESSION['user_id'];
$balance = loyalty_points_balance($uid);
$history = loyalty_history($uid);
$rewards = Database::fetchAll("SELECT * FROM loyalty_rewards WHERE is_active=1 ORDER BY points_required");
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-6">Loyalty Points</h1>
  <div class="bg-gradient-to-br from-brand to-red-900 rounded-2xl p-8 text-center mb-8">
    <div class="text-5xl font-extrabold"><?= number_format($balance) ?></div>
    <div class="text-white/80 text-sm mt-2">Available Points</div>
  </div>
  <h3 class="font-bold mb-3">History</h3>
  <div class="bg-white/5 border border-white/10 rounded-xl divide-y divide-white/5">
    <?php foreach ($history as $h): ?>
    <div class="px-4 py-3 flex justify-between text-sm">
      <div>
        <div><?= e($h['description']) ?></div>
        <div class="text-xs text-white/50"><?= date('d M Y, H:i', strtotime($h['created_at'])) ?></div>
      </div>
      <div class="<?= $h['type']=='earn' ? 'text-green-400':'text-red-400' ?> font-bold"><?= $h['type']=='earn'?'+':'-' ?><?= (int)$h['points'] ?></div>
    </div>
    <?php endforeach; ?>
    <?php if (!$history): ?><div class="px-4 py-8 text-center text-white/50">No points yet.</div><?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>