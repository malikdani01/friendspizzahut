-- Standalone features seed (same as in seed.sql)
-- Run this file only if you re-seed features without full reinstall.
DELETE FROM features WHERE feature_key LIKE '%';
-- (See seed.sql for full feature list.)