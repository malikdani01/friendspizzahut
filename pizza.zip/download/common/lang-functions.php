<?php
/**
 * Multi-language support (English + Urdu)
 */

function current_lang(): string {
    if (!feature_enabled('multi_language')) return 'en';
    if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ur'], true)) {
        $_SESSION['lang'] = $_GET['lang'];
    }
    return $_SESSION['lang'] ?? 'en';
}

function t(string $key, ?string $default = null): string {
    static $strings = null;
    if ($strings === null) {
        $lang = current_lang();
        $file = ROOT_PATH . '/lang/' . $lang . '.php';
        $strings = file_exists($file) ? (require $file) : [];
    }
    return $strings[$key] ?? $default ?? $key;
}

function is_urdu(): bool {
    return current_lang() === 'ur';
}

function lang_switcher_html(): string {
    if (!feature_enabled('multi_language')) return '';
    $cur = current_lang();
    $other = $cur === 'en' ? 'ur' : 'en';
    $label = $other === 'ur' ? 'اردو' : 'English';
    return '<a href="?' . http_build_query(array_merge($_GET, ['lang' => $other])) . '" class="text-xs px-3 py-1 rounded-full bg-white/10 hover:bg-brand">' . $label . '</a>';
}