<?php
require_once __DIR__ . '/../common/bootstrap.php';

if (!easypaisa_is_enabled()) {
    flash_error('Easypaisa payment is not available.');
    redirect(url('checkout.php'));
}

$orderNumber = (string) get('order', '');
$order = $orderNumber ? get_order_by_number($orderNumber) : null;

if (!$order) {
    flash_error('Order not found.');
    redirect(url('checkout.php'));
}

if ($order['payment_status'] === 'paid') {
    flash_info('Ye order already paid hai.');
    redirect(url('order-success.php?order=' . urlencode($orderNumber)));
}

$form = easypaisa_build_form($order);

easypaisa_log('initiate', [
    'order_number' => $orderNumber,
    'total'        => $order['total'],
    'mode'         => easypaisa_is_sandbox() ? 'sandbox' : 'live',
]);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Redirecting to Easypaisa...</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black text-white min-h-screen flex items-center justify-center p-6">
<div class="text-center max-w-md">
  <div class="w-20 h-20 mx-auto rounded-full bg-green-500/20 flex items-center justify-center mb-6">
    <i class="fa-solid fa-mobile-screen text-4xl text-green-500 animate-pulse"></i>
  </div>
  <h1 class="text-2xl font-bold mb-2">Easypaisa Payment</h1>
  <p class="text-white/60 mb-6">Aapko Easypaisa ke secure page pe le ja raha hun...</p>
  <div class="bg-white/5 border border-white/10 rounded-xl p-4 text-sm mb-6">
    <div class="flex justify-between mb-1"><span class="text-white/60">Order</span><span class="font-mono"><?= e($order['order_number']) ?></span></div>
    <div class="flex justify-between font-bold text-lg"><span>Total</span><span class="text-green-500"><?= money($order['total']) ?></span></div>
  </div>

  <form id="easypaisaForm" method="post" action="<?= e($form['action']) ?>">
    <?php foreach ($form['fields'] as $k => $v): ?>
      <input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>">
    <?php endforeach; ?>
    <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg font-bold">
      <i class="fa-solid fa-arrow-right mr-2"></i> Continue to Easypaisa
    </button>
  </form>

  <p class="text-xs text-white/40 mt-6">Auto-redirect in 3 seconds...</p>
</div>

<script>
setTimeout(function() { document.getElementById('easypaisaForm').submit(); }, 3000);
</script>
</body>
</html>