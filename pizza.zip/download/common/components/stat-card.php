<?php /** @var string $label @var string $value @var string $icon @var string $color */
$color = $color ?? 'text-brand'; $icon = $icon ?? 'fa-chart-line'; ?>
<div class="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
  <div class="flex items-center justify-between mb-2">
    <span class="text-xs text-gray-500 uppercase tracking-wide"><?= e($label) ?></span>
    <i class="fa-solid <?= e($icon) ?> <?= e($color) ?>"></i>
  </div>
  <div class="text-2xl font-extrabold"><?= $value ?></div>
</div>