<?php
require_once __DIR__ . '/../common/bootstrap.php';
$n = Database::execute("UPDATE orders SET order_status='confirmed' WHERE is_scheduled=1 AND scheduled_at <= NOW() AND order_status='pending'");
echo "[" . date('c') . "] Scheduled orders activated: $n\n";