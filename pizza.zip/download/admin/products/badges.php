<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('product_badges')) {
    flash_error('Product badges disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Product Badges';
$productId = (int)get('product_id', 0);
$product = $productId ? get_product($productId) : null;
$allBadges = get_all_badges(false);

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'assign' && $product) {
        $ids = array_map('intval', (array)post('badge_ids', []));
        set_product_badges($productId, $ids);
        flash_success('Badges updated.');
    } elseif ($action === 'create_badge') {
        $name = trim((string)post('name', ''));
        if ($name) {
            Database::insert('product_badges', [
                'name' => strtoupper($name),
                'bg_color' => (string)post('bg_color', '#dc2626'),
                'text_color' => (string)post('text_color', '#ffffff'),
                'icon' => trim((string)post('icon', '')) ?: null,
                'sort_order' => (int)post('sort_order', 0),
                'is_active' => 1,
            ]);
            flash_success('Badge created.');
        }
    } elseif ($action === 'delete_badge') {
        Database::execute("DELETE FROM product_badge_map WHERE badge_id = ?", [(int)post('id')]);
        Database::execute("DELETE FROM product_badges WHERE id = ?", [(int)post('id')]);
        flash_success('Badge deleted.');
    }

    redirect(url('admin/products/badges.php' . ($productId ? '?product_id=' . $productId : '')));
}

$assigned = $product ? array_column(get_product_badges($productId), 'id') : [];
require __DIR__ . '/../common/header.php';
?>

<div class="grid md:grid-cols-3 gap-6">

  <div class="bg-white rounded-xl border p-5 h-fit">
    <h3 class="font-bold mb-3">Create Badge</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create_badge">
      <input name="name" required placeholder="Badge name" class="w-full border rounded px-3 py-2">
      <div class="grid grid-cols-2 gap-2">
        <div>
          <label class="text-xs text-gray-500">Background</label>
          <input type="color" name="bg_color" value="#dc2626" class="w-full border rounded px-3 py-1 h-10">
        </div>
        <div>
          <label class="text-xs text-gray-500">Text</label>
          <input type="color" name="text_color" value="#ffffff" class="w-full border rounded px-3 py-1 h-10">
        </div>
      </div>
      <input name="icon" placeholder="FontAwesome (fa-fire)" class="w-full border rounded px-3 py-2">
      <input type="number" name="sort_order" value="0" class="w-full border rounded px-3 py-2">
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Create</button>
    </form>
  </div>

  <div class="md:col-span-2 space-y-5">

    <?php if ($product): ?>
    <div class="bg-white rounded-xl border p-5">
      <h3 class="font-bold mb-3">Assign to: <span class="text-brand"><?= e($product['name']) ?></span></h3>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="assign">
        <div class="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
          <?php foreach ($allBadges as $b): ?>
            <label class="flex items-center gap-2 text-sm border rounded px-3 py-2 cursor-pointer hover:border-brand">
              <input type="checkbox" name="badge_ids[]" value="<?= (int)$b['id'] ?>" <?= in_array($b['id'], $assigned) ? 'checked' : '' ?>>
              <span style="background:<?= e($b['bg_color']) ?>;color:<?= e($b['text_color']) ?>;font-size:10px;font-weight:800;padding:2px 6px;border-radius:999px;"><?= e($b['name']) ?></span>
            </label>
          <?php endforeach; ?>
        </div>
        <button class="bg-brand text-white px-6 py-2 rounded font-semibold">Save</button>
      </form>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl border overflow-hidden">
      <table class="w-full text-sm">
        <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
          <tr><th class="text-left px-4 py-3">Badge</th><th class="text-left px-4 py-3">Color</th><th></th></tr>
        </thead>
        <tbody>
          <?php foreach ($allBadges as $b): ?>
          <tr class="border-t">
            <td class="px-4 py-3">
              <span style="background:<?= e($b['bg_color']) ?>;color:<?= e($b['text_color']) ?>;font-size:10px;font-weight:800;padding:3px 8px;border-radius:999px;"><?= e($b['name']) ?></span>
            </td>
            <td class="px-4 py-3 text-xs font-mono"><?= e($b['bg_color']) ?></td>
            <td class="px-4 py-3 text-right">
              <form method="post" class="inline" data-confirm="Delete?">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete_badge">
                <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                <button class="text-red-600 text-xs">Delete</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="text-sm">
      <a href="<?= url('admin/products/index.php') ?>" class="text-brand hover:underline">← Back to products</a>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>