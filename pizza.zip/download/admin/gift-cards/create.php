<?php
// create.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('gift_cards')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Issue Gift Card';
if (is_post()) {
    verify_csrf();
    $amount = (float)post('amount', 0);
    $code = strtoupper(trim((string)post('code',''))) ?: strtoupper(substr(bin2hex(random_bytes(6)),0,12));
    if ($amount > 0) {
        Database::insert('gift_cards', ['code'=>$code,'initial_balance'=>$amount,'current_balance'=>$amount,'recipient_name'=>trim((string)post('recipient_name',''))?:null,'recipient_email'=>trim((string)post('recipient_email',''))?:null,'is_active'=>1]);
        flash_success("Gift card created: $code");
        redirect(url('admin/gift-cards/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <input name="code" placeholder="Code (auto if blank)" class="w-full border rounded px-3 py-2 font-mono">
    <input type="number" step="0.01" name="amount" required placeholder="Amount" class="w-full border rounded px-3 py-2">
    <input name="recipient_name" placeholder="Recipient name" class="w-full border rounded px-3 py-2">
    <input name="recipient_email" placeholder="Recipient email" class="w-full border rounded px-3 py-2">
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Issue</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>