<?php
// payments.php (settings)
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
redirect(url('admin/integrations/payments.php'));