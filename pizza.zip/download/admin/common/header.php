<?php
/**
 * Admin header — with guaranteed dark theme + fallbacks
 * Works even if Tailwind CDN is slow/blocked
 */
$pageTitle = $pageTitle ?? 'Admin';
$admin = current_admin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> — Admin | <?= e(setting('restaurant_name', 'Friends Pizza Hut')) ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<script src="https://cdn.tailwindcss.com"></script>

<style>
/* ═══════════════════════════════════════════════════════════════
   ADMIN PANEL — GUARANTEED DARK THEME (works with/without Tailwind)
   ═══════════════════════════════════════════════════════════════ */

:root {
  --admin-bg: #0a0a0a;
  --admin-surface: #171717;
  --admin-surface-2: #1f1f1f;
  --admin-border: rgba(255,255,255,0.08);
  --admin-text: #f9fafb;
  --admin-muted: rgba(249,250,251,0.65);
  --admin-dim: rgba(249,250,251,0.4);
  --admin-brand: #dc2626;
  --admin-gold: #f59e0b;
  --admin-success: #16a34a;
}

*, *::before, *::after { box-sizing: border-box; }

html, body {
  margin: 0;
  padding: 0;
  background: var(--admin-bg);
  color: var(--admin-text);
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
  font-size: 14px;
  line-height: 1.55;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  overflow-x: hidden;
}

/* ─── SHELL LAYOUT (CSS Grid — reliable) ─────────────────────── */
.admin-shell {
  display: grid;
  grid-template-columns: 260px 1fr;
  min-height: 100vh;
  background: var(--admin-bg);
}
@media (max-width: 1023px) {
  .admin-shell { grid-template-columns: 1fr; }
}

/* ─── MAIN AREA ──────────────────────────────────────────────── */
.admin-main-area {
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 100vh;
  background: var(--admin-bg);
}

/* ─── TOPBAR ─────────────────────────────────────────────────── */
.admin-topbar {
  position: sticky;
  top: 0;
  z-index: 30;
  background: rgba(10,10,10,0.95);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--admin-border);
  padding: 14px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 64px;
}
.admin-topbar h1 {
  margin: 0;
  font-size: 18px;
  font-weight: 800;
  color: #fff;
  letter-spacing: -0.01em;
  flex: 1;
  text-align: center;
}
@media (min-width: 768px) {
  .admin-topbar h1 { text-align: left; }
}
.admin-topbar-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}
.admin-topbar-link {
  display: none;
  color: var(--admin-muted);
  text-decoration: none;
  font-size: 13px;
  font-weight: 600;
  transition: color .15s;
}
.admin-topbar-link:hover { color: var(--admin-brand); }
@media (min-width: 768px) {
  .admin-topbar-link { display: inline-flex; align-items: center; gap: 6px; }
}
.admin-user-chip {
  display: flex;
  align-items: center;
  gap: 10px;
  padding-left: 12px;
  border-left: 1px solid var(--admin-border);
}
.admin-avatar {
  width: 36px; height: 36px; border-radius: 50%;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-weight: 800; font-size: 14px;
  box-shadow: 0 4px 12px rgba(220,38,38,0.35);
  flex-shrink: 0;
}
.admin-user-name { font-size: 13px; font-weight: 700; color: #fff; line-height: 1.2; }
.admin-user-role { font-size: 11px; color: var(--admin-muted); line-height: 1.2; }
@media (max-width: 767px) {
  .admin-user-name, .admin-user-role { display: none; }
  .admin-user-chip { padding-left: 8px; border-left: 0; }
}
.admin-toggle {
  display: none;
  background: transparent;
  border: 0;
  color: #fff;
  font-size: 22px;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 8px;
  transition: background .15s;
}
.admin-toggle:hover { background: rgba(255,255,255,0.08); }
@media (max-width: 1023px) {
  .admin-toggle { display: inline-flex; align-items: center; justify-content: center; }
}

/* ─── CONTENT AREA ───────────────────────────────────────────── */
.admin-content {
  flex: 1;
  padding: 20px;
  background: var(--admin-bg);
  color: var(--admin-text);
  min-width: 0;
}
@media (min-width: 768px) {
  .admin-content { padding: 24px; }
}

/* ─── FORM FALLBACKS (if Tailwind's preflight is slow) ───────── */
.admin-content input:not([type="checkbox"]):not([type="radio"]):not([type="color"]):not([type="submit"]):not([type="button"]):not([type="file"]),
.admin-content select,
.admin-content textarea {
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  color: #fff;
  border-radius: 10px;
  padding: 10px 13px;
  font-size: 14px;
  font-family: inherit;
  outline: none;
  width: 100%;
  transition: border-color .15s, box-shadow .15s;
  -webkit-appearance: none;
  appearance: none;
}
.admin-content input:focus,
.admin-content select:focus,
.admin-content textarea:focus {
  border-color: var(--admin-brand);
  box-shadow: 0 0 0 3px rgba(220,38,38,0.18);
}
.admin-content input::placeholder,
.admin-content textarea::placeholder {
  color: rgba(255,255,255,0.35);
}
.admin-content select option { background: #171717; color: #fff; }
.admin-content label {
  display: block;
  margin-bottom: 6px;
  color: rgba(255,255,255,0.8);
  font-size: 13px;
  font-weight: 600;
}
.admin-content input[type="checkbox"],
.admin-content input[type="radio"] {
  accent-color: var(--admin-brand);
  width: 16px !important;
  height: 16px !important;
  cursor: pointer;
  margin-right: 6px;
}
.admin-content input[type="color"] {
  padding: 3px !important;
  height: 42px !important;
  cursor: pointer;
}
.admin-content input[type="file"] {
  background: rgba(0,0,0,0.4) !important;
  border: 1.5px solid rgba(255,255,255,0.1) !important;
  color: #fff !important;
  border-radius: 10px !important;
  padding: 10px !important;
}

/* ─── TABLE FALLBACKS ────────────────────────────────────────── */
.admin-content table {
  width: 100%;
  border-collapse: collapse;
  color: var(--admin-text);
}
.admin-content thead {
  background: rgba(255,255,255,0.03);
}
.admin-content th {
  padding: 12px 16px;
  text-align: left;
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: rgba(255,255,255,0.6);
  border-bottom: 1px solid var(--admin-border);
}
.admin-content td {
  padding: 14px 16px;
  border-top: 1px solid rgba(255,255,255,0.05);
  font-size: 13.5px;
  color: var(--admin-text);
}
.admin-content tbody tr:hover {
  background: rgba(255,255,255,0.03);
}

/* ─── HARD OVERRIDE: WHITE BACKGROUNDS → DARK ────────────────── */
.admin-content [class*="bg-white"],
.admin-content [class*="bg-gray-50"],
.admin-content [class*="bg-gray-100"] {
  background: var(--admin-surface) !important;
  color: var(--admin-text) !important;
  border-color: var(--admin-border) !important;
}

/* ─── HARD OVERRIDE: TEXT COLORS ─────────────────────────────── */
.admin-content [class*="text-gray-900"],
.admin-content [class*="text-gray-800"],
.admin-content [class*="text-gray-700"],
.admin-content [class*="text-black"] {
  color: var(--admin-text) !important;
}
.admin-content [class*="text-gray-600"],
.admin-content [class*="text-gray-500"] {
  color: var(--admin-muted) !important;
}
.admin-content [class*="text-gray-400"] {
  color: var(--admin-dim) !important;
}

/* ─── STATUS BADGES (opacity versions) ───────────────────────── */
.admin-content [class*="bg-green-100"] {
  background: rgba(34,197,94,0.18) !important;
  color: #4ade80 !important;
  border: 1px solid rgba(34,197,94,0.3) !important;
}
.admin-content [class*="bg-red-100"] {
  background: rgba(220,38,38,0.18) !important;
  color: #fca5a5 !important;
  border: 1px solid rgba(220,38,38,0.3) !important;
}
.admin-content [class*="bg-yellow-100"] {
  background: rgba(234,179,8,0.18) !important;
  color: #fcd34d !important;
  border: 1px solid rgba(234,179,8,0.3) !important;
}
.admin-content [class*="bg-blue-100"] {
  background: rgba(59,130,246,0.18) !important;
  color: #93c5fd !important;
  border: 1px solid rgba(59,130,246,0.3) !important;
}
.admin-content [class*="bg-gray-200"] {
  background: rgba(255,255,255,0.08) !important;
  color: rgba(255,255,255,0.75) !important;
  border: 1px solid rgba(255,255,255,0.1) !important;
}

/* ─── BUTTONS ────────────────────────────────────────────────── */
.admin-content button.bg-brand,
.admin-content a.bg-brand {
  background: linear-gradient(135deg, #dc2626, #b91c1c) !important;
  color: #fff !important;
  font-weight: 700;
  border-radius: 10px;
  border: 0;
  box-shadow: 0 4px 14px rgba(220,38,38,0.3);
  transition: all .15s;
}
.admin-content button.bg-brand:hover,
.admin-content a.bg-brand:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 20px rgba(220,38,38,0.45);
}
.admin-content button.bg-gray-800,
.admin-content button.bg-gray-900,
.admin-content a.bg-gray-800 {
  background: rgba(255,255,255,0.08) !important;
  color: #fff !important;
  border: 1px solid rgba(255,255,255,0.1) !important;
  font-weight: 700;
  border-radius: 10px;
}
.admin-content button.bg-gray-800:hover,
.admin-content a.bg-gray-800:hover {
  background: rgba(255,255,255,0.15) !important;
}

/* ─── LINKS ──────────────────────────────────────────────────── */
.admin-content a.text-brand,
.admin-content a[class*="text-brand"] { color: var(--admin-brand) !important; text-decoration: none; }
.admin-content a[class*="text-blue-600"] { color: #60a5fa !important; }
.admin-content a[class*="text-red-600"] { color: #f87171 !important; }
.admin-content a[class*="text-green-600"] { color: #4ade80 !important; }

/* ─── GRID FALLBACKS (in case Tailwind is slow) ──────────────── */
.admin-content .grid { display: grid; }
.admin-content .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.admin-content .grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.admin-content .grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
.admin-content .gap-2 { gap: 8px; }
.admin-content .gap-3 { gap: 12px; }
.admin-content .gap-4 { gap: 16px; }
.admin-content .gap-6 { gap: 24px; }
.admin-content .flex { display: flex; }
.admin-content .flex-wrap { flex-wrap: wrap; }
.admin-content .items-center { align-items: center; }
.admin-content .justify-between { justify-content: space-between; }
.admin-content .mb-3 { margin-bottom: 12px; }
.admin-content .mb-4 { margin-bottom: 16px; }
.admin-content .mb-5 { margin-bottom: 20px; }
.admin-content .mb-6 { margin-bottom: 24px; }
.admin-content .mt-3 { margin-top: 12px; }
.admin-content .mt-4 { margin-top: 16px; }
.admin-content .p-4 { padding: 16px; }
.admin-content .p-5 { padding: 20px; }
.admin-content .p-6 { padding: 24px; }
.admin-content .rounded-xl { border-radius: 14px; }
.admin-content .rounded-lg { border-radius: 10px; }
.admin-content .rounded-2xl { border-radius: 16px; }
.admin-content .shadow-sm { box-shadow: 0 4px 20px rgba(0,0,0,0.4); }
.admin-content .border { border: 1px solid var(--admin-border); }

@media (max-width: 767px) {
  .admin-content .md\:grid-cols-4,
  .admin-content .md\:grid-cols-3,
  .admin-content .md\:grid-cols-2 { grid-template-columns: 1fr; }
  .admin-content .lg\:grid-cols-3 { grid-template-columns: 1fr; }
  .admin-content .lg\:col-span-2 { grid-column: auto; }
}

/* ─── SCROLLBAR ──────────────────────────────────────────────── */
::-webkit-scrollbar { width: 10px; height: 10px; }
::-webkit-scrollbar-track { background: rgba(255,255,255,0.02); }
::-webkit-scrollbar-thumb { background: rgba(220,38,38,0.4); border-radius: 999px; }
::-webkit-scrollbar-thumb:hover { background: rgba(220,38,38,0.6); }

/* ─── SELECTION ──────────────────────────────────────────────── */
::selection { background: rgba(220,38,38,0.4); color: #fff; }

/* ─── ANIMATIONS ─────────────────────────────────────────────── */
@keyframes adminFadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
.admin-content > * {
  animation: adminFadeIn .4s cubic-bezier(0.4, 0, 0.2, 1) both;
}
.admin-content > *:nth-child(2) { animation-delay: .04s; }
.admin-content > *:nth-child(3) { animation-delay: .08s; }
.admin-content > *:nth-child(4) { animation-delay: .12s; }
.admin-content > *:nth-child(5) { animation-delay: .16s; }

/* ─── MOBILE OVERLAY ─────────────────────────────────────────── */
.admin-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.7);
  backdrop-filter: blur(4px);
  z-index: 90;
  opacity: 0;
  visibility: hidden;
  transition: opacity .25s, visibility .25s;
}
.admin-overlay.open {
  opacity: 1;
  visibility: visible;
}

/* ─── FLASH ──────────────────────────────────────────────────── */
.flash-container, .fph-flash-container {
  position: fixed;
  top: 80px;
  right: 16px;
  left: 16px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 8px;
  pointer-events: none;
}
@media (min-width: 768px) {
  .flash-container, .fph-flash-container { left: auto; max-width: 380px; }
}
.flash-item, .fph-flash {
  pointer-events: auto;
  padding: 14px 18px;
  border-radius: 12px;
  font-size: 13.5px;
  font-weight: 600;
  color: #fff;
  box-shadow: 0 12px 32px rgba(0,0,0,0.6);
  display: flex;
  align-items: center;
  gap: 10px;
  animation: adminFadeIn .3s ease-out;
}
</style>
</head>
<body>

<div class="admin-shell">

  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="admin-overlay" id="adminOverlay" onclick="document.getElementById('adminSidebar').classList.remove('open'); this.classList.remove('open');"></div>

  <div class="admin-main-area">

    <header class="admin-topbar">
      <button type="button" class="admin-toggle" onclick="document.getElementById('adminSidebar').classList.add('open'); document.getElementById('adminOverlay').classList.add('open');">
        <i class="fa-solid fa-bars"></i>
      </button>

      <h1><?= e($pageTitle) ?></h1>

      <div class="admin-topbar-actions">
        <a href="<?= url('index.php') ?>" target="_blank" class="admin-topbar-link">
          <i class="fa-solid fa-external-link"></i> View Site
        </a>
        <div class="admin-user-chip">
          <div class="admin-avatar"><?= e(strtoupper(substr($admin['name'] ?? 'A', 0, 1))) ?></div>
          <div>
            <div class="admin-user-name"><?= e($admin['name'] ?? 'Admin') ?></div>
            <div class="admin-user-role">Administrator</div>
          </div>
        </div>
      </div>
    </header>

    <main class="admin-content">
      <?= flash_render() ?>