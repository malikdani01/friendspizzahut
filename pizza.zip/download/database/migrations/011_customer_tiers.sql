CREATE TABLE IF NOT EXISTS customer_tiers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    slug VARCHAR(60) NOT NULL UNIQUE,
    color VARCHAR(20) NOT NULL DEFAULT '#6b7280',
    icon VARCHAR(60) NOT NULL DEFAULT 'fa-medal',
    min_spent DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
    free_delivery TINYINT(1) NOT NULL DEFAULT 0,
    bonus_loyalty_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default tiers
INSERT INTO customer_tiers (name, slug, color, icon, min_spent, discount_percent, free_delivery, bonus_loyalty_multiplier, sort_order) VALUES
('Bronze', 'bronze', '#92400e', 'fa-medal', 0, 0, 0, 1.00, 1),
('Silver', 'silver', '#9ca3af', 'fa-medal', 5000, 5, 0, 1.10, 2),
('Gold', 'gold', '#f59e0b', 'fa-crown', 15000, 8, 1, 1.25, 3),
('Platinum', 'platinum', '#8b5cf6', 'fa-gem', 40000, 12, 1, 1.50, 4);