<?php
/**
 * Contact Form Messages — Simple (no threading)
 */

function contact_message_list(string $filter = 'all'): array {
    try {
        $sql = "SELECT * FROM contact_messages WHERE 1=1";
        $params = [];
        if ($filter === 'unread') {
            $sql .= " AND is_read = 0";
        } elseif ($filter === 'archived') {
            $sql .= " AND is_archived = 1";
        } else {
            $sql .= " AND (is_archived = 0 OR is_archived IS NULL)";
        }
        $sql .= " ORDER BY id DESC LIMIT 200";
        return Database::fetchAll($sql, $params);
    } catch (Throwable $e) {
        return [];
    }
}

function contact_message_get(int $id): ?array {
    try {
        return Database::fetch("SELECT * FROM contact_messages WHERE id = ?", [$id]);
    } catch (Throwable $e) { return null; }
}

function contact_message_mark_read(int $id): void {
    try {
        Database::execute("UPDATE contact_messages SET is_read = 1 WHERE id = ?", [$id]);
    } catch (Throwable $e) {}
}

function contact_message_reply(int $id, string $reply): bool {
    try {
        Database::execute(
            "UPDATE contact_messages SET admin_reply = ?, replied_at = NOW(), is_read = 1 WHERE id = ?",
            [mb_substr($reply, 0, 2000), $id]
        );
        return true;
    } catch (Throwable $e) { return false; }
}

function contact_message_archive(int $id): void {
    try {
        Database::execute("UPDATE contact_messages SET is_archived = 1 WHERE id = ?", [$id]);
    } catch (Throwable $e) {}
}

function contact_message_delete(int $id): void {
    try {
        Database::execute("DELETE FROM contact_messages WHERE id = ?", [$id]);
    } catch (Throwable $e) {}
}

function contact_message_unread_count(): int {
    try {
        $r = Database::fetch("SELECT COUNT(*) c FROM contact_messages WHERE is_read = 0 AND (is_archived = 0 OR is_archived IS NULL)");
        return (int)($r['c'] ?? 0);
    } catch (Throwable $e) { return 0; }
}