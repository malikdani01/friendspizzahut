<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();

$pageTitle = 'Feature Manager';

// Handle actions
if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'toggle') {
        $key = (string)post('feature_key', '');
        if ($key && toggle_feature($key)) {
            $enabled = feature_enabled($key);
            $fname = Database::fetch("SELECT feature_name FROM features WHERE feature_key = ?", [$key])['feature_name'] ?? $key;
            audit_log('feature.' . ($enabled ? 'enable' : 'disable'), 'feature', null, null, ['key' => $key]);
            flash_success(($enabled ? 'Enabled: ' : 'Disabled: ') . $fname);
        } else {
            flash_error('Cannot change this feature (core feature or invalid).');
        }
    } elseif ($action === 'enable_category') {
        $cat = (string)post('category', '');
        if ($cat) {
            $n = enable_all_in_category($cat);
            flash_success("Enabled {$n} features in category.");
        }
    } elseif ($action === 'disable_category') {
        $cat = (string)post('category', '');
        if ($cat) {
            $n = disable_all_in_category($cat);
            flash_success("Disabled {$n} features in category.");
        }
    } elseif ($action === 'reset') {
        reset_features_to_defaults();
        flash_success('Features reset to defaults.');
        audit_log('feature.reset');
    }
    redirect(url('admin/features/index.php'));
}

$grouped = get_features_by_category();
$order = ['core','customer','orders','marketing','payments','notifications','integrations','advanced'];
uksort($grouped, function ($a, $b) use ($order) {
    $ia = array_search($a, $order); $ib = array_search($b, $order);
    $ia = $ia === false ? 999 : $ia; $ib = $ib === false ? 999 : $ib;
    return $ia <=> $ib;
});

require __DIR__ . '/../common/header.php';
?>

<div class="flex flex-wrap items-center justify-between gap-3 mb-6">
  <div>
    <p class="text-gray-600 text-sm">Turn features on/off instantly. No code changes needed.</p>
  </div>
  <form method="post" onsubmit="return confirm('Reset all features to their default states?');">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="reset">
    <button class="px-4 py-2 rounded-lg bg-gray-800 text-white text-sm hover:bg-gray-900">
      <i class="fa-solid fa-rotate-left mr-1"></i> Reset to Defaults
    </button>
  </form>
</div>

<?php foreach ($grouped as $category => $features):
    $enabledCount = count(array_filter($features, fn($f) => (int)$f['is_enabled'] === 1));
    $totalCount = count($features);
?>
<div class="mb-6 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
  <div class="px-5 py-4 border-b border-gray-100 flex flex-wrap items-center justify-between gap-2 bg-gray-50">
    <div>
      <h3 class="font-bold text-gray-900"><?= e(feature_category_label($category)) ?></h3>
      <p class="text-xs text-gray-500"><?= $enabledCount ?> of <?= $totalCount ?> enabled</p>
    </div>
    <?php if ($category !== 'core'): ?>
    <div class="flex gap-2">
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="enable_category">
        <input type="hidden" name="category" value="<?= e($category) ?>">
        <button class="text-xs px-3 py-1.5 rounded bg-green-600 text-white hover:bg-green-700">Enable All</button>
      </form>
      <form method="post" onsubmit="return confirm('Disable all features in this category?');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="disable_category">
        <input type="hidden" name="category" value="<?= e($category) ?>">
        <button class="text-xs px-3 py-1.5 rounded bg-gray-300 text-gray-700 hover:bg-gray-400">Disable All</button>
      </form>
    </div>
    <?php endif; ?>
  </div>

  <div class="divide-y divide-gray-100">
    <?php foreach ($features as $f):
        $isCore = (int)$f['is_core'] === 1;
        $isOn = (int)$f['is_enabled'] === 1;
        $needsConfig = (int)$f['requires_config'] === 1;
    ?>
    <div class="px-5 py-4 flex items-start justify-between gap-4 hover:bg-gray-50 transition">
      <div class="flex-1 min-w-0">
        <div class="flex items-center gap-2 flex-wrap">
          <span class="font-semibold text-gray-900"><?= e($f['feature_name']) ?></span>
          <?php if ($isCore): ?>
            <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-gray-900 text-white">Core</span>
          <?php endif; ?>
          <?php if ($needsConfig && $isOn): ?>
            <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-yellow-100 text-yellow-800">
              <i class="fa-solid fa-key mr-0.5"></i> Requires Setup
            </span>
          <?php endif; ?>
        </div>
        <p class="text-sm text-gray-500 mt-1"><?= e($f['description'] ?? '') ?></p>
        <code class="text-[11px] text-gray-400 mt-1 inline-block"><?= e($f['feature_key']) ?></code>
      </div>

      <div class="shrink-0">
        <?php if ($isCore): ?>
          <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-50 text-green-700 text-xs font-semibold">
            <i class="fa-solid fa-lock"></i> Always On
          </span>
        <?php else: ?>
          <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle">
            <input type="hidden" name="feature_key" value="<?= e($f['feature_key']) ?>">
            <button type="submit" title="<?= $isOn ? 'Click to disable' : 'Click to enable' ?>"
              class="relative inline-flex h-7 w-12 items-center rounded-full transition-colors <?= $isOn ? 'bg-brand' : 'bg-gray-300' ?>">
              <span class="inline-block h-5 w-5 rounded-full bg-white shadow transform transition-transform <?= $isOn ? 'translate-x-6' : 'translate-x-1' ?>"></span>
            </button>
          </form>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endforeach; ?>

<?php require __DIR__ . '/../common/footer.php'; ?>