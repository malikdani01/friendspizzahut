-- ═══════════════════════════════════════════════════════════════
-- Migration 017: Complete Your Meal (Upsell Products)
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── UPSELL PRODUCTS TABLE ────────────────────────────────────
CREATE TABLE IF NOT EXISTS cart_upsell_products (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_id INT UNSIGNED NOT NULL,
    is_enabled TINYINT(1) NOT NULL DEFAULT 1,
    display_order INT NOT NULL DEFAULT 0,
    price_override TINYINT(1) NOT NULL DEFAULT 0,
    custom_price DECIMAL(12,2) NULL,
    override_start DATETIME NULL,
    override_end DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_product (product_id),
    INDEX idx_enabled_order (is_enabled, display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── SETTINGS ─────────────────────────────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('upsell_enabled',     '1',                                  'cart'),
('upsell_heading',     'Complete Your Meal 🍟',              'cart'),
('upsell_subtitle',    'Make your order even better — add your favorite sides and drinks!', 'cart'),
('upsell_max_items',   '8',                                  'cart'),
('upsell_hide_in_cart','1',                                  'cart')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ─── FEATURE TOGGLE ───────────────────────────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('upsell_system', 'Complete Your Meal', 'marketing', 'Upsell suggestions in cart', 1, 0, 1, 0, 400)
ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);