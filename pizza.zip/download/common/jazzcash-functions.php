<?php
/**
 * ═══════════════════════════════════════════════════════════════
 * JazzCash Payment Gateway Functions — Pakistan
 * Mobile Wallet API (Hosted Checkout)
 *
 * Setup Steps:
 *   1. jazzcash.com.pk → Become a Merchant
 *   2. Business docs submit karo (CNIC, NTN, bank account)
 *   3. Approval ke baad Merchant ID, Password, Integrity Salt milenge
 *   4. Admin → Integrations → Payments mein daalo
 *
 * Sandbox: https://sandbox.jazzcash.com.pk/ApplicationAPI/API/2.0/Purchase/DoMWalletTransaction
 * Live:    https://payments.jazzcash.com.pk/ApplicationAPI/API/2.0/Purchase/DoMWalletTransaction
 * ═══════════════════════════════════════════════════════════════
 */

/**
 * Check if JazzCash feature is enabled and configured
 */
function jazzcash_is_enabled(): bool {
    return feature_enabled('online_payment')
        && setting('jazzcash_enabled', '0') === '1'
        && setting('jazzcash_merchant_id', '') !== ''
        && setting('jazzcash_integrity_salt', '') !== '';
}

/**
 * Check if running in sandbox mode
 */
function jazzcash_is_sandbox(): bool {
    return setting('jazzcash_mode', 'sandbox') === 'sandbox';
}

/**
 * Get JazzCash API endpoint
 */
function jazzcash_api_url(): string {
    return jazzcash_is_sandbox()
        ? 'https://sandbox.jazzcash.com.pk/ApplicationAPI/API/2.0/Purchase/DoMWalletTransaction'
        : 'https://payments.jazzcash.com.pk/ApplicationAPI/API/2.0/Purchase/DoMWalletTransaction';
}

/**
 * Get JazzCash status inquiry URL
 */
function jazzcash_inquiry_url(): string {
    return jazzcash_is_sandbox()
        ? 'https://sandbox.jazzcash.com.pk/ApplicationAPI/API/PaymentInquiry/Inquire'
        : 'https://payments.jazzcash.com.pk/ApplicationAPI/API/PaymentInquiry/Inquire';
}

/**
 * Generate JazzCash secure hash (HMAC-SHA256)
 *
 * Rules:
 *   - Sort params alphabetically (ksort)
 *   - Start with salt
 *   - Join values with '&' separator
 *   - Empty/null values skipped
 *   - HMAC-SHA256 with integrity salt
 *   - Uppercase
 */
function jazzcash_generate_hash(array $params): string {
    $salt = setting('jazzcash_integrity_salt', '');
    if (!$salt) return '';

    // Remove hash itself
    unset($params['pp_SecureHash']);

    // Filter empty values
    $filtered = [];
    foreach ($params as $k => $v) {
        if ($v === null || $v === '') continue;
        $filtered[$k] = $v;
    }

    // Sort alphabetically
    ksort($filtered);

    // Build string: salt&value1&value2&...
    $string = $salt;
    foreach ($filtered as $v) {
        $string .= '&' . $v;
    }

    // HMAC-SHA256
    $hash = hash_hmac('sha256', $string, $salt);

    return strtoupper($hash);
}

/**
 * Build JazzCash redirect URL with proper hash
 */
function jazzcash_build_redirect_url(array $order): string {
    $merchantId = setting('jazzcash_merchant_id', '');
    $password   = setting('jazzcash_password', '');

    $tz = new DateTimeZone('Asia/Karachi');
    $now = new DateTime('now', $tz);
    $expiry = (clone $now)->modify('+1 day');

    // Amount in paisa (JazzCash expects integer paisa)
    $amountPaisa = (int) round((float)$order['total'] * 100);

    // Unique transaction reference
    $txnRefNo = 'T' . $now->format('YmdHis') . rand(1000, 9999);

    $params = [
        'pp_Version'            => '1.1',
        'pp_TxnType'            => 'MWALLET',
        'pp_Language'           => 'EN',
        'pp_MerchantID'         => $merchantId,
        'pp_Password'           => $password,
        'pp_TxnRefNo'           => $txnRefNo,
        'pp_Amount'             => $amountPaisa,
        'pp_TxnCurrency'        => 'PKR',
        'pp_TxnDateTime'        => $now->format('YmdHis'),
        'pp_BillReference'      => (string)$order['order_number'],
        'pp_Description'        => 'Order ' . $order['order_number'],
        'pp_TxnExpiryDateTime'  => $expiry->format('YmdHis'),
        'pp_ReturnURL'          => url('payment/jazzcash-return.php'),
        'pp_SecureHash'         => '',
    ];

    // Generate hash (excludes pp_SecureHash itself)
    $params['pp_SecureHash'] = jazzcash_generate_hash($params);

    return jazzcash_api_url() . '?' . http_build_query($params);
}

/**
 * Verify JazzCash response hash
 */
function jazzcash_verify_response(array $post): bool {
    if (empty($post['pp_SecureHash'])) {
        return false;
    }

    $receivedHash = strtoupper((string)$post['pp_SecureHash']);

    $hashParams = $post;
    unset($hashParams['pp_SecureHash']);

    $computedHash = jazzcash_generate_hash($hashParams);

    return hash_equals($computedHash, $receivedHash);
}

/**
 * Check if JazzCash response indicates success
 *
 * Success codes:
 *   000 = Success
 *   121 = Approved
 *   200 = OK
 */
function jazzcash_response_success(string $code): bool {
    return in_array(trim($code), ['000', '121', '200'], true);
}

/**
 * Get user-friendly error message for JazzCash codes
 */
function jazzcash_error_message(string $code, string $desc = ''): string {
    return match(trim($code)) {
        '124' => 'Payment timeout. Please try again.',
        '157' => 'Insufficient balance in JazzCash wallet.',
        '199' => 'Payment declined by bank. Please try another method.',
        '110' => 'Transaction declined by issuer bank.',
        '112' => 'Invalid mobile number.',
        '113' => 'Merchant credentials invalid. Contact support.',
        '114' => 'Duplicate transaction reference. Try a new order.',
        '115' => 'Amount exceeds limit.',
        '116' => 'JazzCash service temporarily down.',
        '117' => 'Customer cancelled transaction.',
        '118' => 'Transaction expired.',
        '119' => 'Invalid request from merchant.',
        '120' => 'Customer does not have JazzCash account.',
        '121' => 'Transaction approved (delayed response).',
        ''    => 'Payment cancelled or failed. Try again.',
        default => 'Payment failed: ' . ($desc ?: 'Unknown error (Code: ' . $code . ')'),
    };
}

/**
 * Log JazzCash events
 */
function jazzcash_log(string $action, array $data): void {
    try {
        Database::insert('audit_logs', [
            'user_type'  => 'system',
            'user_id'    => null,
            'action'     => 'jazzcash.' . $action,
            'entity'     => 'payment',
            'entity_id'  => $data['order_id'] ?? null,
            'new_data'   => json_encode($data),
            'ip_address' => client_ip(),
            'user_agent' => 'JazzCash Gateway',
        ]);
    } catch (Throwable $e) {
        error_log('jazzcash_log failed: ' . $e->getMessage());
    }
}

/**
 * Query JazzCash transaction status (server-to-server)
 */
function jazzcash_query_transaction(string $txnRefNo): array {
    $merchantId = setting('jazzcash_merchant_id', '');
    $password   = setting('jazzcash_password', '');

    if (!$merchantId || !$password) {
        return ['ok' => false, 'error' => 'Incomplete credentials'];
    }

    $tz = new DateTimeZone('Asia/Karachi');
    $now = new DateTime('now', $tz);

    $params = [
        'pp_Version'         => '1.1',
        'pp_TxnType'         => 'MWALLET',
        'pp_Language'        => 'EN',
        'pp_MerchantID'      => $merchantId,
        'pp_Password'        => $password,
        'pp_TxnRefNo'        => $txnRefNo,
        'pp_TxnCurrency'     => 'PKR',
        'pp_TxnDateTime'     => $now->format('YmdHis'),
        'pp_BillReference'   => '',
        'pp_SecureHash'      => '',
    ];

    $params['pp_SecureHash'] = jazzcash_generate_hash($params);

    $url = jazzcash_inquiry_url() . '?' . http_build_query($params);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        jazzcash_log('inquiry_error', [
            'txn'   => $txnRefNo,
            'error' => $curlErr,
        ]);
        return ['ok' => false, 'error' => $curlErr];
    }

    $data = json_decode($response, true) ?: [];

    jazzcash_log('inquiry_result', [
        'txn'  => $txnRefNo,
        'http' => $httpCode,
        'data' => $data,
    ]);

    if ($httpCode !== 200) {
        return ['ok' => false, 'error' => 'HTTP ' . $httpCode, 'raw' => $response];
    }

    return ['ok' => true, 'data' => $data];
}

/**
 * Format amount for JazzCash (integer paisa)
 */
function jazzcash_format_amount(float $amount): int {
    return (int) round($amount * 100);
}

/**
 * Convert paisa back to rupees
 */
function jazzcash_paisa_to_rupees(int $paisa): float {
    return $paisa / 100;
}

/**
 * Normalize Pakistani phone number for JazzCash (92XXXXXXXXXX)
 */
function jazzcash_normalize_phone(string $phone): ?string {
    $digits = preg_replace('/\D/', '', $phone);

    if (preg_match('/^92\d{10}$/', $digits)) return $digits;
    if (preg_match('/^0\d{10}$/', $digits)) return '92' . substr($digits, 1);
    if (preg_match('/^3\d{9}$/', $digits)) return '92' . $digits;

    return null;
}