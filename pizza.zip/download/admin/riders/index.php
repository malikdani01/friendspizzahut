<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('rider_module')) {
    flash_error('Rider module disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Riders';

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'create') {
        $name = trim((string)post('name', ''));
        $phone = trim((string)post('phone', ''));
        $pin = (string)post('pin', '');
        if ($name && $phone && strlen($pin) >= 4) {
            Database::insert('riders', [
                'name' => $name, 'phone' => $phone,
                'pin_hash' => password_hash($pin, PASSWORD_DEFAULT),
                'cnic' => trim((string)post('cnic', '')) ?: null,
                'vehicle_type' => trim((string)post('vehicle_type', '')) ?: null,
                'vehicle_number' => trim((string)post('vehicle_number', '')) ?: null,
                'is_active' => 1,
            ]);
            flash_success('Rider added. Login PIN: ' . $pin);
        }
    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM riders WHERE id = ?", [(int)post('id')]);
        flash_success('Rider removed.');
    } elseif ($action === 'toggle') {
        Database::execute("UPDATE riders SET is_active = 1 - is_active WHERE id = ?", [(int)post('id')]);
        flash_success('Updated.');
    }
    redirect(url('admin/riders/index.php'));
}

$riders = get_riders(false);
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl border p-5 h-fit">
    <h3 class="font-bold mb-3">Add Rider</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <input name="name" required placeholder="Full name" class="w-full border rounded px-3 py-2">
      <input name="phone" required placeholder="Phone (03XXXXXXXXX)" class="w-full border rounded px-3 py-2">
      <input name="pin" required minlength="4" maxlength="6" placeholder="Login PIN (4-6 digits)" class="w-full border rounded px-3 py-2 font-mono">
      <input name="cnic" placeholder="CNIC (optional)" class="w-full border rounded px-3 py-2">
      <input name="vehicle_type" placeholder="Bike / Car / Cycle" class="w-full border rounded px-3 py-2">
      <input name="vehicle_number" placeholder="Vehicle number" class="w-full border rounded px-3 py-2">
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Add Rider</button>
    </form>
    <div class="mt-4 pt-4 border-t text-xs text-gray-500">
      <strong>Rider app URL:</strong><br>
      <a href="<?= url('rider/login.php') ?>" target="_blank" class="text-brand underline"><?= url('rider/login.php') ?></a>
    </div>
  </div>
  <div class="md:col-span-2 bg-white rounded-xl border overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
        <tr>
          <th class="text-left px-4 py-3">Name</th>
          <th class="text-left px-4 py-3">Phone</th>
          <th class="text-left px-4 py-3">Vehicle</th>
          <th class="text-left px-4 py-3">Status</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($riders as $r): ?>
        <tr class="border-t hover:bg-gray-50">
          <td class="px-4 py-3 font-semibold"><?= e($r['name']) ?></td>
          <td class="px-4 py-3"><?= e($r['phone']) ?></td>
          <td class="px-4 py-3 text-xs"><?= e($r['vehicle_type'] ?? '—') ?> <?= e($r['vehicle_number'] ?? '') ?></td>
          <td class="px-4 py-3">
            <form method="post" class="inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="text-xs px-2 py-1 rounded <?= $r['is_active'] ? 'bg-green-100 text-green-800' : 'bg-gray-200' ?>"><?= $r['is_active'] ? 'Active' : 'Inactive' ?></button>
            </form>
          </td>
          <td class="px-4 py-3 text-right">
            <form method="post" class="inline" data-confirm="Remove?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="text-red-600 text-xs">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$riders): ?>
        <tr><td colspan="5" class="py-8 text-center text-gray-400">No riders yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>