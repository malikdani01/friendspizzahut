<?php
// create.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('staff_roles')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Add Role';
if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name',''));
    $slug = slugify($name);
    if ($name && !Database::fetch("SELECT id FROM roles WHERE slug=?", [$slug])) {
        Database::insert('roles', ['name'=>$name, 'slug'=>$slug, 'description'=>trim((string)post('description',''))]);
        flash_success('Role created.');
        redirect(url('admin/roles/index.php'));
    }
    flash_error('Invalid or duplicate role.');
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl shadow-sm border p-6">
  <form method="post" class="space-y-4">
    <?= csrf_field() ?>
    <input name="name" required placeholder="Role name" class="w-full border rounded px-3 py-2">
    <input name="description" placeholder="Description" class="w-full border rounded px-3 py-2">
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Create</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>