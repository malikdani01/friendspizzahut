<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Support Chat';

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'delete_chat') {
        $uid = (int)post('user_id', 0);
        Database::execute("DELETE FROM chat_messages WHERE user_id = ?", [$uid]);
        flash_success('Chat deleted.');
    }
    redirect(url('admin/messages/index.php'));
}

$tab = (string)get('tab', 'chat');

$chatThreads = chat_admin_threads();
$chatUnread = chat_admin_unread_count();

$contactMsgs = contact_message_list($tab === 'unread' ? 'unread' : 'all');
$contactUnread = contact_message_unread_count();

require __DIR__ . '/../common/header.php';
?>

<style>
.mx-tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 18px;
  flex-wrap: wrap;
}
.mx-tab {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 11px 18px;
  border-radius: 12px;
  background: rgba(255,255,255,0.03);
  border: 1.5px solid rgba(255,255,255,0.08);
  color: rgba(255,255,255,0.6);
  font-size: 13.5px;
  font-weight: 700;
  text-decoration: none;
  transition: all .18s;
  position: relative;
}
.mx-tab:hover { border-color: rgba(220,38,38,0.4); color: #fff; }
.mx-tab.active {
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  border-color: #dc2626;
  color: #fff;
  box-shadow: 0 4px 14px rgba(220,38,38,0.35);
}
.mx-tab-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 22px;
  height: 22px;
  padding: 0 6px;
  border-radius: 999px;
  background: #fff;
  color: #dc2626;
  font-size: 11px;
  font-weight: 800;
}
.mx-tab.active .mx-tab-badge {
  background: rgba(255,255,255,0.25);
  color: #fff;
}

.mx-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.mx-card {
  display: flex;
  gap: 14px;
  align-items: center;
  padding: 16px;
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  text-decoration: none;
  color: inherit;
  transition: all .2s;
  position: relative;
}
.mx-card:hover {
  border-color: rgba(220,38,38,0.35);
  transform: translateY(-1px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.3);
}
.mx-card.unread {
  border-left: 3px solid #dc2626;
  background: linear-gradient(90deg, rgba(220,38,38,0.05), #171717 40%);
}
.mx-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-weight: 800;
  font-size: 18px;
  flex-shrink: 0;
}
.mx-body { flex: 1; min-width: 0; }
.mx-name {
  font-size: 15px;
  font-weight: 800;
  color: #fff;
  margin-bottom: 2px;
}
.mx-meta {
  font-size: 12px;
  color: rgba(255,255,255,0.5);
}
.mx-preview {
  font-size: 13px;
  color: rgba(255,255,255,0.7);
  margin-top: 5px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.mx-right {
  text-align: right;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 4px;
}
.mx-time {
  font-size: 11px;
  color: rgba(255,255,255,0.4);
}
.mx-badge {
  background: #dc2626;
  color: #fff;
  font-size: 10px;
  font-weight: 800;
  padding: 3px 8px;
  border-radius: 999px;
  text-transform: uppercase;
}
.mx-empty {
  text-align: center;
  padding: 60px 20px;
  color: rgba(255,255,255,0.4);
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
}
.mx-empty i {
  font-size: 40px;
  opacity: 0.3;
  display: block;
  margin-bottom: 12px;
  color: #dc2626;
}
</style>

<!-- Tabs -->
<div class="mx-tabs">
  <a href="?tab=chat" class="mx-tab <?= $tab === 'chat' ? 'active' : '' ?>">
    <i class="fa-solid fa-comments"></i> Live Chat
    <?php if ($chatUnread > 0): ?><span class="mx-tab-badge"><?= $chatUnread ?></span><?php endif; ?>
  </a>
  <a href="?tab=contact" class="mx-tab <?= $tab === 'contact' ? 'active' : '' ?>">
    <i class="fa-solid fa-envelope"></i> Contact Form
    <?php if ($contactUnread > 0): ?><span class="mx-tab-badge"><?= $contactUnread ?></span><?php endif; ?>
  </a>
</div>

<?php if ($tab === 'contact'): ?>
  <!-- CONTACT FORM MESSAGES -->
  <div class="mx-list">
    <?php if (!$contactMsgs): ?>
      <div class="mx-empty">
        <i class="fa-solid fa-envelope"></i>
        No contact messages.
      </div>
    <?php else: foreach ($contactMsgs as $m):
      $isUnread = (int)$m['is_read'] === 0;
    ?>
      <a href="<?= url('admin/messages/contact-view.php?id=' . (int)$m['id']) ?>" class="mx-card <?= $isUnread ? 'unread' : '' ?>">
        <div class="mx-avatar"><?= e(strtoupper(mb_substr($m['name'], 0, 1))) ?></div>
        <div class="mx-body">
          <div class="mx-name">
            <?= e($m['name']) ?>
            <?php if ($isUnread): ?><span class="mx-badge" style="margin-left:6px;">New</span><?php endif; ?>
          </div>
          <div class="mx-meta">
            <i class="fa-solid fa-phone"></i> <?= e($m['phone']) ?>
            <?php if ($m['email']): ?> · <?= e($m['email']) ?><?php endif; ?>
          </div>
          <div class="mx-preview">
            <strong><?= e($m['subject'] ?: 'General') ?>:</strong>
            <?= e(mb_substr($m['message'], 0, 70)) ?>
          </div>
        </div>
        <div class="mx-right">
          <div class="mx-time"><?= date('d M, H:i', strtotime($m['created_at'])) ?></div>
          <?php if (!empty($m['admin_reply'])): ?>
            <span class="mx-badge" style="background:rgba(34,197,94,0.2);color:#4ade80;">Replied</span>
          <?php endif; ?>
        </div>
      </a>
    <?php endforeach; endif; ?>
  </div>

<?php else: ?>
  <!-- LIVE CHAT THREADS -->
  <div class="mx-list">
    <?php if (!$chatThreads): ?>
      <div class="mx-empty">
        <i class="fa-solid fa-comments"></i>
        No live chats yet.<br>
        <span style="font-size:12px;">When customers send messages from <code>/messages.php</code>, they will appear here.</span>
      </div>
    <?php else: foreach ($chatThreads as $t):
      $isUnread = (int)$t['unread'] > 0;
    ?>
      <a href="<?= url('admin/messages/chat.php?user_id=' . (int)$t['user_id']) ?>" class="mx-card <?= $isUnread ? 'unread' : '' ?>">
        <div class="mx-avatar"><?= e(strtoupper(mb_substr($t['user_name'] ?? 'U', 0, 1))) ?></div>
        <div class="mx-body">
          <div class="mx-name"><?= e($t['user_name'] ?? 'Unknown') ?></div>
          <div class="mx-meta">
            <i class="fa-solid fa-phone"></i> <?= e($t['user_phone'] ?? '') ?>
            <?php if (!empty($t['user_email'])): ?> · <?= e($t['user_email']) ?><?php endif; ?>
          </div>
          <div class="mx-preview"><?= e(mb_substr($t['last_message'] ?? 'No messages', 0, 70)) ?></div>
        </div>
        <div class="mx-right">
          <div class="mx-time"><?= $t['last_at'] ? date('d M, H:i', strtotime($t['last_at'])) : '' ?></div>
          <?php if ($isUnread): ?><span class="mx-badge"><?= (int)$t['unread'] ?> new</span><?php endif; ?>
        </div>
      </a>
    <?php endforeach; endif; ?>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/../common/footer.php'; ?>