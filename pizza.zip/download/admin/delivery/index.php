<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Delivery Areas';
if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'create') {
        Database::insert('delivery_areas', [
            'name' => trim((string)post('name','')),
            'city' => trim((string)post('city','')) ?: null,
            'delivery_fee' => (float)post('delivery_fee',0),
            'min_order' => (float)post('min_order',0),
            'estimated_minutes' => (int)post('estimated_minutes',30),
            'is_active' => post('is_active') ? 1 : 0,
        ]);
        flash_success('Area added.');
    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM delivery_areas WHERE id=?", [(int)post('id')]);
        flash_success('Deleted.');
    }
    redirect(url('admin/delivery/index.php'));
}
$rows = Database::fetchAll("SELECT * FROM delivery_areas ORDER BY sort_order, name");
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl shadow-sm border p-5 h-fit">
    <h3 class="font-bold mb-3">Add Area</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <input name="name" placeholder="Area name *" required class="w-full border rounded px-3 py-2">
      <input name="city" placeholder="City" value="<?= e(setting('restaurant_city')) ?>" class="w-full border rounded px-3 py-2">
      <input type="number" step="0.01" name="delivery_fee" placeholder="Delivery fee" required class="w-full border rounded px-3 py-2">
      <input type="number" step="0.01" name="min_order" placeholder="Min order" value="0" class="w-full border rounded px-3 py-2">
      <input type="number" name="estimated_minutes" placeholder="ETA minutes" value="30" class="w-full border rounded px-3 py-2">
      <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" checked> Active</label>
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Add Area</button>
    </form>
  </div>
  <div class="md:col-span-2 bg-white rounded-xl shadow-sm border overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">Area</th><th class="text-left">City</th><th class="text-right">Fee</th><th class="text-right">Min</th><th class="text-right">ETA</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($rows as $a): ?>
        <tr class="border-t">
          <td class="px-4 py-3 font-semibold"><?= e($a['name']) ?><?= !$a['is_active']?' <span class="text-xs text-gray-500">(inactive)</span>':'' ?></td>
          <td class="px-4 py-3"><?= e($a['city']) ?></td>
          <td class="px-4 py-3 text-right"><?= money($a['delivery_fee']) ?></td>
          <td class="px-4 py-3 text-right"><?= money($a['min_order']) ?></td>
          <td class="px-4 py-3 text-right"><?= (int)$a['estimated_minutes'] ?>m</td>
          <td class="px-4 py-3 text-right"><form method="post" class="inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><button class="text-red-600 text-xs">Delete</button></form></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>