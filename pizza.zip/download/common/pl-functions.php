<?php
/**
 * Profit & Loss report engine
 * Feature-gated: profit_loss_report
 */

function get_pl_data(string $from, string $to): array {
    // Revenue
    $revenue = Database::fetch(
        "SELECT COALESCE(SUM(total), 0) r, COUNT(*) c FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?
         AND order_status NOT IN ('cancelled','refunded')",
        [$from, $to]
    );

    // COGS — sum of cost_price × quantity for sold items
    $cogs = Database::fetch(
        "SELECT COALESCE(SUM(oi.quantity * COALESCE(p.cost_price, 0)), 0) c
         FROM order_items oi
         JOIN orders o ON o.id = oi.order_id
         LEFT JOIN products p ON p.id = oi.product_id
         WHERE DATE(o.created_at) BETWEEN ? AND ?
         AND o.order_status NOT IN ('cancelled','refunded')",
        [$from, $to]
    );

    // Discounts given
    $discounts = Database::fetch(
        "SELECT COALESCE(SUM(discount_total), 0) d FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?
         AND order_status NOT IN ('cancelled','refunded')",
        [$from, $to]
    );

    // Refunds issued
    $refunds = Database::fetch(
        "SELECT COALESCE(SUM(amount), 0) r FROM refunds
         WHERE DATE(created_at) BETWEEN ? AND ?
         AND status = 'refunded'",
        [$from, $to]
    );

    // Delivery fees collected
    $deliveryFees = Database::fetch(
        "SELECT COALESCE(SUM(delivery_fee), 0) d FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?
         AND order_status NOT IN ('cancelled','refunded')",
        [$from, $to]
    );

    // SMS/Marketing costs (estimate from audit logs count)
    $smsCount = (int)(Database::fetch(
        "SELECT COUNT(*) c FROM audit_logs
         WHERE action = 'sms.sent' AND DATE(created_at) BETWEEN ? AND ?",
        [$from, $to]
    )['c'] ?? 0);
    $smsCost = $smsCount * 2.0; // Rs. 2 per SMS estimate

    $grossRevenue = (float)$revenue['r'];
    $totalCogs = (float)$cogs['c'];

    return [
        'from' => $from,
        'to' => $to,
        'total_orders' => (int)$revenue['c'],
        'gross_revenue' => $grossRevenue,
        'discounts' => (float)$discounts['d'],
        'refunds' => (float)$refunds['r'],
        'delivery_collected' => (float)$deliveryFees['d'],
        'net_revenue' => $grossRevenue - (float)$refunds['r'],
        'cogs' => $totalCogs,
        'gross_profit' => $grossRevenue - $totalCogs,
        'sms_cost' => $smsCost,
        'marketing_cost' => $smsCost,
        'net_profit' => $grossRevenue - $totalCogs - $smsCost,
    ];
}

function pl_margin_percent(float $profit, float $revenue): float {
    if ($revenue <= 0) return 0;
    return round(($profit / $revenue) * 100, 1);
}