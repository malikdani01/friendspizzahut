<?php
/**
 * Admin notification sound + auto-refresh system
 */

function admin_should_play_sound(): bool {
    if (!feature_enabled('admin_sound_alerts')) return false;
    if (!admin_logged_in()) return false;

    // Check if there's an unread new order notification in last 60 seconds
    $recent = Database::fetch(
        "SELECT COUNT(*) c FROM notifications 
         WHERE user_type='admin' AND is_read=0 
         AND type='new_order' 
         AND created_at >= DATE_SUB(NOW(), INTERVAL 60 SECOND)"
    );
    return ((int)($recent['c'] ?? 0)) > 0;
}

function admin_unread_order_count(): int {
    $r = Database::fetch("SELECT COUNT(*) c FROM notifications 
        WHERE user_type='admin' AND is_read=0 AND type='new_order'");
    return (int)($r['c'] ?? 0);
}

function admin_pending_order_count(): int {
    $r = Database::fetch("SELECT COUNT(*) c FROM orders WHERE order_status='pending'");
    return (int)($r['c'] ?? 0);
}