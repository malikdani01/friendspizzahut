<?php
/**
 * Universal Payment Return Handler
 * Easypaisa aur JazzCash dono ke return URLs yahan aayenge.
 * Agar specific handler set hai to us par redirect karega,
 * warna generic success page dikhayega.
 */
require_once __DIR__ . '/../common/bootstrap.php';

// Get data from POST or GET
$data = $_POST ?: $_GET;

// Determine gateway from data
$gateway = 'unknown';
if (!empty($data['orderRefNum'])) {
    // Easypaisa uses orderRefNum
    $gateway = 'easypaisa';
} elseif (!empty($data['pp_BillReference'])) {
    // JazzCash uses pp_BillReference
    $gateway = 'jazzcash';
} elseif (!empty($data['order'])) {
    // Generic ?order=FPH-XXX
    $gateway = 'generic';
}

// Log all incoming data for debugging
try {
    Database::insert('audit_logs', [
        'user_type'  => 'system',
        'action'     => 'payment.return',
        'entity'     => 'payment',
        'new_data'   => json_encode([
            'gateway' => $gateway,
            'data'    => array_map(fn($v) => is_string($v) ? mb_substr($v, 0, 200) : $v, $data),
        ]),
        'ip_address' => client_ip(),
        'user_agent' => mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250),
    ]);
} catch (Throwable $e) {
    error_log('payment.return log failed: ' . $e->getMessage());
}

// Route to specific handler if exists
if ($gateway === 'easypaisa' && file_exists(__DIR__ . '/easypaisa-return.php')) {
    require __DIR__ . '/easypaisa-return.php';
    exit;
}

if ($gateway === 'jazzcash' && file_exists(__DIR__ . '/jazzcash-return.php')) {
    require __DIR__ . '/jazzcash-return.php';
    exit;
}

// Generic fallback — extract order number from any source
$orderNumber = $data['order']
    ?? $data['orderRefNum']
    ?? $data['pp_BillReference']
    ?? $data['order_number']
    ?? '';

if ($orderNumber) {
    $order = get_order_by_number((string)$orderNumber);
    if ($order) {
        flash_success('Payment completed. Thank you!');
        redirect(url('order-success.php?order=' . urlencode($orderNumber)));
    }
}

// Nothing to route to
flash_info('Payment processing. Please check your order status.');
redirect(url('track-order.php' . ($orderNumber ? '?order=' . urlencode($orderNumber) : '')));