<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('rider_module')) redirect(url('admin/dashboard.php'));
if (!is_post()) redirect(url('admin/orders/index.php'));
verify_csrf();

$orderId = (int)post('order_id', 0);
$riderId = (int)post('rider_id', 0);

if ($orderId && $riderId && assign_rider($orderId, $riderId)) {
    flash_success('Rider assigned.');
} else {
    flash_error('Could not assign rider.');
}
redirect(url('admin/orders/view.php?id=' . $orderId));