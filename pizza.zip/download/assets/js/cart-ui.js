document.addEventListener('click', e => {
  const b = e.target.closest('.qty-btn');
  if (!b) return;
  const input = b.closest('.qty-wrap').querySelector('input');
  const v = Math.max(1, Math.min(50, (parseInt(input.value)||1) + (b.dataset.delta === '+' ? 1 : -1)));
  input.value = v;
});