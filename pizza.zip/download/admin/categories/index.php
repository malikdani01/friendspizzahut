<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Categories';
$rows = get_categories();
require __DIR__ . '/../common/header.php';
?>
<div class="flex justify-between items-center mb-5">
  <p class="text-gray-600 text-sm"><?= count($rows) ?> categories</p>
  <a href="<?= url('admin/categories/create.php') ?>" class="bg-brand hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-semibold">
    <i class="fa-solid fa-plus mr-1"></i> Add Category
  </a>
</div>
<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-gray-600 text-xs uppercase">
      <tr>
        <th class="text-left px-5 py-3">Image</th>
        <th class="text-left px-5 py-3">Name</th>
        <th class="text-left px-5 py-3">Slug</th>
        <th class="text-left px-5 py-3">Products</th>
        <th class="text-left px-5 py-3">Order</th>
        <th class="text-left px-5 py-3">Status</th>
        <th class="text-right px-5 py-3">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7" class="px-5 py-10 text-center text-gray-400">No categories yet. Create your first category.</td></tr>
      <?php else: foreach ($rows as $c): ?>
        <tr class="border-t border-gray-100 hover:bg-gray-50">
          <td class="px-5 py-3">
            <?php if ($c['image']): ?>
              <img src="<?= upload_url($c['image']) ?>" class="w-10 h-10 rounded object-cover">
            <?php else: ?>
              <div class="w-10 h-10 rounded bg-gray-100 flex items-center justify-center text-gray-400"><i class="fa-solid <?= e($c['icon'] ?: 'fa-utensils') ?>"></i></div>
            <?php endif; ?>
          </td>
          <td class="px-5 py-3 font-semibold"><?= e($c['name']) ?></td>
          <td class="px-5 py-3 text-xs text-gray-500 font-mono"><?= e($c['slug']) ?></td>
          <td class="px-5 py-3"><?= get_category_product_count((int)$c['id']) ?></td>
          <td class="px-5 py-3"><?= (int)$c['sort_order'] ?></td>
          <td class="px-5 py-3">
            <?php if ($c['is_active']): ?>
              <span class="text-xs px-2 py-1 rounded bg-green-100 text-green-800 font-semibold">Active</span>
            <?php else: ?>
              <span class="text-xs px-2 py-1 rounded bg-gray-200 text-gray-700 font-semibold">Inactive</span>
            <?php endif; ?>
          </td>
          <td class="px-5 py-3 text-right whitespace-nowrap">
            <a href="<?= url('admin/categories/edit.php?id=' . (int)$c['id']) ?>" class="text-blue-600 hover:underline text-xs mr-3"><i class="fa-solid fa-pen"></i> Edit</a>
            <form method="post" action="<?= url('admin/categories/delete.php') ?>" class="inline" data-confirm="Delete this category?">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="text-red-600 hover:underline text-xs"><i class="fa-solid fa-trash"></i> Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>