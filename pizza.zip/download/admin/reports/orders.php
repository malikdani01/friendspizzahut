<?php
// orders.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Orders Report';
$from = (string)get('from', date('Y-m-01'));
$to = (string)get('to', date('Y-m-d'));
$rows = Database::fetchAll("SELECT order_status, COUNT(*) c FROM orders WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY order_status", [$from, $to]);
require __DIR__ . '/../common/header.php';
?>
<form class="flex gap-2 mb-5"><input type="date" name="from" value="<?= e($from) ?>" class="border rounded px-3 py-2"><input type="date" name="to" value="<?= e($to) ?>" class="border rounded px-3 py-2"><button class="bg-brand text-white px-4 py-2 rounded">Apply</button></form>
<div class="bg-white rounded-xl border overflow-hidden">
  <table class="w-full text-sm"><thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">Status</th><th class="text-right px-4 py-3">Count</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?><tr class="border-t"><td class="px-4 py-3"><?= order_status_label($r['order_status']) ?></td><td class="px-4 py-3 text-right font-semibold"><?= (int)$r['c'] ?></td></tr><?php endforeach; ?>
  </tbody></table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>