<?php /** @var array $offer */ ?>
<div class="bg-gradient-to-br from-brand/20 to-black border border-brand/30 rounded-2xl p-5">
  <div class="text-xs uppercase text-brand font-bold mb-2"><?= e(str_replace('_',' ',$offer['offer_type'])) ?></div>
  <h3 class="font-extrabold text-lg mb-1"><?= e($offer['title']) ?></h3>
  <p class="text-sm text-white/70 mb-3"><?= e($offer['description']) ?></p>
  <div class="text-2xl font-extrabold text-brand">
    <?php if ($offer['offer_type']==='percentage'): ?><?= (int)$offer['discount_value'] ?>% OFF
    <?php elseif ($offer['offer_type']==='fixed'): ?><?= money($offer['discount_value']) ?> OFF
    <?php elseif ($offer['offer_type']==='free_delivery'): ?>FREE DELIVERY
    <?php endif; ?>
  </div>
  <a href="<?= url('menu.php') ?>" class="mt-3 inline-block bg-brand hover:bg-red-700 px-4 py-2 rounded-lg text-sm font-bold">Order Now →</a>
</div>