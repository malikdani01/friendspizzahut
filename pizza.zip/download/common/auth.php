<?php
/**
 * Customer authentication
 */

function customer_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

function current_customer(): ?array
{
    if (!customer_logged_in()) return null;
    static $user = null;
    if ($user === null) {
        $user = Database::fetch("SELECT * FROM users WHERE id = ?", [(int)$_SESSION['user_id']]);
        if ($user && (int)$user['is_blocked'] === 1) {
            logout_customer();
            return null;
        }
    }
    return $user;
}

function require_customer(): void
{
    if (!customer_logged_in()) {
        $_SESSION['_redirect_after_login'] = current_url();
        flash_error('Please login to continue.');
        redirect(url('login.php'));
    }
}

function login_customer(string $identifier, string $password): array
{
    if (!rate_limit_login('customer')) {
        return ['ok' => false, 'error' => 'Too many attempts. Try again in 15 minutes.'];
    }

    $identifier = trim($identifier);
    $user = Database::fetch(
        "SELECT * FROM users WHERE phone = ? OR email = ? LIMIT 1",
        [$identifier, $identifier]
    );

    if (!$user || !password_verify($password, $user['password_hash'])) {
        record_login_attempt($identifier, false, 'customer');
        return ['ok' => false, 'error' => 'Invalid credentials.'];
    }
    if ((int)$user['is_blocked'] === 1) {
        return ['ok' => false, 'error' => 'Your account is blocked. ' . ($user['blocked_reason'] ?? '')];
    }

    session_regenerate();
    $_SESSION['user_id']   = (int)$user['id'];
    $_SESSION['user_name'] = $user['name'];
    Database::execute("UPDATE users SET last_login = NOW() WHERE id = ?", [$user['id']]);
    record_login_attempt($identifier, true, 'customer');
    audit_log('customer.login', 'user', (int)$user['id']);

    return ['ok' => true, 'user' => $user];
}

function logout_customer(): void
{
    unset($_SESSION['user_id'], $_SESSION['user_name']);
}

function register_customer(string $name, string $phone, ?string $email, string $password): array
{
    $name  = trim($name);
    $phone = trim($phone);
    $email = $email ? trim($email) : null;

    if (mb_strlen($name) < 2)          return ['ok' => false, 'error' => 'Please enter your full name.'];
    if (!validate_phone($phone))       return ['ok' => false, 'error' => 'Invalid phone number.'];
    if ($email && !validate_email($email)) return ['ok' => false, 'error' => 'Invalid email address.'];
    if (strlen($password) < 6)         return ['ok' => false, 'error' => 'Password must be at least 6 characters.'];

    if (Database::fetch("SELECT id FROM users WHERE phone = ?", [$phone])) {
        return ['ok' => false, 'error' => 'Phone already registered.'];
    }
    if ($email && Database::fetch("SELECT id FROM users WHERE email = ?", [$email])) {
        return ['ok' => false, 'error' => 'Email already registered.'];
    }

    $id = Database::insert('users', [
        'name'          => $name,
        'phone'         => $phone,
        'email'         => $email,
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
    ]);
    audit_log('customer.register', 'user', $id);
    return ['ok' => true, 'user_id' => $id];
}