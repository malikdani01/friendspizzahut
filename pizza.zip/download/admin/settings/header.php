<?php
// header.php (settings)
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Header Settings';
if (is_post()) {
    verify_csrf();
    update_setting('header_sticky', post('header_sticky') ? '1' : '0');
    flash_success('Saved.');
    redirect(url('admin/settings/header.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <label class="flex items-center gap-2"><input type="checkbox" name="header_sticky" value="1" <?= setting('header_sticky','1')=='1'?'checked':'' ?>> Sticky header</label>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>