<?php
// services/CheckoutService.php
class CheckoutService {
    public static function summary(): array { return get_checkout_summary(); }
    public static function generateOrderNumber(): string { return build_order_number(); }
}