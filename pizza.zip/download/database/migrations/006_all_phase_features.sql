-- ═══════════════════════════════════════════════════════════════
-- Migration 006: All Phase A/B/C Features Added
-- Run this to register all new features in the toggle system.
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── PHASE A: CRITICAL OPERATIONS ─────────────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('admin_sound_alerts',    'Admin Sound Alerts',      'orders',        'Play sound when new order arrives',          1,0,1,0, 100),
('admin_auto_refresh',    'Admin Auto-Refresh',      'orders',        'Auto-refresh admin pages every 30 seconds',  1,0,1,0, 101),
('thermal_printer',       'Thermal Printer Support', 'orders',        '80mm thermal receipt printing',              1,0,1,0, 102),
('facebook_pixel',        'Facebook Pixel',          'marketing',     'Track conversions for Facebook Ads',         1,0,1,1, 103),
('google_analytics',      'Google Analytics',        'marketing',     'GA4 tracking for traffic analysis',          1,0,1,1, 104),
('whatsapp_click_chat',   'WhatsApp Click-to-Chat',  'marketing',     'Floating WhatsApp button on site',           1,0,1,0, 105)
ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);

-- ─── PHASE B: OPERATIONS ─────────────────────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('qr_menu',               'QR Code Menu',            'customer',      'Table QR code ordering system',              0,0,0,0, 110),
('multi_language',        'Multi-Language (Urdu)',   'advanced',      'English/Urdu language switcher',             0,0,0,0, 111),
('rider_module',          'Rider Management',        'orders',        'Assign riders to orders + rider app',        0,0,0,0, 112),
('rider_live_tracking',   'Live Rider Tracking',     'advanced',      'Real-time rider location on map',            0,0,0,1, 113),
('table_number_tracking', 'Table Number Tracking',   'orders',        'Track orders by table number (dine-in)',     0,0,0,0, 114),
('delivery_zones_map',    'Delivery Zones Map',      'advanced',      'Visual delivery zone editor',                0,0,0,0, 115)
ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);

-- ─── PHASE C: ADVANCED ───────────────────────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('product_gallery',       'Product Gallery',         'customer',      'Multiple images per product',                1,0,1,0, 120),
('bulk_product_import',   'Bulk Product Import',     'advanced',      'Import products from CSV',                   0,0,0,0, 121),
('customer_wallet',       'Customer Wallet',         'customer',      'Prepaid balance for customers',              0,0,0,0, 122),
('recipe_tracking',       'Recipe & Ingredient',     'advanced',      'Auto stock deduction by recipe',             0,0,0,0, 123),
('order_editing',         'Admin Order Editing',     'orders',        'Edit orders before preparing',               0,0,0,0, 124),
('search_autocomplete',   'Search Autocomplete',     'customer',      'Real-time search suggestions',               1,0,1,0, 125),
('email_templates_ui',    'Email Templates Editor',  'notifications', 'Edit email/SMS templates from admin',        1,0,1,0, 126),
('birthday_reminders',    'Birthday Reminders',      'marketing',     'Auto SMS/email on customer birthday',        0,0,0,1, 127),
('feedback_after_order',  'Post-Order Feedback',     'customer',      'Auto-prompt for review after delivery',      1,0,1,0, 128),
('featured_collections',  'Featured Collections',    'marketing',     'Curated product collections',                1,0,1,0, 129),
('product_badges',        'Product Badges',          'customer',      'New/Bestseller/Sale badges on products',     1,0,1,0, 130),
('countdown_timers',      'Offer Countdown Timers',  'marketing',     'Show time remaining on offers',              1,0,1,0, 131),
('order_notes_customer',  'Customer Order Notes',    'orders',        'Allow notes on entire order',                1,0,1,0, 132),
('share_buttons',         'Social Share Buttons',    'marketing',     'Share products on WhatsApp/FB',              1,0,1,0, 133),
('recently_viewed',       'Recently Viewed',         'customer',      'Show recently viewed products',              1,0,1,0, 134),
('related_products',      'Related Products',        'customer',      'You may also like section',                  1,0,1,0, 135)
ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);