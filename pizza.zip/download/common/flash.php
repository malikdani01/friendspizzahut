<?php
/**
 * Flash message helpers
 */

function flash_set(string $type, string $message): void
{
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}

function flash_get(): array
{
    $msgs = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $msgs;
}

function flash_success(string $m): void { flash_set('success', $m); }
function flash_error(string $m): void   { flash_set('error', $m); }
function flash_info(string $m): void    { flash_set('info', $m); }
function flash_warning(string $m): void { flash_set('warning', $m); }

function flash_render(): string
{
    $msgs = flash_get();
    if (!$msgs) return '';
    $html = '<div class="flash-container fixed top-4 right-4 z-50 space-y-2 max-w-sm">';
    foreach ($msgs as $m) {
        $type = $m['type'];
        $cls = match ($type) {
            'success' => 'bg-green-600 text-white',
            'error'   => 'bg-red-600 text-white',
            'warning' => 'bg-yellow-500 text-black',
            default   => 'bg-gray-800 text-white',
        };
        $html .= '<div class="flash-item ' . $cls . ' px-4 py-3 rounded-lg shadow-lg text-sm font-medium flex items-center gap-2">'
              . '<i class="fa-solid fa-circle-info"></i>'
              . e($m['message'])
              . '</div>';
    }
    $html .= '</div>';
    return $html;
}