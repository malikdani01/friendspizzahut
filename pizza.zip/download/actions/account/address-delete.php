<?php
// actions/account/address-delete.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('addresses.php'));
verify_csrf();
Database::execute("DELETE FROM addresses WHERE id=? AND user_id=?", [(int)post('id'), (int)$_SESSION['user_id']]);
flash_success('Deleted.');
redirect(url('addresses.php'));