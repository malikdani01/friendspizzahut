<?php /** @var string $message */
?>
<div class="bg-white rounded-xl border border-gray-100 p-10 text-center text-gray-400">
  <i class="fa-solid fa-inbox text-4xl mb-3"></i>
  <p><?= e($message ?? 'Nothing here.') ?></p>
</div>