<?php /** @var string $id @var string $title @var string $content */
$id = $id ?? 'modal'; $title = $title ?? ''; $content = $content ?? ''; ?>
<div id="<?= e($id) ?>" class="hidden fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
  <div class="bg-ink border border-white/10 rounded-2xl max-w-lg w-full">
    <div class="px-5 py-4 border-b border-white/10 flex justify-between items-center">
      <h3 class="font-bold"><?= e($title) ?></h3>
      <button onclick="document.getElementById('<?= e($id) ?>').classList.add('hidden')" class="text-white/60 hover:text-white text-xl">&times;</button>
    </div>
    <div class="p-5"><?= $content ?></div>
  </div>
</div>