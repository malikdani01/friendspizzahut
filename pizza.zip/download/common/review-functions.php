<?php
/**
 * Reviews + Replies + Likes — Complete System
 */

function get_product_reviews(int $productId, bool $approvedOnly = true): array {
    $sql = "SELECT r.*, u.name AS user_name, u.avatar AS user_avatar
            FROM reviews r
            JOIN users u ON u.id = r.user_id
            WHERE r.product_id = ?";
    if ($approvedOnly) $sql .= " AND r.is_approved = 1";
    $sql .= " ORDER BY r.id DESC";

    $rows = Database::fetchAll($sql, [$productId]);

    // Attach replies + user liked status
    foreach ($rows as &$r) {
        $r['replies'] = get_review_replies((int)$r['id'], $approvedOnly);
        $r['like_count'] = review_like_count((int)$r['id']);
        $r['user_liked'] = customer_logged_in()
            ? review_user_liked((int)$r['id'], (int)$_SESSION['user_id'])
            : false;
    }

    return $rows;
}

function get_review_replies(int $reviewId, bool $approvedOnly = true): array {
    $sql = "SELECT rr.*, u.name AS user_name, u.avatar AS user_avatar
            FROM review_replies rr
            JOIN users u ON u.id = rr.user_id
            WHERE rr.review_id = ?";
    if ($approvedOnly) $sql .= " AND rr.is_approved = 1";
    $sql .= " ORDER BY rr.id ASC";
    return Database::fetchAll($sql, [$reviewId]);
}

function review_like_count(int $reviewId): int {
    $r = Database::fetch("SELECT COUNT(*) c FROM review_likes WHERE review_id = ?", [$reviewId]);
    return (int)($r['c'] ?? 0);
}

function review_user_liked(int $reviewId, int $userId): bool {
    return (bool) Database::fetch(
        "SELECT id FROM review_likes WHERE review_id = ? AND user_id = ?",
        [$reviewId, $userId]
    );
}

function review_toggle_like(int $reviewId, int $userId): bool {
    if (review_user_liked($reviewId, $userId)) {
        Database::execute("DELETE FROM review_likes WHERE review_id = ? AND user_id = ?", [$reviewId, $userId]);
        Database::execute("UPDATE reviews SET like_count = GREATEST(0, like_count - 1) WHERE id = ?", [$reviewId]);
        return false;
    }
    Database::insert('review_likes', ['review_id' => $reviewId, 'user_id' => $userId]);
    Database::execute("UPDATE reviews SET like_count = like_count + 1 WHERE id = ?", [$reviewId]);
    return true;
}

function review_add_reply(int $reviewId, int $userId, string $text, ?int $parentId = null): array {
    $text = trim($text);
    if (strlen($text) < 2) return ['ok' => false, 'error' => 'Reply is too short.'];
    if (strlen($text) > 1000) return ['ok' => false, 'error' => 'Reply is too long (max 1000 chars).'];

    $id = Database::insert('review_replies', [
        'review_id' => $reviewId,
        'parent_reply_id' => $parentId,
        'user_id' => $userId,
        'reply_text' => $text,
        'is_approved' => 1,
    ]);
    Database::execute("UPDATE reviews SET reply_count = reply_count + 1 WHERE id = ?", [$reviewId]);
    return ['ok' => true, 'id' => $id];
}

function user_can_review(int $userId, int $productId): bool {
    return (bool) Database::fetch(
        "SELECT oi.id FROM order_items oi
         JOIN orders o ON o.id = oi.order_id
         WHERE o.user_id = ? AND oi.product_id = ?
         AND o.order_status IN ('delivered','picked_up','completed')
         LIMIT 1",
        [$userId, $productId]
    );
}

function recalc_product_rating(int $productId): void {
    $r = Database::fetch(
        "SELECT AVG(rating) a, COUNT(*) c FROM reviews WHERE product_id = ? AND is_approved = 1",
        [$productId]
    );
    Database::execute(
        "UPDATE products SET rating_avg = ?, review_count = ? WHERE id = ?",
        [round((float)($r['a'] ?? 0), 2), (int)($r['c'] ?? 0), $productId]
    );
}

function submit_product_review(int $userId, int $productId, int $rating, ?string $title, ?string $comment): array {
    $rating = max(1, min(5, $rating));

    // Prevent duplicate review for same product by same user
    $exists = Database::fetch(
        "SELECT id FROM reviews WHERE user_id = ? AND product_id = ? AND is_approved IN (0,1)",
        [$userId, $productId]
    );
    if ($exists) {
        return ['ok' => false, 'error' => 'You have already reviewed this product.'];
    }

    $verified = user_can_review($userId, $productId);

    $id = Database::insert('reviews', [
        'product_id' => $productId,
        'user_id' => $userId,
        'rating' => $rating,
        'title' => $title ? mb_substr(trim($title), 0, 190) : null,
        'comment' => $comment ? mb_substr(trim($comment), 0, 2000) : null,
        'is_verified_purchase' => $verified ? 1 : 0,
        'is_approved' => 0, // Pending admin approval
    ]);

    return ['ok' => true, 'id' => $id, 'verified' => $verified];
}

function review_get(int $id): ?array {
    return Database::fetch("SELECT * FROM reviews WHERE id = ?", [$id]);
}

function review_approve(int $id): void {
    Database::execute("UPDATE reviews SET is_approved = 1 WHERE id = ?", [$id]);
    $r = review_get($id);
    if ($r) recalc_product_rating((int)$r['product_id']);
}

function review_reject(int $id): void {
    Database::execute("UPDATE reviews SET is_approved = 0 WHERE id = ?", [$id]);
    $r = review_get($id);
    if ($r) recalc_product_rating((int)$r['product_id']);
}

function review_delete(int $id): void {
    $r = review_get($id);
    if (!$r) return;
    Database::execute("DELETE FROM review_replies WHERE review_id = ?", [$id]);
    Database::execute("DELETE FROM review_likes WHERE review_id = ?", [$id]);
    Database::execute("DELETE FROM reviews WHERE id = ?", [$id]);
    recalc_product_rating((int)$r['product_id']);
}