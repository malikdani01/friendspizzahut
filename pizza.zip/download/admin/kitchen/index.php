<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('kitchen_display')) { flash_error('Kitchen display is disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'Kitchen Display';

if (is_post()) {
    verify_csrf();
    if (post('action') === 'advance') {
        $id = (int)post('id');
        $to = (string)post('to');
        update_order_status($id, $to, (int)$_SESSION['admin_id']);
        flash_success('Order advanced.');
    }
    redirect(url('admin/kitchen/index.php'));
}

$cols = [
    'pending'   => ['New', 'bg-yellow-100 text-yellow-800'],
    'confirmed' => ['Confirmed', 'bg-blue-100 text-blue-800'],
    'preparing' => ['Preparing', 'bg-indigo-100 text-indigo-800'],
    'ready'     => ['Ready', 'bg-purple-100 text-purple-800'],
];
$orders = [];
foreach ($cols as $status => $info) {
    $orders[$status] = Database::fetchAll(
        "SELECT * FROM orders WHERE order_status = ? ORDER BY created_at ASC LIMIT 20",
        [$status]
    );
}
require __DIR__ . '/../common/header.php';
?>
<div class="grid grid-cols-1 md:grid-cols-4 gap-4">
  <?php foreach ($cols as $status => $info): ?>
  <div class="bg-gray-50 rounded-xl p-4">
    <div class="flex items-center justify-between mb-3">
      <h3 class="font-bold"><?= e($info[0]) ?></h3>
      <span class="text-xs px-2 py-1 rounded <?= $info[1] ?>"><?= count($orders[$status]) ?></span>
    </div>
    <div class="space-y-2">
      <?php foreach ($orders[$status] as $o): 
        $mins = (int) floor((time() - strtotime($o['created_at']))/60);
      ?>
        <div class="bg-white rounded-lg border p-3">
          <div class="flex justify-between items-start mb-1">
            <div class="font-mono text-xs"><?= e($o['order_number']) ?></div>
            <div class="text-xs text-gray-500"><?= $mins ?>m</div>
          </div>
          <div class="font-semibold text-sm mb-2"><?= e($o['customer_name']) ?></div>
          <?php $items = get_order_items((int)$o['id']); foreach ($items as $it): ?>
            <div class="text-xs text-gray-700"><?= (int)$it['quantity'] ?>× <?= e($it['product_name']) ?></div>
          <?php endforeach; ?>
          <div class="flex gap-1 mt-3">
            <?php 
              $next = match($status) {
                'pending' => 'confirmed',
                'confirmed' => 'preparing',
                'preparing' => 'ready',
                'ready' => 'out_for_delivery',
              };
            ?>
            <form method="post" class="flex-1"><?= csrf_field() ?>
              <input type="hidden" name="action" value="advance">
              <input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
              <input type="hidden" name="to" value="<?= $next ?>">
              <button class="w-full text-xs bg-brand text-white py-1.5 rounded">→ Advance</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (!$orders[$status]): ?><div class="text-xs text-gray-400 text-center py-4">Empty</div><?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>