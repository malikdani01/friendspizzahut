<?php
function wallet_balance(int $userId): float {
    $r = Database::fetch("SELECT COALESCE(SUM(amount), 0) s FROM wallet_transactions WHERE user_id = ?", [$userId]);
    return (float)($r['s'] ?? 0);
}

function wallet_credit(int $userId, float $amount, string $reason, ?int $orderId = null): void {
    Database::insert('wallet_transactions', [
        'user_id' => $userId, 'amount' => abs($amount),
        'type' => 'credit', 'reason' => $reason, 'order_id' => $orderId,
    ]);
}

function wallet_debit(int $userId, float $amount, string $reason, ?int $orderId = null): bool {
    if (wallet_balance($userId) < $amount) return false;
    Database::insert('wallet_transactions', [
        'user_id' => $userId, 'amount' => -abs($amount),
        'type' => 'debit', 'reason' => $reason, 'order_id' => $orderId,
    ]);
    return true;
}

function wallet_history(int $userId, int $limit = 50): array {
    return Database::fetchAll(
        "SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY id DESC LIMIT " . (int)$limit,
        [$userId]
    );
}