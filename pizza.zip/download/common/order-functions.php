<?php
function get_order(int $id): ?array {
    return Database::fetch("SELECT * FROM orders WHERE id = ?", [$id]);
}

function get_order_by_number(string $num): ?array {
    return Database::fetch("SELECT * FROM orders WHERE order_number = ?", [$num]);
}

function get_user_orders(int $userId, int $limit = 20): array {
    return Database::fetchAll(
        "SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT " . (int)$limit,
        [$userId]
    );
}

function get_order_items(int $orderId): array {
    $items = Database::fetchAll("SELECT * FROM order_items WHERE order_id = ? ORDER BY id", [$orderId]);
    foreach ($items as &$it) {
        $it['options'] = Database::fetchAll("SELECT * FROM order_item_options WHERE order_item_id = ?", [$it['id']]);
        $it['addons']  = Database::fetchAll("SELECT * FROM order_item_addons WHERE order_item_id = ?", [$it['id']]);
    }
    return $items;
}

function get_order_status_history(int $orderId): array {
    return Database::fetchAll(
        "SELECT * FROM order_status_history WHERE order_id = ? ORDER BY id ASC",
        [$orderId]
    );
}

function can_customer_cancel_order(array $order): bool {
    if (!feature_enabled('order_cancel')) return false;
    if (!in_array($order['order_status'], ['pending','confirmed'], true)) return false;
    $window = (int) setting('cancellation_window_minutes', 5);
    return (time() - strtotime($order['created_at'])) <= $window * 60;
}

function update_order_status(int $orderId, string $newStatus, ?int $adminId = null, ?int $customerId = null, string $note = ''): bool {
    $order = get_order($orderId);
    if (!$order) return false;
    $oldStatus = $order['order_status'];
    if ($oldStatus === $newStatus) return true;

    Database::beginTransaction();
    try {
        Database::execute("UPDATE orders SET order_status = ? WHERE id = ?", [$newStatus, $orderId]);

        // Timestamps
        $col = match ($newStatus) {
            'confirmed'        => 'accepted_at',
            'preparing'        => 'preparing_at',
            'ready','ready_for_pickup' => 'ready_at',
            'out_for_delivery' => 'dispatched_at',
            'delivered'        => 'delivered_at',
            'completed'        => 'completed_at',
            'cancelled'        => 'cancelled_at',
            default            => null,
        };
        if ($col) Database::execute("UPDATE orders SET $col = NOW() WHERE id = ?", [$orderId]);

        Database::insert('order_status_history', [
            'order_id' => $orderId,
            'old_status' => $oldStatus,
            'new_status' => $newStatus,
            'changed_by_admin' => $adminId,
            'changed_by_user' => $customerId,
            'note' => mb_substr($note, 0, 500),
        ]);
        Database::commit();

        // Send WhatsApp notification (if enabled)
        if (feature_enabled('whatsapp_business_api') && whatsapp_business_is_enabled()) {
            try {
                whatsapp_notify_order($orderId, $newStatus);
            } catch (Throwable $e) {
                error_log('WhatsApp notify failed: ' . $e->getMessage());
            }
        }

        return true;
    } catch (Throwable $e) {
        Database::rollback();
        error_log('update_order_status: ' . $e->getMessage());
        return false;
    }
}

function cancel_order(int $orderId, string $reason, string $by = 'customer'): bool {
    $order = get_order($orderId);
    if (!$order) return false;
    Database::beginTransaction();
    try {
        Database::execute(
            "UPDATE orders SET order_status='cancelled', cancelled_at=NOW(), cancel_reason=?, cancelled_by=? WHERE id=?",
            [mb_substr($reason, 0, 250), $by, $orderId]
        );
        Database::insert('order_status_history', [
            'order_id' => $orderId, 'old_status' => $order['order_status'],
            'new_status' => 'cancelled', 'note' => $reason,
            'changed_by_admin' => $by === 'admin' ? ($_SESSION['admin_id'] ?? null) : null,
            'changed_by_user'  => $by === 'customer' ? ($_SESSION['user_id'] ?? null) : null,
        ]);
        Database::commit();
        return true;
    } catch (Throwable $e) {
        Database::rollback();
        return false;
    }
}

function order_status_label(string $s): string {
    return match ($s) {
        'pending'          => 'Pending',
        'confirmed'        => 'Confirmed',
        'preparing'        => 'Preparing',
        'ready'            => 'Ready',
        'ready_for_pickup' => 'Ready for Pickup',
        'out_for_delivery' => 'Out for Delivery',
        'delivered'        => 'Delivered',
        'picked_up'        => 'Picked Up',
        'completed'        => 'Completed',
        'cancelled'        => 'Cancelled',
        'refunded'         => 'Refunded',
        default            => ucwords(str_replace('_',' ', $s)),
    };
}