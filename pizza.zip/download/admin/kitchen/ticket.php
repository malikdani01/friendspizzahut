<?php
// admin/kitchen/ticket.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id', 0);
$o = get_order($id);
if (!$o) { flash_error('Not found.'); redirect(url('admin/kitchen/index.php')); }
$items = get_order_items($id);
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Kitchen Ticket</title>
<style>body{font-family:monospace;max-width:420px;margin:0 auto;padding:10px}h1{text-align:center;font-size:20px}hr{border:0;border-top:2px solid #000}table{width:100%;font-size:14px}</style>
</head><body onload="window.print()">
<h1>KITCHEN ORDER</h1>
<hr>
<div style="font-size:16px"><strong>#<?= e($o['order_number']) ?></strong> — <?= e(strtoupper($o['order_type'])) ?></div>
<div><?= date('d M, H:i', strtotime($o['created_at'])) ?></div>
<hr>
<table>
<?php foreach ($items as $it): ?>
<tr><td style="font-size:20px;padding:8px 0"><strong><?= (int)$it['quantity'] ?>× <?= e($it['product_name']) ?></strong></td></tr>
<?php foreach ($it['options'] as $op): ?><tr><td style="font-size:14px;padding-left:20px">→ <?= e($op['variation_option_name']) ?></td></tr><?php endforeach; ?>
<?php foreach ($it['addons'] as $ad): ?><tr><td style="font-size:14px;padding-left:20px">+ <?= e($ad['addon_name']) ?></td></tr><?php endforeach; ?>
<?php if ($it['special_instructions']): ?><tr><td style="font-size:14px;padding-left:20px;font-style:italic">Note: <?= e($it['special_instructions']) ?></td></tr><?php endif; ?>
<tr><td>&nbsp;</td></tr>
<?php endforeach; ?>
</table>
<hr>
<?php if ($o['customer_note']): ?><div style="font-size:14px"><strong>Customer note:</strong> <?= e($o['customer_note']) ?></div><?php endif; ?>
</body></html>