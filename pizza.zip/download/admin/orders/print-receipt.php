<?php
// admin/orders/print-receipt.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id', 0);
$o = get_order($id);
if (!$o) { flash_error('Not found.'); redirect(url('admin/orders/index.php')); }
$items = get_order_items($id);
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Receipt</title>
<style>body{font-family:monospace;max-width:320px;margin:0 auto;padding:10px;font-size:12px}h1{text-align:center;font-size:16px;margin:5px 0}hr{border:0;border-top:1px dashed #000}table{width:100%}.r{text-align:right}.b{font-weight:bold}</style>
</head><body onload="window.print()">
<h1>FRIENDS PIZZA HUT</h1>
<div style="text-align:center;font-size:10px"><?= e(setting('restaurant_address')) ?><br><?= e(setting('restaurant_phone')) ?></div>
<hr>
<div>Order: <?= e($o['order_number']) ?></div>
<div>Date: <?= date('d M Y, H:i', strtotime($o['created_at'])) ?></div>
<div>Customer: <?= e($o['customer_name']) ?></div>
<div>Phone: <?= e($o['customer_phone']) ?></div>
<hr>
<table>
<?php foreach ($items as $it): ?>
<tr><td colspan="2" class="b"><?= e($it['product_name']) ?></td></tr>
<tr><td>&nbsp;&nbsp;<?= (int)$it['quantity'] ?> × <?= money($it['unit_price']) ?></td><td class="r"><?= money($it['line_total']) ?></td></tr>
<?php foreach ($it['options'] as $op): ?><tr><td colspan="2" style="font-size:10px">&nbsp;&nbsp;<?= e($op['variation_option_name']) ?></td></tr><?php endforeach; ?>
<?php foreach ($it['addons'] as $ad): ?><tr><td colspan="2" style="font-size:10px">&nbsp;&nbsp;+ <?= e($ad['addon_name']) ?> (<?= money($ad['addon_price']) ?>)</td></tr><?php endforeach; ?>
<?php endforeach; ?>
</table>
<hr>
<table>
<tr><td>Subtotal</td><td class="r"><?= money($o['subtotal']) ?></td></tr>
<?php if ((float)$o['discount_total'] > 0): ?><tr><td>Discount</td><td class="r">-<?= money($o['discount_total']) ?></td></tr><?php endif; ?>
<tr><td>Delivery</td><td class="r"><?= money($o['delivery_fee']) ?></td></tr>
<?php if ((float)$o['tax_amount'] > 0): ?><tr><td>Tax</td><td class="r"><?= money($o['tax_amount']) ?></td></tr><?php endif; ?>
<tr class="b"><td>TOTAL</td><td class="r"><?= money($o['total']) ?></td></tr>
</table>
<hr>
<div style="text-align:center;font-size:10px">Payment: <?= e(strtoupper($o['payment_method'])) ?><br>Thank you!</div>
</body></html>