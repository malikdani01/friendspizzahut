<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('recipe_tracking')) {
    flash_error('Recipe tracking disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Recipes & Ingredients';

$productId = (int)get('product_id', 0);

if (is_post()) {
    verify_csrf();
    if (post('action') === 'add') {
        Database::insert('recipe_ingredients', [
            'product_id' => (int)post('product_id'),
            'ingredient_product_id' => (int)post('ingredient_product_id'),
            'quantity' => (float)post('quantity', 0),
        ]);
        flash_success('Ingredient added.');
    } elseif (post('action') === 'delete') {
        Database::execute("DELETE FROM recipe_ingredients WHERE id = ?", [(int)post('id')]);
        flash_success('Removed.');
    }
    redirect(url('admin/recipes/index.php?product_id=' . $productId));
}

$products = Database::fetchAll("SELECT id, name FROM products WHERE status='active' ORDER BY name");
$ingredients = $products; // same list — one product can be ingredient of another
$recipe = $productId ? get_recipe($productId) : [];

require __DIR__ . '/../common/header.php';
?>

<div class="grid md:grid-cols-3 gap-6">

  <div class="bg-white rounded-xl border p-5 h-fit">
    <h3 class="font-bold mb-3">Select Product</h3>
    <form method="get" class="space-y-3">
      <select name="product_id" onchange="this.form.submit()" class="w-full border rounded px-3 py-2">
        <option value="">— Choose —</option>
        <?php foreach ($products as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= $productId == $p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </form>

    <?php if ($productId): ?>
    <hr class="my-4">
    <h3 class="font-bold mb-3">Add Ingredient</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add">
      <input type="hidden" name="product_id" value="<?= $productId ?>">
      <select name="ingredient_product_id" required class="w-full border rounded px-3 py-2">
        <option value="">— Ingredient —</option>
        <?php foreach ($ingredients as $i): ?>
          <option value="<?= (int)$i['id'] ?>"><?= e($i['name']) ?></option>
        <?php endforeach; ?>
      </select>
      <input type="number" step="0.01" name="quantity" required placeholder="Qty used" class="w-full border rounded px-3 py-2">
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Add</button>
    </form>
    <?php endif; ?>
  </div>

  <div class="md:col-span-2 bg-white rounded-xl border overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
        <tr>
          <th class="text-left px-4 py-3">Ingredient</th>
          <th class="text-right px-4 py-3">Qty / Unit</th>
          <th class="text-right px-4 py-3">Stock</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($recipe as $r): ?>
        <tr class="border-t">
          <td class="px-4 py-3 font-semibold"><?= e($r['ingredient_name']) ?></td>
          <td class="px-4 py-3 text-right"><?= (float)$r['quantity'] ?></td>
          <td class="px-4 py-3 text-right <?= (int)$r['current_stock'] <= 10 ? 'text-red-600 font-bold' : '' ?>"><?= (int)$r['current_stock'] ?></td>
          <td class="px-4 py-3 text-right">
            <form method="post" class="inline" data-confirm="Delete?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="text-red-600 text-xs">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$productId): ?>
          <tr><td colspan="4" class="py-8 text-center text-gray-400">Select a product to manage its recipe.</td></tr>
        <?php elseif (!$recipe): ?>
          <tr><td colspan="4" class="py-8 text-center text-gray-400">No ingredients yet for this product.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>