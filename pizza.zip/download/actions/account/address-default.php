<?php
// actions/account/address-default.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('addresses.php'));
verify_csrf();
$uid = (int)$_SESSION['user_id'];
Database::execute("UPDATE addresses SET is_default=0 WHERE user_id=?", [$uid]);
Database::execute("UPDATE addresses SET is_default=1 WHERE id=? AND user_id=?", [(int)post('id'), $uid]);
flash_success('Default set.');
redirect(url('addresses.php'));