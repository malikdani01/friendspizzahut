INSERT INTO roles (name, slug, description, is_system) VALUES
('Super Admin','super-admin','Full access',1),
('Manager','manager','Store manager',0),
('Cashier','cashier','Process payments',0),
('Kitchen','kitchen','Kitchen staff',0),
('Rider','rider','Delivery rider',0);

INSERT INTO permissions (name, slug, module) VALUES
('View Orders','orders.view','orders'),
('Update Orders','orders.update','orders'),
('Cancel Orders','orders.cancel','orders'),
('View Products','products.view','products'),
('Create Products','products.create','products'),
('Edit Products','products.edit','products'),
('Delete Products','products.delete','products'),
('View Customers','customers.view','customers'),
('Block Customers','customers.block','customers'),
('View Payments','payments.view','payments'),
('Verify Payments','payments.verify','payments'),
('View Reports','reports.view','reports'),
('View Settings','settings.view','settings'),
('Edit Settings','settings.edit','settings'),
('Manage Staff','staff.manage','staff');