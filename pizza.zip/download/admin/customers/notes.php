<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/customers/index.php'));
verify_csrf();
$id = (int)post('id', 0);
$note = trim((string)post('note', ''));
if ($note) {
    Database::insert('audit_logs', [
        'user_type' => 'admin', 'user_id' => $_SESSION['admin_id'],
        'action' => 'customer.note', 'entity' => 'user', 'entity_id' => $id,
        'new_data' => json_encode(['note' => $note]),
    ]);
    flash_success('Note saved.');
}
redirect(url('admin/customers/view.php?id=' . $id));