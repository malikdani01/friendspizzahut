<?php
require_once __DIR__ . '/../../common/bootstrap.php';
header('Content-Type: application/json');

if (!customer_logged_in()) {
    echo json_encode(['ok' => false, 'error' => 'Login required']);
    exit;
}
if (!is_post()) {
    echo json_encode(['ok' => false, 'error' => 'Invalid method']);
    exit;
}

// CSRF check
$token = $_POST['csrf_token'] ?? '';
if (!hash_equals($_SESSION['_csrf'] ?? '', $token)) {
    echo json_encode(['ok' => false, 'error' => 'CSRF failed']);
    exit;
}

$reviewId = (int)($_POST['review_id'] ?? 0);
$userId = (int)$_SESSION['user_id'];

$review = Database::fetch("SELECT id FROM reviews WHERE id = ? AND is_approved = 1", [$reviewId]);
if (!$review) {
    echo json_encode(['ok' => false, 'error' => 'Review not found']);
    exit;
}

$liked = review_toggle_like($reviewId, $userId);
echo json_encode([
    'ok' => true,
    'liked' => $liked,
    'count' => review_like_count($reviewId),
]);