<?php
require_once __DIR__ . '/common/bootstrap.php';
if (customer_logged_in()) redirect(url('account.php'));
$pageTitle = 'Forgot Password';
$done = false;
$error = '';
if (is_post()) {
    verify_csrf();
    $identifier = trim((string)post('identifier',''));
    $user = Database::fetch("SELECT * FROM users WHERE phone=? OR email=? LIMIT 1", [$identifier, $identifier]);
    if ($user) {
        $token = bin2hex(random_bytes(32));
        Database::insert('password_resets', [
            'user_type' => 'customer', 'user_id' => (int)$user['id'],
            'token' => $token, 'expires_at' => date('Y-m-d H:i:s', time() + 3600),
        ]);
        // In production: send email/SMS with reset link
        $_SESSION['_reset_link'] = url('reset-password.php?token=' . $token);
    }
    $done = true; // Always show success (prevent user enumeration)
}
require __DIR__ . '/common/header.php';
?>
<div class="max-w-md mx-auto py-12 px-4">
  <h1 class="text-3xl font-extrabold mb-2">Forgot Password</h1>
  <p class="text-white/60 mb-6">Enter your phone or email</p>
  <?php if ($done): ?>
    <div class="bg-green-500/20 border border-green-500/40 text-green-200 px-4 py-3 rounded-lg mb-4 text-sm">
      If an account exists, a reset link has been sent.
    </div>
    <a href="<?= url('login.php') ?>" class="text-brand hover:underline text-sm">← Back to login</a>
  <?php else: ?>
    <form method="post" class="space-y-4 bg-white/5 border border-white/10 rounded-2xl p-6">
      <?= csrf_field() ?>
      <input name="identifier" required placeholder="Phone or email" class="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 outline-none focus:border-brand">
      <button class="w-full bg-brand hover:bg-red-700 py-3 rounded-lg font-bold">Send Reset Link</button>
      <p class="text-center text-sm text-white/60"><a href="<?= url('login.php') ?>" class="text-brand hover:underline">← Back to login</a></p>
    </form>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>