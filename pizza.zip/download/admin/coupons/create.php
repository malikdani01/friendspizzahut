<?php
// admin/coupons/create.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Add Coupon';
$errors = [];

if (is_post()) {
    verify_csrf();
    $code = strtoupper(trim((string)post('code','')));
    if (!$code) $errors[] = 'Code required.';
    if (Database::fetch("SELECT id FROM coupons WHERE code = ?", [$code])) $errors[] = 'Code already exists.';
    if (!$errors) {
        Database::insert('coupons', [
            'code' => $code,
            'description' => trim((string)post('description','')) ?: null,
            'discount_type' => (string)post('discount_type','percentage'),
            'discount_value' => (float)post('discount_value',0),
            'min_order' => (float)post('min_order',0),
            'max_discount' => post('max_discount') !== '' ? (float)post('max_discount') : null,
            'usage_limit' => post('usage_limit') !== '' ? (int)post('usage_limit') : null,
            'per_user_limit' => post('per_user_limit') !== '' ? (int)post('per_user_limit') : null,
            'start_date' => post('start_date') ?: null,
            'end_date' => post('end_date') ?: null,
            'is_active' => post('is_active') ? 1 : 0,
        ]);
        flash_success('Coupon created.');
        redirect(url('admin/coupons/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-2xl">
  <?php if ($errors): ?><div class="bg-red-50 text-red-700 px-4 py-3 rounded mb-4"><?php foreach($errors as $e_) echo '• '.e($e_).'<br>'; ?></div><?php endif; ?>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input name="code" placeholder="Coupon code (e.g. SAVE20)" required class="w-full border rounded px-3 py-2 uppercase">
    <input name="description" placeholder="Description" class="w-full border rounded px-3 py-2">
    <div class="grid grid-cols-2 gap-4">
      <select name="discount_type" class="border rounded px-3 py-2">
        <option value="percentage">Percentage (%)</option>
        <option value="fixed">Fixed amount</option>
        <option value="free_delivery">Free delivery</option>
      </select>
      <input type="number" step="0.01" name="discount_value" placeholder="Value" required class="border rounded px-3 py-2">
      <input type="number" step="0.01" name="min_order" placeholder="Min order" value="0" class="border rounded px-3 py-2">
      <input type="number" step="0.01" name="max_discount" placeholder="Max discount (optional)" class="border rounded px-3 py-2">
      <input type="number" name="usage_limit" placeholder="Total usage limit" class="border rounded px-3 py-2">
      <input type="number" name="per_user_limit" placeholder="Per user limit" class="border rounded px-3 py-2">
      <input type="datetime-local" name="start_date" class="border rounded px-3 py-2">
      <input type="datetime-local" name="end_date" class="border rounded px-3 py-2">
    </div>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" checked> Active</label>
    <div class="flex gap-2">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Create</button>
      <a href="<?= url('admin/coupons/index.php') ?>" class="px-6 py-2.5 rounded-lg bg-gray-100">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>