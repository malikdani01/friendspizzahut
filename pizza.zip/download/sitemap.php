<?php
require_once __DIR__ . '/common/bootstrap.php';
header('Content-Type: application/xml; charset=utf-8');
$urls = [url('index.php'), url('menu.php'), url('deals.php'), url('offers.php'), url('contact.php'), url('about.php')];
foreach (get_categories(true) as $c) $urls[] = url('category.php?slug=' . urlencode($c['slug']));
foreach (Database::fetchAll("SELECT slug FROM products WHERE status='active' LIMIT 500") as $p) $urls[] = url('product.php?slug=' . urlencode($p['slug']));
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
foreach ($urls as $u) echo "  <url><loc>" . e($u) . "</loc></url>\n";
echo '</urlset>';