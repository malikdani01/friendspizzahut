<?php
// notifications.php (settings)
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Notification Settings';
if (is_post()) {
    verify_csrf();
    foreach (['notify_admin_email','notify_customer_sms'] as $k) update_setting($k, isset($_POST[$k]) ? '1' : '0');
    flash_success('Saved.');
    redirect(url('admin/settings/notifications.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <label class="flex items-center gap-2"><input type="checkbox" name="notify_admin_email" value="1" <?= setting('notify_admin_email','1')=='1'?'checked':'' ?>> Email admin on new order</label>
    <label class="flex items-center gap-2"><input type="checkbox" name="notify_customer_sms" value="1" <?= setting('notify_customer_sms','0')=='1'?'checked':'' ?>> SMS customer on order status</label>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>