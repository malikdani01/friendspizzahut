<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('daily_closing')) {
    flash_error('Daily closing feature disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Daily Closing';

$date = (string)get('date', date('Y-m-d'));
$data = get_daily_closing($date);
$autoPrint = get('print') === '1';

require __DIR__ . '/../common/header.php';
?>

<div class="flex flex-wrap items-center justify-between gap-3 mb-5">
  <form class="flex gap-2">
    <input type="date" name="date" value="<?= e($date) ?>" class="border rounded px-3 py-2 text-sm">
    <button class="bg-gray-800 text-white px-4 py-2 rounded text-sm">View</button>
  </form>
  <div class="flex gap-2">
    <a href="?date=<?= e($date) ?>&print=1" target="_blank" class="bg-brand text-white px-4 py-2 rounded text-sm font-semibold">
      <i class="fa-solid fa-print mr-1"></i> Print Report
    </a>
  </div>
</div>

<div class="space-y-5 <?= $autoPrint ? '' : '' ?>">

  <!-- Summary Cards -->
  <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
    <div class="bg-white rounded-xl border p-5">
      <div class="text-xs text-gray-500 uppercase">Total Orders</div>
      <div class="text-2xl font-extrabold"><?= number_format($data['total_orders']) ?></div>
      <div class="text-xs text-green-600 mt-1"><?= (int)$data['completed_orders'] ?> completed</div>
      <?php if ($data['cancelled_orders']): ?>
      <div class="text-xs text-red-600"><?= (int)$data['cancelled_orders'] ?> cancelled</div>
      <?php endif; ?>
    </div>
    <div class="bg-white rounded-xl border p-5">
      <div class="text-xs text-gray-500 uppercase">Gross Revenue</div>
      <div class="text-2xl font-extrabold text-brand"><?= money($data['gross_revenue']) ?></div>
    </div>
    <div class="bg-white rounded-xl border p-5">
      <div class="text-xs text-gray-500 uppercase">Net Revenue</div>
      <div class="text-2xl font-extrabold text-green-600"><?= money($data['net_revenue']) ?></div>
    </div>
    <div class="bg-white rounded-xl border p-5">
      <div class="text-xs text-gray-500 uppercase">Avg Order</div>
      <div class="text-2xl font-extrabold">
        <?= $data['completed_orders'] ? money($data['gross_revenue'] / $data['completed_orders']) : money(0) ?>
      </div>
    </div>
  </div>

  <!-- Cash Register -->
  <div class="bg-gradient-to-br from-gray-900 to-black text-white rounded-xl p-6">
    <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
      <i class="fa-solid fa-cash-register text-brand"></i> Cash Register
    </h3>
    <div class="grid grid-cols-3 gap-4">
      <div>
        <div class="text-xs opacity-70 uppercase">Cash (COD)</div>
        <div class="text-2xl font-extrabold"><?= money($data['cash_collected']) ?></div>
      </div>
      <div>
        <div class="text-xs opacity-70 uppercase">JazzCash</div>
        <div class="text-2xl font-extrabold"><?= money($data['jazzcash_collected']) ?></div>
      </div>
      <div>
        <div class="text-xs opacity-70 uppercase">Bank Transfer</div>
        <div class="text-2xl font-extrabold"><?= money($data['bank_collected']) ?></div>
      </div>
    </div>
    <div class="mt-4 pt-4 border-t border-white/10 flex justify-between items-center">
      <span class="text-sm uppercase">Total Collected</span>
      <span class="text-3xl font-extrabold text-brand">
        <?= money($data['cash_collected'] + $data['jazzcash_collected'] + $data['bank_collected']) ?>
      </span>
    </div>
  </div>

  <!-- Order Types -->
  <div class="grid md:grid-cols-2 gap-5">
    <div class="bg-white rounded-xl border p-5">
      <h3 class="font-bold mb-3">Order Type Split</h3>
      <div class="space-y-3">
        <div class="flex justify-between">
          <span><i class="fa-solid fa-truck text-brand mr-2"></i> Delivery</span>
          <span class="font-bold"><?= (int)$data['by_type']['delivery'] ?></span>
        </div>
        <div class="flex justify-between">
          <span><i class="fa-solid fa-store text-brand mr-2"></i> Pickup</span>
          <span class="font-bold"><?= (int)$data['by_type']['pickup'] ?></span>
        </div>
      </div>
    </div>

    <div class="bg-white rounded-xl border p-5">
      <h3 class="font-bold mb-3">Payment Method</h3>
      <?php if (!$data['by_payment']): ?>
        <div class="text-sm text-gray-400">No payments.</div>
      <?php else: foreach ($data['by_payment'] as $method => $info): ?>
      <div class="flex justify-between py-1">
        <span class="uppercase text-sm"><?= e($method) ?> <span class="text-gray-400">(<?= (int)$info['count'] ?>)</span></span>
        <span class="font-bold"><?= money($info['amount']) ?></span>
      </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <!-- Hourly Breakdown -->
  <?php if ($data['by_hour']): ?>
  <div class="bg-white rounded-xl border p-5">
    <h3 class="font-bold mb-3">Hourly Breakdown</h3>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="text-xs text-gray-500 uppercase">
          <tr>
            <th class="text-left py-2">Hour</th>
            <th class="text-right">Orders</th>
            <th class="text-right">Revenue</th>
          </tr>
        </thead>
        <tbody>
          <?php for ($h = 0; $h < 24; $h++): if (!isset($data['by_hour'][$h])) continue; ?>
          <tr class="border-t">
            <td class="py-2"><?= sprintf('%02d:00 - %02d:59', $h, $h) ?></td>
            <td class="text-right"><?= (int)$data['by_hour'][$h]['count'] ?></td>
            <td class="text-right font-semibold"><?= money($data['by_hour'][$h]['amount']) ?></td>
          </tr>
          <?php endfor; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

  <!-- Top Products -->
  <?php if ($data['top_products']): ?>
  <div class="bg-white rounded-xl border p-5">
    <h3 class="font-bold mb-3">Top Products</h3>
    <table class="w-full text-sm">
      <thead class="text-xs text-gray-500 uppercase">
        <tr>
          <th class="text-left py-2">Product</th>
          <th class="text-right">Qty</th>
          <th class="text-right">Revenue</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($data['top_products'] as $p): ?>
        <tr class="border-t">
          <td class="py-2"><?= e($p['product_name']) ?></td>
          <td class="text-right"><?= (int)$p['qty'] ?></td>
          <td class="text-right font-semibold"><?= money($p['revenue']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>

</div>

<?php if ($autoPrint): ?>
<script>window.print();</script>
<?php endif; ?>

<?php require __DIR__ . '/../common/footer.php'; ?>