<?php
function validate_coupon(string $code, float $subtotal, ?int $userId = null): array {
    $code = strtoupper(trim($code));
    if (!$code) return ['ok' => false, 'error' => 'Coupon code required.'];
    $c = Database::fetch("SELECT * FROM coupons WHERE code = ? AND is_active = 1", [$code]);
    if (!$c) return ['ok' => false, 'error' => 'Invalid coupon code.'];

    $now = date('Y-m-d H:i:s');
    if ($c['start_date'] && $now < $c['start_date']) return ['ok' => false, 'error' => 'Coupon not yet active.'];
    if ($c['end_date'] && $now > $c['end_date'])   return ['ok' => false, 'error' => 'Coupon expired.'];
    if ((float)$c['min_order'] > 0 && $subtotal < (float)$c['min_order']) {
        return ['ok' => false, 'error' => 'Minimum order ' . money($c['min_order']) . ' required.'];
    }
    if ($c['usage_limit']) {
        $used = (int)(Database::fetch("SELECT COUNT(*) c FROM coupon_usage WHERE coupon_id=?", [$c['id']])['c'] ?? 0);
        if ($used >= (int)$c['usage_limit']) return ['ok' => false, 'error' => 'Coupon usage limit reached.'];
    }
    if ($userId && $c['per_user_limit']) {
        $usedByUser = (int)(Database::fetch("SELECT COUNT(*) c FROM coupon_usage WHERE coupon_id=? AND user_id=?", [$c['id'], $userId])['c'] ?? 0);
        if ($usedByUser >= (int)$c['per_user_limit']) return ['ok' => false, 'error' => 'You already used this coupon.'];
    }

    $discount = 0;
    if ($c['discount_type'] === 'percentage') {
        $discount = $subtotal * (float)$c['discount_value'] / 100;
        if ($c['max_discount'] && $discount > (float)$c['max_discount']) $discount = (float)$c['max_discount'];
    } elseif ($c['discount_type'] === 'fixed') {
        $discount = (float)$c['discount_value'];
    } elseif ($c['discount_type'] === 'free_delivery') {
        $discount = (float) setting('default_delivery_fee', 100);
    }
    $discount = min($discount, $subtotal);

    return ['ok' => true, 'coupon' => $c, 'discount' => round($discount, 2)];
}

function record_coupon_usage(int $couponId, ?int $userId, int $orderId, float $discount): void {
    Database::insert('coupon_usage', [
        'coupon_id' => $couponId, 'user_id' => $userId,
        'order_id' => $orderId, 'discount_amount' => $discount,
    ]);
}