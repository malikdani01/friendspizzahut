<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Add Add-on';
$errors = [];
if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name',''));
    $price = (float)post('price', 0);
    if (!$name) $errors[] = 'Name required.';
    if ($price < 0) $errors[] = 'Price invalid.';
    if (!$errors) {
        Database::insert('addons', [
            'name' => $name, 'price' => $price,
            'category' => (string)post('category','topping'),
            'description' => trim((string)post('description','')) ?: null,
            'is_active' => post('is_active') ? 1 : 0,
            'sort_order' => (int)post('sort_order',0),
        ]);
        flash_success('Add-on created.');
        redirect(url('admin/addons/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl">
  <?php if ($errors): ?><div class="bg-red-50 text-red-700 px-4 py-3 rounded mb-4"><?php foreach($errors as $e_) echo '• '.e($e_).'<br>'; ?></div><?php endif; ?>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input name="name" required placeholder="Name" class="w-full border rounded px-3 py-2">
    <input type="number" step="0.01" name="price" required placeholder="Price" class="w-full border rounded px-3 py-2">
    <input name="category" value="topping" placeholder="Category" class="w-full border rounded px-3 py-2">
    <textarea name="description" rows="2" placeholder="Description" class="w-full border rounded px-3 py-2"></textarea>
    <input type="number" name="sort_order" value="0" class="w-full border rounded px-3 py-2">
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" checked> Active</label>
    <div class="flex gap-2">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Create</button>
      <a href="<?= url('admin/addons/index.php') ?>" class="px-6 py-2.5 rounded-lg bg-gray-100">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>