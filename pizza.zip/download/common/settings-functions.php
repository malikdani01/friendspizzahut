<?php
/**
 * Settings helper — cached key/value lookup
 */

function setting(string $key, $default = null)
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (Database::fetchAll("SELECT setting_key, setting_value FROM settings") as $row) {
                $cache[$row['setting_key']] = $row['setting_value'];
            }
        } catch (Throwable $e) {
            $cache = [];
        }
    }
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function update_setting(string $key, $value): void
{
    $exists = Database::fetch("SELECT id FROM settings WHERE setting_key = ?", [$key]);
    if ($exists) {
        Database::execute("UPDATE settings SET setting_value = ? WHERE setting_key = ?", [$value, $key]);
    } else {
        Database::insert('settings', ['setting_key' => $key, 'setting_value' => $value, 'setting_group' => 'general']);
    }
}

function get_settings_group(string $group): array
{
    return Database::fetchAll("SELECT setting_key, setting_value FROM settings WHERE setting_group = ?", [$group]);
}

function save_settings_array(array $kv, string $group = 'general'): void
{
    foreach ($kv as $k => $v) {
        $exists = Database::fetch("SELECT id FROM settings WHERE setting_key = ?", [$k]);
        if ($exists) {
            Database::execute("UPDATE settings SET setting_value = ? WHERE setting_key = ?", [(string)$v, $k]);
        } else {
            Database::insert('settings', ['setting_key' => $k, 'setting_value' => (string)$v, 'setting_group' => $group]);
        }
    }
}