<?php /** @var string $status */
echo status_badge($status ?? 'pending');