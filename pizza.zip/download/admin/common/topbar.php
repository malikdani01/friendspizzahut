<header class="bg-white border-b border-gray-200 sticky top-0 z-30">
  <div class="px-4 md:px-6 py-3 flex items-center justify-between">
    <button onclick="document.getElementById('adminSidebar').classList.toggle('-translate-x-full')" class="md:hidden text-gray-700 text-xl"><i class="fa-solid fa-bars"></i></button>
    <h1 class="text-lg md:text-xl font-bold text-gray-900"><?= e($pageTitle ?? 'Admin') ?></h1>
    <a href="<?= url('index.php') ?>" target="_blank" class="text-sm text-gray-500 hover:text-brand"><i class="fa-solid fa-external-link"></i></a>
  </div>
</header>