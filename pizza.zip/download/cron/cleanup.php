<?php
require_once __DIR__ . '/../common/bootstrap.php';
$old = date('Y-m-d H:i:s', time() - 30*24*3600);
$n1 = Database::execute("DELETE FROM login_attempts WHERE created_at < ?", [$old]);
$n2 = Database::execute("DELETE FROM password_resets WHERE expires_at < ?", [$old]);
echo "[" . date('c') . "] Cleaned: login_attempts=$n1, password_resets=$n2\n";