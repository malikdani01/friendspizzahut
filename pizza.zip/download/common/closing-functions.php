<?php
/**
 * Daily closing / cash register report
 * Feature-gated: daily_closing
 */

function get_daily_closing(string $date): array {
    $data = [
        'date' => $date,
        'total_orders' => 0,
        'completed_orders' => 0,
        'cancelled_orders' => 0,
        'gross_revenue' => 0.0,
        'net_revenue' => 0.0,
        'cash_collected' => 0.0,
        'jazzcash_collected' => 0.0,
        'bank_collected' => 0.0,
        'by_hour' => [],
        'by_payment' => [],
        'by_type' => ['delivery' => 0, 'pickup' => 0],
        'top_products' => [],
        'rider_payouts' => [],
    ];

    // Order counts
    $row = Database::fetch(
        "SELECT COUNT(*) c,
                SUM(CASE WHEN order_status NOT IN ('cancelled','refunded') THEN 1 ELSE 0 END) active_c,
                SUM(CASE WHEN order_status = 'cancelled' THEN 1 ELSE 0 END) cancelled_c,
                COALESCE(SUM(CASE WHEN order_status NOT IN ('cancelled','refunded') THEN total ELSE 0 END), 0) gross
         FROM orders WHERE DATE(created_at) = ?",
        [$date]
    );
    $data['total_orders'] = (int)($row['c'] ?? 0);
    $data['completed_orders'] = (int)($row['active_c'] ?? 0);
    $data['cancelled_orders'] = (int)($row['cancelled_c'] ?? 0);
    $data['gross_revenue'] = (float)($row['gross'] ?? 0);

    // Payment breakdown
    $payments = Database::fetchAll(
        "SELECT payment_method, COUNT(*) c, COALESCE(SUM(total), 0) amount
         FROM orders
         WHERE DATE(created_at) = ? AND order_status NOT IN ('cancelled','refunded')
         GROUP BY payment_method",
        [$date]
    );
    foreach ($payments as $p) {
        $data['by_payment'][$p['payment_method']] = [
            'count' => (int)$p['c'],
            'amount' => (float)$p['amount'],
        ];
        $m = $p['payment_method'];
        if ($m === 'cod') $data['cash_collected'] += (float)$p['amount'];
        elseif ($m === 'jazzcash') $data['jazzcash_collected'] += (float)$p['amount'];
        elseif ($m === 'bank') $data['bank_collected'] += (float)$p['amount'];
    }

    // Order type split
    $types = Database::fetchAll(
        "SELECT order_type, COUNT(*) c FROM orders
         WHERE DATE(created_at) = ? AND order_status NOT IN ('cancelled','refunded')
         GROUP BY order_type",
        [$date]
    );
    foreach ($types as $t) {
        $data['by_type'][$t['order_type']] = (int)$t['c'];
    }

    // Hourly breakdown
    $hours = Database::fetchAll(
        "SELECT HOUR(created_at) h, COUNT(*) c, COALESCE(SUM(total), 0) amt
         FROM orders WHERE DATE(created_at) = ? AND order_status NOT IN ('cancelled','refunded')
         GROUP BY HOUR(created_at) ORDER BY h",
        [$date]
    );
    foreach ($hours as $h) {
        $data['by_hour'][(int)$h['h']] = [
            'count' => (int)$h['c'],
            'amount' => (float)$h['amt'],
        ];
    }

    // Top products
    $data['top_products'] = Database::fetchAll(
        "SELECT oi.product_name, SUM(oi.quantity) qty, SUM(oi.line_total) revenue
         FROM order_items oi
         JOIN orders o ON o.id = oi.order_id
         WHERE DATE(o.created_at) = ? AND o.order_status NOT IN ('cancelled','refunded')
         GROUP BY oi.product_name ORDER BY qty DESC LIMIT 10",
        [$date]
    );

    // Net revenue = gross - refunds - discounts
    $refunds = (float)(Database::fetch(
        "SELECT COALESCE(SUM(amount), 0) s FROM refunds
         WHERE DATE(created_at) = ? AND status = 'refunded'",
        [$date]
    )['s'] ?? 0);
    $data['net_revenue'] = $data['gross_revenue'] - $refunds;

    return $data;
}