<?php
/**
 * QR Menu — table-based ordering
 */

function generate_qr_url(int $tableNumber): string {
    return url('qr-menu.php?table=' . $tableNumber);
}

/**
 * Generate QR code using free API (Google Charts)
 * NO library needed — pure image URL
 */
function qr_image_url(string $data, int $size = 300): string {
    return 'https://api.qrserver.com/v1/create-qr-code/?size=' . $size . 'x' . $size . '&data=' . urlencode($data);
}

function get_active_tables(): array {
    // Simple: 1-20 tables. Can be extended later.
    $tables = [];
    for ($i = 1; $i <= 20; $i++) {
        $tables[] = [
            'number' => $i,
            'url' => generate_qr_url($i),
        ];
    }
    return $tables;
}