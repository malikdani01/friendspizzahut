<?php
function seo_title(?string $page = null): string {
    $base = setting('restaurant_name', 'Friends Pizza Hut');
    return $page ? "$page — $base" : $base;
}
function seo_meta(?string $desc = null): string {
    $d = $desc ?: setting('tagline', 'Hot • Fresh • Delicious');
    return '<meta name="description" content="' . e($d) . '">';
}
function seo_og(string $title, string $desc, ?string $image = null): string {
    $html = '<meta property="og:title" content="' . e($title) . '">';
    $html .= '<meta property="og:description" content="' . e($desc) . '">';
    if ($image) $html .= '<meta property="og:image" content="' . e($image) . '">';
    return $html;
}