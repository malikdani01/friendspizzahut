<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Analytics';

$days = (int)get('days', 30);
$from = date('Y-m-d', strtotime("-{$days} days"));

$daily = Database::fetchAll("
  SELECT DATE(created_at) d, COUNT(*) orders, COALESCE(SUM(total),0) revenue
  FROM orders WHERE DATE(created_at) >= ? AND order_status NOT IN ('cancelled','refunded')
  GROUP BY DATE(created_at) ORDER BY d
", [$from]);

$statusCounts = Database::fetchAll("SELECT order_status, COUNT(*) c FROM orders GROUP BY order_status");
$topCats = Database::fetchAll("
  SELECT c.name, COUNT(oi.id) cnt, COALESCE(SUM(oi.line_total),0) revenue
  FROM order_items oi JOIN products p ON p.id=oi.product_id
  JOIN categories c ON c.id=p.category_id
  JOIN orders o ON o.id=oi.order_id
  WHERE o.order_status NOT IN ('cancelled','refunded')
  GROUP BY c.id ORDER BY revenue DESC LIMIT 10
");

require __DIR__ . '/../common/header.php';
?>
<div class="flex justify-between items-center mb-5">
  <div class="flex gap-2">
    <a href="?days=7"  class="px-3 py-1.5 rounded text-sm <?= $days==7?'bg-brand text-white':'bg-white border' ?>">7 days</a>
    <a href="?days=30" class="px-3 py-1.5 rounded text-sm <?= $days==30?'bg-brand text-white':'bg-white border' ?>">30 days</a>
    <a href="?days=90" class="px-3 py-1.5 rounded text-sm <?= $days==90?'bg-brand text-white':'bg-white border' ?>">90 days</a>
  </div>
</div>

<div class="grid lg:grid-cols-2 gap-6">
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <h3 class="font-bold mb-3">Daily Revenue (last <?= $days ?> days)</h3>
    <canvas id="revenueChart" height="200"></canvas>
  </div>
  <div class="bg-white rounded-xl shadow-sm border p-5">
    <h3 class="font-bold mb-3">Order Status</h3>
    <table class="w-full text-sm">
      <thead class="text-xs text-gray-500 uppercase"><tr><th class="text-left py-2">Status</th><th class="text-right">Count</th></tr></thead>
      <tbody>
        <?php foreach ($statusCounts as $s): ?>
          <tr class="border-t"><td class="py-2"><?= order_status_label($s['order_status']) ?></td><td class="text-right font-semibold"><?= (int)$s['c'] ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="lg:col-span-2 bg-white rounded-xl shadow-sm border p-5">
    <h3 class="font-bold mb-3">Top Categories</h3>
    <table class="w-full text-sm">
      <thead class="text-xs text-gray-500 uppercase"><tr><th class="text-left py-2">Category</th><th class="text-right">Items Sold</th><th class="text-right">Revenue</th></tr></thead>
      <tbody>
        <?php foreach ($topCats as $c): ?>
          <tr class="border-t"><td class="py-2"><?= e($c['name']) ?></td><td class="text-right"><?= (int)$c['cnt'] ?></td><td class="text-right font-semibold"><?= money($c['revenue']) ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('revenueChart').getContext('2d');
new Chart(ctx, {
  type: 'line',
  data: {
    labels: <?= json_encode(array_column($daily, 'd')) ?>,
    datasets: [{
      label: 'Revenue (Rs.)',
      data: <?= json_encode(array_map('floatval', array_column($daily, 'revenue'))) ?>,
      borderColor: '#dc2626', backgroundColor: 'rgba(220,38,38,0.1)', fill: true, tension: 0.3,
    }]
  },
  options: { responsive: true, plugins: { legend: { display: false } } }
});
</script>
<?php require __DIR__ . '/../common/footer.php'; ?>