<?php
// export.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$type = (string)get('type', 'orders');
$from = (string)get('from', date('Y-m-01'));
$to = (string)get('to', date('Y-m-d'));

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $type . '-report-' . $from . '-to-' . $to . '.csv"');
$out = fopen('php://output', 'w');

if ($type === 'orders') {
    fputcsv($out, ['Order #', 'Date', 'Customer', 'Phone', 'Status', 'Payment', 'Total']);
    foreach (Database::fetchAll("SELECT * FROM orders WHERE DATE(created_at) BETWEEN ? AND ? ORDER BY id DESC", [$from, $to]) as $r) {
        fputcsv($out, [$r['order_number'], $r['created_at'], $r['customer_name'], $r['customer_phone'], $r['order_status'], $r['payment_method'], $r['total']]);
    }
} elseif ($type === 'products') {
    fputcsv($out, ['Product', 'Qty Sold', 'Revenue']);
    foreach (report_top_products($from, $to, 500) as $r) fputcsv($out, [$r['product_name'], $r['qty'], $r['revenue']]);
} elseif ($type === 'customers') {
    fputcsv($out, ['Name', 'Phone', 'Orders', 'Spent']);
    foreach (report_top_customers($from, $to, 500) as $r) fputcsv($out, [$r['customer_name'], $r['customer_phone'], $r['orders'], $r['spent']]);
}
fclose($out);
exit;