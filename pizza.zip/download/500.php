<?php
// 500.php
require_once __DIR__ . '/common/bootstrap.php';
http_response_code(500);
$pageTitle = 'Server Error';
require __DIR__ . '/common/header.php';
?>
<div class="max-w-xl mx-auto px-4 py-24 text-center">
  <div class="text-7xl font-extrabold text-red-500 mb-4">500</div>
  <h1 class="text-2xl font-bold mb-3">Something Went Wrong</h1>
  <a href="<?= url('index.php') ?>" class="bg-brand px-6 py-3 rounded-full font-bold">Back Home</a>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>