<?php
// admin/offers/create.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Add Offer';
$errors = [];
if (is_post()) {
    verify_csrf();
    $title = trim((string)post('title',''));
    if (!$title) $errors[] = 'Title required.';
    if (!$errors) {
        Database::insert('offers', [
            'title' => $title,
            'description' => trim((string)post('description','')) ?: null,
            'offer_type' => (string)post('offer_type','percentage'),
            'discount_value' => (float)post('discount_value',0),
            'max_discount' => post('max_discount') !== '' ? (float)post('max_discount') : null,
            'min_order' => (float)post('min_order',0),
            'applies_to' => (string)post('applies_to','all'),
            'start_date' => post('start_date') ?: null,
            'end_date' => post('end_date') ?: null,
            'is_active' => post('is_active') ? 1 : 0,
        ]);
        flash_success('Offer created.');
        redirect(url('admin/offers/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-2xl">
  <?php if ($errors): ?><div class="bg-red-50 text-red-700 px-4 py-3 rounded mb-4"><?php foreach($errors as $e_) echo '• '.e($e_).'<br>'; ?></div><?php endif; ?>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input name="title" required placeholder="Offer title" class="w-full border rounded px-3 py-2">
    <textarea name="description" rows="2" placeholder="Description" class="w-full border rounded px-3 py-2"></textarea>
    <div class="grid grid-cols-2 gap-4">
      <select name="offer_type" class="border rounded px-3 py-2">
        <option value="percentage">Percentage off</option>
        <option value="fixed">Fixed amount off</option>
        <option value="free_delivery">Free delivery</option>
      </select>
      <input type="number" step="0.01" name="discount_value" placeholder="Value" required class="border rounded px-3 py-2">
      <input type="number" step="0.01" name="min_order" placeholder="Min order" value="0" class="border rounded px-3 py-2">
      <input type="number" step="0.01" name="max_discount" placeholder="Max discount" class="border rounded px-3 py-2">
      <input type="datetime-local" name="start_date" class="border rounded px-3 py-2">
      <input type="datetime-local" name="end_date" class="border rounded px-3 py-2">
    </div>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" checked> Active</label>
    <div class="flex gap-2">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Create</button>
      <a href="<?= url('admin/offers/index.php') ?>" class="px-6 py-2.5 rounded-lg bg-gray-100">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>