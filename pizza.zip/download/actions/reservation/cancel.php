<?php
/**
 * Customer Reservation — Cancel Action
 * Ye file reservations.php ke cancel button se call hoti hai.
 * Uses: reservation_cancel() from common/reservation-functions.php
 */
require_once __DIR__ . '/../../common/bootstrap.php';

if (!feature_enabled('table_reservation')) {
    redirect(url('index.php'));
}
require_customer();

if (!is_post()) {
    redirect(url('reservations.php'));
}
verify_csrf();

$id = (int)post('id', 0);
$reservation = reservation_get($id);

// Ownership check — customer apni hi reservation cancel kar sakta hai
if (!$reservation || (int)$reservation['user_id'] !== (int)$_SESSION['user_id']) {
    flash_error('Reservation nahi mili.');
    redirect(url('reservations.php'));
}

$result = reservation_cancel($id, 'Cancelled by customer', 'customer');

if ($result['ok']) {
    flash_success('Reservation cancel ho gayi.');
} else {
    flash_error($result['error']);
}

redirect(url('reservations.php'));