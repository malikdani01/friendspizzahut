<?php
function is_restaurant_accepting_scheduled(string $datetime): array {
    $ts = strtotime($datetime);
    if (!$ts) return ['ok' => false, 'error' => 'Invalid date/time.'];

    $now = time();
    // At least 60 minutes advance
    if ($ts < $now + 3600) {
        return ['ok' => false, 'error' => 'Minimum 1 hour advance required.'];
    }
    // Max 7 days ahead
    if ($ts > $now + 7 * 86400) {
        return ['ok' => false, 'error' => 'Maximum 7 days advance allowed.'];
    }

    $tz = setting('timezone', 'Asia/Karachi');
    try {
        $dt = new DateTime($datetime, new DateTimeZone($tz));
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => 'Invalid timezone.'];
    }

    // Check against restaurant hours
    $hour = (int)$dt->format('H');
    $open = (int)substr(setting('opening_time', '11:00'), 0, 2);
    $close = (int)substr(setting('closing_time', '02:00'), 0, 2);

    if ($close <= $open) {
        // Crosses midnight
        if ($hour < $open && $hour > $close) {
            return ['ok' => false, 'error' => 'Restaurant is closed at that time.'];
        }
    } else {
        if ($hour < $open || $hour >= $close) {
            return ['ok' => false, 'error' => 'Restaurant is closed at that time.'];
        }
    }

    return ['ok' => true];
}