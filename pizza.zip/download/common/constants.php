<?php
define('ORDER_STATUSES', ['pending','confirmed','preparing','ready','ready_for_pickup','out_for_delivery','delivered','picked_up','completed','cancelled','refunded']);
define('PAYMENT_STATUSES', ['pending','paid','failed','refunded']);
define('PAYMENT_METHODS', ['cod','bank','online','gift_card']);
define('ORDER_TYPES', ['delivery','pickup']);