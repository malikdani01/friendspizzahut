<?php
/**
 * AUTO MIGRATION RUNNER
 * Browser mein kholo: yoursite.com/run-migrations.php
 * Sab missing columns automatic add ho jayengi.
 * 
 * DELETE this file after running.
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/common/config.php';

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('❌ DB failed: ' . $e->getMessage());
}

// ═══════════════════════════════════════════════════════════════
// COLUMNS TO ADD (auto-check + auto-add)
// ═══════════════════════════════════════════════════════════════
$migrations = [
    // ADDONS
    'addons' => [
        'has_sizes'   => "TINYINT(1) NOT NULL DEFAULT 0",
        'price_s'     => "DECIMAL(12,2) NULL",
        'price_m'     => "DECIMAL(12,2) NULL",
        'price_l'     => "DECIMAL(12,2) NULL",
        'size_labels' => "VARCHAR(60) NOT NULL DEFAULT 'S,M,L'",
    ],
    // PRODUCTS
    'products' => [
        'has_sizes'            => "TINYINT(1) NOT NULL DEFAULT 0",
        'price_s'              => "DECIMAL(12,2) NULL",
        'price_m'              => "DECIMAL(12,2) NULL",
        'price_l'              => "DECIMAL(12,2) NULL",
        'size_labels'          => "VARCHAR(60) NOT NULL DEFAULT 'Small,Medium,Large'",
        'button_mode'          => "VARCHAR(30) NOT NULL DEFAULT 'add_to_cart'",
        'order_button_text'    => "VARCHAR(60) NULL DEFAULT 'Add to Cart'",
        'order_button_enabled' => "TINYINT(1) NOT NULL DEFAULT 1",
        'button_bg_color'      => "VARCHAR(20) NULL",
        'button_text_color'    => "VARCHAR(20) NULL",
        'prep_time_minutes'    => "INT NULL DEFAULT 15",
        'prep_time_min'        => "INT NULL",
        'prep_time_max'        => "INT NULL",
        'spice_level'          => "VARCHAR(20) NULL",
        'dietary_info'         => "VARCHAR(190) NULL",
        'allergens'            => "VARCHAR(500) NULL",
        'serving_info'         => "VARCHAR(120) NULL",
        'calories'             => "INT NULL",
        'is_recommended'       => "TINYINT(1) NOT NULL DEFAULT 0",
        'is_limited_deal'      => "TINYINT(1) NOT NULL DEFAULT 0",
        'is_coming_soon'       => "TINYINT(1) NOT NULL DEFAULT 0",
        'meta_title'           => "VARCHAR(190) NULL",
        'meta_description'     => "VARCHAR(500) NULL",
    ],
    // CART ITEM ADDONS
    'cart_item_addons' => [
        'addon_size'    => "VARCHAR(10) NULL",
        'addon_price_s' => "DECIMAL(12,2) NULL",
        'addon_price_m' => "DECIMAL(12,2) NULL",
        'addon_price_l' => "DECIMAL(12,2) NULL",
    ],
    // ORDER ITEM ADDONS
    'order_item_addons' => [
        'addon_size' => "VARCHAR(10) NULL",
    ],
    // ORDERS
    'orders' => [
        'transaction_id'    => "VARCHAR(120) NULL",
        'estimated_minutes' => "INT NULL",
        'eta_started_at'    => "DATETIME NULL",
        'eta_set_by'        => "INT UNSIGNED NULL",
    ],
    // DELIVERY AREAS
    'delivery_areas' => [
        'free_delivery_enabled' => "TINYINT(1) NOT NULL DEFAULT 0",
        'free_delivery_above'   => "DECIMAL(12,2) NULL",
    ],
];

// ═══════════════════════════════════════════════════════════════
// RUN
// ═══════════════════════════════════════════════════════════════
$results = ['added' => 0, 'skipped' => 0, 'errors' => 0];
$log = [];

foreach ($migrations as $table => $columns) {
    // Check table exists
    try {
        $t = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
        if ($t->rowCount() === 0) {
            $log[] = ['error', $table, '(table)', 'Table not found'];
            $results['errors']++;
            continue;
        }
    } catch (Throwable $e) {
        $log[] = ['error', $table, '(table)', $e->getMessage()];
        $results['errors']++;
        continue;
    }

    foreach ($columns as $column => $definition) {
        // Check if column exists
        try {
            $c = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
            $c->execute([$column]);
            if ($c->rowCount() > 0) {
                $log[] = ['skip', $table, $column, 'Already exists'];
                $results['skipped']++;
                continue;
            }
        } catch (Throwable $e) { /* continue */ }

        // Add
        try {
            $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
            $log[] = ['added', $table, $column, 'Added'];
            $results['added']++;
        } catch (Throwable $e) {
            $log[] = ['error', $table, $column, $e->getMessage()];
            $results['errors']++;
        }
    }
}

// Also fix addons 'price' column if missing
try {
    $c = $pdo->query("SHOW COLUMNS FROM addons LIKE 'price'");
    if ($c->rowCount() === 0) {
        $pdo->exec("ALTER TABLE addons ADD COLUMN price DECIMAL(12,2) NOT NULL DEFAULT 0");
        $log[] = ['added', 'addons', 'price', 'Added'];
        $results['added']++;
    }
} catch (Throwable $e) {}

// ═══════════════════════════════════════════════════════════════
// UI
// ═══════════════════════════════════════════════════════════════
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Auto Migration</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0a0a0a;color:#f9fafb;font-family:'Inter',sans-serif;min-height:100vh;padding:40px 20px;line-height:1.5}
.wrap{max-width:900px;margin:0 auto}
.head{text-align:center;margin-bottom:32px}
.icon{width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#dc2626,#b91c1c);display:inline-flex;align-items:center;justify-content:center;font-size:36px;color:#fff;margin-bottom:16px;box-shadow:0 12px 40px rgba(220,38,38,.5)}
h1{font-size:28px;font-weight:900;margin-bottom:6px}
.sub{font-size:14px;color:rgba(255,255,255,.5)}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:24px}
.stat{background:#171717;border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:16px;text-align:center}
.num{font-size:28px;font-weight:900;margin-bottom:4px}
.num.g{color:#4ade80}.num.y{color:#facc15}.num.r{color:#f87171}
.lbl{font-size:11px;color:rgba(255,255,255,.5);font-weight:700;text-transform:uppercase;letter-spacing:.5px}
.list{background:#171717;border:1px solid rgba(255,255,255,.08);border-radius:14px;overflow:hidden;max-height:500px;overflow-y:auto;margin-bottom:24px}
.item{display:flex;align-items:center;gap:12px;padding:11px 18px;border-bottom:1px solid rgba(255,255,255,.04);font-size:13px}
.item:last-child{border-bottom:0}
.item i{width:18px;flex-shrink:0}
.item.added i{color:#4ade80}.item.skip i{color:#facc15}.item.error i{color:#f87171}
.tbl{background:rgba(220,38,38,.15);color:#fca5a5;padding:3px 10px;border-radius:6px;font-size:11px;font-weight:700;font-family:monospace;flex-shrink:0}
.col{color:#fff;font-weight:600;flex:1}
.msg{font-size:12px;color:rgba(255,255,255,.5)}
.actions{display:flex;gap:12px;justify-content:center;margin-bottom:20px;flex-wrap:wrap}
.btn{display:inline-flex;align-items:center;gap:8px;padding:14px 28px;border-radius:12px;font-size:14px;font-weight:800;text-decoration:none;cursor:pointer;border:0;font-family:inherit;transition:all .2s}
.btn-p{background:linear-gradient(135deg,#dc2626,#b91c1c);color:#fff;box-shadow:0 8px 24px rgba(220,38,38,.4)}
.btn-p:hover{transform:translateY(-2px)}
.btn-g{background:rgba(255,255,255,.05);border:1.5px solid rgba(255,255,255,.1);color:#fff}
.btn-g:hover{background:rgba(255,255,255,.1);text-decoration:none}
.warn{background:rgba(234,179,8,.12);border:1.5px solid rgba(234,179,8,.4);color:#fcd34d;padding:16px;border-radius:12px;font-size:13.5px;line-height:1.7}
.warn strong{color:#fff}
</style>
</head>
<body>
<div class="wrap">
  <div class="head">
    <div class="icon"><i class="fa-solid fa-database"></i></div>
    <h1>Auto Migration</h1>
    <p class="sub">Friends Pizza Hut — Database Update</p>
  </div>

  <div class="stats">
    <div class="stat"><div class="num g"><?= $results['added'] ?></div><div class="lbl">Added</div></div>
    <div class="stat"><div class="num y"><?= $results['skipped'] ?></div><div class="lbl">Skipped</div></div>
    <div class="stat"><div class="num r"><?= $results['errors'] ?></div><div class="lbl">Errors</div></div>
  </div>

  <div class="list">
    <?php foreach ($log as $r): 
      [$s, $t, $c, $m] = $r;
      $ic = match($s){'added'=>'fa-circle-check','skip'=>'fa-circle-minus','error'=>'fa-circle-xmark'};
    ?>
      <div class="item <?= $s ?>">
        <i class="fa-solid <?= $ic ?>"></i>
        <span class="tbl"><?= htmlspecialchars($t) ?></span>
        <span class="col"><?= htmlspecialchars($c) ?></span>
        <span class="msg"><?= htmlspecialchars($m) ?></span>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="actions">
    <a href="<?= rtrim(dirname($_SERVER['SCRIPT_NAME']),'/') ?>/admin/products/index.php" class="btn btn-p">
      <i class="fa-solid fa-arrow-right"></i> Go to Products
    </a>
    <a href="" class="btn btn-g">
      <i class="fa-solid fa-rotate"></i> Run Again
    </a>
  </div>

  <div class="warn">
    <strong><i class="fa-solid fa-triangle-exclamation"></i> Important:</strong><br>
    Migration complete. Ab <strong>ye file (run-migrations.php) DELETE kar do</strong> security ke liye.
    Product edit page kholo → sab sections dikhne chahiye.
  </div>
</div>
</body>
</html>