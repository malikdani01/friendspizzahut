# Database Migrations

Ye folder numeric order mein auto-run hoti hai `setup.php` se.

## Files

| File | Purpose |
|---|---|
| `001_initial_schema.sql` | Base tables (features, settings, users, products, orders, etc.) |
| `002_indexes.sql` | Performance indexes |
| `003_default_features.sql` | Feature toggle seed (core + launch + disabled) |
| `004_jazzcash_settings.sql` | JazzCash + Easypaisa + SMS + SMTP + WhatsApp settings |
| `005_email_templates.sql` | Email + SMS + WhatsApp + Push notification templates |
| `006_all_phase_features.sql` | Phase A/B/C features (sound, refresh, thermal, pixel, QR, etc.) |
| `007_rider_module.sql` | `riders` table + `orders.rider_id` column |
| `008_wallet.sql` | `wallet_transactions` table |
| `009_recipe.sql` | `recipe_ingredients` table |
| `010_option_a_features.sql` | Backup, daily closing, tiers, scheduled orders, bulk SMS, P&L, WhatsApp API, heatmap |
| `011_customer_tiers.sql` | `customer_tiers` table + default tiers |
| `012_easypaisa_setup.sql` | Easypaisa feature + settings, bank_transfer disabled |
| `013_reservations.sql` | `reservations` table (COMPLETE reservation system) |

## Fresh Install

`setup.php` **automatically ye saari files run karta hai** in order. Kuch manually nahi karna.

## Existing Database Update

Naya migration file banao (jaise `014_xxx.sql`), aur `setup.php` dobara chalao.

Ya phpMyAdmin se manually import karo.