<?php
function validate_required(array $fields, array $data): array {
    $errors = [];
    foreach ($fields as $f => $label) {
        if (!isset($data[$f]) || trim((string)$data[$f]) === '') $errors[] = "$label is required.";
    }
    return $errors;
}
function validate_length(string $val, int $min, int $max, string $label): ?string {
    $len = mb_strlen($val);
    if ($len < $min) return "$label must be at least $min characters.";
    if ($len > $max) return "$label must be at most $max characters.";
    return null;
}
function validate_numeric($val, string $label): ?string {
    return is_numeric($val) ? null : "$label must be a number.";
}
function validate_url(string $val): bool { return (bool) filter_var($val, FILTER_VALIDATE_URL); }