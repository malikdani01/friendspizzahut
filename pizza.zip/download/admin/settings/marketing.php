<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Marketing & Tracking';

if (is_post()) {
    verify_csrf();
    foreach ([
        'facebook_pixel_id',
        'facebook_conversion_api_token',
        'google_analytics_id',
        'google_tag_manager_id',
        'whatsapp_float_number',
        'whatsapp_float_message',
        'whatsapp_float_enabled',
    ] as $k) {
        update_setting($k, (string)post($k, ''));
    }
    flash_success('Marketing settings saved.');
    redirect(url('admin/settings/marketing.php'));
}

require __DIR__ . '/../common/header.php';
?>

<div class="max-w-3xl space-y-5">

  <div class="bg-white rounded-xl shadow-sm border p-6">
    <h3 class="font-bold mb-4 text-brand flex items-center gap-2">
      <i class="fa-brands fa-facebook"></i> Facebook Pixel
    </h3>
    <?php if (!feature_enabled('facebook_pixel')): ?>
      <div class="text-sm text-gray-500 mb-3">Feature disabled. Enable in Feature Manager first.</div>
    <?php endif; ?>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input name="facebook_pixel_id" value="<?= e(setting('facebook_pixel_id','')) ?>" placeholder="Pixel ID (e.g. 1234567890)" class="w-full border rounded px-3 py-2 font-mono text-sm">
      <input name="facebook_conversion_api_token" value="<?= e(setting('facebook_conversion_api_token','')) ?>" placeholder="Conversion API Token (optional)" class="w-full border rounded px-3 py-2 font-mono text-sm">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save FB</button>
    </form>
  </div>

  <div class="bg-white rounded-xl shadow-sm border p-6">
    <h3 class="font-bold mb-4 text-brand flex items-center gap-2">
      <i class="fa-brands fa-google"></i> Google Analytics / Tag Manager
    </h3>
    <?php if (!feature_enabled('google_analytics')): ?>
      <div class="text-sm text-gray-500 mb-3">Feature disabled. Enable in Feature Manager first.</div>
    <?php endif; ?>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input name="google_analytics_id" value="<?= e(setting('google_analytics_id','')) ?>" placeholder="GA4 ID (G-XXXXXXXXXX)" class="w-full border rounded px-3 py-2 font-mono text-sm">
      <input name="google_tag_manager_id" value="<?= e(setting('google_tag_manager_id','')) ?>" placeholder="GTM ID (GTM-XXXXXXX)" class="w-full border rounded px-3 py-2 font-mono text-sm">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save GA</button>
    </form>
  </div>

  <div class="bg-white rounded-xl shadow-sm border p-6">
    <h3 class="font-bold mb-4 text-brand flex items-center gap-2">
      <i class="fa-brands fa-whatsapp"></i> WhatsApp Floating Button
    </h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <label class="flex items-center gap-2">
        <input type="checkbox" name="whatsapp_float_enabled" value="1" <?= setting('whatsapp_float_enabled') === '1' ? 'checked' : '' ?> class="w-4 h-4">
        <span>Show WhatsApp floating button on all pages</span>
      </label>
      <input name="whatsapp_float_number" value="<?= e(setting('whatsapp_float_number', setting('restaurant_whatsapp'))) ?>" placeholder="03XXXXXXXXX" class="w-full border rounded px-3 py-2 font-mono text-sm">
      <input name="whatsapp_float_message" value="<?= e(setting('whatsapp_float_message', 'Hello, I want to place an order')) ?>" placeholder="Default message" class="w-full border rounded px-3 py-2">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save WhatsApp</button>
    </form>
  </div>

  <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-5 text-sm text-yellow-900">
    <div class="font-bold mb-2"><i class="fa-solid fa-info-circle mr-1"></i> Facebook Pixel Setup</div>
    <ol class="list-decimal list-inside space-y-1">
      <li>business.facebook.com → Events Manager</li>
      <li>Data Sources → Connect Data → Web</li>
      <li>Pixel ID copy karo (15-16 digit number)</li>
      <li>Yahan paste karke save karo</li>
      <li>Track events: PageView, AddToCart, Purchase — automatic hain</li>
    </ol>
    <div class="mt-3 text-xs">Google Analytics: analytics.google.com → GA4 property → Measurement ID (G-XXXX) copy karo</div>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>