<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('upsell_system')) {
    flash_error('Complete Your Meal feature is disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Complete Your Meal';

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'settings') {
        update_setting('upsell_enabled', isset($_POST['upsell_enabled']) ? '1' : '0');
        update_setting('upsell_heading', (string)post('upsell_heading', 'Complete Your Meal 🍟'));
        update_setting('upsell_subtitle', (string)post('upsell_subtitle', ''));
        update_setting('upsell_max_items', (string)(int)post('upsell_max_items', 8));
        update_setting('upsell_hide_in_cart', isset($_POST['upsell_hide_in_cart']) ? '1' : '0');
        flash_success('Settings saved.');
        redirect(url('admin/marketing/upsell.php'));

    } elseif ($action === 'add') {
        $pid = (int)post('product_id', 0);
        if ($pid > 0 && get_product($pid)) {
            if (Database::fetch("SELECT id FROM cart_upsell_products WHERE product_id = ?", [$pid])) {
                flash_error('Product already in list.');
            } else {
                Database::insert('cart_upsell_products', [
                    'product_id' => $pid,
                    'is_enabled' => 1,
                    'display_order' => (int)post('display_order', 0),
                ]);
                flash_success('Product added.');
            }
        }
        redirect(url('admin/marketing/upsell.php'));

    } elseif ($action === 'toggle') {
        Database::execute("UPDATE cart_upsell_products SET is_enabled = 1 - is_enabled WHERE id = ?", [(int)post('id')]);
        flash_success('Updated.');
        redirect(url('admin/marketing/upsell.php'));

    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM cart_upsell_products WHERE id = ?", [(int)post('id')]);
        flash_success('Removed.');
        redirect(url('admin/marketing/upsell.php'));

    } elseif ($action === 'reorder') {
        $order = (array)post('order', []);
        foreach ($order as $rowId => $ord) {
            Database::execute("UPDATE cart_upsell_products SET display_order = ? WHERE id = ?", [(int)$ord, (int)$rowId]);
        }
        flash_success('Order saved.');
        redirect(url('admin/marketing/upsell.php'));

    } elseif ($action === 'save_override') {
        $rowId = (int)post('id');
        $override = post('price_override') ? 1 : 0;
        $custom = post('custom_price') !== '' ? (float)post('custom_price') : null;
        Database::execute(
            "UPDATE cart_upsell_products SET price_override = ?, custom_price = ?, override_start = ?, override_end = ? WHERE id = ?",
            [
                $override,
                $custom,
                post('override_start') ?: null,
                post('override_end') ?: null,
                $rowId,
            ]
        );
        flash_success('Price override saved.');
        redirect(url('admin/marketing/upsell.php'));
    }
}

$upsellRows = Database::fetchAll(
    "SELECT up.*, p.name, p.image, p.price, p.sale_price, p.status AS p_status
     FROM cart_upsell_products up
     JOIN products p ON p.id = up.product_id
     ORDER BY up.display_order ASC, p.name ASC"
);

$allProducts = Database::fetchAll("SELECT id, name, price, sale_price FROM products WHERE status='active' ORDER BY name LIMIT 500");

require __DIR__ . '/../common/header.php';
?>

<div class="space-y-5">

  <!-- SETTINGS -->
  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-4 text-brand">Section Settings</h3>
    <form method="post" class="grid md:grid-cols-2 gap-4">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="settings">

      <label class="md:col-span-2 flex items-center gap-2">
        <input type="checkbox" name="upsell_enabled" value="1" <?= setting('upsell_enabled', '1') === '1' ? 'checked' : '' ?> class="w-4 h-4">
        <span class="font-semibold">Enable Complete Your Meal section</span>
      </label>

      <div class="md:col-span-2">
        <label class="block text-sm font-semibold mb-1">Heading</label>
        <input name="upsell_heading" value="<?= e(setting('upsell_heading', 'Complete Your Meal 🍟')) ?>" class="w-full border rounded px-3 py-2">
      </div>

      <div class="md:col-span-2">
        <label class="block text-sm font-semibold mb-1">Subtitle</label>
        <input name="upsell_subtitle" value="<?= e(setting('upsell_subtitle', '')) ?>" class="w-full border rounded px-3 py-2">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-1">Max Items Shown</label>
        <input type="number" name="upsell_max_items" value="<?= e(setting('upsell_max_items', 8)) ?>" min="1" max="20" class="w-full border rounded px-3 py-2">
      </div>

      <label class="flex items-center gap-2 md:col-span-2">
        <input type="checkbox" name="upsell_hide_in_cart" value="1" <?= setting('upsell_hide_in_cart', '1') === '1' ? 'checked' : '' ?> class="w-4 h-4">
        <span>Hide products that are already in the customer's cart</span>
      </label>

      <button class="md:col-span-2 bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save Settings</button>
    </form>
  </div>

  <!-- ADD PRODUCT -->
  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-4 text-brand">Add Product to Suggestions</h3>
    <form method="post" class="grid md:grid-cols-3 gap-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add">
      <div class="md:col-span-2">
        <select name="product_id" required class="w-full border rounded px-3 py-2">
          <option value="">— Select product —</option>
          <?php foreach ($allProducts as $pr): ?>
            <option value="<?= (int)$pr['id'] ?>"><?= e($pr['name']) ?> (Rs. <?= number_format((float)($pr['sale_price'] ?: $pr['price']), 0) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <input type="number" name="display_order" value="0" placeholder="Order" class="w-full border rounded px-3 py-2">
      </div>
      <button class="md:col-span-3 bg-brand text-white py-2.5 rounded-lg font-semibold">Add to Complete Your Meal</button>
    </form>
  </div>

  <!-- LIST -->
  <div class="bg-white rounded-xl border overflow-x-auto">
    <div class="px-5 py-4 border-b font-bold">Current Suggestions (<?= count($upsellRows) ?>)</div>
    <?php if (!$upsellRows): ?>
      <div class="p-8 text-center text-gray-400">No products yet. Add one above.</div>
    <?php else: ?>
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
        <tr>
          <th class="text-left px-4 py-3">Image</th>
          <th class="text-left px-4 py-3">Product</th>
          <th class="text-left px-4 py-3">Price</th>
          <th class="text-left px-4 py-3">Order</th>
          <th class="text-left px-4 py-3">Status</th>
          <th class="text-right px-4 py-3">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($upsellRows as $r): ?>
        <tr class="border-t hover:bg-gray-50">
          <td class="px-4 py-3">
            <?php if ($r['image']): ?>
              <img src="<?= upload_url($r['image']) ?>" class="w-12 h-12 rounded object-cover">
            <?php else: ?>
              <div class="w-12 h-12 rounded bg-gray-100 flex items-center justify-center text-gray-400"><i class="fa-solid fa-box"></i></div>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3 font-semibold"><?= e($r['name']) ?></td>
          <td class="px-4 py-3"><?= money($r['sale_price'] ?: $r['price']) ?></td>
          <td class="px-4 py-3"><?= (int)$r['display_order'] ?></td>
          <td class="px-4 py-3">
            <form method="post" class="inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="text-xs px-2 py-1 rounded <?= $r['is_enabled'] ? 'bg-green-100 text-green-800' : 'bg-gray-200' ?>">
                <?= $r['is_enabled'] ? 'Active' : 'Inactive' ?>
              </button>
            </form>
          </td>
          <td class="px-4 py-3 text-right">
            <form method="post" class="inline" data-confirm="Remove from suggestions?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="text-red-600 text-xs">Remove</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>