<?php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('deals.php'));
verify_csrf();
$comboId = (int)post('combo_id', 0);
$combo = Database::fetch("SELECT * FROM combos WHERE id=? AND is_active=1", [$comboId]);
if (!$combo) { flash_error('Deal not found.'); redirect(url('deals.php')); }

Database::beginTransaction();
try {
    [$where, $params] = cart_query();
    $cartItemId = null;
    if (customer_logged_in()) {
        $cartItemId = Database::insert('cart_items', [
            'user_id' => (int)$_SESSION['user_id'],
            'combo_id' => $comboId,
            'quantity' => 1,
            'unit_price_snapshot' => (float)$combo['fixed_price'],
        ]);
    } else {
        if (empty($_SESSION['guest_sid'])) $_SESSION['guest_sid'] = bin2hex(random_bytes(16));
        $cartItemId = Database::insert('cart_items', [
            'session_id' => $_SESSION['guest_sid'],
            'combo_id' => $comboId,
            'quantity' => 1,
            'unit_price_snapshot' => (float)$combo['fixed_price'],
        ]);
    }
    Database::commit();
    flash_success($combo['name'] . ' added to cart!');
    redirect(url('cart.php'));
} catch (Throwable $e) {
    Database::rollback();
    flash_error('Could not add deal.');
    redirect(url('deals.php'));
}