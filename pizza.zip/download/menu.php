<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Menu';
$cats = get_categories(true);
$activeCat = null;
$catSlug = (string)get('category', '');
if ($catSlug) $activeCat = get_category_by_slug($catSlug);

$search = trim((string)get('q',''));
$sort = (string)get('sort', 'sort_order');
$f = ['available' => 1, 'sort' => $sort, 'limit' => 60];
if ($activeCat) $f['category_id'] = (int)$activeCat['id'];
if ($search) $f['search'] = $search;
$products = get_products($f);

require __DIR__ . '/common/header.php';
?>
<div class="max-w-7xl mx-auto px-4 py-10">
  <div class="mb-8">
    <h1 class="text-3xl md:text-4xl font-extrabold">
      <?= $activeCat ? e($activeCat['name']) : 'Our Menu' ?>
    </h1>
    <p class="text-white/60 mt-1"><?= count($products) ?> items</p>
  </div>

  <!-- Category filter -->
  <div class="overflow-x-auto -mx-4 px-4 mb-6">
    <div class="flex gap-2 min-w-max">
      <a href="<?= url('menu.php') ?>" class="px-4 py-2 rounded-full text-sm font-semibold <?= !$activeCat ? 'bg-brand text-white' : 'bg-white/10 hover:bg-white/20' ?>">All</a>
      <?php foreach ($cats as $c): ?>
        <a href="<?= url('menu.php?category=' . urlencode($c['slug'])) ?>"
           class="px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap <?= $activeCat && $activeCat['id']==$c['id'] ? 'bg-brand text-white' : 'bg-white/10 hover:bg-white/20' ?>">
          <?= e($c['name']) ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Search & sort -->
  <form class="flex gap-2 mb-6 flex-wrap">
    <?php if ($activeCat): ?><input type="hidden" name="category" value="<?= e($activeCat['slug']) ?>"><?php endif; ?>
    <input name="q" value="<?= e($search) ?>" placeholder="Search menu..." class="flex-1 min-w-[200px] bg-white/5 border border-white/10 rounded-lg px-4 py-2.5 outline-none focus:border-brand">
    <select name="sort" class="bg-white/5 border border-white/10 rounded-lg px-4 py-2.5">
      <option value="sort_order" <?= $sort=='sort_order'?'selected':'' ?>>Default</option>
      <option value="price" <?= $sort=='price'?'selected':'' ?>>Price (low → high)</option>
      <option value="name" <?= $sort=='name'?'selected':'' ?>>Name</option>
      <option value="rating_avg" <?= $sort=='rating_avg'?'selected':'' ?>>Rating</option>
    </select>
    <button class="px-5 py-2.5 bg-brand rounded-lg font-semibold">Apply</button>
  </form>

  <?php if (!$products): ?>
    <div class="text-center py-20 text-white/60">
      <i class="fa-solid fa-pizza-slice text-5xl mb-4 opacity-40"></i>
      <p>No items found.</p>
    </div>
  <?php else: ?>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      <?php foreach ($products as $p): require __DIR__ . '/common/components/product-card.php'; endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>