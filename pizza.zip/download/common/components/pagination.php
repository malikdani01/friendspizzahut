<?php /** @var array $pagination */
echo pagination_links($pagination ?? [], current_url());