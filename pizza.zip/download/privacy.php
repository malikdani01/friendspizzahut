<?php
// privacy.php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Privacy Policy';
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-16 prose prose-invert">
  <h1 class="text-4xl font-extrabold mb-6">Privacy Policy</h1>
  <div class="space-y-4 text-white/70 text-sm leading-relaxed">
    <p>At Friends Pizza Hut, we respect your privacy. This policy explains what information we collect and how we use it.</p>
    <h3 class="text-white font-bold text-lg mt-6">Information We Collect</h3>
    <p>Name, phone number, email, delivery address, and order history — used to process and deliver your orders.</p>
    <h3 class="text-white font-bold text-lg mt-6">How We Use Your Data</h3>
    <p>To fulfill orders, improve our services, and send order updates. We never sell your data to third parties.</p>
    <h3 class="text-white font-bold text-lg mt-6">Data Security</h3>
    <p>Your password is stored using industry-standard hashing. Our platform uses CSRF protection and secure sessions.</p>
    <h3 class="text-white font-bold text-lg mt-6">Contact</h3>
    <p>Questions? Reach us at <?= e(setting('restaurant_phone')) ?> or <?= e(setting('restaurant_email')) ?>.</p>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>