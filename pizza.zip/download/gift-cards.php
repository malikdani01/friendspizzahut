<?php
require_once __DIR__ . '/common/bootstrap.php';
if (!feature_enabled('gift_cards')) { flash_error('Gift cards not available.'); redirect(url('account.php')); }
require_customer();
$pageTitle = 'Gift Cards';
$uid = (int)$_SESSION['user_id'];
$cards = Database::fetchAll("SELECT * FROM gift_cards WHERE purchaser_user_id=? OR recipient_phone=? ORDER BY id DESC", [$uid, current_customer()['phone']]);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-6">Gift Cards</h1>
  <div class="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
    <?php foreach ($cards as $c): ?>
      <div class="bg-gradient-to-br from-brand to-red-900 rounded-2xl p-5 text-white">
        <div class="text-xs opacity-80">Balance</div>
        <div class="text-2xl font-extrabold"><?= money($c['current_balance']) ?></div>
        <div class="text-xs font-mono mt-2"><?= e($c['code']) ?></div>
      </div>
    <?php endforeach; ?>
    <?php if (!$cards): ?>
      <div class="col-span-full text-white/60 text-center py-8">No gift cards yet. Buy from us at <?= e(setting('restaurant_phone')) ?>.</div>
    <?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>