<?php
require_once __DIR__ . '/common/bootstrap.php';

$slug = (string)get('slug', '');
$p = get_product_by_slug($slug);
if (!$p) { flash_error('Product not found.'); redirect(url('menu.php')); }

$pageTitle   = $p['name'];
$gallery     = get_product_images((int)$p['id']);
$varGroups   = get_product_variation_groups((int)$p['id']);
$addons      = get_product_addons((int)$p['id']);
$related     = get_related_products((int)$p['id'], (int)$p['category_id'], 6);
$reviews     = feature_enabled('product_reviews') ? get_product_reviews((int)$p['id'], true) : [];
$canReview   = customer_logged_in() && feature_enabled('product_reviews') && user_can_review((int)$_SESSION['user_id'], (int)$p['id']);
$canOrder    = (int)($p['order_button_enabled'] ?? 1) === 1 && $p['status'] === 'active' && (int)$p['is_available'] === 1;
$basePrice   = (float)($p['sale_price'] ?: $p['price']);
$hasSale     = !empty($p['sale_price']) && $p['sale_price'] < $p['price'];
$discountPct = $hasSale ? round((1 - ($p['sale_price'] / $p['price'])) * 100) : 0;
$favHas      = customer_logged_in() && feature_enabled('wishlist') && function_exists('wishlist_has');
$isFav       = $favHas ? wishlist_has((int)$_SESSION['user_id'], (int)$p['id']) : false;

if (is_post()) {
    verify_csrf();
    $qty      = max(1, (int)post('quantity', 1));
    $optIds   = array_map('intval', (array)($_POST['variation'] ?? []));
    $addonIds = (array)($_POST['addons'] ?? []);
    $notes    = (string)post('notes', '');
    $r = add_to_cart((int)$p['id'], $qty, $optIds, $addonIds, $notes);
    if ($r['ok']) { flash_success('Added to cart!'); redirect(url('cart.php')); }
    flash_error($r['error'] ?? 'Failed to add.');
}

$placeholder = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMDAgMjAwIj48cmVjdCBmaWxsPSIjMWExYTFhIiB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIvPjx0ZXh0IHg9IjEwMCIgeT0iMTE1IiBmb250LXNpemU9IjgwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj7wn42VPC90ZXh0Pjwvc3ZnPg==';
$heroImg     = !empty($p['image']) ? upload_url($p['image']) : $placeholder;

// Build all images list
$allImages = [['src' => $heroImg, 'alt' => $p['name']]];
foreach ($gallery as $g) {
    $allImages[] = ['src' => upload_url($g['image']), 'alt' => $p['name']];
}

// Deduplicate size groups (fix duplicate issue)
$seenGroups = [];
$cleanGroups = [];
foreach ($varGroups as $g) {
    $key = (int)$g['id'];
    if (isset($seenGroups[$key])) continue;
    $seenGroups[$key] = true;
    // Filter out empty groups
    if (empty($g['options'])) continue;
    // Deduplicate options within group
    $seenOpts = [];
    $cleanOpts = [];
    foreach ($g['options'] as $o) {
        $okey = (string)$o['name'] . '|' . (float)($o['absolute_price'] ?: $o['price_delta']);
        if (isset($seenOpts[$okey])) continue;
        $seenOpts[$okey] = true;
        $cleanOpts[] = $o;
    }
    $g['options'] = $cleanOpts;
    $cleanGroups[] = $g;
}
$varGroups = $cleanGroups;

// Deduplicate addons
$seenAddons = [];
$cleanAddons = [];
foreach ($addons as $a) {
    if (isset($seenAddons[$a['id']])) continue;
    $seenAddons[$a['id']] = true;
    $cleanAddons[] = $a;
}
$addons = $cleanAddons;

require __DIR__ . '/common/header.php';
?>

<style>
/* ═══ PRODUCT DETAILS — COMPACT VERTICAL ═══ */
.pd-wrap { max-width: 1100px; margin: 0 auto; padding: 12px 16px 140px; box-sizing: border-box; }
.pd-wrap * { box-sizing: border-box; }

.pd-bread { display: flex; align-items: center; gap: 6px; font-size: 12.5px; color: rgba(255,255,255,0.5); margin-bottom: 12px; flex-wrap: wrap; }
.pd-bread a { color: rgba(255,255,255,0.7); text-decoration: none; }
.pd-bread a:hover { color: #dc2626; }

.pd-layout { display: grid; grid-template-columns: 1fr; gap: 20px; }
@media (min-width: 900px) { .pd-layout { grid-template-columns: 1fr 1fr; gap: 32px; align-items: start; } }

/* Gallery */
.pd-gallery { position: relative; width: 100%; }
.pd-hero {
  aspect-ratio: 1/1; background: #111;
  border-radius: 16px; overflow: hidden;
  position: relative; border: 1px solid rgba(255,255,255,0.06);
  width: 100%;
}
.pd-hero img { width: 100%; height: 100%; object-fit: cover; display: block; }
.pd-hero-badges { position: absolute; top: 10px; left: 10px; display: flex; gap: 5px; flex-wrap: wrap; z-index: 2; max-width: calc(100% - 20px); }
.pd-badge-chip { font-size: 9.5px; font-weight: 800; padding: 4px 9px; border-radius: 999px; letter-spacing: 0.3px; text-transform: uppercase; white-space: nowrap; }
.pd-hero-nav { position: absolute; top: 50%; transform: translateY(-50%); width: 36px; height: 36px; border-radius: 50%; background: rgba(0,0,0,0.6); border: 0; color: #fff; font-size: 13px; cursor: pointer; display: flex; align-items: center; justify-content: center; z-index: 3; }
.pd-hero-nav:hover { background: rgba(220,38,38,0.9); }
.pd-hero-nav.prev { left: 10px; } .pd-hero-nav.next { right: 10px; }
.pd-hero-dots { position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); display: flex; gap: 5px; z-index: 3; }
.pd-hero-dot { width: 7px; height: 7px; border-radius: 50%; background: rgba(255,255,255,0.4); border: 0; cursor: pointer; padding: 0; }
.pd-hero-dot.active { background: #dc2626; width: 20px; border-radius: 999px; }

.pd-thumbs { display: flex; gap: 8px; margin-top: 10px; overflow-x: auto; scrollbar-width: none; padding-bottom: 3px; }
.pd-thumbs::-webkit-scrollbar { display: none; }
.pd-thumb { flex: 0 0 62px; width: 62px; height: 62px; border-radius: 10px; overflow: hidden; border: 2px solid rgba(255,255,255,0.08); background: #111; cursor: pointer; padding: 0; }
.pd-thumb.active { border-color: #dc2626; }
.pd-thumb img { width: 100%; height: 100%; object-fit: cover; }

/* Product info */
.pd-cat { font-size: 11px; font-weight: 800; color: #dc2626; text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 5px; }
.pd-title { font-size: 24px; font-weight: 900; color: #fff; line-height: 1.15; margin: 0 0 8px; }
@media (min-width: 768px) { .pd-title { font-size: 30px; } }
.pd-rating { display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: rgba(255,255,255,0.6); margin-bottom: 10px; }
.pd-stars { color: #fbbf24; font-size: 13px; letter-spacing: 1px; }
.pd-desc { font-size: 13.5px; color: rgba(255,255,255,0.72); line-height: 1.6; margin-bottom: 16px; }
.pd-price-row { display: flex; align-items: baseline; gap: 10px; margin-bottom: 6px; flex-wrap: wrap; }
.pd-price { font-size: 28px; font-weight: 900; color: #dc2626; line-height: 1; }
.pd-price-old { font-size: 15px; color: rgba(255,255,255,0.35); text-decoration: line-through; font-weight: 500; }
.pd-price-save { background: rgba(34,197,94,0.15); color: #4ade80; border: 1px solid rgba(34,197,94,0.3); font-size: 10.5px; font-weight: 800; padding: 3px 9px; border-radius: 999px; }

/* ═══ COMPACT VERTICAL OPTION ROWS ═══ */
.pd-section {
  margin: 22px 0 0;
  width: 100%;
}
.pd-section-head {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 10px;
  gap: 8px;
}
.pd-section-title {
  display: flex; align-items: center; gap: 8px;
  font-size: 15px; font-weight: 800; color: #fff;
  margin: 0;
  letter-spacing: 0.2px;
}
.pd-section-num {
  display: inline-flex; align-items: center; justify-content: center;
  width: 22px; height: 22px; border-radius: 50%;
  background: rgba(220,38,38,0.15);
  color: #dc2626; font-size: 11px; font-weight: 800;
  flex-shrink: 0;
}
.pd-required {
  font-size: 9.5px; font-weight: 800;
  background: #dc2626; color: #fff;
  padding: 3px 8px; border-radius: 999px;
  letter-spacing: 0.4px; text-transform: uppercase;
  white-space: nowrap;
}
.pd-optional {
  font-size: 11px; font-weight: 600;
  color: rgba(255,255,255,0.4);
  text-transform: none;
}

/* Options list — vertical */
.pd-opt-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
}
.pd-opt-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 12px 14px;
  min-height: 50px;
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  background: rgba(255,255,255,0.025);
  cursor: pointer;
  transition: all .18s;
  width: 100%;
  box-sizing: border-box;
}
.pd-opt-row:hover { border-color: rgba(220,38,38,0.4); }
.pd-opt-row:active { transform: scale(0.995); }

.pd-opt-row input { display: none; }

.pd-opt-left {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
  min-width: 0;
}

/* Selection indicator */
.pd-indicator {
  width: 20px; height: 20px;
  flex-shrink: 0;
  border: 2px solid rgba(255,255,255,0.28);
  display: flex; align-items: center; justify-content: center;
  position: relative;
  transition: all .18s;
}
.pd-indicator.radio { border-radius: 50%; }
.pd-indicator.checkbox { border-radius: 5px; }

.pd-opt-row.selected {
  border-color: #dc2626;
  background: rgba(220,38,38,0.08);
}
.pd-opt-row.selected .pd-indicator.radio { border-color: #dc2626; }
.pd-opt-row.selected .pd-indicator.radio::after {
  content: ''; width: 10px; height: 10px; border-radius: 50%;
  background: #dc2626; position: absolute;
}
.pd-opt-row.selected .pd-indicator.checkbox {
  background: #dc2626; border-color: #dc2626;
}
.pd-opt-row.selected .pd-indicator.checkbox::after {
  content: '\f00c';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  font-size: 10px; color: #fff;
  position: absolute;
}

.pd-opt-name {
  font-size: 14.5px; font-weight: 600;
  color: rgba(255,255,255,0.88);
  line-height: 1.3;
  word-break: break-word;
  flex: 1;
  min-width: 0;
}
.pd-opt-row.selected .pd-opt-name { color: #fff; font-weight: 700; }

.pd-opt-price {
  font-size: 14.5px; font-weight: 800;
  color: #dc2626;
  white-space: nowrap;
  flex-shrink: 0;
  text-align: right;
}
.pd-opt-price.free {
  color: rgba(255,255,255,0.4);
  font-weight: 600;
  font-size: 13px;
}

/* Quantity */
.pd-qty-row { display: flex; align-items: center; gap: 12px; margin: 20px 0 0; }
.pd-qty {
  display: inline-flex; align-items: center;
  border: 1.5px solid rgba(255,255,255,0.15);
  border-radius: 12px;
  background: rgba(0,0,0,0.3);
  overflow: hidden;
}
.pd-qty-btn {
  width: 46px; height: 46px;
  background: transparent; color: #fff;
  border: 0; cursor: pointer;
  font-size: 20px; font-weight: 700;
  transition: background .15s;
}
.pd-qty-btn:active { background: rgba(255,255,255,0.08); }
.pd-qty-input {
  width: 54px; height: 46px;
  text-align: center; border: 0;
  background: transparent; color: #fff;
  font-weight: 800; font-size: 17px;
  outline: none;
  -moz-appearance: textfield;
}
.pd-qty-input::-webkit-outer-spin-button,
.pd-qty-input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }

/* Total strip */
.pd-total-strip {
  display: flex; align-items: center; gap: 10px;
  padding: 14px 16px;
  background: linear-gradient(135deg, rgba(220,38,38,0.15), rgba(220,38,38,0.04));
  border: 1px solid rgba(220,38,38,0.3);
  border-radius: 12px;
  margin-top: 16px;
  width: 100%;
  box-sizing: border-box;
}
.pd-total-label { font-size: 11px; text-transform: uppercase; opacity: 0.7; letter-spacing: 0.5px; color: #fff; }
.pd-total-value { font-size: 22px; font-weight: 900; color: #dc2626; margin-left: auto; transition: transform .2s; }
.pd-total-value.bump { transform: scale(1.08); }

/* CTA */
.pd-cta-row { display: flex; gap: 10px; align-items: stretch; margin-top: 14px; width: 100%; }
.pd-add-btn {
  flex: 1;
  display: flex; align-items: center; justify-content: center; gap: 10px;
  padding: 16px;
  background: #dc2626; color: #fff;
  border: 0; border-radius: 12px;
  font-size: 15px; font-weight: 800;
  cursor: pointer;
  box-shadow: 0 8px 24px rgba(220,38,38,0.35);
  transition: background .2s, transform .1s;
}
.pd-add-btn:hover { background: #b91c1c; }
.pd-add-btn:active { transform: scale(0.98); }
.pd-add-btn:disabled { opacity: 0.5; cursor: not-allowed; box-shadow: none; }

.pd-fav-btn {
  width: 54px; display: flex; align-items: center; justify-content: center;
  border: 2px solid rgba(255,255,255,0.15);
  border-radius: 12px;
  background: rgba(255,255,255,0.03);
  color: rgba(255,255,255,0.7);
  font-size: 19px; text-decoration: none;
  transition: all .18s;
}
.pd-fav-btn:hover { border-color: #dc2626; color: #dc2626; }
.pd-fav-btn.active { border-color: #dc2626; color: #dc2626; background: rgba(220,38,38,0.1); }

/* Benefits */
.pd-benefits { margin-top: 22px; background: #171717; border: 1px solid rgba(255,255,255,0.06); border-radius: 14px; padding: 16px; }
.pd-benefits h4 { font-size: 13.5px; font-weight: 800; color: #fff; margin: 0 0 12px; display: flex; align-items: center; gap: 8px; }
.pd-benefits h4 i { color: #dc2626; }
.pd-benefit { display: flex; align-items: flex-start; gap: 10px; padding: 8px 0; }
.pd-benefit:not(:last-child) { border-bottom: 1px solid rgba(255,255,255,0.05); }
.pd-benefit-icon { width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
.pd-benefit-icon.green { background: rgba(34,197,94,0.15); color: #22c55e; }
.pd-benefit-icon.orange { background: rgba(234,88,12,0.15); color: #ea580c; }
.pd-benefit-icon.blue { background: rgba(59,130,246,0.15); color: #3b82f6; }
.pd-benefit-icon.red { background: rgba(220,38,38,0.15); color: #dc2626; }
.pd-benefit-title { font-size: 12.5px; font-weight: 700; color: #fff; margin-bottom: 1px; }
.pd-benefit-text { font-size: 11px; color: rgba(255,255,255,0.55); line-height: 1.4; }

/* Tabs */
.pd-tabs { margin-top: 36px; }
.pd-tab-nav { display: flex; gap: 2px; overflow-x: auto; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 18px; scrollbar-width: none; }
.pd-tab-nav::-webkit-scrollbar { display: none; }
.pd-tab-btn { flex-shrink: 0; padding: 11px 16px; background: transparent; border: 0; color: rgba(255,255,255,0.55); font-size: 13px; font-weight: 700; cursor: pointer; border-bottom: 2px solid transparent; white-space: nowrap; }
.pd-tab-btn.active { color: #fff; border-bottom-color: #dc2626; }
.pd-tab-panel { display: none; }
.pd-tab-panel.active { display: block; }

.pd-info-block { background: #171717; border: 1px solid rgba(255,255,255,0.06); border-radius: 14px; padding: 16px; font-size: 13.5px; color: rgba(255,255,255,0.75); line-height: 1.7; }
.pd-info-grid { display: grid; grid-template-columns: 1fr; gap: 0; font-size: 13.5px; }
.pd-info-grid .row { display: flex; justify-content: space-between; padding: 9px 0; border-bottom: 1px solid rgba(255,255,255,0.05); color: rgba(255,255,255,0.6); gap: 12px; }
.pd-info-grid .row:last-child { border-bottom: 0; }
.pd-info-grid .row strong { color: #fff; font-weight: 600; text-align: right; }

/* Reviews */
.pd-reviews-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; background: #171717; border: 1px solid rgba(255,255,255,0.06); border-radius: 14px; padding: 14px 16px; margin-bottom: 14px; }
.pd-rating-big { display: flex; align-items: center; gap: 12px; }
.pd-rating-big-num { font-size: 32px; font-weight: 900; color: #fff; line-height: 1; }
.pd-rating-big-stars { color: #fbbf24; font-size: 15px; letter-spacing: 1px; }
.pd-rating-big-count { font-size: 11.5px; color: rgba(255,255,255,0.5); margin-top: 2px; }
.pd-write-review { display: inline-flex; align-items: center; gap: 6px; padding: 9px 14px; background: rgba(220,38,38,0.15); color: #dc2626; border: 1px solid rgba(220,38,38,0.3); border-radius: 10px; font-size: 12.5px; font-weight: 700; cursor: pointer; }
.pd-review { background: #171717; border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 14px; margin-bottom: 10px; }
.pd-review-head { display: flex; gap: 10px; align-items: flex-start; margin-bottom: 8px; }
.pd-review-avatar { width: 38px; height: 38px; border-radius: 50%; background: linear-gradient(135deg, #dc2626, #b91c1c); display: flex; align-items: center; justify-content: center; font-weight: 800; color: #fff; font-size: 14px; flex-shrink: 0; }
.pd-review-name { font-size: 13px; font-weight: 700; color: #fff; }
.pd-review-date { font-size: 10.5px; color: rgba(255,255,255,0.4); margin-top: 2px; }
.pd-review-body { font-size: 13px; color: rgba(255,255,255,0.75); line-height: 1.55; }
.pd-admin-reply { margin-top: 10px; padding: 10px; background: rgba(220,38,38,0.08); border-left: 3px solid #dc2626; border-radius: 6px; font-size: 12.5px; color: rgba(255,255,255,0.75); }
.pd-admin-reply strong { display: block; color: #dc2626; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 3px; }

/* Related */
.pd-related-title { font-size: 20px; font-weight: 900; color: #fff; margin: 32px 0 14px; display: flex; align-items: center; gap: 8px; }
.pd-related-title i { color: #dc2626; font-size: 16px; }
.pd-related-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
@media (min-width: 640px) { .pd-related-grid { grid-template-columns: repeat(3, minmax(0,1fr)); gap: 12px; } }
@media (min-width: 900px) { .pd-related-grid { grid-template-columns: repeat(4, minmax(0,1fr)); gap: 14px; } }

.pd-rcard { background: #171717; border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; overflow: hidden; text-decoration: none; color: inherit; display: flex; flex-direction: column; transition: border-color .2s, transform .2s; }
.pd-rcard:hover { border-color: rgba(220,38,38,0.4); transform: translateY(-2px); }
.pd-rcard-img { aspect-ratio: 1/1; background: #111; position: relative; overflow: hidden; }
.pd-rcard-img img { width: 100%; height: 100%; object-fit: cover; }
.pd-rcard-body { padding: 9px 11px 11px; flex: 1; display: flex; flex-direction: column; }
.pd-rcard-cat { font-size: 9px; font-weight: 800; color: #dc2626; text-transform: uppercase; letter-spacing: 0.5px; }
.pd-rcard-name { font-size: 12.5px; font-weight: 700; color: #fff; margin: 3px 0 6px; line-height: 1.3; min-height: 31px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.pd-rcard-price { font-size: 13.5px; font-weight: 800; color: #dc2626; margin-top: auto; margin-bottom: 8px; }
.pd-rcard-add { display: block; width: 100%; padding: 8px; background: #dc2626; color: #fff; border: 0; border-radius: 8px; font-size: 11.5px; font-weight: 800; text-align: center; text-decoration: none; cursor: pointer; }
.pd-rcard-add:hover { background: #b91c1c; }
.pd-rcard-add.disabled { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.4); pointer-events: none; }

/* Reviews extra */
.pd-review-like {
  display: inline-flex; align-items: center; gap: 6px;
  background: transparent; border: 0;
  color: rgba(255,255,255,0.6);
  font-size: 12.5px; font-weight: 600;
  cursor: pointer; padding: 4px 8px;
  border-radius: 6px;
  text-decoration: none;
  transition: all .15s;
}
.pd-review-like:hover { background: rgba(255,255,255,0.06); color: #fff; }
.pd-review-like.liked { color: #dc2626; }
.pd-review-like.liked i { animation: likePop .3s ease; }
@keyframes likePop {
  0% { transform: scale(1); }
  50% { transform: scale(1.3); }
  100% { transform: scale(1); }
}
/* Add-on with sizes */
.pd-addon-group {
  background: rgba(255,255,255,0.025);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 12px;
  padding: 12px 14px;
  margin-bottom: 10px;
}
.pd-addon-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}
.pd-addon-name {
  font-size: 14.5px;
  font-weight: 700;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 8px;
}
.pd-addon-price {
  font-size: 14px;
  font-weight: 800;
  color: #dc2626;
}
.pd-size-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
}
.pd-size-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 10px 6px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  cursor: pointer;
  transition: all .15s;
  text-align: center;
}
.pd-size-btn:hover { border-color: rgba(220,38,38,0.4); }
.pd-size-btn input:checked ~ * { color: #fff; }
.pd-size-btn:has(input:checked) {
  background: rgba(220,38,38,0.15);
  border-color: #dc2626;
  box-shadow: 0 0 0 2px rgba(220,38,38,0.2);
}
.pd-size-lbl {
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 1px;
  color: rgba(255,255,255,0.6);
}
.pd-size-btn:has(input:checked) .pd-size-lbl { color: #dc2626; }
.pd-size-prc {
  font-size: 11.5px;
  font-weight: 700;
  color: #fff;
}
</style>

<div class="pd-wrap">

  <!-- Breadcrumb -->
  <div class="pd-bread">
    <a href="<?= url('menu.php') ?>">Menu</a>
    <span>›</span>
    <?php if (!empty($p['category_slug'])): ?>
      <a href="<?= url('menu.php?category=' . urlencode($p['category_slug'])) ?>"><?= e($p['category_name']) ?></a>
      <span>›</span>
    <?php endif; ?>
    <span style="color:rgba(255,255,255,0.4);"><?= e($p['name']) ?></span>
  </div>

  <div class="pd-layout">

    <!-- Gallery -->
    <div class="pd-gallery">
      <div class="pd-hero" id="pdHero">
        <div class="pd-hero-badges">
          <?= render_product_badges((int)$p['id']) ?>
          <?php if ($hasSale): ?>
            <span class="pd-badge-chip" style="background:#16a34a;color:#fff;">SAVE <?= $discountPct ?>%</span>
          <?php endif; ?>
        </div>
        <img id="pdMainImage" src="<?= e($allImages[0]['src']) ?>" onerror="this.onerror=null;this.src='<?= $placeholder ?>'" alt="<?= e($p['name']) ?>">
        <?php if (count($allImages) > 1): ?>
          <button type="button" class="pd-hero-nav prev" onclick="pdGalleryNav(-1)"><i class="fa-solid fa-chevron-left"></i></button>
          <button type="button" class="pd-hero-nav next" onclick="pdGalleryNav(1)"><i class="fa-solid fa-chevron-right"></i></button>
          <div class="pd-hero-dots">
            <?php foreach ($allImages as $i => $img): ?>
              <button type="button" class="pd-hero-dot <?= $i === 0 ? 'active' : '' ?>" onclick="pdGalleryGo(<?= $i ?>)"></button>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
      <?php if (count($allImages) > 1): ?>
      <div class="pd-thumbs">
        <?php foreach ($allImages as $i => $img): ?>
          <button type="button" class="pd-thumb <?= $i === 0 ? 'active' : '' ?>" onclick="pdGalleryGo(<?= $i ?>)">
            <img src="<?= e($img['src']) ?>" onerror="this.onerror=null;this.src='<?= $placeholder ?>'" alt="Thumb">
          </button>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Info + Options -->
    <div id="pdConfig" data-base-price="<?= $basePrice ?>">
      <?php if (!empty($p['category_name'])): ?>
        <div class="pd-cat"><?= e($p['category_name']) ?></div>
      <?php endif; ?>

      <h1 class="pd-title"><?= e($p['name']) ?></h1>

      <?php if ((float)$p['rating_avg'] > 0): ?>
        <div class="pd-rating">
          <span class="pd-stars">
            <?php for ($i = 1; $i <= 5; $i++): ?><i class="fa-solid fa-star<?= $i > round((float)$p['rating_avg']) ? ' text-white/20' : '' ?>"></i><?php endfor; ?>
          </span>
          <strong style="color:#fff;"><?= number_format((float)$p['rating_avg'], 1) ?></strong>
          <span>(<?= (int)$p['review_count'] ?> reviews)</span>
        </div>
      <?php endif; ?>

      <?php if (!empty($p['short_description'])): ?>
        <p class="pd-desc"><?= e($p['short_description']) ?></p>
      <?php endif; ?>

      <div class="pd-price-row">
        <div class="pd-price" id="pdDisplayPrice"><?= money($basePrice) ?></div>
        <?php if ($hasSale): ?>
          <div class="pd-price-old"><?= money($p['price']) ?></div>
          <div class="pd-price-save">Save <?= money((float)$p['price'] - (float)$p['sale_price']) ?></div>
        <?php endif; ?>
      </div>

      <?php if (!restaurant_is_open()): ?>
        <div style="background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.4);color:#fca5a5;padding:11px 13px;border-radius:10px;font-size:13px;margin-bottom:14px;">
          <i class="fa-solid fa-exclamation-triangle"></i> Restaurant is currently closed.
        </div>
      <?php endif; ?>

      <form method="post" id="pdForm">
        <?= csrf_field() ?>

        <?php $stepNum = 1; ?>

        <?php foreach ($varGroups as $g): ?>
          <div class="pd-section">
            <div class="pd-section-head">
              <div class="pd-section-title">
                <span class="pd-section-num"><?= $stepNum ?></span>
                <?= e($g['display_name']) ?>
              </div>
              <?php if (!empty($g['is_required'])): ?>
                <span class="pd-required">Required</span>
              <?php else: ?>
                <span class="pd-optional">Optional</span>
              <?php endif; ?>
            </div>

            <div class="pd-opt-list">
              <?php
              $groupType = ($g['type'] ?? 'single') === 'multiple' ? 'checkbox' : 'radio';
              foreach ($g['options'] as $o):
                $abs    = (float)($o['absolute_price'] ?: 0);
                $delta  = (float)$o['price_delta'];
                $checked = !empty($o['is_default']);
                $priceLabel = '';
                $priceFree = false;
                if ($abs > 0) { $priceLabel = money($abs); }
                elseif ($delta > 0) { $priceLabel = '+' . money($delta); }
                elseif ($delta < 0) { $priceLabel = money($delta); }
                else { $priceLabel = 'Free'; $priceFree = true; }
              ?>
                <label class="pd-opt-row <?= $checked ? 'selected' : '' ?>">
                  <input type="<?= $groupType ?>" name="variation[<?= (int)$g['id'] ?>]<?= $groupType === 'checkbox' ? '[]' : '' ?>"
                         value="<?= (int)$o['id'] ?>"
                         data-abs-price="<?= $abs ?>"
                         data-delta="<?= $delta ?>"
                         <?= $checked ? 'checked' : '' ?>
                         <?= (!empty($g['is_required']) && $groupType === 'radio') ? 'required' : '' ?>>
                  <div class="pd-opt-left">
                    <div class="pd-indicator <?= $groupType ?>"></div>
                    <div class="pd-opt-name"><?= e($o['name']) ?></div>
                  </div>
                  <div class="pd-opt-price <?= $priceFree ? 'free' : '' ?>"><?= $priceLabel ?></div>
                </label>
              <?php endforeach; ?>
            </div>
          </div>
          <?php $stepNum++; ?>
        <?php endforeach; ?>

        <?php if ($addons): ?>
          <div class="pd-section">
            <div class="pd-section-head">
              <div class="pd-section-title">
                <span class="pd-section-num"><?= $stepNum ?></span>
                Add Extras
              </div>
              <span class="pd-optional">Optional</span>
            </div>

            <div class="pd-opt-list">
              <?php foreach ($addons as $a):
                $hasSz = (int)($a['has_sizes'] ?? 0) === 1;
              ?>
                <div class="pd-addon-group">
                  <div class="pd-addon-header">
                    <div class="pd-addon-name">
                      <i class="fa-solid fa-plus" style="color:#dc2626;"></i>
                      <?= e($a['name']) ?>
                    </div>
                    <?php if (!$hasSz): ?>
                      <div class="pd-addon-price">+<?= money($a['price']) ?></div>
                    <?php endif; ?>
                  </div>

                  <?php if ($hasSz): ?>
                    <div class="pd-size-row" data-addon-id="<?= (int)$a['id'] ?>">
                      <label class="pd-size-btn">
                        <input type="checkbox" name="addons[]" value="<?= (int)$a['id'] ?>" data-size="S" data-price="<?= (float)($a['price_s'] ?? 0) ?>" style="display:none;" onchange="onAddonToggle(this)">
                        <span class="pd-size-lbl">S</span>
                        <span class="pd-size-prc">Rs. <?= number_format((float)($a['price_s'] ?? 0), 0) ?></span>
                      </label>
                      <label class="pd-size-btn">
                        <input type="checkbox" name="addons[]" value="<?= (int)$a['id'] ?>" data-size="M" data-price="<?= (float)($a['price_m'] ?? 0) ?>" style="display:none;" onchange="onAddonToggle(this)">
                        <span class="pd-size-lbl">M</span>
                        <span class="pd-size-prc">Rs. <?= number_format((float)($a['price_m'] ?? 0), 0) ?></span>
                      </label>
                      <label class="pd-size-btn">
                        <input type="checkbox" name="addons[]" value="<?= (int)$a['id'] ?>" data-size="L" data-price="<?= (float)($a['price_l'] ?? 0) ?>" style="display:none;" onchange="onAddonToggle(this)">
                        <span class="pd-size-lbl">L</span>
                        <span class="pd-size-prc">Rs. <?= number_format((float)($a['price_l'] ?? 0), 0) ?></span>
                      </label>
                    </div>
                  <?php else: ?>
                    <label class="pd-opt-row" onclick="event.preventDefault(); this.querySelector('input').click();">
                      <input type="checkbox" name="addons[]" value="<?= (int)$a['id'] ?>" data-price="<?= (float)$a['price'] ?>" onchange="onAddonToggle(this)">
                      <div class="pd-opt-left">
                        <div class="pd-indicator checkbox"></div>
                        <div class="pd-opt-name">Add <?= e($a['name']) ?></div>
                      </div>
                      <div class="pd-opt-price">+<?= money($a['price']) ?></div>
                    </label>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php $stepNum++; ?>
        <?php endif; ?>

        <!-- Quantity -->
        <div class="pd-section">
          <div class="pd-section-head">
            <div class="pd-section-title">
              <span class="pd-section-num"><?= $stepNum ?></span>
              Quantity
            </div>
          </div>
          <div class="pd-qty-row">
            <div class="pd-qty">
              <button type="button" class="pd-qty-btn" data-delta="-1">−</button>
              <input type="number" name="quantity" id="pdQtyInput" value="1" min="1" max="50" class="pd-qty-input">
              <button type="button" class="pd-qty-btn" data-delta="1">+</button>
            </div>
          </div>
        </div>

        <!-- Total -->
        <div class="pd-total-strip">
          <div>
            <div class="pd-total-label">Item Total</div>
            <div style="font-size:10.5px;color:rgba(255,255,255,0.4);">Price updates live</div>
          </div>
          <div class="pd-total-value" id="pdTotalValue"><?= money($basePrice) ?></div>
        </div>

        <!-- CTA -->
        <div class="pd-cta-row">
          <button type="submit" <?= !$canOrder ? 'disabled' : '' ?> class="pd-add-btn">
            <i class="fa-solid fa-cart-plus"></i>
            <?= e($p['order_button_text'] ?: 'Add to Cart') ?>
          </button>
          <?php if (feature_enabled('wishlist')): ?>
            <?php if (customer_logged_in()): ?>
              <button type="submit" formaction="<?= url('actions/account/favorite-toggle.php') ?>" class="pd-fav-btn <?= $isFav ? 'active' : '' ?>" formnovalidate>
                <i class="fa-<?= $isFav ? 'solid' : 'regular' ?> fa-heart"></i>
                <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
                <input type="hidden" name="back" value="<?= url('product.php?slug=' . urlencode($p['slug'])) ?>">
              </button>
            <?php else: ?>
              <a href="<?= url('login.php') ?>" class="pd-fav-btn"><i class="fa-regular fa-heart"></i></a>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </form>

      <!-- Benefits -->
      <div class="pd-benefits">
        <h4><i class="fa-solid fa-circle-check"></i> Why You'll Love It</h4>
        <div class="pd-benefit">
          <div class="pd-benefit-icon green"><i class="fa-solid fa-leaf"></i></div>
          <div>
            <div class="pd-benefit-title">Fresh Ingredients</div>
            <div class="pd-benefit-text">Only the freshest ingredients used.</div>
          </div>
        </div>
        <div class="pd-benefit">
          <div class="pd-benefit-icon orange"><i class="fa-solid fa-truck-fast"></i></div>
          <div>
            <div class="pd-benefit-title">Fast Delivery</div>
            <div class="pd-benefit-text">Get your order hot and fresh.</div>
          </div>
        </div>
        <div class="pd-benefit">
          <div class="pd-benefit-icon blue"><i class="fa-solid fa-shield-heart"></i></div>
          <div>
            <div class="pd-benefit-title">Hygienic & Safe</div>
            <div class="pd-benefit-text">Prepared in clean environment.</div>
          </div>
        </div>
        <div class="pd-benefit">
          <div class="pd-benefit-icon red"><i class="fa-solid fa-thumbs-up"></i></div>
          <div>
            <div class="pd-benefit-title">Satisfaction Guaranteed</div>
            <div class="pd-benefit-text">Your happiness is our priority.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Tabs -->
  <div class="pd-tabs">
    <div class="pd-tab-nav">
      <button type="button" class="pd-tab-btn active" data-tab="description">Description</button>
      <?php if (!empty($p['ingredients'])): ?><button type="button" class="pd-tab-btn" data-tab="ingredients">Ingredients</button><?php endif; ?>
      <button type="button" class="pd-tab-btn" data-tab="details">Details</button>
      <button type="button" class="pd-tab-btn" data-tab="reviews">Reviews (<?= count($reviews) ?>)</button>
    </div>
    <div class="pd-tab-panel active" data-panel="description">
      <div class="pd-info-block">
        <?php if (!empty($p['description'])): ?><p style="margin:0;"><?= nl2br(e($p['description'])) ?></p>
        <?php elseif (!empty($p['short_description'])): ?><p style="margin:0;"><?= nl2br(e($p['short_description'])) ?></p>
        <?php else: ?><p style="margin:0;color:rgba(255,255,255,0.5);">No description available.</p><?php endif; ?>
      </div>
    </div>
    <?php if (!empty($p['ingredients'])): ?>
    <div class="pd-tab-panel" data-panel="ingredients">
      <div class="pd-info-block"><p style="margin:0;"><?= nl2br(e($p['ingredients'])) ?></p></div>
    </div>
    <?php endif; ?>
    <div class="pd-tab-panel" data-panel="details">
      <div class="pd-info-block">
        <div class="pd-info-grid">
          <div class="row"><span>Category</span><strong><?= e($p['category_name'] ?? 'N/A') ?></strong></div>
          <?php if (!empty($p['prep_time_minutes'])): ?><div class="row"><span>Prep Time</span><strong><?= (int)$p['prep_time_minutes'] ?> min</strong></div><?php endif; ?>
          <div class="row"><span>Availability</span><strong style="color:<?= $canOrder ? '#4ade80' : '#f87171' ?>;"><?= $canOrder ? 'Available' : 'Unavailable' ?></strong></div>
        </div>
      </div>
    </div>
    <div class="pd-tab-panel" data-panel="reviews">
      <?php if (feature_enabled('product_reviews')): ?>

        <div class="pd-reviews-head">
          <div class="pd-rating-big">
            <div class="pd-rating-big-num"><?= number_format((float)$p['rating_avg'], 1) ?></div>
            <div>
              <div class="pd-rating-big-stars">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                  <i class="fa-solid fa-star<?= $i > round((float)$p['rating_avg']) ? ' text-white/20' : '' ?>"></i>
                <?php endfor; ?>
              </div>
              <div class="pd-rating-big-count"><?= count($reviews) ?> reviews</div>
            </div>
          </div>

          <?php if (customer_logged_in()): ?>
            <?php if ($canReview): ?>
              <button type="button" class="pd-write-review" onclick="document.getElementById('pdReviewForm').style.display='block';this.style.display='none';">
                <i class="fa-solid fa-pen"></i> Write a Review
              </button>
            <?php else: ?>
              <span style="font-size:12px;color:rgba(255,255,255,0.5);padding:8px 12px;background:rgba(255,255,255,0.05);border-radius:8px;">
                <i class="fa-solid fa-circle-info"></i> Order first to review
              </span>
            <?php endif; ?>
          <?php else: ?>
            <a href="<?= url('login.php') ?>" class="pd-write-review">
              <i class="fa-solid fa-right-to-bracket"></i> Login to Review
            </a>
          <?php endif; ?>
        </div>

        <!-- Review Form -->
        <?php if ($canReview): ?>
        <form method="post" action="<?= url('actions/account/review-submit.php') ?>" class="pd-review-form" id="pdReviewForm" style="display:none;">
          <?= csrf_field() ?>
          <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
          <input type="hidden" name="product_slug" value="<?= e($p['slug']) ?>">

          <div style="font-size:13px;font-weight:700;color:#fff;margin-bottom:8px;">Your Rating *</div>
          <div class="pd-star-select" id="pdStarSelect">
            <?php for ($i = 1; $i <= 5; $i++): ?>
              <label data-star="<?= $i ?>">
                <input type="radio" name="rating" value="<?= $i ?>" <?= $i === 5 ? 'checked' : '' ?>>
                <i class="fa-solid fa-star"></i>
              </label>
            <?php endfor; ?>
          </div>

          <input name="title" placeholder="Review title (optional)" maxlength="190"
                 style="width:100%;padding:12px 14px;background:rgba(0,0,0,0.4);border:1.5px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:14px;margin-bottom:10px;outline:none;font-family:inherit;">

          <textarea name="comment" rows="4" placeholder="Share your experience with this product..." maxlength="2000"
                    style="width:100%;padding:12px 14px;background:rgba(0,0,0,0.4);border:1.5px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:14px;margin-bottom:12px;outline:none;font-family:inherit;resize:vertical;"></textarea>

          <div style="display:flex;gap:10px;">
            <button type="submit" style="background:#dc2626;color:#fff;padding:12px 24px;border:0;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;">
              <i class="fa-solid fa-paper-plane"></i> Submit Review
            </button>
            <button type="button" onclick="document.getElementById('pdReviewForm').style.display='none';" style="background:rgba(255,255,255,0.08);color:#fff;padding:12px 20px;border:0;border-radius:10px;font-weight:600;font-size:13px;cursor:pointer;">
              Cancel
            </button>
          </div>
        </form>
        <?php endif; ?>

        <!-- Reviews List -->
        <?php if (!$reviews): ?>
          <div style="text-align:center;padding:40px 20px;background:#171717;border:1px solid rgba(255,255,255,0.06);border-radius:14px;color:rgba(255,255,255,0.5);">
            <i class="fa-solid fa-comment-dots" style="font-size:40px;margin-bottom:12px;display:block;opacity:0.3;"></i>
            <p style="margin:0;font-size:13.5px;">No reviews yet. Be the first to share your experience!</p>
          </div>
        <?php else: foreach ($reviews as $rv): ?>
          <div class="pd-review" data-review-id="<?= (int)$rv['id'] ?>">
            <div class="pd-review-head">
              <div class="pd-review-avatar"><?= e(strtoupper(mb_substr($rv['user_name'] ?? 'U', 0, 1))) ?></div>
              <div style="flex:1;min-width:0;">
                <div class="pd-review-name">
                  <?= e($rv['user_name'] ?? 'Customer') ?>
                  <?php if ((int)$rv['is_verified_purchase']): ?>
                    <span style="font-size:10px;color:#4ade80;margin-left:6px;font-weight:600;">
                      <i class="fa-solid fa-circle-check"></i> Verified
                    </span>
                  <?php endif; ?>
                </div>
                <div class="pd-review-date"><?= date('d M Y', strtotime($rv['created_at'])) ?></div>
                <div style="color:#fbbf24;font-size:12px;margin-top:2px;letter-spacing:1px;">
                  <?php for ($i = 1; $i <= 5; $i++): ?>
                    <i class="fa-solid fa-star<?= $i > (int)$rv['rating'] ? ' text-white/20' : '' ?>"></i>
                  <?php endfor; ?>
                </div>
              </div>
            </div>
            <?php if (!empty($rv['title'])): ?>
              <div style="font-size:13.5px;font-weight:700;color:#fff;margin-bottom:4px;"><?= e($rv['title']) ?></div>
            <?php endif; ?>
            <?php if (!empty($rv['comment'])): ?>
              <div class="pd-review-body"><?= nl2br(e($rv['comment'])) ?></div>
            <?php endif; ?>

            <?php if (!empty($rv['admin_reply'])): ?>
              <div class="pd-admin-reply">
                <strong>Reply from <?= e(setting('restaurant_name', 'Friends Pizza Hut')) ?></strong>
                <?= nl2br(e($rv['admin_reply'])) ?>
              </div>
            <?php endif; ?>

            <!-- Actions: Like + Reply -->
            <div style="display:flex;gap:14px;align-items:center;margin-top:10px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.05);">
              <?php if (customer_logged_in()): ?>
                <button type="button" class="pd-review-like <?= $rv['user_liked'] ? 'liked' : '' ?>"
                        onclick="reviewToggleLike(<?= (int)$rv['id'] ?>, this)">
                  <i class="fa-<?= $rv['user_liked'] ? 'solid' : 'regular' ?> fa-thumbs-up"></i>
                  <span class="like-count"><?= (int)$rv['like_count'] ?></span>
                </button>
              <?php else: ?>
                <a href="<?= url('login.php') ?>" class="pd-review-like">
                  <i class="fa-regular fa-thumbs-up"></i>
                  <span class="like-count"><?= (int)$rv['like_count'] ?></span>
                </a>
              <?php endif; ?>

              <?php if (customer_logged_in()): ?>
                <button type="button" class="pd-review-like" onclick="reviewReplyToggle(<?= (int)$rv['id'] ?>)">
                  <i class="fa-regular fa-comment"></i>
                  <span><?= count($rv['replies']) ?> Replies</span>
                </button>
              <?php else: ?>
                <span class="pd-review-like" style="opacity:0.5;">
                  <i class="fa-regular fa-comment"></i>
                  <span><?= count($rv['replies']) ?> Replies</span>
                </span>
              <?php endif; ?>
            </div>

            <!-- Replies -->
            <div class="pd-replies-list" id="replies-<?= (int)$rv['id'] ?>" style="margin-top:12px;padding-left:16px;border-left:2px solid rgba(220,38,38,0.3);">
              <?php foreach ($rv['replies'] as $reply): ?>
                <div style="margin-bottom:10px;">
                  <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                    <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#dc2626,#7f1d1d);display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;font-size:11px;">
                      <?= e(strtoupper(mb_substr($reply['user_name'], 0, 1))) ?>
                    </div>
                    <div style="font-size:12.5px;font-weight:700;color:#fff;"><?= e($reply['user_name']) ?></div>
                    <div style="font-size:10.5px;color:rgba(255,255,255,0.4);"><?= date('d M', strtotime($reply['created_at'])) ?></div>
                  </div>
                  <div style="font-size:13px;color:rgba(255,255,255,0.75);line-height:1.5;"><?= nl2br(e($reply['reply_text'])) ?></div>
                </div>
              <?php endforeach; ?>
            </div>

            <!-- Reply Form -->
            <?php if (customer_logged_in()): ?>
            <form method="post" action="<?= url('actions/account/review-reply.php') ?>" class="pd-reply-form" id="reply-form-<?= (int)$rv['id'] ?>" style="display:none;margin-top:10px;">
              <?= csrf_field() ?>
              <input type="hidden" name="review_id" value="<?= (int)$rv['id'] ?>">
              <input type="hidden" name="product_slug" value="<?= e($p['slug']) ?>">
              <textarea name="reply_text" rows="2" required maxlength="1000" placeholder="Write your reply..."
                        style="width:100%;padding:10px 12px;background:rgba(0,0,0,0.4);border:1.5px solid rgba(255,255,255,0.1);border-radius:10px;color:#fff;font-size:13px;outline:none;font-family:inherit;resize:vertical;"></textarea>
              <div style="display:flex;gap:8px;margin-top:8px;">
                <button type="submit" style="background:#dc2626;color:#fff;padding:8px 16px;border:0;border-radius:8px;font-weight:700;font-size:12.5px;cursor:pointer;">
                  Reply
                </button>
                <button type="button" onclick="reviewReplyToggle(<?= (int)$rv['id'] ?>)" style="background:rgba(255,255,255,0.08);color:#fff;padding:8px 14px;border:0;border-radius:8px;font-weight:600;font-size:12px;cursor:pointer;">
                  Cancel
                </button>
              </div>
            </form>
            <?php endif; ?>
          </div>
        <?php endforeach; endif; ?>

      <?php else: ?>
        <div class="pd-info-block">
          <p style="margin:0;color:rgba(255,255,255,0.5);">Reviews are currently disabled.</p>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Related -->
  <?php if ($related): ?>
  <h2 class="pd-related-title"><i class="fa-solid fa-heart"></i> You May Also Like</h2>
  <div class="pd-related-grid">
    <?php foreach ($related as $rp):
      $rImg = !empty($rp['image']) ? upload_url($rp['image']) : $placeholder;
      $rPrice = (float)($rp['sale_price'] ?: $rp['price']);
      $rHasSale = !empty($rp['sale_price']) && $rp['sale_price'] < $rp['price'];
      $rCanOrder = (int)($rp['order_button_enabled'] ?? 1) === 1 && $rp['status'] === 'active' && (int)$rp['is_available'] === 1;
    ?>
      <div class="pd-rcard">
        <a href="<?= url('product.php?slug=' . urlencode($rp['slug'])) ?>">
          <div class="pd-rcard-img">
            <div class="pd-hero-badges"><?= render_product_badges((int)$rp['id'], true) ?></div>
            <img src="<?= e($rImg) ?>" onerror="this.onerror=null;this.src='<?= $placeholder ?>'" alt="<?= e($rp['name']) ?>" loading="lazy">
          </div>
        </a>
        <div class="pd-rcard-body">
          <?php if (!empty($rp['category_name'])): ?><div class="pd-rcard-cat"><?= e($rp['category_name']) ?></div><?php endif; ?>
          <a href="<?= url('product.php?slug=' . urlencode($rp['slug'])) ?>" style="text-decoration:none;color:inherit;">
            <div class="pd-rcard-name"><?= e($rp['name']) ?></div>
          </a>
          <div class="pd-rcard-price"><?= money($rPrice) ?><?php if ($rHasSale): ?><span style="font-size:10.5px;color:rgba(255,255,255,0.35);text-decoration:line-through;margin-left:4px;font-weight:500;"><?= money($rp['price']) ?></span><?php endif; ?></div>
          <a href="<?= url('product.php?slug=' . urlencode($rp['slug'])) ?>" class="pd-rcard-add <?= !$rCanOrder ? 'disabled' : '' ?>">
            <i class="fa-solid fa-cart-plus"></i> Add
          </a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

</div>

<script>
(function() {
  // ─── Gallery ──────────────────────────────────────────────
  var galleryImages = <?= json_encode(array_map(fn($x) => $x['src'], $allImages)) ?>;
  var galleryIdx = 0;
  window.pdGalleryGo = function(i) {
    if (i < 0) i = galleryImages.length - 1;
    if (i >= galleryImages.length) i = 0;
    galleryIdx = i;
    var main = document.getElementById('pdMainImage');
    if (main) main.src = galleryImages[i];
    document.querySelectorAll('.pd-hero-dot').forEach(function(d, n) { d.classList.toggle('active', n === i); });
    document.querySelectorAll('.pd-thumb').forEach(function(t, n) { t.classList.toggle('active', n === i); });
  };
  window.pdGalleryNav = function(delta) { window.pdGalleryGo(galleryIdx + delta); };

  // ─── Tabs ─────────────────────────────────────────────────
  document.querySelectorAll('.pd-tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var tab = btn.dataset.tab;
      document.querySelectorAll('.pd-tab-btn').forEach(function(b) { b.classList.remove('active'); });
      document.querySelectorAll('.pd-tab-panel').forEach(function(p) { p.classList.remove('active'); });
      btn.classList.add('active');
      var panel = document.querySelector('.pd-tab-panel[data-panel="' + tab + '"]');
      if (panel) panel.classList.add('active');
    });
  });


  // Review like toggle
  window.reviewToggleLike = function(reviewId, btn) {
    fetch('<?= url('actions/account/review-like.php') ?>', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'review_id=' + reviewId + '&csrf_token=<?= csrf_token() ?>'
    }).then(function(r) { return r.json(); }).then(function(data) {
      if (data.ok) {
        var cnt = btn.querySelector('.like-count');
        var icon = btn.querySelector('i');
        if (data.liked) {
          btn.classList.add('liked');
          icon.className = 'fa-solid fa-thumbs-up';
        } else {
          btn.classList.remove('liked');
          icon.className = 'fa-regular fa-thumbs-up';
        }
        if (cnt) cnt.textContent = data.count;
      }
    });
  };

  // Reply form toggle
  window.reviewReplyToggle = function(reviewId) {
    var f = document.getElementById('reply-form-' + reviewId);
    if (f) f.style.display = (f.style.display === 'none' || !f.style.display) ? 'block' : 'none';
  };

  // Star rating click
  document.querySelectorAll('.pd-star-select label').forEach(function(lbl, idx) {
    lbl.addEventListener('click', function() {
      document.querySelectorAll('.pd-star-select input').forEach(function(i, n) {
        i.checked = (n === idx);
      });
      document.querySelectorAll('.pd-star-select label i').forEach(function(star, n) {
        star.style.opacity = n <= idx ? '1' : '0.3';
      });
    });
  });

  // ─── Live price calculation ───────────────────────────────
  var config = document.getElementById('pdConfig');
  if (!config) return;
  var basePrice   = parseFloat(config.dataset.basePrice || '0');
  var qtyInput    = document.getElementById('pdQtyInput');
  var totalEl     = document.getElementById('pdTotalValue');
  var displayEl   = document.getElementById('pdDisplayPrice');
  var allInputs   = config.querySelectorAll('input[name^="variation["]');
  var addonInputs = config.querySelectorAll('input[name="addons[]"]');

  function recalc() {
    var selectedAbs = null;
    var deltaSum = 0;

    allInputs.forEach(function(inp) {
      if (!inp.checked) return;
      var abs = parseFloat(inp.dataset.absPrice || '0');
      var delta = parseFloat(inp.dataset.delta || '0');
      if (abs > 0) {
        // Use the highest absolute (which is typically the size choice)
        if (selectedAbs === null || abs > selectedAbs) selectedAbs = abs;
      } else if (delta !== 0) {
        deltaSum += delta;
      }
    });

    var itemBase = selectedAbs !== null ? selectedAbs : basePrice;
    itemBase += deltaSum;

    var addonsTotal = 0;
    addonInputs.forEach(function(inp) { if (inp.checked) addonsTotal += parseFloat(inp.dataset.price || '0'); });

    var qty = Math.max(1, parseInt(qtyInput ? qtyInput.value : '1', 10) || 1);
    var total = (itemBase + addonsTotal) * qty;

    if (totalEl) {
      totalEl.textContent = 'Rs. ' + Math.round(total).toLocaleString('en-PK');
      totalEl.classList.add('bump');
      setTimeout(function() { totalEl.classList.remove('bump'); }, 180);
    }
    if (displayEl) displayEl.textContent = 'Rs. ' + Math.round(itemBase).toLocaleString('en-PK');
  }

  // Handle addon size selection — allow only one size per addon group.
  window.onAddonToggle = function(input) {
    var row = input.closest('.pd-size-row');
    if (row) {
      row.querySelectorAll('input[name="addons[]"]').forEach(function(sib) {
        if (sib !== input) sib.checked = false;
      });
    }
    recalc();
  };

  // Row click handling — make the whole row clickable
  document.querySelectorAll('.pd-opt-row').forEach(function(row) {
    row.addEventListener('click', function(e) {
      // If clicking on input directly (shouldn't happen since it's hidden), skip
      if (e.target.tagName === 'INPUT') return;
      e.preventDefault();
      var inp = row.querySelector('input');
      if (!inp) return;

      if (inp.type === 'radio') {
        // Uncheck all in same group
        var gname = inp.name;
        document.querySelectorAll('input[name="' + gname + '"]').forEach(function(other) {
          other.checked = (other === inp);
          var optRow = other.closest('.pd-opt-row');
          if (optRow) optRow.classList.toggle('selected', other.checked);
        });
        inp.checked = true;
      } else if (inp.type === 'checkbox') {
        inp.checked = !inp.checked;
        row.classList.toggle('selected', inp.checked);
      }
      recalc();
    });
  });

  // Qty buttons
  document.querySelectorAll('.pd-qty-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      if (!qtyInput) return;
      var delta = parseInt(btn.dataset.delta, 10);
      var v = Math.max(1, Math.min(50, (parseInt(qtyInput.value, 10) || 1) + delta));
      qtyInput.value = v;
      recalc();
    });
  });
  if (qtyInput) qtyInput.addEventListener('input', recalc);

  // Prevent double-submit
  var form = document.getElementById('pdForm');
  if (form) {
    form.addEventListener('submit', function(e) {
      var btn = form.querySelector('.pd-add-btn');
      if (btn && e.submitter !== btn) return;

      // Submit selected size addons as structured {id, size} entries for add_to_cart().
      var selectedAddons = Array.prototype.slice.call(form.querySelectorAll('input[name="addons[]"]:checked'));
      selectedAddons.forEach(function(inp, index) {
        var size = inp.dataset.size;
        if (size) {
          inp.name = 'addons[' + index + '][id]';
          var sizeField = document.createElement('input');
          sizeField.type = 'hidden';
          sizeField.name = 'addons[' + index + '][size]';
          sizeField.value = size;
          form.appendChild(sizeField);
        } else {
          inp.name = 'addons[' + index + ']';
        }
      });

      if (btn) {
        setTimeout(function() {
          btn.disabled = true;
          btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Adding...';
        }, 10);
      }
    });
  }

  recalc();
})();
</script>

<?php require __DIR__ . '/common/footer.php'; ?>