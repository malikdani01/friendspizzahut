<?php
// actions/auth/logout.php
require_once __DIR__ . '/../../common/bootstrap.php';
logout_customer();
flash_info('Logged out.');
redirect(url('index.php'));