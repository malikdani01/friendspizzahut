<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Search';
$q = trim((string)get('q', ''));
$results = $q ? get_products(['search' => $q, 'available' => 1, 'limit' => 60]) : [];
require __DIR__ . '/common/header.php';
?>
<div class="max-w-7xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-6">Search</h1>
  <form method="get" class="mb-8">
    <div class="flex gap-2">
      <input name="q" value="<?= e($q) ?>" autofocus placeholder="Search for pizzas, burgers, deals..."
             class="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-3 outline-none focus:border-brand">
      <button class="bg-brand px-6 py-3 rounded-lg font-bold">Search</button>
    </div>
  </form>

  <?php if ($q): ?>
    <p class="text-white/60 mb-6"><?= count($results) ?> result(s) for "<span class="text-brand font-semibold"><?= e($q) ?></span>"</p>
    <?php if ($results): ?>
      <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        <?php foreach ($results as $p): require __DIR__ . '/common/components/product-card.php'; endforeach; ?>
      </div>
    <?php else: ?>
      <div class="text-center py-16 text-white/60">
        <i class="fa-solid fa-magnifying-glass text-4xl mb-3 opacity-40"></i>
        <p>No results found. Try a different keyword.</p>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>