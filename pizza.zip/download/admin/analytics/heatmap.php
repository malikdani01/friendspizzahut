<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('peak_hours_heatmap')) {
    flash_error('Heatmap feature disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Peak Hours Heatmap';

$from = (string)get('from', date('Y-m-d', strtotime('-30 days')));
$to = (string)get('to', date('Y-m-d'));
$data = get_heatmap_data($from, $to);
$max = max(1, (int)$data['max_count']);

require __DIR__ . '/../common/header.php';
?>

<form class="flex flex-wrap gap-2 mb-5">
  <input type="date" name="from" value="<?= e($from) ?>" class="border rounded px-3 py-2 text-sm">
  <input type="date" name="to" value="<?= e($to) ?>" class="border rounded px-3 py-2 text-sm">
  <button class="bg-gray-800 text-white px-4 py-2 rounded text-sm">Apply</button>
</form>

<div class="grid md:grid-cols-3 gap-4 mb-6">
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Peak Day</div>
    <div class="text-2xl font-extrabold text-brand"><?= heatmap_day_name((int)$data['peak_day']) ?></div>
  </div>
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Peak Hour</div>
    <div class="text-2xl font-extrabold text-brand"><?= sprintf('%02d:00', (int)$data['peak_hour']) ?></div>
  </div>
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Peak Orders</div>
    <div class="text-2xl font-extrabold text-brand"><?= (int)$data['peak_count'] ?></div>
  </div>
</div>

<div class="bg-white rounded-xl border p-5 overflow-x-auto">
  <h3 class="font-bold mb-4">Order Density Heatmap</h3>

  <?php if ($data['peak_count'] === 0): ?>
    <div class="text-center py-10 text-gray-400">Is period mein koi order nahi.</div>
  <?php else: ?>
    <table class="text-xs" style="border-collapse: separate; border-spacing: 2px;">
      <thead>
        <tr>
          <th class="text-right pr-2 text-gray-500 font-normal">Hour →</th>
          <?php for ($h = 0; $h < 24; $h++): ?>
            <th class="text-center text-gray-500 font-normal" style="min-width: 28px;"><?= $h ?></th>
          <?php endfor; ?>
          <th class="text-left pl-2 text-gray-500 font-normal">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php for ($d = 1; $d <= 7; $d++): ?>
        <tr>
          <td class="text-right pr-2 font-semibold" style="white-space: nowrap;"><?= heatmap_day_short($d) ?></td>
          <?php for ($h = 0; $h < 24; $h++):
              $count = (int)$data['matrix'][$d][$h]['count'];
              $intensity = $max > 0 ? ($count / $max) : 0;
              $alpha = 0.1 + ($intensity * 0.9);
              $bg = 'rgba(220, 38, 38, ' . round($alpha, 2) . ')';
              $textColor = $intensity > 0.6 ? '#fff' : '#000';
          ?>
            <td class="text-center font-bold" style="width: 28px; height: 28px; background: <?= $bg ?>; color: <?= $textColor ?>; border-radius: 4px; font-size: 10px;" title="<?= heatmap_day_name($d) ?> <?= $h ?>:00 — <?= $count ?> orders">
              <?= $count > 0 ? $count : '' ?>
            </td>
          <?php endfor; ?>
          <td class="text-left pl-2 font-bold"><?= (int)$data['day_totals'][$d] ?></td>
        </tr>
        <?php endfor; ?>
        <tr>
          <td class="text-right pr-2 pt-2 text-gray-500 font-normal">Total</td>
          <?php for ($h = 0; $h < 24; $h++): ?>
            <td class="text-center pt-2 font-bold text-gray-700"><?= (int)$data['hourly_totals'][$h] ?></td>
          <?php endfor; ?>
          <td></td>
        </tr>
      </tbody>
    </table>

    <div class="mt-6 flex items-center gap-2 text-xs text-gray-500">
      <span>Low</span>
      <?php for ($i = 0; $i <= 10; $i++): 
          $alpha = 0.1 + ($i * 0.09);
      ?>
        <span style="width: 16px; height: 16px; background: rgba(220, 38, 38, <?= round($alpha, 2) ?>); border-radius: 3px; display: inline-block;"></span>
      <?php endfor; ?>
      <span>High</span>
    </div>
  <?php endif; ?>
</div>

<div class="mt-5 bg-blue-50 border border-blue-200 rounded-xl p-5 text-sm text-blue-900">
  <div class="font-bold mb-2"><i class="fa-solid fa-lightbulb mr-1"></i> Heatmap Kaise Use Karo</div>
  <ul class="list-disc list-inside space-y-1">
    <li><strong>Peak hours</strong> mein extra staff rakho</li>
    <li><strong>Off-peak hours</strong> (light color) mein special offer SMS bhejo</li>
    <li><strong>Weekend high</strong> hai → Friday night deals banao</li>
    <li><strong>Weekday low</strong> hai → "Tuesday Special" launch karo</li>
    <li>Rider scheduling peak hours ke hisab se karo</li>
    <li>Product prep — peak se 30 min pehle ready rakho</li>
  </ul>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>