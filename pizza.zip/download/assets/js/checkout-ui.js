document.addEventListener('change', e => {
  if (e.target.name === 'order_type') {
    document.getElementById('deliveryBlock').style.display = e.target.value === 'delivery' ? '' : 'none';
  }
});