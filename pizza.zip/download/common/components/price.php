<?php /** @var float $price @var float|null $salePrice */
$price = (float)($price ?? 0); $salePrice = $salePrice ?? null; ?>
<div class="flex items-baseline gap-2">
  <span class="text-brand font-extrabold text-lg"><?= money($salePrice ?: $price) ?></span>
  <?php if ($salePrice && $salePrice < $price): ?>
    <span class="text-white/40 line-through text-sm"><?= money($price) ?></span>
  <?php endif; ?>
</div>