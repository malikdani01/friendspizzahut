<?php
// checkout.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Checkout Settings';
if (is_post()) {
    verify_csrf();
    foreach (['tax_percent','service_fee','packaging_fee'] as $k) update_setting($k, (string)post($k,'0'));
    flash_success('Saved.');
    redirect(url('admin/settings/checkout.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <div><label class="text-xs text-gray-500">Tax %</label><input type="number" step="0.01" name="tax_percent" value="<?= e(setting('tax_percent','0')) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Service Fee</label><input type="number" step="0.01" name="service_fee" value="<?= e(setting('service_fee','0')) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Packaging Fee</label><input type="number" step="0.01" name="packaging_fee" value="<?= e(setting('packaging_fee','0')) ?>" class="w-full border rounded px-3 py-2"></div>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>