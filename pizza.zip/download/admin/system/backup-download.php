<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('backup_restore')) {
    flash_error('Backup feature disabled.');
    redirect(url('admin/dashboard.php'));
}

$file = basename((string)get('file', ''));
$path = backup_dir() . '/' . $file;

if (!file_exists($path) || !str_starts_with(realpath($path), realpath(backup_dir()))) {
    flash_error('Backup file not found.');
    redirect(url('admin/system/backup.php'));
}

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($path));
header('Cache-Control: no-cache, must-revalidate');
readfile($path);
exit;