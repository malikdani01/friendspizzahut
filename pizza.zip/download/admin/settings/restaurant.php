<?php
// restaurant.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Restaurant Info';
if (is_post()) {
    verify_csrf();
    foreach (['restaurant_name','restaurant_owner','restaurant_phone','restaurant_whatsapp','restaurant_email','restaurant_address','restaurant_city','opening_time','closing_time','restaurant_status','tagline'] as $k) {
        update_setting($k, (string)post($k,''));
    }
    flash_success('Saved.');
    redirect(url('admin/settings/restaurant.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-3xl bg-white rounded-xl border p-6">
  <form method="post" class="grid md:grid-cols-2 gap-4"><?= csrf_field() ?>
    <?php foreach (['restaurant_name'=>'Name','restaurant_owner'=>'Owner','restaurant_phone'=>'Phone','restaurant_whatsapp'=>'WhatsApp','restaurant_email'=>'Email','restaurant_address'=>'Address','restaurant_city'=>'City','opening_time'=>'Opening Time','closing_time'=>'Closing Time','tagline'=>'Tagline'] as $k=>$l): ?>
      <div><label class="text-xs text-gray-500"><?= $l ?></label><input name="<?= $k ?>" value="<?= e(setting($k,'')) ?>" class="w-full border rounded px-3 py-2"></div>
    <?php endforeach; ?>
    <div class="md:col-span-2">
      <label class="text-xs text-gray-500">Status</label>
      <select name="restaurant_status" class="w-full border rounded px-3 py-2">
        <?php foreach (['open'=>'Open','closed'=>'Closed','temporary'=>'Temporarily Closed'] as $k=>$v): ?>
          <option value="<?= $k ?>" <?= setting('restaurant_status')===$k?'selected':'' ?>><?= $v ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button class="md:col-span-2 bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>