<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('gift_cards')) { flash_error('Gift cards disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'Gift Cards';

if (is_post()) {
    verify_csrf();
    if (post('action') === 'create') {
        $code = strtoupper(trim((string)post('code',''))) ?: strtoupper(substr(bin2hex(random_bytes(6)),0,12));
        $amount = (float)post('amount',0);
        Database::insert('gift_cards', [
            'code' => $code, 'initial_balance' => $amount, 'current_balance' => $amount,
            'recipient_name' => trim((string)post('recipient_name','')) ?: null,
            'recipient_email' => trim((string)post('recipient_email','')) ?: null,
            'expires_at' => post('expires_at') ?: null,
            'is_active' => 1,
        ]);
        flash_success("Gift card created: $code");
    } elseif (post('action') === 'toggle') {
        Database::execute("UPDATE gift_cards SET is_active = 1 - is_active WHERE id=?", [(int)post('id')]);
        flash_success('Updated.');
    }
    redirect(url('admin/gift-cards/index.php'));
}
$rows = Database::fetchAll("SELECT * FROM gift_cards ORDER BY id DESC LIMIT 100");
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl shadow-sm border p-5 h-fit">
    <h3 class="font-bold mb-3">Issue New Gift Card</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <input name="code" placeholder="Code (auto)" class="w-full border rounded px-3 py-2 font-mono">
      <input type="number" step="0.01" name="amount" placeholder="Amount *" required class="w-full border rounded px-3 py-2">
      <input name="recipient_name" placeholder="Recipient name" class="w-full border rounded px-3 py-2">
      <input name="recipient_email" placeholder="Recipient email" class="w-full border rounded px-3 py-2">
      <input type="date" name="expires_at" class="w-full border rounded px-3 py-2">
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Issue Card</button>
    </form>
  </div>
  <div class="md:col-span-2 bg-white rounded-xl shadow-sm border overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">Code</th><th class="text-left px-4 py-3">Recipient</th><th class="text-right">Balance</th><th class="text-left px-4 py-3">Status</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($rows as $g): ?>
        <tr class="border-t">
          <td class="px-4 py-3 font-mono font-bold"><?= e($g['code']) ?></td>
          <td class="px-4 py-3"><?= e($g['recipient_name'] ?: '—') ?></td>
          <td class="px-4 py-3 text-right font-semibold"><?= money($g['current_balance']) ?> <span class="text-xs text-gray-400">/ <?= money($g['initial_balance']) ?></span></td>
          <td class="px-4 py-3"><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$g['id'] ?>"><button class="text-xs px-2 py-1 rounded <?= $g['is_active']?'bg-green-100 text-green-800':'bg-gray-200' ?>"><?= $g['is_active']?'Active':'Disabled' ?></button></form></td>
          <td class="px-4 py-3 text-xs text-gray-500"><?= $g['expires_at'] ? date('d M Y', strtotime($g['expires_at'])) : '' ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="5" class="py-8 text-center text-gray-400">No gift cards yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>