<?php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!customer_logged_in()) { flash_error('Login required.'); redirect(url('login.php')); }
if (!is_post()) redirect(url('menu.php'));
verify_csrf();

$reviewId    = (int)post('review_id', 0);
$text        = (string)post('reply_text', '');
$productSlug = (string)post('product_slug', '');

$review = Database::fetch("SELECT id FROM reviews WHERE id = ? AND is_approved = 1", [$reviewId]);
if (!$review) { flash_error('Review not found.'); redirect(url('menu.php')); }

$r = review_add_reply($reviewId, (int)$_SESSION['user_id'], $text);
if ($r['ok']) flash_success('Reply posted!');
else flash_error($r['error']);

redirect(url('product.php?slug=' . urlencode($productSlug)) . '#replies-' . $reviewId);