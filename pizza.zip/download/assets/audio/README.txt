Place order-alert.mp3 here.

Free alert sounds:
- https://mixkit.co/free-sound-effects/notification/
- https://notificationsounds.com/
- https://pixabay.com/sound-effects/search/notification/

Recommended: 1-2 second chime sound, saved as order-alert.mp3