<?php
// transactions.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('gift_cards')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Gift Card Transactions';
$rows = Database::fetchAll("SELECT t.*, g.code FROM gift_card_transactions t LEFT JOIN gift_cards g ON g.id=t.gift_card_id ORDER BY t.id DESC LIMIT 200");
require __DIR__ . '/../common/header.php';
?>
<div class="bg-white rounded-xl border overflow-x-auto">
  <table class="w-full text-sm"><thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">Card</th><th class="text-left px-4 py-3">Type</th><th class="text-right px-4 py-3">Amount</th><th class="text-left px-4 py-3">Date</th></tr></thead>
  <tbody><?php foreach ($rows as $r): ?><tr class="border-t"><td class="px-4 py-3 font-mono"><?= e($r['code']) ?></td><td class="px-4 py-3 capitalize"><?= e($r['type']) ?></td><td class="px-4 py-3 text-right font-semibold"><?= money($r['amount']) ?></td><td class="px-4 py-3 text-xs text-gray-500"><?= date('d M Y H:i', strtotime($r['created_at'])) ?></td></tr><?php endforeach; ?></tbody></table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>