<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Messages';
require_customer();

$userId = (int)$_SESSION['user_id'];
$user = current_customer();

$activeOrder = chat_user_active_order($userId);

// Mark read
chat_mark_read($userId, 'user', null);

if (is_post()) {
    verify_csrf();
    $msg = (string)post('message', '');
    $r = chat_send($userId, 'user', $user['name'], $msg, null, null);
    if ($r['ok']) redirect(url('messages.php'));
    flash_error($r['error']);
}

$chatMessages = chat_get_messages($userId, null);

require __DIR__ . '/common/header.php';
?>

<style>
.mc-wrap {
  max-width: 800px;
  margin: 0 auto;
  padding: 16px 16px 140px;
  min-height: calc(100vh - 60px);
  display: flex;
  flex-direction: column;
}
.mc-title {
  font-size: 24px;
  font-weight: 900;
  color: #fff;
  margin: 0 0 14px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.mc-title i { color: #dc2626; }

.mc-info {
  background: linear-gradient(135deg, rgba(59,130,246,0.1), rgba(59,130,246,0.04));
  border: 1px solid rgba(59,130,246,0.25);
  border-radius: 12px;
  padding: 11px 14px;
  margin-bottom: 14px;
  font-size: 12.5px;
  color: #93c5fd;
  display: flex;
  gap: 8px;
  align-items: center;
  font-weight: 600;
}
.mc-info strong { color: #fff; }

.mc-chat {
  flex: 1;
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px 16px 0 0;
  padding: 18px;
  overflow-y: auto;
  min-height: 300px;
  max-height: calc(100vh - 400px);
}
.mc-empty {
  text-align: center;
  padding: 40px 20px;
  color: rgba(255,255,255,0.4);
}
.mc-empty i {
  font-size: 44px;
  color: #dc2626;
  opacity: 0.3;
  display: block;
  margin-bottom: 12px;
}

.mc-msg {
  margin-bottom: 12px;
  max-width: 82%;
  display: flex;
  flex-direction: column;
}
.mc-msg.user { margin-left: auto; align-items: flex-end; }
.mc-msg.admin, .mc-msg.rider { margin-right: auto; align-items: flex-start; }
.mc-bubble {
  padding: 11px 15px;
  border-radius: 14px;
  font-size: 14px;
  line-height: 1.5;
  word-wrap: break-word;
}
.mc-msg.user .mc-bubble {
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  border-bottom-right-radius: 4px;
}
.mc-msg.admin .mc-bubble {
  background: rgba(59,130,246,0.15);
  border: 1px solid rgba(59,130,246,0.3);
  color: #f9fafb;
  border-bottom-left-radius: 4px;
}
.mc-msg.rider .mc-bubble {
  background: rgba(34,197,94,0.15);
  border: 1px solid rgba(34,197,94,0.3);
  color: #f9fafb;
  border-bottom-left-radius: 4px;
}
.mc-sender {
  font-size: 10.5px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: rgba(255,255,255,0.5);
  margin-bottom: 4px;
}
.mc-time { font-size: 10px; color: rgba(255,255,255,0.4); margin-top: 4px; }

.mc-form {
  display: flex;
  gap: 10px;
  padding: 12px;
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 0 0 16px 16px;
  border-top: 1px solid rgba(255,255,255,0.04);
}
.mc-input {
  flex: 1;
  padding: 12px 16px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  color: #fff;
  font-size: 14px;
  outline: none;
  font-family: inherit;
  resize: none;
  min-height: 46px;
  max-height: 100px;
}
.mc-input:focus { border-color: #dc2626; box-shadow: 0 0 0 3px rgba(220,38,38,0.15); }
.mc-input::placeholder { color: rgba(255,255,255,0.35); }
.mc-send {
  width: 46px;
  height: 46px;
  border-radius: 10px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  border: 0;
  cursor: pointer;
  font-size: 17px;
  flex-shrink: 0;
  box-shadow: 0 4px 14px rgba(220,38,38,0.3);
}
.mc-send:hover { transform: translateY(-1px); }
</style>

<div class="mc-wrap">
  <h1 class="mc-title"><i class="fa-solid fa-comments"></i> Messages</h1>

  <div class="mc-info">
    <i class="fa-solid fa-headset"></i>
    <span>Chatting with <strong>Friends Pizza Hut Support</strong></span>
  </div>

  <div class="mc-chat" id="mcChat">
    <?php if (!$chatMessages): ?>
      <div class="mc-empty">
        <i class="fa-solid fa-comments"></i>
        <div style="font-size:13.5px;">No messages yet.<br>Send one below to start chatting!</div>
      </div>
    <?php else: foreach ($chatMessages as $m): ?>
      <div class="mc-msg <?= e($m['sender_type']) ?>">
        <?php if ($m['sender_type'] !== 'user'): ?>
          <div class="mc-sender"><?= e($m['sender_name']) ?></div>
        <?php endif; ?>
        <div class="mc-bubble"><?= nl2br(e($m['message'])) ?></div>
        <div class="mc-time"><?= date('d M, H:i', strtotime($m['created_at'])) ?></div>
      </div>
    <?php endforeach; endif; ?>
  </div>

  <form method="post" class="mc-form">
    <?= csrf_field() ?>
    <textarea name="message" required class="mc-input" placeholder="Type your message..." rows="1" id="mcInput"></textarea>
    <button type="submit" class="mc-send"><i class="fa-solid fa-paper-plane"></i></button>
  </form>
</div>

<script>
(function() {
  var chat = document.getElementById('mcChat');
  if (chat) chat.scrollTop = chat.scrollHeight;
  var inp = document.getElementById('mcInput');
  if (inp) inp.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 100) + 'px';
  });
})();
</script>

<?php require __DIR__ . '/common/footer.php'; ?>