<?php
// delete.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/reviews/index.php'));
verify_csrf();
$id = (int)post('id', 0);
$r = Database::fetch("SELECT product_id FROM reviews WHERE id=?", [$id]);
Database::execute("DELETE FROM reviews WHERE id=?", [$id]);
if ($r) recalc_product_rating((int)$r['product_id']);
flash_success('Deleted.');
redirect(url('admin/reviews/index.php'));