<?php
/**
 * Facebook Pixel + Google Analytics tracking
 */

function track_page_view(): void {
    if (!feature_enabled('facebook_pixel') && !feature_enabled('google_analytics')) return;
    $fbPixel = setting('facebook_pixel_id', '');
    $gaId = setting('google_analytics_id', '');
    $gtmId = setting('google_tag_manager_id', '');

    echo "<!-- Tracking Scripts -->\n";

    // Google Analytics 4
    if (feature_enabled('google_analytics') && $gaId) {
        echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . e($gaId) . '"></script>' . "\n";
        echo '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config","' . e($gaId) . '");</script>' . "\n";
    }

    // Google Tag Manager
    if ($gtmId) {
        echo '<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({"gtm.start":new Date().getTime(),event:"gtm.js"});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!="dataLayer"?"&l="+l:"";j.async=true;j.src="https://www.googletagmanager.com/gtm.js?id="+i+dl;f.parentNode.insertBefore(j,f);})(window,document,"script","dataLayer","' . e($gtmId) . '");</script>' . "\n";
    }

    // Facebook Pixel
    if (feature_enabled('facebook_pixel') && $fbPixel) {
        echo '<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version="2.0";n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","' . e($fbPixel) . '");fbq("track","PageView");</script>' . "\n";
    }

    echo "<!-- End Tracking -->\n";
}

function track_add_to_cart(int $productId, string $name, float $price): void {
    $fbPixel = setting('facebook_pixel_id', '');
    if (!feature_enabled('facebook_pixel') || !$fbPixel) return;
    ?>
<script>
if (typeof fbq === 'function') {
  fbq('track', 'AddToCart', {
    content_ids: ['<?= (int)$productId ?>'],
    content_name: '<?= e(addslashes($name)) ?>',
    value: <?= (float)$price ?>,
    currency: 'PKR'
  });
}
if (typeof gtag === 'function') {
  gtag('event', 'add_to_cart', {
    currency: 'PKR',
    value: <?= (float)$price ?>,
    items: [{ item_id: '<?= (int)$productId ?>', item_name: '<?= e(addslashes($name)) ?>' }]
  });
}
</script>
    <?php
}

function track_purchase(int $orderId, string $orderNumber, float $total, array $items = []): void {
    $fbPixel = setting('facebook_pixel_id', '');
    if (!feature_enabled('facebook_pixel') || !$fbPixel) return;

    $fbItems = [];
    foreach ($items as $it) {
        $fbItems[] = [
            'id' => (string)($it['product_id'] ?? ''),
            'quantity' => (int)($it['quantity'] ?? 1),
            'item_price' => (float)($it['unit_price'] ?? 0),
        ];
    }
    ?>
<script>
if (typeof fbq === 'function') {
  fbq('track', 'Purchase', {
    value: <?= (float)$total ?>,
    currency: 'PKR',
    content_type: 'product',
    content_ids: <?= json_encode(array_column($fbItems, 'id')) ?>,
    contents: <?= json_encode($fbItems) ?>,
    num_items: <?= count($fbItems) ?>
  });
}
if (typeof gtag === 'function') {
  gtag('event', 'purchase', {
    transaction_id: '<?= e($orderNumber) ?>',
    value: <?= (float)$total ?>,
    currency: 'PKR',
    items: <?= json_encode(array_map(function($it) {
        return [
            'item_id' => (string)($it['product_id'] ?? ''),
            'item_name' => (string)($it['product_name'] ?? ''),
            'quantity' => (int)($it['quantity'] ?? 1),
            'price' => (float)($it['unit_price'] ?? 0),
        ];
    }, $items)) ?>
  });
}
</script>
    <?php
}