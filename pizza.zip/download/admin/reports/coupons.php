<?php
// coupons.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Coupons Report';
$rows = Database::fetchAll("SELECT c.code, c.discount_type, c.discount_value, COUNT(cu.id) uses, COALESCE(SUM(cu.discount_amount),0) total_discount
    FROM coupons c LEFT JOIN coupon_usage cu ON cu.coupon_id=c.id GROUP BY c.id ORDER BY uses DESC");
require __DIR__ . '/../common/header.php';
?>
<div class="bg-white rounded-xl border overflow-hidden"><table class="w-full text-sm"><thead class="bg-gray-50 text-xs text-gray-500 uppercase"><tr><th class="text-left px-4 py-3">Code</th><th class="text-left px-4 py-3">Type</th><th class="text-right px-4 py-3">Uses</th><th class="text-right px-4 py-3">Total Discount</th></tr></thead>
<tbody><?php foreach ($rows as $r): ?><tr class="border-t"><td class="px-4 py-3 font-mono"><?= e($r['code']) ?></td><td class="px-4 py-3"><?= e($r['discount_type']) ?></td><td class="px-4 py-3 text-right"><?= (int)$r['uses'] ?></td><td class="px-4 py-3 text-right font-semibold"><?= money($r['total_discount']) ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php require __DIR__ . '/../common/footer.php'; ?>