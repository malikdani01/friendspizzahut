<?php
// actions/account/address-create.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('addresses.php'));
verify_csrf();
$uid = (int)$_SESSION['user_id'];
$id = Database::insert('addresses', [
    'user_id'=>$uid,
    'label'=>trim((string)post('label','')) ?: null,
    'customer_name'=>trim((string)post('customer_name','')),
    'mobile'=>trim((string)post('mobile','')),
    'address_line'=>trim((string)post('address_line','')),
    'area'=>trim((string)post('area','')) ?: null,
    'city'=>trim((string)post('city','')) ?: null,
    'landmark'=>trim((string)post('landmark','')) ?: null,
    'is_default'=>post('is_default')?1:0,
]);
if (post('is_default')) Database::execute("UPDATE addresses SET is_default=0 WHERE user_id=? AND id!=?", [$uid, $id]);
flash_success('Address added.');
redirect(url('addresses.php'));