<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('table_reservation')) {
    redirect(url('admin/dashboard.php'));
}

$id = (int)get('id', 0);
$r = reservation_get($id);
if (!$r) { flash_error('Reservation not found.'); redirect(url('admin/reservations/index.php')); }

$pageTitle = 'Reservation ' . $r['reservation_code'];

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'update_status') {
        $newStatus = (string)post('status', '');
        $note = trim((string)post('admin_note', ''));
        $result = reservation_update_status($id, $newStatus, (int)$_SESSION['admin_id'], $note ?: null);
        if ($result['ok']) flash_success('Status updated.');
        else flash_error($result['error']);

    } elseif ($action === 'assign_table') {
        $table = trim((string)post('table_number', ''));
        Database::update('reservations', ['table_number' => $table ?: null], 'id = :id', ['id' => $id]);
        flash_success('Table assigned.');

    } elseif ($action === 'cancel') {
        $reason = trim((string)post('cancel_reason', 'Cancelled by admin'));
        $result = reservation_cancel($id, $reason, 'admin');
        if ($result['ok']) flash_success('Reservation cancelled.');
        else flash_error($result['error']);
    }

    redirect(url('admin/reservations/view.php?id=' . $id));
}

require __DIR__ . '/../common/header.php';
?>

<div class="grid lg:grid-cols-3 gap-6">

  <!-- Main Details -->
  <div class="lg:col-span-2 space-y-5">
    <div class="bg-white rounded-xl border p-6">
      <div class="flex items-start justify-between mb-4">
        <div>
          <div class="text-xs text-gray-500">Reservation Code</div>
          <div class="font-mono font-bold text-lg"><?= e($r['reservation_code']) ?></div>
          <div class="text-xs text-gray-500 mt-1">Booked: <?= date('d M Y, H:i', strtotime($r['created_at'])) ?></div>
        </div>
        <div><?= reservation_status_badge($r['status']) ?></div>
      </div>

      <div class="grid md:grid-cols-2 gap-4 pt-4 border-t">
        <div>
          <div class="text-xs text-gray-500 mb-1">Customer</div>
          <div class="font-semibold"><?= e($r['customer_name']) ?></div>
          <a href="tel:<?= e($r['customer_phone']) ?>" class="text-brand text-sm"><?= e($r['customer_phone']) ?></a>
          <?php if ($r['customer_email']): ?>
            <div class="text-xs text-gray-500"><?= e($r['customer_email']) ?></div>
          <?php endif; ?>
        </div>
        <div>
          <div class="text-xs text-gray-500 mb-1">Reservation</div>
          <div class="font-semibold text-lg"><?= date('D, d M Y', strtotime($r['reservation_date'])) ?></div>
          <div class="text-gray-600"><?= date('h:i A', strtotime($r['reservation_time'])) ?> (<?= (int)$r['duration_minutes'] ?> min)</div>
          <div class="text-sm mt-1"><strong><?= (int)$r['party_size'] ?></strong> guests</div>
        </div>
      </div>

      <?php if ($r['table_number']): ?>
      <div class="mt-4 pt-4 border-t">
        <div class="text-xs text-gray-500 mb-1">Assigned Table</div>
        <div class="text-2xl font-bold text-brand"><i class="fa-solid fa-chair"></i> <?= e($r['table_number']) ?></div>
      </div>
      <?php endif; ?>

      <?php if ($r['special_requests']): ?>
      <div class="mt-4 pt-4 border-t">
        <div class="text-xs text-gray-500 mb-1">Special Requests</div>
        <div class="text-sm"><?= nl2br(e($r['special_requests'])) ?></div>
      </div>
      <?php endif; ?>

      <?php if ($r['admin_note']): ?>
      <div class="mt-4 pt-4 border-t">
        <div class="text-xs text-gray-500 mb-1">Admin Note</div>
        <div class="text-sm p-3 bg-gray-50 rounded"><?= nl2br(e($r['admin_note'])) ?></div>
      </div>
      <?php endif; ?>

      <?php if ($r['cancel_reason']): ?>
      <div class="mt-4 pt-4 border-t">
        <div class="text-xs text-gray-500 mb-1">Cancellation Reason</div>
        <div class="text-sm text-red-600"><?= e($r['cancel_reason']) ?> (by <?= e($r['cancelled_by']) ?>)</div>
      </div>
      <?php endif; ?>
    </div>

    <!-- Timeline -->
    <div class="bg-white rounded-xl border p-6">
      <h3 class="font-bold mb-4">Timeline</h3>
      <ol class="relative border-l-2 border-gray-200 ml-3 space-y-4 text-sm">
        <li class="ml-4">
          <div class="absolute -left-[7px] w-3 h-3 rounded-full bg-gray-400"></div>
          <div class="font-semibold">Created</div>
          <div class="text-xs text-gray-500"><?= date('d M Y, H:i', strtotime($r['created_at'])) ?></div>
        </li>
        <?php if ($r['confirmed_at']): ?>
        <li class="ml-4">
          <div class="absolute -left-[7px] w-3 h-3 rounded-full bg-blue-500"></div>
          <div class="font-semibold">Confirmed</div>
          <div class="text-xs text-gray-500"><?= date('d M Y, H:i', strtotime($r['confirmed_at'])) ?></div>
        </li>
        <?php endif; ?>
        <?php if ($r['seated_at']): ?>
        <li class="ml-4">
          <div class="absolute -left-[7px] w-3 h-3 rounded-full bg-purple-500"></div>
          <div class="font-semibold">Seated</div>
          <div class="text-xs text-gray-500"><?= date('d M Y, H:i', strtotime($r['seated_at'])) ?></div>
        </li>
        <?php endif; ?>
        <?php if ($r['completed_at']): ?>
        <li class="ml-4">
          <div class="absolute -left-[7px] w-3 h-3 rounded-full bg-green-500"></div>
          <div class="font-semibold">Completed</div>
          <div class="text-xs text-gray-500"><?= date('d M Y, H:i', strtotime($r['completed_at'])) ?></div>
        </li>
        <?php endif; ?>
        <?php if ($r['cancelled_at']): ?>
        <li class="ml-4">
          <div class="absolute -left-[7px] w-3 h-3 rounded-full bg-red-500"></div>
          <div class="font-semibold">Cancelled</div>
          <div class="text-xs text-gray-500"><?= date('d M Y, H:i', strtotime($r['cancelled_at'])) ?></div>
        </li>
        <?php endif; ?>
      </ol>
    </div>
  </div>

  <!-- Actions Sidebar -->
  <div class="space-y-5">

    <!-- Status Update -->
    <div class="bg-white rounded-xl border p-5">
      <h3 class="font-bold mb-3">Update Status</h3>
      <form method="post" class="space-y-3">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update_status">
        <select name="status" class="w-full border rounded px-3 py-2">
          <?php foreach (['pending','confirmed','seated','completed','no_show','cancelled'] as $s): ?>
            <option value="<?= $s ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= ucwords(str_replace('_',' ',$s)) ?></option>
          <?php endforeach; ?>
        </select>
        <textarea name="admin_note" rows="2" placeholder="Note (optional)" class="w-full border rounded px-3 py-2 text-sm"><?= e($r['admin_note']) ?></textarea>
        <button class="w-full bg-brand text-white py-2 rounded font-semibold">Save</button>
      </form>
    </div>

    <!-- Assign Table -->
    <div class="bg-white rounded-xl border p-5">
      <h3 class="font-bold mb-3">Assign Table</h3>
      <form method="post" class="space-y-3">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="assign_table">
        <input name="table_number" value="<?= e($r['table_number']) ?>" placeholder="e.g. T-05" class="w-full border rounded px-3 py-2">
        <button class="w-full bg-gray-800 text-white py-2 rounded text-sm">Save Table</button>
      </form>
    </div>

    <!-- Contact -->
    <div class="bg-white rounded-xl border p-5">
      <h3 class="font-bold mb-3">Quick Actions</h3>
      <div class="space-y-2">
        <a href="tel:<?= e($r['customer_phone']) ?>" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-50 text-sm">
          <i class="fa-solid fa-phone text-brand"></i> Call customer
        </a>
        <?php if ($r['customer_phone']): 
          $waPhone = preg_replace('/\D/', '', $r['customer_phone']);
          if (str_starts_with($waPhone, '0')) $waPhone = '92' . substr($waPhone, 1);
        ?>
        <a href="https://wa.me/<?= e($waPhone) ?>?text=<?= urlencode('Aapki reservation ' . $r['reservation_code'] . ' confirm ho gayi hai.') ?>" target="_blank" class="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-50 text-sm">
          <i class="fa-brands fa-whatsapp text-green-600"></i> WhatsApp
        </a>
        <?php endif; ?>
      </div>
    </div>

    <!-- Cancel -->
    <?php if (!in_array($r['status'], ['completed','cancelled','no_show'], true)): ?>
    <div class="bg-white rounded-xl border p-5">
      <h3 class="font-bold mb-3 text-red-600">Cancel Reservation</h3>
      <form method="post" class="space-y-2" data-confirm="Cancel this reservation?">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="cancel">
        <input name="cancel_reason" placeholder="Reason" class="w-full border rounded px-3 py-2 text-sm">
        <button class="w-full bg-red-600 text-white py-2 rounded text-sm font-semibold">Cancel Reservation</button>
      </form>
    </div>
    <?php endif; ?>

    <a href="<?= url('admin/reservations/index.php') ?>" class="block text-center text-sm text-gray-500 hover:text-brand">← Back to reservations</a>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>