<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('combo_deals')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Combos / Deals';

if (is_post()) {
    verify_csrf();
    if (post('action') === 'delete') {
        $cid = (int)post('id');
        $c = Database::fetch("SELECT image FROM combos WHERE id = ?", [$cid]);
        if ($c && !empty($c['image']) && file_exists(UPLOAD_PATH . '/' . $c['image'])) {
            @unlink(UPLOAD_PATH . '/' . $c['image']);
        }
        Database::execute("DELETE FROM combo_items WHERE combo_id=?", [$cid]);
        Database::execute("DELETE FROM combos WHERE id=?", [$cid]);
        flash_success('Deal deleted.');
    } elseif (post('action') === 'toggle') {
        Database::execute("UPDATE combos SET is_active = 1 - is_active WHERE id=?", [(int)post('id')]);
        flash_success('Updated.');
    }
    redirect(url('admin/combos/index.php'));
}

$rows = Database::fetchAll("SELECT * FROM combos ORDER BY sort_order, id DESC");
require __DIR__ . '/../common/header.php';
?>

<style>
.deal-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
}
@media (min-width: 640px) { .deal-grid { grid-template-columns: repeat(2, 1fr); } }
@media (min-width: 1024px) { .deal-grid { grid-template-columns: repeat(3, 1fr); } }

.deal-card-item {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
  overflow: hidden;
  transition: all .2s;
}
.deal-card-item:hover {
  border-color: rgba(220,38,38,0.4);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(220,38,38,0.15);
}
.deal-card-img {
  aspect-ratio: 16/10;
  background: linear-gradient(135deg, rgba(220,38,38,0.2), rgba(220,38,38,0.05));
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  position: relative;
}
.deal-card-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.deal-card-img .no-img {
  font-size: 48px;
  color: rgba(255,255,255,0.15);
}
.deal-card-img .price-badge {
  position: absolute;
  top: 10px;
  right: 10px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  font-size: 13px;
  font-weight: 800;
  padding: 6px 12px;
  border-radius: 999px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.4);
}
.deal-card-body {
  padding: 16px;
}
.deal-card-title {
  font-size: 16px;
  font-weight: 800;
  color: #fff;
  margin: 0 0 6px;
}
.deal-card-desc {
  font-size: 12.5px;
  color: rgba(255,255,255,0.55);
  line-height: 1.5;
  margin-bottom: 14px;
  min-height: 36px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.deal-card-actions {
  display: flex;
  gap: 8px;
  padding-top: 12px;
  border-top: 1px solid rgba(255,255,255,0.06);
}
.deal-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 7px 12px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 700;
  text-decoration: none;
  border: 0;
  cursor: pointer;
  transition: all .15s;
  font-family: inherit;
}
.deal-btn-toggle-active { background: rgba(34,197,94,0.15); color: #4ade80; }
.deal-btn-toggle-active:hover { background: rgba(34,197,94,0.25); }
.deal-btn-toggle-inactive { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.6); }
.deal-btn-toggle-inactive:hover { background: rgba(255,255,255,0.15); color: #fff; }
.deal-btn-edit { background: rgba(59,130,246,0.15); color: #93c5fd; }
.deal-btn-edit:hover { background: rgba(59,130,246,0.25); color: #bfdbfe; text-decoration: none; }
.deal-btn-delete { background: rgba(220,38,38,0.15); color: #fca5a5; margin-left: auto; }
.deal-btn-delete:hover { background: #dc2626; color: #fff; }

.deal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}
.deal-header p {
  color: rgba(255,255,255,0.6);
  font-size: 13.5px;
  margin: 0;
}
.deal-add-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 11px 22px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  border: 0;
  border-radius: 11px;
  font-size: 13.5px;
  font-weight: 800;
  text-decoration: none;
  cursor: pointer;
  box-shadow: 0 6px 18px rgba(220,38,38,0.35);
  transition: all .2s;
}
.deal-add-btn:hover { transform: translateY(-1px); box-shadow: 0 10px 28px rgba(220,38,38,0.5); text-decoration: none; }

.deal-empty {
  text-align: center;
  padding: 60px 20px;
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
  color: rgba(255,255,255,0.4);
}
.deal-empty i { font-size: 48px; color: rgba(220,38,38,0.3); display: block; margin-bottom: 12px; }
</style>

<div class="deal-header">
  <p><?= count($rows) ?> deals</p>
  <a href="<?= url('admin/combos/create.php') ?>" class="deal-add-btn">
    <i class="fa-solid fa-plus"></i> Add Deal
  </a>
</div>

<?php if (!$rows): ?>
  <div class="deal-empty">
    <i class="fa-solid fa-tags"></i>
    <p>No deals yet. Add your first deal.</p>
  </div>
<?php else: ?>
<div class="deal-grid">
  <?php foreach ($rows as $c): ?>
    <div class="deal-card-item">
      <div class="deal-card-img">
        <?php if (!empty($c['image']) && file_exists(UPLOAD_PATH . '/' . $c['image'])): ?>
          <img src="<?= upload_url($c['image']) ?>" alt="<?= e($c['name']) ?>">
        <?php else: ?>
          <i class="fa-solid fa-tags no-img"></i>
        <?php endif; ?>
        <div class="price-badge"><?= money($c['fixed_price']) ?></div>
      </div>
      <div class="deal-card-body">
        <h3 class="deal-card-title"><?= e($c['name']) ?></h3>
        <p class="deal-card-desc"><?= e($c['description']) ?></p>
        <div class="deal-card-actions">
          <form method="post" style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle">
            <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
            <button class="deal-btn <?= $c['is_active'] ? 'deal-btn-toggle-active' : 'deal-btn-toggle-inactive' ?>">
              <i class="fa-solid fa-<?= $c['is_active'] ? 'circle-check' : 'circle-xmark' ?>"></i>
              <?= $c['is_active'] ? 'Active' : 'Inactive' ?>
            </button>
          </form>
          <a href="<?= url('admin/combos/edit.php?id=' . (int)$c['id']) ?>" class="deal-btn deal-btn-edit">
            <i class="fa-solid fa-pen"></i> Edit
          </a>
          <form method="post" style="display:inline;" onsubmit="return confirm('Delete this deal?');">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
            <button class="deal-btn deal-btn-delete">
              <i class="fa-solid fa-trash"></i>
            </button>
          </form>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../common/footer.php'; ?>