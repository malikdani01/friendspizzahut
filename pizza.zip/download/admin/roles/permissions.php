<?php
// permissions.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('staff_roles')) redirect(url('admin/dashboard.php'));
$rid = (int)get('id', 0);
$r = Database::fetch("SELECT * FROM roles WHERE id=?", [$rid]);
if (!$r) { flash_error('Not found.'); redirect(url('admin/roles/index.php')); }
$pageTitle = 'Permissions: ' . $r['name'];

if (is_post()) {
    verify_csrf();
    Database::execute("DELETE FROM role_permissions WHERE role_id=?", [$rid]);
    foreach ((array)post('permissions', []) as $pid) {
        Database::insert('role_permissions', ['role_id'=>$rid, 'permission_id'=>(int)$pid]);
    }
    flash_success('Permissions saved.');
    redirect(url('admin/roles/permissions.php?id=' . $rid));
}

$perms = Database::fetchAll("SELECT * FROM permissions ORDER BY module, slug");
$grouped = [];
foreach ($perms as $p) $grouped[$p['module']][] = $p;
$assigned = array_column(Database::fetchAll("SELECT permission_id FROM role_permissions WHERE role_id=?", [$rid]), 'permission_id');
require __DIR__ . '/../common/header.php';
?>
<a href="<?= url('admin/roles/index.php') ?>" class="text-sm text-gray-500 hover:text-brand mb-4 inline-block">← Roles</a>
<form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-5">
  <?= csrf_field() ?>
  <?php foreach ($grouped as $module => $items): ?>
    <div>
      <div class="text-xs font-bold text-gray-500 uppercase mb-2"><?= e($module) ?></div>
      <div class="flex flex-wrap gap-4">
        <?php foreach ($items as $p): ?>
          <label class="text-sm flex items-center gap-2"><input type="checkbox" name="permissions[]" value="<?= (int)$p['id'] ?>" <?= in_array($p['id'], $assigned)?'checked':'' ?> class="w-4 h-4"> <?= e($p['name']) ?></label>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endforeach; ?>
  <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save Permissions</button>
</form>
<?php require __DIR__ . '/../common/footer.php'; ?>