<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Add Banner';
$errors = [];

if (is_post()) {
    verify_csrf();

    $title      = trim((string)post('title', ''));
    $subtitle   = trim((string)post('subtitle', ''));
    $btnText    = trim((string)post('button_text', ''));
    $btnUrl     = trim((string)post('button_url', ''));
    $position   = (string)post('position', 'homepage');
    $sortOrder  = (int)post('sort_order', 0);
    $isActive   = post('is_active') ? 1 : 0;
    $mediaType  = (string)post('media_type', 'image'); // 'image' or 'video'
    $videoUrl = trim((string)post('video_url', ''));
    $overlayOpacity = max(0, min(100, (int)post('overlay_opacity', 50)));

    $image = null;
    $video = null;
    $videoPoster = null;

    if ($mediaType === 'video') {
        // Video upload
        if (empty($_FILES['video']['name']) && $videoUrl === '') {
            $errors[] = 'Choose a video file or enter a video URL.';
        } elseif (!empty($_FILES['video']['name'])) {
            $v = $_FILES['video'];

            // Validate size (max 30MB)
            if ($v['size'] > 30 * 1024 * 1024) {
                $errors[] = 'Video too large (max 30 MB).';
            }

            // Validate type
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($v['tmp_name']);
            $allowedVideo = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'];
            if (!in_array($mime, $allowedVideo, true)) {
                $errors[] = 'Only MP4, WEBM, OGG, MOV videos allowed.';
            }

            if (!$errors) {
                $ext = match ($mime) {
                    'video/mp4' => 'mp4',
                    'video/webm' => 'webm',
                    'video/ogg' => 'ogg',
                    'video/quicktime' => 'mov',
                    default => 'mp4',
                };
                $dir = UPLOAD_PATH . '/banners-video';
                if (!is_dir($dir)) @mkdir($dir, 0755, true);
                $fname = 'vid-' . bin2hex(random_bytes(8)) . '.' . $ext;
                $dest = $dir . '/' . $fname;
                if (move_uploaded_file($v['tmp_name'], $dest)) {
                    $video = 'banners-video/' . $fname;
                } else {
                    $errors[] = 'Could not save video.';
                }
            }
        }

        // Optional poster image
        if (!empty($_FILES['video_poster']['name']) && !$errors) {
            $p = save_uploaded_image($_FILES['video_poster'], 'banners');
            if ($p['ok']) $videoPoster = $p['path'];
            else $errors[] = 'Poster: ' . $p['error'];
        }
    } else {
        // Image upload
        if (empty($_FILES['image']['name'])) {
            $errors[] = 'Image file required.';
        } else {
            $r = save_uploaded_image($_FILES['image'], 'banners');
            if (!$r['ok']) $errors[] = 'Image: ' . $r['error'];
            else $image = $r['path'];
        }
    }

    if (!$errors) {
        try {
            Database::insert('banners', [
                'title' => $title ?: null,
                'subtitle' => $subtitle ?: null,
                'image' => $image ?: ($videoPoster ?: ''),
                'video' => $video,
                'video_url' => $videoUrl ?: null,
                'video_poster' => $videoPoster,
                'media_type' => $mediaType,
                'overlay_opacity' => $overlayOpacity,
                'video_autoplay' => post('video_autoplay') ? 1 : 0,
                'video_loop' => post('video_loop') ? 1 : 0,
                'video_muted' => post('video_muted') ? 1 : 0,
                'button_text' => $btnText ?: null,
                'button_url' => $btnUrl ?: null,
                'position' => $position,
                'sort_order' => $sortOrder,
                'is_active' => $isActive,
            ]);
            flash_success('Banner added.');
            redirect(url('admin/banners/index.php'));
        } catch (Throwable $e) {
            $errors[] = 'Error: ' . $e->getMessage();
        }
    }
}

require __DIR__ . '/../common/header.php';
?>

<style>
.bn-wrap { max-width: 720px; }
.bn-card { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 24px; margin-bottom: 20px; }
.bn-card h3 { font-size: 14px; font-weight: 800; color: #dc2626; margin: 0 0 18px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.06); text-transform: uppercase; letter-spacing: 0.6px; display: flex; align-items: center; gap: 8px; }
.bn-label { display: block; font-size: 12.5px; font-weight: 700; color: rgba(255,255,255,0.7); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
.bn-input, .bn-select, .bn-textarea { width: 100%; padding: 12px 14px; background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 10px; color: #fff; font-size: 14.5px; font-family: inherit; outline: none; margin-bottom: 16px; transition: all .15s; -webkit-appearance: none; appearance: none; }
.bn-input:focus, .bn-select:focus, .bn-textarea:focus { border-color: #dc2626; box-shadow: 0 0 0 3px rgba(220,38,38,0.15); }
.bn-input::placeholder, .bn-textarea::placeholder { color: rgba(255,255,255,0.3); }
.bn-select option { background: #171717; color: #fff; }
.bn-grid-2 { display: grid; grid-template-columns: 1fr; gap: 0 16px; }
@media (min-width: 640px) { .bn-grid-2 { grid-template-columns: 1fr 1fr; } }

/* Media type selector */
.media-type-tabs { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
.media-type-tab { padding: 20px; background: rgba(0,0,0,0.3); border: 2px solid rgba(255,255,255,0.1); border-radius: 14px; text-align: center; cursor: pointer; transition: all .2s; }
.media-type-tab:hover { border-color: rgba(220,38,38,0.4); }
.media-type-tab.active { border-color: #dc2626; background: rgba(220,38,38,0.08); box-shadow: 0 0 0 1px #dc2626 inset; }
.media-type-tab input { display: none; }
.media-type-icon { font-size: 32px; margin-bottom: 8px; color: rgba(255,255,255,0.5); }
.media-type-tab.active .media-type-icon { color: #dc2626; }
.media-type-label { font-size: 14px; font-weight: 800; color: rgba(255,255,255,0.7); }
.media-type-tab.active .media-type-label { color: #dc2626; }
.media-type-hint { font-size: 11px; color: rgba(255,255,255,0.4); margin-top: 4px; }

/* Upload boxes */
.upload-box { background: rgba(0,0,0,0.3); border: 2px dashed rgba(255,255,255,0.15); border-radius: 12px; padding: 24px; text-align: center; cursor: pointer; transition: all .2s; }
.upload-box:hover { border-color: rgba(220,38,38,0.5); background: rgba(220,38,38,0.03); }
.upload-box i { font-size: 32px; color: rgba(255,255,255,0.3); margin-bottom: 10px; display: block; }
.upload-box strong { color: #fff; display: block; margin-bottom: 4px; font-size: 14px; }
.upload-box span { font-size: 12px; color: rgba(255,255,255,0.4); }
.upload-box input { display: none; }

/* Preview */
.preview-box { margin-top: 12px; border-radius: 12px; overflow: hidden; background: #0a0a0a; border: 1px solid rgba(255,255,255,0.1); display: none; }
.preview-box img, .preview-box video { width: 100%; height: auto; display: block; max-height: 320px; object-fit: cover; }

.bn-toggle { display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: rgba(0,0,0,0.3); border: 1.5px solid rgba(255,255,255,0.08); border-radius: 10px; cursor: pointer; margin-bottom: 10px; }
.bn-toggle input { width: 18px !important; height: 18px !important; accent-color: #dc2626; cursor: pointer; }
.bn-toggle span { font-size: 13.5px; font-weight: 600; color: #fff; }

.bn-actions { display: flex; gap: 12px; }
.bn-btn-save { padding: 14px 32px; background: linear-gradient(135deg, #dc2626, #b91c1c); color: #fff; border: 0; border-radius: 10px; font-size: 14.5px; font-weight: 800; cursor: pointer; box-shadow: 0 8px 24px rgba(220,38,38,0.4); display: flex; align-items: center; gap: 8px; font-family: inherit; }
.bn-btn-cancel { padding: 14px 28px; background: rgba(255,255,255,0.05); border: 1.5px solid rgba(255,255,255,0.1); color: rgba(255,255,255,0.8); border-radius: 10px; font-size: 14px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
.bn-btn-cancel:hover { background: rgba(255,255,255,0.1); color: #fff; text-decoration: none; }
.bn-error { background: rgba(220,38,38,0.12); border: 1.5px solid rgba(220,38,38,0.4); color: #fca5a5; padding: 14px 16px; border-radius: 12px; font-size: 13.5px; margin-bottom: 20px; line-height: 1.6; }
.bn-error div { padding: 2px 0; }
.bn-back { display: inline-flex; align-items: center; gap: 6px; color: rgba(255,255,255,0.5); font-size: 13px; text-decoration: none; margin-bottom: 16px; }
.bn-back:hover { color: #dc2626; text-decoration: none; }
</style>

<div class="bn-wrap">
  <a href="<?= url('admin/banners/index.php') ?>" class="bn-back">
    <i class="fa-solid fa-arrow-left"></i> Back to Banners
  </a>

  <?php if ($errors): ?>
    <div class="bn-error">
      <?php foreach ($errors as $e_): ?><div>• <?= e($e_) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <!-- Media Type -->
    <div class="bn-card">
      <h3><i class="fa-solid fa-photo-film"></i> Media Type</h3>

      <div class="media-type-tabs">
        <label class="media-type-tab active" data-type="image">
          <input type="radio" name="media_type" value="image" checked onchange="switchMedia('image')">
          <div class="media-type-icon"><i class="fa-solid fa-image"></i></div>
          <div class="media-type-label">Image</div>
          <div class="media-type-hint">Static image banner</div>
        </label>
        <label class="media-type-tab" data-type="video">
          <input type="radio" name="media_type" value="video" onchange="switchMedia('video')">
          <div class="media-type-icon"><i class="fa-solid fa-video"></i></div>
          <div class="media-type-label">Video</div>
          <div class="media-type-hint">Autoplay video banner</div>
        </label>
      </div>

      <!-- Image Upload -->
      <div id="imageFields">
        <label class="bn-label">Banner Image *</label>
        <div class="upload-box" onclick="document.getElementById('imageInput').click();">
          <i class="fa-solid fa-cloud-arrow-up"></i>
          <strong>Choose Image</strong>
          <span>JPG, PNG, WEBP · Max 5 MB</span>
          <input type="file" name="image" id="imageInput" accept="image/*" onchange="previewImage(event);">
        </div>
        <div class="preview-box" id="imagePreview"></div>
      </div>

      <!-- Video Upload -->
      <div id="videoFields" style="display:none;">
        <label class="bn-label">Banner Video *</label>
        <div class="upload-box" onclick="document.getElementById('videoInput').click();">
          <i class="fa-solid fa-cloud-arrow-up"></i>
          <strong>Choose Video</strong>
          <span>MP4, WEBM, OGG, MOV · Max 30 MB</span>
          <input type="file" name="video" id="videoInput" accept="video/mp4,video/webm,video/ogg,video/quicktime" onchange="previewVideo(event);">
        </div>
        <div class="preview-box" id="videoPreview"></div>

        <label class="bn-label" style="margin-top:16px;">Video URL (MP4 link — optional)</label>
        <input type="url" name="video_url" value="<?= e(post('video_url','')) ?>" placeholder="https://example.com/video.mp4" class="bn-input">
        <div class="media-type-hint" style="margin:-8px 0 16px;">Agar video URL use karni hai to MP4 link daalein. URL ya uploaded video mein se ek use karein.</div>

        <label class="bn-label" style="margin-top:16px;">Poster Image (optional)</label>
        <div class="upload-box" onclick="document.getElementById('posterInput').click();">
          <i class="fa-solid fa-image"></i>
          <strong>Choose Poster</strong>
          <span>Shows before video loads · JPG, PNG</span>
          <input type="file" name="video_poster" id="posterInput" accept="image/*" onchange="previewPoster(event);">
        </div>
        <div class="preview-box" id="posterPreview"></div>

        <label class="bn-label" style="margin-top:16px;">Video Settings</label>
        <label class="bn-toggle">
          <input type="checkbox" name="video_autoplay" value="1" checked>
          <span>Autoplay video (recommended)</span>
        </label>
        <label class="bn-toggle">
          <input type="checkbox" name="video_loop" value="1" checked>
          <span>Loop video</span>
        </label>
        <label class="bn-toggle">
          <input type="checkbox" name="video_muted" value="1" checked>
          <span>Muted (required for autoplay)</span>
        </label>
      </div>
    </div>

    <!-- Banner Info -->
    <div class="bn-card">
      <h3><i class="fa-solid fa-tag"></i> Banner Info</h3>

      <label class="bn-label">Title</label>
      <input type="text" name="title" value="<?= e(post('title','')) ?>" placeholder="Optional title" class="bn-input">

      <label class="bn-label">Subtitle</label>
      <input type="text" name="subtitle" value="<?= e(post('subtitle','')) ?>" placeholder="Optional subtitle" class="bn-input">

      <div class="bn-grid-2">
        <div>
          <label class="bn-label">Button Text</label>
          <input type="text" name="button_text" value="<?= e(post('button_text','')) ?>" placeholder="Order Now" class="bn-input">
        </div>
        <div>
          <label class="bn-label">Button URL</label>
          <input type="text" name="button_url" value="<?= e(post('button_url','')) ?>" placeholder="/menu.php" class="bn-input">
        </div>
      </div>

      <div class="bn-grid-2">
        <div>
          <label class="bn-label">Position</label>
          <select name="position" class="bn-select">
            <option value="homepage">Homepage Hero</option>
            <option value="category">Category Banner</option>
            <option value="product">Product Banner</option>
          </select>
        </div>
        <div>
          <label class="bn-label">Sort Order</label>
          <input type="number" name="sort_order" value="<?= e(post('sort_order','0')) ?>" class="bn-input">
        </div>
      </div>

      <label class="bn-label">Overlay Darkness (0–100)</label>
      <input type="number" name="overlay_opacity" min="0" max="100" value="<?= e(post('overlay_opacity','50')) ?>" class="bn-input">

      <label class="bn-toggle">
        <input type="checkbox" name="is_active" value="1" checked>
        <span>Active (show on website)</span>
      </label>
    </div>

    <div class="bn-card">
      <div class="bn-actions">
        <button type="submit" class="bn-btn-save">
          <i class="fa-solid fa-save"></i> Create Banner
        </button>
        <a href="<?= url('admin/banners/index.php') ?>" class="bn-btn-cancel">
          <i class="fa-solid fa-xmark"></i> Cancel
        </a>
      </div>
    </div>
  </form>
</div>

<script>
function switchMedia(type) {
  var isImage = type === 'image';
  document.getElementById('imageFields').style.display = isImage ? '' : 'none';
  document.getElementById('videoFields').style.display = isImage ? 'none' : '';
  document.querySelectorAll('.media-type-tab').forEach(function(t) {
    t.classList.toggle('active', t.dataset.type === type);
  });
}
function previewImage(e) {
  var f = e.target.files[0]; if (!f) return;
  var r = new FileReader();
  r.onload = function(ev) {
    var box = document.getElementById('imagePreview');
    box.innerHTML = '<img src="' + ev.target.result + '">';
    box.style.display = 'block';
  };
  r.readAsDataURL(f);
}
function previewVideo(e) {
  var f = e.target.files[0]; if (!f) return;
  var box = document.getElementById('videoPreview');
  var url = URL.createObjectURL(f);
  box.innerHTML = '<video src="' + url + '" controls muted></video>';
  box.style.display = 'block';
}
function previewPoster(e) {
  var f = e.target.files[0]; if (!f) return;
  var r = new FileReader();
  r.onload = function(ev) {
    var box = document.getElementById('posterPreview');
    box.innerHTML = '<img src="' + ev.target.result + '">';
    box.style.display = 'block';
  };
  r.readAsDataURL(f);
}
</script>

<?php require __DIR__ . '/../common/footer.php'; ?>