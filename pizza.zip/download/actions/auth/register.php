<?php
// actions/auth/register.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('register.php'));
verify_csrf();
$r = register_customer((string)post('name',''), (string)post('phone',''), post('email') ?: null, (string)post('password',''));
if (!$r['ok']) { remember_old($_POST); flash_error($r['error']); redirect(url('register.php')); }
$login = login_customer((string)post('phone',''), (string)post('password',''));
merge_guest_cart_after_login((int)$r['user_id']);
flash_success('Account created!');
redirect(url('account.php'));