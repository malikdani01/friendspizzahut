<?php
// maintenance.php
$message = 'We are performing scheduled maintenance. Back soon!';
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Maintenance</title><meta name="viewport" content="width=device-width, initial-scale=1"><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-black text-white min-h-screen flex items-center justify-center p-6">
<div class="text-center max-w-md">
  <div class="text-6xl mb-4">🔧</div>
  <h1 class="text-2xl font-bold mb-2">Under Maintenance</h1>
  <p class="text-white/60"><?= htmlspecialchars($message) ?></p>
</div>
</body></html>