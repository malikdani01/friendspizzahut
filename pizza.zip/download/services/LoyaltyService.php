<?php
// services/LoyaltyService.php
class LoyaltyService {
    public static function balance(int $u): int { return loyalty_points_balance($u); }
    public static function award(int $u, int $o, float $t): int { return loyalty_award($u, $o, $t); }
    public static function redeem(int $u, int $p, ?int $o = null): bool { return loyalty_redeem($u, $p, $o); }
}