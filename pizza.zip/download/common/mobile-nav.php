<?php if (restaurant_is_open()): ?>
<nav class="fixed bottom-0 left-0 right-0 md:hidden bg-ink/95 backdrop-blur border-t border-white/10 z-30">
  <div class="grid grid-cols-5 text-center text-[10px] font-medium">
    <a href="<?= url('index.php') ?>" class="py-2 flex flex-col items-center gap-1 text-white/70 hover:text-brand">
      <i class="fa-solid fa-house text-lg"></i> Home
    </a>
    <a href="<?= url('menu.php') ?>" class="py-2 flex flex-col items-center gap-1 text-white/70 hover:text-brand">
      <i class="fa-solid fa-utensils text-lg"></i> Menu
    </a>
    <a href="<?= url('search.php') ?>" class="py-2 flex flex-col items-center gap-1 text-white/70 hover:text-brand">
      <i class="fa-solid fa-magnifying-glass text-lg"></i> Search
    </a>
    <a href="<?= url('cart.php') ?>" class="py-2 flex flex-col items-center gap-1 text-white/70 hover:text-brand relative">
      <i class="fa-solid fa-cart-shopping text-lg"></i> Cart
      <?php $c = get_cart_count(); if ($c > 0): ?>
        <span class="absolute top-1 right-1/4 bg-brand text-white text-[9px] rounded-full px-1.5 py-0.5"><?= $c ?></span>
      <?php endif; ?>
    </a>
    <a href="<?= customer_logged_in() ? url('account.php') : url('login.php') ?>" class="py-2 flex flex-col items-center gap-1 text-white/70 hover:text-brand">
      <i class="fa-solid fa-user text-lg"></i> Account
    </a>
  </div>
</nav>
<?php endif; ?>