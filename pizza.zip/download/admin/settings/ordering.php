<?php
// ordering.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Ordering Settings';
if (is_post()) {
    verify_csrf();
    update_setting('minimum_order', (string)post('minimum_order','300'));
    update_setting('cancellation_window_minutes', (string)post('cancellation_window_minutes','5'));
    flash_success('Saved.');
    redirect(url('admin/settings/ordering.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <div><label class="text-xs text-gray-500">Minimum Order (Rs.)</label><input type="number" name="minimum_order" value="<?= e(setting('minimum_order','300')) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Cancellation window (minutes)</label><input type="number" name="cancellation_window_minutes" value="<?= e(setting('cancellation_window_minutes','5')) ?>" class="w-full border rounded px-3 py-2"></div>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>