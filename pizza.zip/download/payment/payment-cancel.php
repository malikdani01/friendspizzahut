<?php
/**
 * Universal Payment Cancel Handler
 * Jab customer gateway pe "Cancel" kare to yahan aayega.
 */
require_once __DIR__ . '/../common/bootstrap.php';

$data = $_POST ?: $_GET;
$orderNumber = $data['order']
    ?? $data['orderRefNum']
    ?? $data['pp_BillReference']
    ?? '';

$order = $orderNumber ? get_order_by_number((string)$orderNumber) : null;

// Log cancellation
try {
    Database::insert('audit_logs', [
        'user_type'  => 'system',
        'action'     => 'payment.cancel',
        'entity'     => 'payment',
        'new_data'   => json_encode([
            'order_number' => $orderNumber,
            'data'         => array_map(fn($v) => is_string($v) ? mb_substr($v, 0, 200) : $v, $data),
        ]),
        'ip_address' => client_ip(),
        'user_agent' => mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250),
    ]);
} catch (Throwable $e) {
    error_log('payment.cancel log failed: ' . $e->getMessage());
}

if ($order) {
    // Find the pending payment and mark as failed
    $payment = Database::fetch(
        "SELECT * FROM payments WHERE order_id = ? AND payment_status = 'pending' ORDER BY id DESC LIMIT 1",
        [(int)$order['id']]
    );

    if ($payment) {
        mark_payment_failed((int)$payment['id'], 'Customer cancelled on gateway page');
    }

    flash_warning('Payment cancel ho gaya. Aap phir se try kar sakte hain ya COD use kar sakte hain.');

    // If order still pending, redirect to order detail so customer can retry payment
    if ($order['order_status'] === 'pending' && $order['payment_status'] === 'pending') {
        redirect(url('order-detail.php?id=' . (int)$order['id']));
    }

    redirect(url('track-order.php?order=' . urlencode($orderNumber)));
}

flash_warning('Payment cancel ho gaya.');
redirect(url('checkout.php'));