<?php
// services/PricingService.php
class PricingService {
    public static function cartSubtotal(): float { return calculate_cart_subtotal(); }
    public static function deliveryFee(?int $areaId, float $subtotal, bool $pickup): float { return calculate_delivery_fee($areaId, $subtotal, $pickup); }
    public static function finalTotal(array $parts): float { return calculate_final_total($parts); }
    public static function validateMinimum(float $sub): array { return validate_minimum_order($sub); }
}