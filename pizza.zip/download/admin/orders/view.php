<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id', 0);
$order = get_order($id);
if (!$order) { flash_error('Order not found.'); redirect(url('admin/orders/index.php')); }

$pageTitle = 'Order ' . $order['order_number'];

// Mark notification as read when admin views this order
try {
    Database::execute(
        "UPDATE notifications SET is_read = 1, read_at = NOW()
         WHERE user_type = 'admin' AND type = 'new_order' AND is_read = 0
         AND (link LIKE ? OR message LIKE ?)",
        ['%/admin/orders/view.php?id=' . $id . '%', '%' . $order['order_number'] . '%']
    );
} catch (Throwable $e) {}

// Handle POST
if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'update_status') {
        $newStatus  = (string)post('status', '');
        $etaMinutes = (int)post('estimated_minutes', 0);
        $note       = (string)post('note', '');

        $allowed = ['pending','confirmed','preparing','ready','ready_for_pickup',
                    'out_for_delivery','delivered','picked_up','completed','cancelled'];

        if ($newStatus && in_array($newStatus, $allowed, true)) {
            // Update ETA if provided
            if ($etaMinutes > 0) {
                Database::execute(
                    "UPDATE orders SET estimated_minutes = ?, eta_started_at = NOW(), eta_set_by = ? WHERE id = ?",
                    [$etaMinutes, (int)$_SESSION['admin_id'], $id]
                );
            }

            update_order_status($id, $newStatus, (int)$_SESSION['admin_id'], null, $note);

            // Clear ETA when order is finished
            if (in_array($newStatus, ['delivered','completed','picked_up','cancelled'], true)) {
                Database::execute(
                    "UPDATE orders SET estimated_minutes = NULL, eta_started_at = NULL WHERE id = ?",
                    [$id]
                );
            }

            // Mark notification read on status change
            Database::execute(
                "UPDATE notifications SET is_read = 1, read_at = NOW()
                 WHERE user_type = 'admin' AND type = 'new_order' AND is_read = 0
                 AND (message LIKE ? OR link LIKE ?)",
                ['%' . $order['order_number'] . '%', '%/admin/orders/view.php?id=' . $id . '%']
            );

            flash_success('Status updated.' . ($etaMinutes > 0 ? ' Timer set to ' . $etaMinutes . ' minutes.' : ''));
        }

    } elseif ($action === 'add_note') {
        Database::execute(
            "UPDATE orders SET admin_note = ? WHERE id = ?",
            [mb_substr((string)post('admin_note', ''), 0, 500), $id]
        );
        flash_success('Note saved.');
    }

    redirect(url('admin/orders/view.php?id=' . $id));
}

$items   = get_order_items($id);
$history = get_order_status_history($id);

$statuses = $order['order_type'] === 'pickup'
    ? ['pending','confirmed','preparing','ready_for_pickup','picked_up','completed','cancelled']
    : ['pending','confirmed','preparing','ready','out_for_delivery','delivered','completed','cancelled'];

require __DIR__ . '/../common/header.php';
?>

<style>
.admin-order-wrap { max-width: 1200px; margin: 0 auto; }
.ao-grid { display: grid; grid-template-columns: 1fr; gap: 16px; }
@media (min-width: 900px) { .ao-grid { grid-template-columns: 1fr 360px; gap: 20px; } }
.ao-main { display: flex; flex-direction: column; gap: 16px; }
.ao-side { display: flex; flex-direction: column; gap: 16px; }

.ao-card {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  padding: 20px;
  color: #fff;
}
.ao-head-row {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
}
.ao-ordernum { font-family: ui-monospace, monospace; font-size: 18px; font-weight: 800; color: #fff; }
.ao-label-xs {
  font-size: 11px;
  color: rgba(255,255,255,0.5);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.ao-section-title {
  font-size: 15px;
  font-weight: 800;
  color: #dc2626;
  margin: 0 0 14px;
  padding-bottom: 8px;
  border-bottom: 1px solid rgba(255,255,255,0.06);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.ao-item {
  display: flex;
  gap: 12px;
  align-items: flex-start;
  padding: 12px;
  margin-bottom: 8px;
  background: rgba(0,0,0,0.3);
  border: 1px solid rgba(255,255,255,0.06);
  border-radius: 10px;
}
.ao-item-name { font-weight: 700; color: #fff; font-size: 14px; margin-bottom: 3px; }
.ao-item-meta { font-size: 12px; color: rgba(255,255,255,0.55); }
.ao-item-opt { font-size: 11.5px; color: rgba(255,255,255,0.5); margin-top: 2px; }
.ao-item-price { font-weight: 800; color: #dc2626; white-space: nowrap; }

.ao-totals {
  border-top: 1px solid rgba(255,255,255,0.08);
  margin-top: 14px;
  padding-top: 12px;
}
.ao-total-row {
  display: flex;
  justify-content: space-between;
  padding: 5px 0;
  font-size: 13.5px;
  color: rgba(255,255,255,0.7);
}
.ao-total-row span:last-child { color: #fff; font-weight: 600; }
.ao-total-row.discount span:last-child { color: #4ade80; }
.ao-total-row.grand {
  border-top: 2px solid rgba(220,38,38,0.3);
  margin-top: 8px;
  padding-top: 12px;
  font-size: 18px;
  font-weight: 800;
  color: #fff;
}
.ao-total-row.grand span:last-child { color: #dc2626; font-size: 22px; font-weight: 900; }

.ao-timeline { list-style: none; padding: 0; margin: 0; position: relative; }
.ao-timeline::before {
  content: '';
  position: absolute;
  left: 5px;
  top: 8px;
  bottom: 8px;
  width: 2px;
  background: rgba(255,255,255,0.08);
}
.ao-timeline li { position: relative; padding: 0 0 16px 24px; }
.ao-timeline li:last-child { padding-bottom: 0; }
.ao-timeline-dot {
  position: absolute;
  left: 0;
  top: 4px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #dc2626;
  border: 2px solid #171717;
  box-shadow: 0 0 0 2px rgba(220,38,38,0.3);
}
.ao-timeline-title { font-weight: 700; color: #fff; font-size: 13.5px; }
.ao-timeline-date { font-size: 11.5px; color: rgba(255,255,255,0.5); margin-top: 2px; }
.ao-timeline-note { font-size: 12px; color: rgba(255,255,255,0.6); font-style: italic; margin-top: 4px; }

.ao-select, .ao-input, .ao-textarea {
  width: 100%;
  padding: 11px 13px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  color: #fff;
  font-size: 14px;
  font-family: inherit;
  outline: none;
  margin-bottom: 10px;
  transition: border-color .15s;
}
.ao-select:focus, .ao-input:focus, .ao-textarea:focus { border-color: #dc2626; }
.ao-textarea { resize: vertical; min-height: 60px; }
.ao-select option { background: #171717; color: #fff; }

.ao-btn-primary {
  width: 100%;
  padding: 12px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  border: 0;
  border-radius: 10px;
  font-weight: 800;
  font-size: 13.5px;
  cursor: pointer;
  transition: all .15s;
  box-shadow: 0 4px 14px rgba(220,38,38,0.3);
  font-family: inherit;
}
.ao-btn-primary:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 20px rgba(220,38,38,0.45);
}

.ao-btn-secondary {
  width: 100%;
  padding: 10px;
  background: rgba(255,255,255,0.08);
  color: #fff;
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  font-weight: 700;
  font-size: 13px;
  cursor: pointer;
  transition: background .15s;
  font-family: inherit;
}
.ao-btn-secondary:hover { background: rgba(255,255,255,0.15); }

.ao-info-row {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  padding: 7px 0;
  font-size: 13.5px;
  color: rgba(255,255,255,0.7);
  border-bottom: 1px solid rgba(255,255,255,0.04);
}
.ao-info-row:last-child { border-bottom: 0; }
.ao-info-row a { color: #dc2626; text-decoration: none; }
.ao-info-row strong { color: #fff; text-align: right; }

.ao-address {
  margin-top: 12px;
  padding: 10px;
  background: rgba(0,0,0,0.3);
  border-radius: 8px;
  font-size: 13px;
  color: rgba(255,255,255,0.8);
  line-height: 1.5;
}

.ao-back {
  display: block;
  text-align: center;
  padding: 12px;
  color: rgba(255,255,255,0.5);
  text-decoration: none;
  font-size: 13px;
  transition: color .2s;
}
.ao-back:hover { color: #dc2626; }

.ao-eta-box {
  margin-top: 14px;
  padding: 10px 14px;
  background: rgba(234,179,8,0.1);
  border: 1px solid rgba(234,179,8,0.3);
  border-radius: 10px;
  font-size: 12.5px;
  color: #fcd34d;
  line-height: 1.6;
}
.ao-eta-box i { color: #fcd34d; }
.ao-eta-box strong { color: #fff; }
</style>

<div class="admin-order-wrap">
  <div class="ao-grid">

    <!-- ═══ MAIN COLUMN ═══ -->
    <div class="ao-main">

      <!-- ORDER HEADER + ITEMS -->
      <div class="ao-card">
        <div class="ao-head-row">
          <div>
            <div class="ao-label-xs">Order Number</div>
            <div class="ao-ordernum"><?= e($order['order_number']) ?></div>
            <div class="ao-label-xs" style="margin-top:4px;"><?= date('d M Y, H:i', strtotime($order['created_at'])) ?></div>
          </div>
          <div><?= status_badge($order['order_status']) ?></div>
        </div>

        <h3 class="ao-section-title">Items (<?= count($items) ?>)</h3>
        <?php foreach ($items as $it): ?>
          <div class="ao-item">
            <div style="flex:1;min-width:0;">
              <div class="ao-item-name"><?= e($it['product_name']) ?></div>
              <div class="ao-item-meta">Qty: <?= (int)$it['quantity'] ?> × <?= money($it['unit_price']) ?></div>
              <?php foreach ($it['options'] as $op): ?>
                <div class="ao-item-opt">↳ <?= e($op['variation_option_name']) ?> <?= (float)$op['option_price_delta'] ? '(' . money($op['option_price_delta']) . ')' : '' ?></div>
              <?php endforeach; ?>
              <?php foreach ($it['addons'] as $ad): ?>
                <div class="ao-item-opt">+ <?= e($ad['addon_name']) ?> (<?= money($ad['addon_price']) ?>)</div>
              <?php endforeach; ?>
              <?php if (!empty($it['special_instructions'])): ?>
                <div class="ao-item-opt" style="font-style:italic;">Note: <?= e($it['special_instructions']) ?></div>
              <?php endif; ?>
            </div>
            <div class="ao-item-price"><?= money($it['line_total']) ?></div>
          </div>
        <?php endforeach; ?>

        <div class="ao-totals">
          <div class="ao-total-row"><span>Subtotal</span><span><?= money($order['subtotal']) ?></span></div>
          <?php if ((float)$order['discount_total'] > 0): ?>
            <div class="ao-total-row discount"><span>Discount</span><span>-<?= money($order['discount_total']) ?></span></div>
          <?php endif; ?>
          <div class="ao-total-row"><span>Delivery</span><span><?= money($order['delivery_fee']) ?></span></div>
          <?php if ((float)$order['tax_amount'] > 0): ?>
            <div class="ao-total-row"><span>Tax</span><span><?= money($order['tax_amount']) ?></span></div>
          <?php endif; ?>
          <?php if ((float)$order['service_fee'] > 0): ?>
            <div class="ao-total-row"><span>Service Fee</span><span><?= money($order['service_fee']) ?></span></div>
          <?php endif; ?>
          <?php if ((float)$order['packaging_fee'] > 0): ?>
            <div class="ao-total-row"><span>Packaging</span><span><?= money($order['packaging_fee']) ?></span></div>
          <?php endif; ?>
          <div class="ao-total-row grand"><span>Total</span><span><?= money($order['total']) ?></span></div>
        </div>
      </div>

      <!-- STATUS HISTORY -->
      <div class="ao-card">
        <h3 class="ao-section-title">Status History</h3>
        <ol class="ao-timeline">
          <?php foreach ($history as $h): ?>
          <li>
            <div class="ao-timeline-dot"></div>
            <div class="ao-timeline-title"><?= order_status_label($h['new_status']) ?></div>
            <div class="ao-timeline-date"><?= date('d M Y, H:i', strtotime($h['created_at'])) ?></div>
            <?php if (!empty($h['note'])): ?>
              <div class="ao-timeline-note"><?= e($h['note']) ?></div>
            <?php endif; ?>
          </li>
          <?php endforeach; ?>
          <?php if (!$history): ?>
            <li><div class="ao-timeline-dot"></div><div class="ao-timeline-title">No history yet</div></li>
          <?php endif; ?>
        </ol>
      </div>

    </div>

    <!-- ═══ SIDEBAR ═══ -->
    <div class="ao-side">

      <!-- UPDATE STATUS WITH ETA -->
      <div class="ao-card">
        <h3 class="ao-section-title">Update Status</h3>
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="update_status">

          <label style="display:block;font-size:12px;font-weight:700;color:rgba(255,255,255,0.6);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Order Status</label>
          <select name="status" class="ao-select">
            <?php foreach ($statuses as $s): ?>
              <option value="<?= $s ?>" <?= $order['order_status']===$s?'selected':'' ?>><?= order_status_label($s) ?></option>
            <?php endforeach; ?>
          </select>

          <label style="display:block;font-size:12px;font-weight:700;color:rgba(255,255,255,0.6);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;margin-top:12px;">
            <i class="fa-solid fa-hourglass-half" style="color:#f59e0b;"></i> Estimated Time (minutes)
          </label>
          <input type="number" name="estimated_minutes" min="1" max="180"
                 value="<?= (int)($order['estimated_minutes'] ?? 30) ?>"
                 placeholder="e.g. 30" class="ao-input" style="margin-bottom:6px;">
          <div style="font-size:11.5px;color:rgba(255,255,255,0.45);margin-bottom:12px;line-height:1.5;">
            Customer ko countdown timer dikhega. Status update karte hi timer restart hoga.
          </div>

          <label style="display:block;font-size:12px;font-weight:700;color:rgba(255,255,255,0.6);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">Note (optional)</label>
          <input name="note" placeholder="Internal note" class="ao-input">

          <button type="submit" class="ao-btn-primary">
            <i class="fa-solid fa-check"></i> Update Status
          </button>
        </form>

        <?php if (!empty($order['estimated_minutes']) && !empty($order['eta_started_at'])): ?>
          <div class="ao-eta-box">
            <i class="fa-solid fa-clock"></i>
            Timer set: <strong><?= (int)$order['estimated_minutes'] ?> minutes</strong><br>
            Started: <?= date('d M Y, H:i', strtotime($order['eta_started_at'])) ?>
          </div>
        <?php endif; ?>
      </div>

      <!-- CUSTOMER -->
      <div class="ao-card">
        <h3 class="ao-section-title">Customer</h3>
        <div class="ao-info-row"><span>Name:</span><strong><?= e($order['customer_name']) ?></strong></div>
        <div class="ao-info-row"><span>Phone:</span><a href="tel:<?= e($order['customer_phone']) ?>"><?= e($order['customer_phone']) ?></a></div>
        <?php if (!empty($order['customer_email'])): ?>
          <div class="ao-info-row"><span>Email:</span><strong style="font-size:12px;"><?= e($order['customer_email']) ?></strong></div>
        <?php endif; ?>
        <div class="ao-info-row"><span>Type:</span><strong><?= e(ucfirst($order['order_type'])) ?></strong></div>
        <?php if ($order['order_type'] === 'delivery' && $order['delivery_address_snapshot']): ?>
          <div class="ao-address">
            <div class="ao-label-xs" style="margin-bottom:6px;">Delivery Address</div>
            <div><?= e($order['delivery_address_snapshot']) ?></div>
            <?php if (!empty($order['city'])): ?>
              <div class="ao-item-opt" style="margin-top:4px;"><?= e($order['city']) ?></div>
            <?php endif; ?>
            <?php if (!empty($order['landmark'])): ?>
              <div class="ao-item-opt">Landmark: <?= e($order['landmark']) ?></div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>

      <!-- PAYMENT -->
      <div class="ao-card">
        <h3 class="ao-section-title">Payment</h3>
        <div class="ao-info-row">
          <span>Method:</span>
          <strong style="text-transform:uppercase;"><?= e($order['payment_method']) ?></strong>
        </div>
        <div class="ao-info-row">
          <span>Status:</span>
          <span><?= status_badge($order['payment_status']) ?></span>
        </div>
        <?php if (!empty($order['transaction_id'])): ?>
          <div class="ao-info-row">
            <span>Txn ID:</span>
            <strong style="font-family:monospace;font-size:12px;"><?= e($order['transaction_id']) ?></strong>
          </div>
        <?php endif; ?>
      </div>

      <!-- ADMIN NOTE -->
      <div class="ao-card">
        <h3 class="ao-section-title">Admin Note</h3>
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="add_note">
          <textarea name="admin_note" rows="3" class="ao-textarea"><?= e($order['admin_note']) ?></textarea>
          <button type="submit" class="ao-btn-secondary">
            <i class="fa-solid fa-save"></i> Save Note
          </button>
        </form>
      </div>

      <a href="<?= url('admin/orders/index.php') ?>" class="ao-back">
        <i class="fa-solid fa-arrow-left"></i> Back to Orders
      </a>

    </div>

  </div>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>