<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Notifications';

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'mark_read') Database::execute("UPDATE notifications SET is_read=1, read_at=NOW() WHERE id=?", [(int)post('id')]);
    elseif ($action === 'read_all') Database::execute("UPDATE notifications SET is_read=1, read_at=NOW() WHERE user_type='admin' AND is_read=0");
    elseif ($action === 'delete') Database::execute("DELETE FROM notifications WHERE id=?", [(int)post('id')]);
    redirect(url('admin/notifications/index.php'));
}

$rows = Database::fetchAll("SELECT * FROM notifications WHERE user_type='admin' ORDER BY id DESC LIMIT 100");
require __DIR__ . '/../common/header.php';
?>
<div class="flex justify-end mb-4">
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="read_all"><button class="text-sm text-brand hover:underline">Mark all read</button></form>
</div>
<div class="space-y-2">
  <?php foreach ($rows as $n): ?>
  <div class="bg-white rounded-xl border <?= $n['is_read']?'border-gray-100':'border-brand/40' ?> p-4">
    <div class="flex justify-between items-start">
      <div>
        <div class="font-semibold"><?= e($n['title']) ?></div>
        <div class="text-sm text-gray-600 mt-1"><?= e($n['message']) ?></div>
        <div class="text-xs text-gray-400 mt-1"><?= date('d M Y, H:i', strtotime($n['created_at'])) ?></div>
      </div>
      <div class="flex gap-2 text-xs">
        <?php if ($n['link']): ?><a href="<?= e($n['link']) ?>" class="text-brand">View</a><?php endif; ?>
        <?php if (!$n['is_read']): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="mark_read"><input type="hidden" name="id" value="<?= (int)$n['id'] ?>"><button class="text-gray-500">Read</button></form><?php endif; ?>
        <form method="post" class="inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$n['id'] ?>"><button class="text-red-500">Delete</button></form>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><div class="text-center py-10 text-gray-400 bg-white rounded-xl border">No notifications.</div><?php endif; ?>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>