<?php
/**
 * Chat / Support Messages — User ↔ Admin
 */

function chat_send(int $userId, string $senderType, string $senderName, string $message, ?int $senderId = null, ?int $orderId = null): array {
    $message = trim($message);
    if ($message === '')         return ['ok' => false, 'error' => 'Message is empty.'];
    if (strlen($message) > 3000) return ['ok' => false, 'error' => 'Message too long.'];

    if (!in_array($senderType, ['user','admin','rider'], true)) {
        return ['ok' => false, 'error' => 'Invalid sender type.'];
    }

    $user = Database::fetch("SELECT id FROM users WHERE id = ?", [$userId]);
    if (!$user) return ['ok' => false, 'error' => 'User not found.'];

    $id = Database::insert('chat_messages', [
        'user_id'     => $userId,
        'order_id'    => $orderId,
        'sender_type' => $senderType,
        'sender_id'   => $senderId,
        'sender_name' => $senderName,
        'message'     => $message,
        'is_read'     => 0,
    ]);

    if ($senderType === 'user') {
        Database::insert('notifications', [
            'user_type' => 'admin',
            'user_id'   => 1,
            'type'      => 'chat_message',
            'title'     => 'New message from ' . $senderName,
            'message'   => mb_substr($message, 0, 120),
            'link'      => '/admin/messages/chat.php?user_id=' . $userId,
        ]);
    } else {
        Database::insert('notifications', [
            'user_type' => 'customer',
            'user_id'   => $userId,
            'type'      => 'chat_message',
            'title'     => 'New message from ' . $senderName,
            'message'   => mb_substr($message, 0, 120),
            'link'      => '/messages.php',
        ]);
    }

    return ['ok' => true, 'id' => $id];
}

function chat_get_messages(int $userId, ?int $orderId = null, int $limit = 200): array {
    if ($orderId) {
        return Database::fetchAll(
            "SELECT * FROM chat_messages WHERE user_id = ? AND order_id = ? ORDER BY id ASC LIMIT " . (int)$limit,
            [$userId, $orderId]
        );
    }
    return Database::fetchAll(
        "SELECT * FROM chat_messages WHERE user_id = ? AND order_id IS NULL ORDER BY id ASC LIMIT " . (int)$limit,
        [$userId]
    );
}

function chat_mark_read(int $userId, string $readerType, ?int $orderId = null): void {
    if ($orderId) {
        Database::execute(
            "UPDATE chat_messages SET is_read = 1, read_at = NOW()
             WHERE user_id = ? AND order_id = ? AND sender_type != ? AND is_read = 0",
            [$userId, $orderId, $readerType]
        );
    } else {
        Database::execute(
            "UPDATE chat_messages SET is_read = 1, read_at = NOW()
             WHERE user_id = ? AND order_id IS NULL AND sender_type != ? AND is_read = 0",
            [$userId, $readerType]
        );
    }
}

function chat_unread_count(int $userId, string $readerType, ?int $orderId = null): int {
    if ($orderId) {
        $r = Database::fetch(
            "SELECT COUNT(*) c FROM chat_messages WHERE user_id = ? AND order_id = ? AND sender_type != ? AND is_read = 0",
            [$userId, $orderId, $readerType]
        );
    } else {
        $r = Database::fetch(
            "SELECT COUNT(*) c FROM chat_messages WHERE user_id = ? AND order_id IS NULL AND sender_type != ? AND is_read = 0",
            [$userId, $readerType]
        );
    }
    return (int)($r['c'] ?? 0);
}

function chat_admin_unread_count(): int {
    try {
        $r = Database::fetch("SELECT COUNT(*) c FROM chat_messages WHERE sender_type = 'user' AND is_read = 0");
        return (int)($r['c'] ?? 0);
    } catch (Throwable $e) { return 0; }
}

function chat_admin_threads(): array {
    try {
        return Database::fetchAll(
            "SELECT 
                cm.user_id,
                u.name AS user_name,
                u.phone AS user_phone,
                u.email AS user_email,
                (SELECT message FROM chat_messages WHERE user_id = cm.user_id AND order_id IS NULL ORDER BY id DESC LIMIT 1) AS last_message,
                (SELECT created_at FROM chat_messages WHERE user_id = cm.user_id AND order_id IS NULL ORDER BY id DESC LIMIT 1) AS last_at,
                (SELECT COUNT(*) FROM chat_messages WHERE user_id = cm.user_id AND order_id IS NULL AND sender_type = 'user' AND is_read = 0) AS unread
             FROM chat_messages cm
             JOIN users u ON u.id = cm.user_id
             WHERE cm.order_id IS NULL
             GROUP BY cm.user_id
             ORDER BY last_at DESC
             LIMIT 200"
        );
    } catch (Throwable $e) { return []; }
}

function chat_user_active_order(int $userId): ?array {
    try {
        return Database::fetch(
            "SELECT o.*, r.name AS rider_name
             FROM orders o
             LEFT JOIN riders r ON r.id = o.rider_id
             WHERE o.user_id = ?
             AND o.order_status IN ('confirmed','preparing','ready','out_for_delivery')
             ORDER BY o.id DESC LIMIT 1",
            [$userId]
        );
    } catch (Throwable $e) { return null; }
}