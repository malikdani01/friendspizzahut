<?php
/**
 * CHECKOUT DEBUG SCRIPT
 * Access: yoursite.com/checkout-debug.php
 * DELETE AFTER DEBUGGING
 */
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/common/bootstrap.php';

echo "<pre style='background:#000;color:#0f0;padding:20px;font-size:13px;line-height:1.6;'>";
echo "═══════════════════════════════════════════════════════\n";
echo "  FRIENDS PIZZA HUT — CHECKOUT DEBUG\n";
echo "═══════════════════════════════════════════════════════\n\n";

// ─── 1. DB CONNECTION TEST ─────────────────────────────────
echo "1️⃣ DB CONNECTION\n";
try {
    $pdo = Database::pdo();
    echo "   ✅ Connected\n";
    echo "   Host: " . DB_HOST . "\n";
    echo "   DB:   " . DB_NAME . "\n";
} catch (Throwable $e) {
    echo "   ❌ FAILED: " . $e->getMessage() . "\n";
    echo "</pre>"; exit;
}

// ─── 2. ORDERS TABLE COLUMNS ───────────────────────────────
echo "\n2️⃣ ORDERS TABLE COLUMNS\n";
try {
    $cols = Database::fetchAll("SHOW COLUMNS FROM orders");
    foreach ($cols as $c) {
        $null = $c['Null'] === 'YES' ? 'NULL' : 'NOT NULL';
        $default = $c['Default'] ?? 'NULL';
        $extra = $c['Extra'] ?? '';
        echo "   • {$c['Field']} — {$c['Type']} — {$null} — Default: {$default} {$extra}\n";
    }
} catch (Throwable $e) {
    echo "   ❌ " . $e->getMessage() . "\n";
}

// ─── 3. TEST ORDER INSERT (dry run) ────────────────────────
echo "\n3️⃣ TEST ORDER INSERT\n";
try {
    Database::beginTransaction();
    
    $orderNumber = 'TEST-' . date('YmdHis') . '-' . rand(1000, 9999);
    
    echo "   Attempting insert with order_number: $orderNumber\n";
    
    $testData = [
        'order_number'              => $orderNumber,
        'user_id'                   => null,
        'customer_name'             => 'Debug Test',
        'customer_phone'            => '03001234567',
        'customer_email'            => null,
        'order_type'                => 'delivery',
        'delivery_address_snapshot' => 'Test address here',
        'city'                      => 'City Tamman',
        'subtotal'                  => 320,
        'discount_total'            => 0,
        'delivery_fee'              => 50,
        'tax_amount'                => 0,
        'service_fee'               => 0,
        'packaging_fee'             => 0,
        'total'                     => 370,
        'payment_method'            => 'cod',
        'payment_status'            => 'pending',
        'order_status'              => 'pending',
        'ip_address'                => '127.0.0.1',
    ];
    
    $id = Database::insert('orders', $testData);
    echo "   ✅ Insert SUCCESS — Order ID: $id\n";
    
    // Test order_items
    echo "\n   Testing order_items insert...\n";
    $itemId = Database::insert('order_items', [
        'order_id'              => $id,
        'product_id'            => null,
        'product_name'          => 'Debug Product',
        'unit_price'            => 320,
        'quantity'              => 1,
        'addons_total'          => 0,
        'line_total'            => 320,
    ]);
    echo "   ✅ Item ID: $itemId\n";
    
    // Test payments
    echo "\n   Testing payments insert...\n";
    $payId = Database::insert('payments', [
        'order_id'       => $id,
        'method'         => 'cod',
        'amount'         => 370,
        'currency'       => 'PKR',
        'payment_status' => 'pending',
    ]);
    echo "   ✅ Payment ID: $payId\n";
    
    // Test status history
    echo "\n   Testing order_status_history insert...\n";
    $histId = Database::insert('order_status_history', [
        'order_id'   => $id,
        'old_status' => null,
        'new_status' => 'pending',
        'note'       => 'Debug test',
    ]);
    echo "   ✅ History ID: $histId\n";
    
    // Test notifications
    echo "\n   Testing notifications insert...\n";
    try {
        $notifId = Database::insert('notifications', [
            'user_type' => 'admin',
            'user_id'   => 1,
            'type'      => 'new_order',
            'title'     => 'Debug Test',
            'message'   => 'Test message',
            'link'      => '/admin/orders/view.php?id=' . $id,
        ]);
        echo "   ✅ Notification ID: $notifId\n";
    } catch (Throwable $e) {
        echo "   ⚠️  Notification FAILED (non-critical): " . $e->getMessage() . "\n";
    }
    
    // Rollback — we don't want test data
    Database::rollback();
    echo "\n   🔄 Rolled back — test data NOT saved\n";
    echo "\n   ✅ ALL INSERTS WORKING\n";
    
} catch (Throwable $e) {
    Database::rollback();
    echo "   ❌ INSERT FAILED!\n";
    echo "   Error: " . $e->getMessage() . "\n";
    echo "   File:  " . $e->getFile() . "\n";
    echo "   Line:  " . $e->getLine() . "\n";
}

// ─── 4. CART / SESSION TEST ────────────────────────────────
echo "\n4️⃣ CART TEST\n";
try {
    $cartCount = function_exists('get_cart_count') ? get_cart_count() : 'FUNC MISSING';
    echo "   Cart count: $cartCount\n";
    
    $items = function_exists('get_cart_items') ? get_cart_items() : [];
    echo "   Cart items: " . count($items) . "\n";
    foreach ($items as $it) {
        echo "     - {$it['name']} x {$it['quantity']} = Rs.{$it['line_total']}\n";
    }
} catch (Throwable $e) {
    echo "   ❌ " . $e->getMessage() . "\n";
}

// ─── 5. HELPER FUNCTIONS TEST ──────────────────────────────
echo "\n5️⃣ HELPER FUNCTIONS\n";
$funcs = ['generate_order_number', 'calculate_cart_subtotal', 'validate_minimum_order',
          'calculate_delivery_fee', 'calculate_tax', 'calculate_final_total',
          'clear_cart', 'validate_phone'];
foreach ($funcs as $f) {
    echo "   " . (function_exists($f) ? '✅' : '❌') . " $f()\n";
}

// ─── 6. RESTAURANT OPEN CHECK ──────────────────────────────
echo "\n6️⃣ RESTAURANT STATUS\n";
try {
    $isOpen = restaurant_is_open();
    echo "   Is Open: " . ($isOpen ? 'YES' : 'NO') . "\n";
    echo "   Opening: " . setting('opening_time', '11:00') . "\n";
    echo "   Closing: " . setting('closing_time', '02:00') . "\n";
    echo "   Status:  " . setting('restaurant_status', 'open') . "\n";
} catch (Throwable $e) {
    echo "   ❌ " . $e->getMessage() . "\n";
}

// ─── 7. PHP INFO ───────────────────────────────────────────
echo "\n7️⃣ ENVIRONMENT\n";
echo "   PHP Version: " . PHP_VERSION . "\n";
echo "   APP_DEBUG: " . (defined('APP_DEBUG') && APP_DEBUG ? 'TRUE' : 'FALSE') . "\n";
echo "   APP_URL: " . (defined('APP_URL') ? APP_URL : 'NOT DEFINED') . "\n";

echo "\n═══════════════════════════════════════════════════════\n";
echo "  DONE — Screenshot this and send it\n";
echo "  DELETE this file after debugging\n";
echo "═══════════════════════════════════════════════════════\n";
echo "</pre>";