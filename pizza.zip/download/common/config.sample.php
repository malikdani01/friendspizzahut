<?php
/**
 * Friends Pizza Hut — Configuration Sample
 * setup.php writes common/config.php after installation.
 * DO NOT EDIT config.sample.php; edit common/config.php instead.
 */

// ─── Database ────────────────────────────────────────────────
define('DB_HOST', 'sql205.byethost7.com');
define('DB_NAME', 'friends_pizza_hut');
define('DB_USER', 'b7_43136823');
define('DB_PASS', 'b7_43136823');
define('DB_CHARSET', 'utf8mb4');

// ─── App ─────────────────────────────────────────────────────
define('APP_NAME', 'Friends Pizza Hut');
define('APP_URL', 'http://localhost/friends-pizza-hut');
define('APP_DEBUG', false);
define('APP_TIMEZONE', 'Asia/Karachi');

// ─── Security ────────────────────────────────────────────────
define('SESSION_NAME', 'fph_session');
define('SESSION_LIFETIME', 86400 * 7);

// ─── Paths ───────────────────────────────────────────────────
define('ROOT_PATH', dirname(__DIR__));
define('UPLOAD_PATH', ROOT_PATH . '/uploads');
define('UPLOAD_URL', APP_URL . '/uploads');