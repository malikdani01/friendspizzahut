<?php
// actions/cart/add.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('menu.php'));
verify_csrf();
$pid = (int)post('product_id', 0);
$qty = max(1, (int)post('quantity', 1));
$opts = array_map('intval', (array)($_POST['variation'] ?? []));
$addons = array_map('intval', (array)($_POST['addons'] ?? []));
$notes = (string)post('notes','');
$r = add_to_cart($pid, $qty, $opts, $addons, $notes);
if ($r['ok']) { flash_success('Added to cart!'); redirect(url('cart.php')); }
flash_error($r['error'] ?? 'Failed.');
redirect(url('product.php?slug=' . urlencode((string)post('slug',''))));