<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Contact Us';
$user = customer_logged_in() ? current_customer() : null;

$errors = [];
if (is_post()) {
    verify_csrf();
    $name    = trim((string)post('name',''));
    $phone   = trim((string)post('phone',''));
    $email   = trim((string)post('email',''));
    $subject = trim((string)post('subject',''));
    $message = trim((string)post('message',''));

    if (strlen($name) < 2)      $errors[] = 'Name required.';
    if (!validate_phone($phone)) $errors[] = 'Valid phone required.';
    if (strlen($message) < 5)   $errors[] = 'Message too short.';

    if (!$errors) {
        Database::insert('contact_messages', [
            'name'        => $name,
            'phone'       => $phone,
            'email'       => $email ?: null,
            'subject'     => $subject ?: null,
            'message'     => $message,
            'user_id'     => $user['id'] ?? null,
            'sender_type' => $user ? 'user' : 'guest',
            'ip_address'  => client_ip(),
        ]);
        flash_success('Message sent! We will reply soon.');
        redirect(url('contact.php'));
    }
}

require __DIR__ . '/common/header.php';
?>

<style>
.ct-wrap { max-width: 700px; margin: 0 auto; padding: 20px 16px 140px; }
.ct-title { font-size: 26px; font-weight: 900; color: #fff; margin: 0 0 4px; }
.ct-sub { font-size: 13.5px; color: rgba(255,255,255,0.55); margin: 0 0 24px; }
.ct-info-grid { display: grid; grid-template-columns: 1fr; gap: 10px; margin-bottom: 20px; }
@media (min-width: 640px) { .ct-info-grid { grid-template-columns: 1fr 1fr; } }
.ct-info { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 14px; display: flex; gap: 12px; align-items: center; }
.ct-info-icon { width: 40px; height: 40px; border-radius: 50%; background: rgba(220,38,38,0.12); display: flex; align-items: center; justify-content: center; color: #dc2626; font-size: 16px; flex-shrink: 0; }
.ct-info-title { font-size: 12px; color: rgba(255,255,255,0.5); font-weight: 600; }
.ct-info-value { font-size: 14px; color: #fff; font-weight: 700; }
.ct-card { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 20px; }
.ct-card h3 { font-size: 15px; font-weight: 800; color: #dc2626; margin: 0 0 16px; text-transform: uppercase; letter-spacing: 0.5px; }
.ct-label { display: block; font-size: 13px; font-weight: 600; color: rgba(255,255,255,0.72); margin-bottom: 6px; }
.ct-input, .ct-textarea { width: 100%; padding: 12px 14px; background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 10px; color: #fff; font-size: 15px; font-family: inherit; outline: none; margin-bottom: 14px; -webkit-appearance: none; }
.ct-input:focus, .ct-textarea:focus { border-color: #dc2626; box-shadow: 0 0 0 3px rgba(220,38,38,0.15); }
.ct-input::placeholder, .ct-textarea::placeholder { color: rgba(255,255,255,0.35); }
.ct-textarea { resize: vertical; min-height: 120px; }
.ct-btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; width: 100%; min-height: 46px; padding: 12px 24px; background: linear-gradient(135deg, #dc2626, #b91c1c); color: #fff; border: 0; border-radius: 12px; font-size: 14px; font-weight: 800; cursor: pointer; box-shadow: 0 6px 18px rgba(220,38,38,0.3); }
.ct-btn:hover { transform: translateY(-1px); }
.ct-error { background: rgba(239,68,68,0.12); border: 1px solid rgba(239,68,68,0.4); color: #fca5a5; padding: 12px 14px; border-radius: 10px; font-size: 13.5px; margin-bottom: 16px; }
.ct-alt { margin-top: 20px; padding: 16px; background: linear-gradient(135deg, rgba(59,130,246,0.12), rgba(59,130,246,0.04)); border: 1px solid rgba(59,130,246,0.3); border-radius: 12px; display: flex; gap: 12px; align-items: center; text-decoration: none; color: inherit; }
.ct-alt:hover { border-color: rgba(59,130,246,0.5); }
.ct-alt-icon { width: 44px; height: 44px; border-radius: 50%; background: rgba(59,130,246,0.2); display: flex; align-items: center; justify-content: center; color: #60a5fa; font-size: 18px; flex-shrink: 0; }
.ct-alt-title { font-size: 14px; font-weight: 800; color: #fff; }
.ct-alt-sub { font-size: 12px; color: rgba(255,255,255,0.55); margin-top: 2px; }
</style>

<div class="ct-wrap">
  <h1 class="ct-title">📬 Contact Us</h1>
  <p class="ct-sub">Have a question? Send us a message.</p>

  <div class="ct-info-grid">
    <div class="ct-info">
      <div class="ct-info-icon"><i class="fa-solid fa-location-dot"></i></div>
      <div>
        <div class="ct-info-title">Visit Us</div>
        <div class="ct-info-value"><?= e(setting('restaurant_address', 'City Tamman')) ?></div>
      </div>
    </div>
    <div class="ct-info">
      <div class="ct-info-icon"><i class="fa-solid fa-phone"></i></div>
      <div>
        <div class="ct-info-title">Call Us</div>
        <div class="ct-info-value"><?= e(setting('restaurant_phone', '')) ?></div>
      </div>
    </div>
  </div>

  <?php foreach ($errors as $er): ?>
    <div class="ct-error">• <?= e($er) ?></div>
  <?php endforeach; ?>

  <div class="ct-card">
    <h3><i class="fa-solid fa-paper-plane"></i> Send us a message</h3>
    <form method="post">
      <?= csrf_field() ?>
      <label class="ct-label">Full Name *</label>
      <input class="ct-input" name="name" required value="<?= e($user['name'] ?? post('name','')) ?>" placeholder="Your name">

      <label class="ct-label">Phone Number *</label>
      <input class="ct-input" name="phone" required value="<?= e($user['phone'] ?? post('phone','')) ?>" placeholder="03XXXXXXXXX" inputmode="tel">

      <label class="ct-label">Email (optional)</label>
      <input class="ct-input" type="email" name="email" value="<?= e($user['email'] ?? post('email','')) ?>" placeholder="you@example.com">

      <label class="ct-label">Subject</label>
      <input class="ct-input" name="subject" value="<?= e(post('subject','')) ?>" placeholder="What is this about?">

      <label class="ct-label">Message *</label>
      <textarea class="ct-textarea" name="message" required placeholder="Type your message..."><?= e(post('message','')) ?></textarea>

      <button type="submit" class="ct-btn"><i class="fa-solid fa-paper-plane"></i> Send Message</button>
    </form>
  </div>

  <?php if ($user): ?>
    <a href="<?= url('messages.php') ?>" class="ct-alt">
      <div class="ct-alt-icon"><i class="fa-solid fa-comments"></i></div>
      <div style="flex:1;">
        <div class="ct-alt-title">Chat with us instantly</div>
        <div class="ct-alt-sub">Real-time chat with admin and rider</div>
      </div>
      <i class="fa-solid fa-arrow-right" style="color:rgba(255,255,255,0.4);"></i>
    </a>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/common/footer.php'; ?>