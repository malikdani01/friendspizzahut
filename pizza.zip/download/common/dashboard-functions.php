<?php
/**
 * Admin Dashboard — Analytics Helper Functions
 */

/**
 * Get date range based on filter type
 */
function dashboard_date_range(string $filter = 'today', ?string $from = null, ?string $to = null): array {
    $today = date('Y-m-d');
    switch ($filter) {
        case 'today':
            return ['from' => $today, 'to' => $today, 'label' => 'Today'];
        case 'yesterday':
            return ['from' => date('Y-m-d', strtotime('-1 day')), 'to' => date('Y-m-d', strtotime('-1 day')), 'label' => 'Yesterday'];
        case 'week':
            return ['from' => date('Y-m-d', strtotime('monday this week')), 'to' => $today, 'label' => 'This Week'];
        case 'month':
            return ['from' => date('Y-m-01'), 'to' => $today, 'label' => 'This Month'];
        case 'year':
            return ['from' => date('Y-01-01'), 'to' => $today, 'label' => 'This Year'];
        case 'last7':
            return ['from' => date('Y-m-d', strtotime('-6 days')), 'to' => $today, 'label' => 'Last 7 Days'];
        case 'last30':
            return ['from' => date('Y-m-d', strtotime('-29 days')), 'to' => $today, 'label' => 'Last 30 Days'];
        case 'last90':
            return ['from' => date('Y-m-d', strtotime('-89 days')), 'to' => $today, 'label' => 'Last 90 Days'];
        case 'custom':
            return [
                'from' => $from ?: $today,
                'to'   => $to ?: $today,
                'label' => 'Custom Range',
            ];
        default:
            return ['from' => $today, 'to' => $today, 'label' => 'Today'];
    }
}

/**
 * Core dashboard stats for a date range
 */
function dashboard_stats(string $from, string $to): array {
    $stats = [
        'orders'          => 0,
        'completed'       => 0,
        'cancelled'       => 0,
        'pending'         => 0,
        'revenue'         => 0.0,
        'avg_order'       => 0.0,
        'delivery_orders' => 0,
        'pickup_orders'   => 0,
        'new_customers'   => 0,
        'products_sold'   => 0,
    ];

    // Orders
    $r = Database::fetch(
        "SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN order_status NOT IN ('cancelled','refunded') THEN 1 ELSE 0 END) AS active_total,
            SUM(CASE WHEN order_status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_total,
            SUM(CASE WHEN order_status = 'pending' THEN 1 ELSE 0 END) AS pending_total,
            COALESCE(SUM(CASE WHEN order_status NOT IN ('cancelled','refunded') THEN total ELSE 0 END), 0) AS rev,
            COALESCE(AVG(CASE WHEN order_status NOT IN ('cancelled','refunded') THEN total END), 0) AS av,
            SUM(CASE WHEN order_type = 'delivery' AND order_status NOT IN ('cancelled','refunded') THEN 1 ELSE 0 END) AS deliv,
            SUM(CASE WHEN order_type = 'pickup' AND order_status NOT IN ('cancelled','refunded') THEN 1 ELSE 0 END) AS pick
         FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?",
        [$from, $to]
    );
    $stats['orders']          = (int)($r['total'] ?? 0);
    $stats['completed']       = (int)($r['active_total'] ?? 0);
    $stats['cancelled']       = (int)($r['cancelled_total'] ?? 0);
    $stats['pending']         = (int)($r['pending_total'] ?? 0);
    $stats['revenue']         = (float)($r['rev'] ?? 0);
    $stats['avg_order']       = (float)($r['av'] ?? 0);
    $stats['delivery_orders'] = (int)($r['deliv'] ?? 0);
    $stats['pickup_orders']   = (int)($r['pick'] ?? 0);

    // New customers
    $c = Database::fetch(
        "SELECT COUNT(*) AS c FROM users WHERE DATE(created_at) BETWEEN ? AND ?",
        [$from, $to]
    );
    $stats['new_customers'] = (int)($c['c'] ?? 0);

    // Products sold
    $ps = Database::fetch(
        "SELECT COALESCE(SUM(oi.quantity), 0) AS q
         FROM order_items oi
         JOIN orders o ON o.id = oi.order_id
         WHERE DATE(o.created_at) BETWEEN ? AND ?
         AND o.order_status NOT IN ('cancelled','refunded')",
        [$from, $to]
    );
    $stats['products_sold'] = (int)($ps['q'] ?? 0);

    return $stats;
}

/**
 * Top selling products
 */
function dashboard_top_products(string $from, string $to, int $limit = 10): array {
    return Database::fetchAll(
        "SELECT 
            oi.product_id,
            oi.product_name,
            p.image,
            p.slug,
            SUM(oi.quantity) AS qty_sold,
            SUM(oi.line_total) AS revenue
         FROM order_items oi
         JOIN orders o ON o.id = oi.order_id
         LEFT JOIN products p ON p.id = oi.product_id
         WHERE DATE(o.created_at) BETWEEN ? AND ?
         AND o.order_status NOT IN ('cancelled','refunded')
         GROUP BY oi.product_id, oi.product_name
         ORDER BY qty_sold DESC
         LIMIT " . (int)$limit,
        [$from, $to]
    );
}

/**
 * Top spending customers
 */
function dashboard_top_customers(string $from, string $to, int $limit = 10): array {
    return Database::fetchAll(
        "SELECT 
            o.user_id,
            o.customer_name,
            o.customer_phone,
            u.email,
            COUNT(*) AS order_count,
            SUM(o.total) AS total_spent
         FROM orders o
         LEFT JOIN users u ON u.id = o.user_id
         WHERE DATE(o.created_at) BETWEEN ? AND ?
         AND o.order_status NOT IN ('cancelled','refunded')
         GROUP BY o.customer_phone
         ORDER BY total_spent DESC
         LIMIT " . (int)$limit,
        [$from, $to]
    );
}

/**
 * Revenue chart data — daily buckets
 */
function dashboard_revenue_chart(string $from, string $to): array {
    $rows = Database::fetchAll(
        "SELECT DATE(created_at) AS d,
                COUNT(*) AS orders,
                COALESCE(SUM(CASE WHEN order_status NOT IN ('cancelled','refunded') THEN total ELSE 0 END), 0) AS revenue
         FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?
         GROUP BY DATE(created_at)
         ORDER BY d ASC",
        [$from, $to]
    );

    // Fill gaps
    $labels = [];
    $revenueData = [];
    $ordersData = [];

    $start = new DateTime($from);
    $end = new DateTime($to);
    $end->modify('+1 day');
    $interval = new DateInterval('P1D');
    $period = new DatePeriod($start, $interval, $end);

    $byDate = [];
    foreach ($rows as $r) {
        $byDate[$r['d']] = [
            'revenue' => (float)$r['revenue'],
            'orders'  => (int)$r['orders'],
        ];
    }

    foreach ($period as $dt) {
        $key = $dt->format('Y-m-d');
        $labels[] = $dt->format('d M');
        $revenueData[] = $byDate[$key]['revenue'] ?? 0;
        $ordersData[]  = $byDate[$key]['orders'] ?? 0;
    }

    return [
        'labels'  => $labels,
        'revenue' => $revenueData,
        'orders'  => $ordersData,
    ];
}

/**
 * Status distribution
 */
function dashboard_status_distribution(string $from, string $to): array {
    return Database::fetchAll(
        "SELECT order_status, COUNT(*) AS c
         FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?
         GROUP BY order_status
         ORDER BY c DESC",
        [$from, $to]
    );
}

/**
 * Recent orders in range
 */
function dashboard_recent_orders(string $from, string $to, int $limit = 8): array {
    return Database::fetchAll(
        "SELECT * FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?
         ORDER BY id DESC
         LIMIT " . (int)$limit,
        [$from, $to]
    );
}

/**
 * Payment method breakdown
 */
function dashboard_payment_breakdown(string $from, string $to): array {
    return Database::fetchAll(
        "SELECT payment_method, COUNT(*) AS c, COALESCE(SUM(total),0) AS amount
         FROM orders
         WHERE DATE(created_at) BETWEEN ? AND ?
         AND order_status NOT IN ('cancelled','refunded')
         GROUP BY payment_method
         ORDER BY amount DESC",
        [$from, $to]
    );
}