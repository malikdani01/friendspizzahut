<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$pageTitle = 'Wishlist';
$items = feature_enabled('wishlist') ? wishlist_get((int)$_SESSION['user_id']) : [];
require __DIR__ . '/common/header.php';
?>
<div class="max-w-7xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-8">My Wishlist</h1>
  <?php if (!$items): ?>
    <div class="text-center py-16 bg-white/5 rounded-2xl border border-white/10">
      <i class="fa-solid fa-heart text-5xl text-white/30 mb-4"></i>
      <p class="text-white/60 mb-6">No favorites yet.</p>
      <a href="<?= url('menu.php') ?>" class="bg-brand px-6 py-3 rounded-full font-bold">Browse Menu</a>
    </div>
  <?php else: ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
      <?php foreach ($items as $p): require __DIR__ . '/common/components/product-card.php'; endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>