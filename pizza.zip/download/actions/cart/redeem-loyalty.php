<?php
// actions/cart/redeem-loyalty.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('cart.php'));
verify_csrf();
$pts = (int)post('points', 0);
$uid = (int)$_SESSION['user_id'];
$bal = loyalty_points_balance($uid);
if ($pts <= 0 || $pts > $bal) { flash_error('Invalid points.'); redirect(url('cart.php')); }
$_SESSION['cart_loyalty_points'] = $pts;
flash_success("$pts points will be redeemed at checkout.");
redirect(url('cart.php'));