<?php
require_once __DIR__ . '/common/bootstrap.php';
if (!feature_enabled('customer_wallet')) { redirect(url('account.php')); }
require_customer();
$pageTitle = 'My Wallet';
$uid = (int)$_SESSION['user_id'];
$balance = wallet_balance($uid);
$history = wallet_history($uid);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-6">My Wallet</h1>

  <div class="bg-gradient-to-br from-brand to-red-900 rounded-2xl p-8 text-center mb-8">
    <div class="text-white/80 text-sm">Available Balance</div>
    <div class="text-5xl font-extrabold my-3"><?= money($balance) ?></div>
    <div class="text-xs text-white/70">Wallet balance checkout pe use kar sakte ho</div>
  </div>

  <h3 class="font-bold mb-3">Transaction History</h3>
  <div class="bg-white/5 border border-white/10 rounded-xl divide-y divide-white/5">
    <?php foreach ($history as $t): ?>
      <div class="px-4 py-3 flex justify-between text-sm">
        <div>
          <div><?= e($t['reason']) ?></div>
          <div class="text-xs text-white/50"><?= date('d M Y, H:i', strtotime($t['created_at'])) ?></div>
        </div>
        <div class="<?= (float)$t['amount'] >= 0 ? 'text-green-400' : 'text-red-400' ?> font-bold">
          <?= (float)$t['amount'] >= 0 ? '+' : '' ?><?= money(abs($t['amount'])) ?>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (!$history): ?><div class="px-4 py-8 text-center text-white/50">No transactions yet.</div><?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>