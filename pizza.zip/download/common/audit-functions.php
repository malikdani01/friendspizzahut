<?php
function log_admin_action(string $action, ?string $entity = null, ?int $entityId = null, ?array $old = null, ?array $new = null): void {
    audit_log($action, $entity, $entityId, $old, $new);
}
function get_recent_logs(int $limit = 50): array {
    return Database::fetchAll("SELECT * FROM audit_logs ORDER BY id DESC LIMIT " . (int)$limit);
}