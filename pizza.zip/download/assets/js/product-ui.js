document.addEventListener('change', e => {
  if (!e.target.matches('input[name^="variation"]')) return;
  // Live-price preview hook (server validates final price)
  const form = e.target.closest('form');
  if (form) form.dataset.dirty = '1';
});