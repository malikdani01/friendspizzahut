<?php
/** Product helper functions */

function get_product(int $id): ?array {
    return Database::fetch("SELECT * FROM products WHERE id = ?", [$id]);
}

function get_product_by_slug(string $slug): ?array {
    return Database::fetch("SELECT p.*, c.name AS category_name, c.slug AS category_slug
        FROM products p LEFT JOIN categories c ON c.id = p.category_id
        WHERE p.slug = ? AND p.status='active'", [$slug]);
}

function get_products(array $f = []): array {
    $sql = "SELECT p.*, c.name AS category_name, c.slug AS category_slug
            FROM products p LEFT JOIN categories c ON c.id = p.category_id
            WHERE 1=1";
    $params = [];
    if (!empty($f['category_id'])) { $sql .= " AND p.category_id = ?"; $params[] = (int)$f['category_id']; }
    if (!empty($f['search'])) {
        $sql .= " AND (p.name LIKE ? OR p.short_description LIKE ?)";
        $params[] = '%' . $f['search'] . '%'; $params[] = '%' . $f['search'] . '%';
    }
    if (isset($f['status']) && $f['status'] !== '') { $sql .= " AND p.status = ?"; $params[] = $f['status']; }
    if (!empty($f['featured']))      $sql .= " AND p.is_featured=1";
    if (!empty($f['bestseller']))    $sql .= " AND p.is_bestseller=1";
    if (!empty($f['new']))           $sql .= " AND p.is_new=1";
    if (!empty($f['available']))     $sql .= " AND p.is_available=1 AND p.status='active'";

    $sort = $f['sort'] ?? 'sort_order';
    $dir  = strtoupper($f['dir'] ?? 'ASC');
    $dir  = in_array($dir, ['ASC','DESC']) ? $dir : 'ASC';
    $allowed = ['sort_order','name','price','created_at','rating_avg'];
    if (!in_array($sort, $allowed)) $sort = 'sort_order';
    $sql .= " ORDER BY p.$sort $dir";

    if (!empty($f['limit'])) {
        $sql .= " LIMIT " . (int)$f['limit'];
        if (!empty($f['offset'])) $sql .= " OFFSET " . (int)$f['offset'];
    }
    return Database::fetchAll($sql, $params);
}

function count_products(array $f = []): int {
    $sql = "SELECT COUNT(*) c FROM products WHERE 1=1";
    $params = [];
    if (!empty($f['category_id'])) { $sql .= " AND category_id = ?"; $params[] = (int)$f['category_id']; }
    if (!empty($f['search'])) {
        $sql .= " AND name LIKE ?";
        $params[] = '%' . $f['search'] . '%';
    }
    if (isset($f['status']) && $f['status'] !== '') { $sql .= " AND status = ?"; $params[] = $f['status']; }
    $row = Database::fetch($sql, $params);
    return (int)($row['c'] ?? 0);
}

function get_featured_products(int $limit = 8): array {
    return get_products(['featured' => 1, 'available' => 1, 'limit' => $limit]);
}

function get_related_products(int $productId, int $categoryId, int $limit = 4): array {
    return Database::fetchAll(
        "SELECT p.*, c.name AS category_name FROM products p
         LEFT JOIN categories c ON c.id = p.category_id
         WHERE p.category_id = ? AND p.id != ? AND p.status='active' AND p.is_available=1
         ORDER BY RAND() LIMIT " . (int)$limit,
        [$categoryId, $productId]
    );
}

function get_product_images(int $productId): array {
    return Database::fetchAll("SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order", [$productId]);
}

function get_product_variation_groups(int $productId): array {
    $groups = Database::fetchAll(
        "SELECT g.*, pvg.is_required_override
         FROM product_variation_groups pvg
         JOIN variation_groups g ON g.id = pvg.group_id
         WHERE pvg.product_id = ? AND g.is_active = 1
         ORDER BY pvg.sort_order, g.sort_order",
        [$productId]
    );
    foreach ($groups as &$g) {
        $g['options'] = Database::fetchAll(
            "SELECT * FROM variation_options WHERE group_id = ? AND is_active = 1 ORDER BY sort_order",
            [$g['id']]
        );
    }
    return $groups;
}

function get_product_addons(int $productId): array {
    return Database::fetchAll(
        "SELECT a.*, pa.is_required FROM product_addons pa
         JOIN addons a ON a.id = pa.addon_id
         WHERE pa.product_id = ? AND a.is_active = 1
         ORDER BY pa.sort_order, a.sort_order",
        [$productId]
    );
}

function product_is_available(int $productId): bool {
    $p = Database::fetch("SELECT is_available, status FROM products WHERE id = ?", [$productId]);
    return $p && (int)$p['is_available'] === 1 && $p['status'] === 'active';
}

function generate_product_slug(string $name, int $excludeId = 0): string {
    $base = slugify($name);
    $slug = $base;
    $i = 2;
    while (Database::fetch("SELECT id FROM products WHERE slug = ? AND id != ?", [$slug, $excludeId])) {
        $slug = $base . '-' . $i++;
    }
    return $slug;
}