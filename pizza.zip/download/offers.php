<?php
require_once __DIR__ . '/common/bootstrap.php';
if (!feature_enabled('offers')) { redirect(url('menu.php')); }
$pageTitle = 'Offers';
$now = date('Y-m-d H:i:s');
$offers = Database::fetchAll("SELECT * FROM offers WHERE is_active=1 AND (start_date IS NULL OR start_date<=?) AND (end_date IS NULL OR end_date>=?) ORDER BY sort_order", [$now, $now]);
$coupons = feature_enabled('coupons') ? Database::fetchAll("SELECT * FROM coupons WHERE is_active=1 AND (end_date IS NULL OR end_date>=?) ORDER BY id DESC", [$now]) : [];
require __DIR__ . '/common/header.php';
?>
<div class="max-w-7xl mx-auto px-4 py-10">
  <h1 class="text-3xl md:text-4xl font-extrabold mb-2">Current <span class="text-brand">Offers</span></h1>
  <p class="text-white/60 mb-8">Grab these deals before they expire</p>

  <?php if ($offers): ?>
  <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
    <?php foreach ($offers as $o): ?>
      <div class="bg-gradient-to-br from-brand/20 to-black border border-brand/30 rounded-2xl p-5">
        <div class="text-xs uppercase text-brand font-bold mb-2"><?= e(str_replace('_',' ', $o['offer_type'])) ?></div>
        <h3 class="font-extrabold text-lg mb-1"><?= e($o['title']) ?></h3>
        <p class="text-sm text-white/70 mb-3"><?= e($o['description']) ?></p>
        <div class="text-2xl font-extrabold text-brand mb-2">
          <?php if ($o['offer_type'] === 'percentage'): ?><?= (int)$o['discount_value'] ?>% OFF
          <?php elseif ($o['offer_type'] === 'fixed'): ?><?= money($o['discount_value']) ?> OFF
          <?php elseif ($o['offer_type'] === 'free_delivery'): ?>FREE DELIVERY
          <?php else: ?><?= e(strtoupper($o['offer_type'])) ?>
          <?php endif; ?>
        </div>
        <?php if ((float)$o['min_order'] > 0): ?><div class="text-xs text-white/50">Min order: <?= money($o['min_order']) ?></div><?php endif; ?>
        <a href="<?= url('menu.php') ?>" class="mt-4 inline-block bg-brand hover:bg-red-700 px-5 py-2 rounded-lg font-bold text-sm">Order Now →</a>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if ($coupons): ?>
  <h2 class="text-2xl font-extrabold mb-4">Coupon Codes</h2>
  <div class="grid md:grid-cols-3 gap-4">
    <?php foreach ($coupons as $c): ?>
      <div class="bg-white/5 border border-dashed border-brand/50 rounded-2xl p-5 relative">
        <div class="text-2xl font-mono font-extrabold text-brand text-center py-3 mb-2 border-b border-white/10"><?= e($c['code']) ?></div>
        <div class="text-sm text-white/70 text-center">
          <?php if ($c['discount_type']==='percentage'): ?>Save <?= (int)$c['discount_value'] ?>%
          <?php elseif ($c['discount_type']==='fixed'): ?>Save <?= money($c['discount_value']) ?>
          <?php else: ?>Free Delivery<?php endif; ?>
        </div>
        <?php if ((float)$c['min_order'] > 0): ?><div class="text-xs text-white/40 text-center mt-1">Min: <?= money($c['min_order']) ?></div><?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if (!$offers && !$coupons): ?>
    <div class="text-center py-20 text-white/60">
      <i class="fa-solid fa-bolt text-5xl mb-4 opacity-40"></i>
      <p>No active offers right now. Check back soon!</p>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>