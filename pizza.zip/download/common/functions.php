<?php
/**
 * Global helper functions
 */

function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): void
{
    if (!headers_sent()) {
        header('Location: ' . $url);
    } else {
        echo '<script>location.href=' . json_encode($url) . ';</script>';
    }
    exit;
}

function url(string $path = ''): string
{
    return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    return url('assets/' . ltrim($path, '/'));
}

function upload_url(string $path): string
{
    return url('uploads/' . ltrim($path, '/'));
}

function money($amount): string
{
    return setting('currency_symbol', 'Rs.') . number_format((float)$amount, 0);
}

function money_precise($amount): string
{
    return setting('currency_symbol', 'Rs.') . number_format((float)$amount, 2);
}

function now(): string { return date('Y-m-d H:i:s'); }

function slugify(string $text): string
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

function generate_order_number(): string
{
    return 'FPH-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
}

function random_code(int $len = 8): string
{
    return strtoupper(substr(bin2hex(random_bytes($len)), 0, $len));
}

function client_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function current_url(): string
{
    return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
        . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
        . ($_SERVER['REQUEST_URI'] ?? '/');
}

function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }

function post(string $key, $default = null) { return $_POST[$key] ?? $default; }
function get(string $key, $default = null)  { return $_GET[$key] ?? $default; }

function old(string $key, $default = '')
{
    return e($_SESSION['_old'][$key] ?? $default);
}

function remember_old(array $data): void
{
    unset($data['password'], $data['password_confirm'], $data['csrf_token']);
    $_SESSION['_old'] = $data;
}

function clear_old(): void
{
    unset($_SESSION['_old']);
}

function restaurant_is_open(): bool
{
    $status = setting('restaurant_status', 'open');
    if ($status !== 'open') return false;

    $tz = setting('timezone', 'Asia/Karachi');
    try { $now = new DateTime('now', new DateTimeZone($tz)); }
    catch (Throwable $e) { $now = new DateTime(); }

    $open  = setting('opening_time', '11:00');
    $close = setting('closing_time', '02:00');
    $cur   = $now->format('H:i');

    if ($close <= $open) {
        // crosses midnight
        return $cur >= $open || $cur <= $close;
    }
    return $cur >= $open && $cur <= $close;
}

function status_badge(string $status): string
{
    $colors = [
        'pending'          => 'bg-yellow-100 text-yellow-800',
        'confirmed'        => 'bg-blue-100 text-blue-800',
        'preparing'        => 'bg-indigo-100 text-indigo-800',
        'ready'            => 'bg-purple-100 text-purple-800',
        'out_for_delivery' => 'bg-orange-100 text-orange-800',
        'delivered'        => 'bg-green-100 text-green-800',
        'completed'        => 'bg-green-100 text-green-800',
        'cancelled'        => 'bg-red-100 text-red-800',
        'refunded'         => 'bg-gray-100 text-gray-800',
    ];
    $label = ucwords(str_replace('_', ' ', $status));
    $cls   = $colors[$status] ?? 'bg-gray-100 text-gray-800';
    return '<span class="inline-block px-2 py-1 text-xs font-semibold rounded ' . $cls . '">' . e($label) . '</span>';
}