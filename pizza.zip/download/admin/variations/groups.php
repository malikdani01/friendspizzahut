<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Variation Groups';

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'create') {
        Database::insert('variation_groups', [
            'name' => slugify((string)post('name','')),
            'display_name' => (string)post('display_name',''),
            'type' => (string)post('type','single'),
            'is_required' => post('is_required') ? 1 : 0,
            'min_selections' => (int)post('min_selections',1),
            'max_selections' => (int)post('max_selections',1),
            'sort_order' => (int)post('sort_order',0),
        ]);
        flash_success('Group created.');
    } elseif ($action === 'delete') {
        $id = (int)post('id');
        Database::execute("DELETE FROM variation_options WHERE group_id=?", [$id]);
        Database::execute("DELETE FROM product_variation_groups WHERE group_id=?", [$id]);
        Database::execute("DELETE FROM variation_groups WHERE id=?", [$id]);
        flash_success('Deleted.');
    }
    redirect(url('admin/variations/groups.php'));
}

$groups = Database::fetchAll("SELECT * FROM variation_groups ORDER BY sort_order");
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl shadow-sm border p-5 h-fit">
    <h3 class="font-bold mb-3">Add Group</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?><input type="hidden" name="action" value="create">
      <input name="name" placeholder="Internal name (pizza_size)" required class="w-full border rounded px-3 py-2">
      <input name="display_name" placeholder="Display name (Size)" required class="w-full border rounded px-3 py-2">
      <select name="type" class="w-full border rounded px-3 py-2"><option value="single">Single</option><option value="multiple">Multiple</option></select>
      <input type="number" name="sort_order" value="0" class="w-full border rounded px-3 py-2">
      <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_required" value="1" checked> Required</label>
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Create</button>
    </form>
  </div>
  <div class="md:col-span-2 space-y-3">
    <?php foreach ($groups as $g): ?>
    <div class="bg-white rounded-xl shadow-sm border p-5">
      <div class="flex justify-between items-center">
        <div><div class="font-bold"><?= e($g['display_name']) ?></div><div class="text-xs text-gray-500"><?= e($g['name']) ?> • <?= e($g['type']) ?></div></div>
        <div class="flex gap-2">
          <a href="<?= url('admin/variations/options.php?group_id='.(int)$g['id']) ?>" class="text-xs text-blue-600">Manage Options</a>
          <form method="post" class="inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$g['id'] ?>"><button class="text-xs text-red-600">Delete</button></form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>