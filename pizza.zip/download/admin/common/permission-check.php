<?php
// Use in individual admin pages:
// require_once __DIR__ . '/../common/permission-check.php';
// require_permission('products.edit');
require_once __DIR__ . '/../../common/permissions.php';