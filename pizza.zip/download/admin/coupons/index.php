<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Coupons';

if (is_post()) {
    verify_csrf();
    if (post('action') === 'delete') {
        Database::execute("DELETE FROM coupon_usage WHERE coupon_id = ?", [(int)post('id')]);
        Database::execute("DELETE FROM coupons WHERE id = ?", [(int)post('id')]);
        flash_success('Coupon deleted.');
    } elseif (post('action') === 'toggle') {
        Database::execute("UPDATE coupons SET is_active = 1 - is_active WHERE id = ?", [(int)post('id')]);
        flash_success('Updated.');
    }
    redirect(url('admin/coupons/index.php'));
}

$rows = Database::fetchAll("SELECT c.*, (SELECT COUNT(*) FROM coupon_usage WHERE coupon_id=c.id) used FROM coupons c ORDER BY c.id DESC");
require __DIR__ . '/../common/header.php';
?>
<div class="flex justify-between items-center mb-5">
  <p class="text-sm text-gray-600"><?= count($rows) ?> coupons</p>
  <a href="<?= url('admin/coupons/create.php') ?>" class="bg-brand text-white px-4 py-2 rounded-lg text-sm font-semibold"><i class="fa-solid fa-plus mr-1"></i> Add Coupon</a>
</div>
<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr><th class="text-left px-4 py-3">Code</th><th class="text-left px-4 py-3">Type</th><th class="text-left px-4 py-3">Value</th><th class="text-left px-4 py-3">Min</th><th class="text-left px-4 py-3">Used</th><th class="text-left px-4 py-3">Status</th><th></th></tr>
    </thead>
    <tbody>
      <?php if (!$rows): ?><tr><td colspan="7" class="py-8 text-center text-gray-400">No coupons yet.</td></tr>
      <?php else: foreach ($rows as $c): ?>
        <tr class="border-t hover:bg-gray-50">
          <td class="px-4 py-3 font-mono font-bold"><?= e($c['code']) ?></td>
          <td class="px-4 py-3 capitalize"><?= e($c['discount_type']) ?></td>
          <td class="px-4 py-3"><?= $c['discount_type']=='percentage' ? $c['discount_value'].'%' : money($c['discount_value']) ?></td>
          <td class="px-4 py-3"><?= money($c['min_order']) ?></td>
          <td class="px-4 py-3"><?= (int)$c['used'] ?><?= $c['usage_limit']?'/'.(int)$c['usage_limit']:'' ?></td>
          <td class="px-4 py-3">
            <form method="post" class="inline"><?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="text-xs px-2 py-1 rounded <?= $c['is_active']?'bg-green-100 text-green-800':'bg-gray-200' ?>"><?= $c['is_active']?'Active':'Inactive' ?></button>
            </form>
          </td>
          <td class="px-4 py-3 text-right">
            <a href="<?= url('admin/coupons/edit.php?id='.(int)$c['id']) ?>" class="text-blue-600 text-xs mr-2">Edit</a>
            <form method="post" class="inline" data-confirm="Delete coupon?"><?= csrf_field() ?>
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="text-red-600 text-xs">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>