<?php
function report_sales(string $from, string $to): array {
    return Database::fetch(
        "SELECT COUNT(*) orders, COALESCE(SUM(total),0) revenue, COALESCE(AVG(total),0) avg
         FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND order_status NOT IN ('cancelled','refunded')",
        [$from, $to]) ?: ['orders'=>0,'revenue'=>0,'avg'=>0];
}
function report_top_products(string $from, string $to, int $limit = 10): array {
    return Database::fetchAll(
        "SELECT oi.product_name, SUM(oi.quantity) qty, SUM(oi.line_total) revenue
         FROM order_items oi JOIN orders o ON o.id=oi.order_id
         WHERE DATE(o.created_at) BETWEEN ? AND ? AND o.order_status NOT IN ('cancelled','refunded')
         GROUP BY oi.product_name ORDER BY qty DESC LIMIT " . (int)$limit,
        [$from, $to]);
}
function report_top_customers(string $from, string $to, int $limit = 10): array {
    return Database::fetchAll(
        "SELECT customer_name, customer_phone, COUNT(*) orders, SUM(total) spent
         FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND order_status NOT IN ('cancelled','refunded')
         GROUP BY customer_phone ORDER BY spent DESC LIMIT " . (int)$limit,
        [$from, $to]);
}