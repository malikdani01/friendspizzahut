<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('combo_deals')) redirect(url('admin/dashboard.php'));

$pageTitle = 'Add Deal';
$errors = [];
$products = Database::fetchAll("SELECT id, name, price FROM products WHERE status='active' ORDER BY name");

if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name', ''));
    $price = (float)post('price', 0);
    if (!$name)     $errors[] = 'Deal name required.';
    if ($price <= 0) $errors[] = 'Deal price required.';

    // Handle image upload
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $r = save_uploaded_image($_FILES['image'], 'combos');
        if (!$r['ok']) {
            $errors[] = 'Image: ' . $r['error'];
        } else {
            $image = $r['path'];
        }
    }

    if (!$errors) {
        $id = Database::insert('combos', [
            'name' => $name,
            'slug' => slugify($name) . '-' . time(),
            'description' => trim((string)post('description','')) ?: null,
            'image' => $image,
            'fixed_price' => $price,
            'compare_price' => post('compare_price') !== '' ? (float)post('compare_price') : null,
            'is_active' => post('is_active') ? 1 : 0,
            'sort_order' => (int)post('sort_order',0),
        ]);

        $pids = (array)post('product_ids', []);
        $qtys = (array)post('quantities', []);
        foreach ($pids as $i => $pid) {
            if (!$pid) continue;
            Database::insert('combo_items', [
                'combo_id' => $id,
                'product_id' => (int)$pid,
                'quantity' => max(1,(int)($qtys[$i]??1)),
                'sort_order' => $i
            ]);
        }
        flash_success('Deal created.');
        redirect(url('admin/combos/index.php'));
    }
}

require __DIR__ . '/../common/header.php';
?>

<style>
.deal-form-wrap { max-width: 720px; }
.deal-card {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
  padding: 24px;
  margin-bottom: 20px;
}
.deal-card h3 {
  font-size: 14px;
  font-weight: 800;
  color: #dc2626;
  margin: 0 0 18px;
  text-transform: uppercase;
  letter-spacing: 0.6px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(255,255,255,0.06);
}
.deal-label {
  display: block;
  font-size: 12.5px;
  font-weight: 700;
  color: rgba(255,255,255,0.7);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 8px;
}
.deal-input,
.deal-textarea,
.deal-select {
  width: 100%;
  padding: 12px 14px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 11px;
  color: #fff;
  font-size: 15px;
  font-family: inherit;
  outline: none;
  margin-bottom: 16px;
  transition: border-color .15s, box-shadow .15s;
  -webkit-appearance: none;
  appearance: none;
}
.deal-input:focus,
.deal-textarea:focus,
.deal-select:focus {
  border-color: #dc2626;
  box-shadow: 0 0 0 3px rgba(220,38,38,0.15);
}
.deal-input::placeholder,
.deal-textarea::placeholder {
  color: rgba(255,255,255,0.35);
}
.deal-textarea {
  resize: vertical;
  min-height: 80px;
  line-height: 1.5;
}
.deal-select option {
  background: #171717;
  color: #fff;
}
.deal-grid-2 {
  display: grid;
  grid-template-columns: 1fr;
  gap: 0 16px;
}
@media (min-width: 640px) {
  .deal-grid-2 { grid-template-columns: 1fr 1fr; }
}

.deal-image-preview {
  width: 100%;
  max-width: 320px;
  aspect-ratio: 16/10;
  background: #0a0a0a;
  border: 2px dashed rgba(255,255,255,0.15);
  border-radius: 14px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 12px;
}
.deal-image-preview img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.deal-image-preview .placeholder-icon {
  font-size: 42px;
  color: rgba(255,255,255,0.15);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}
.deal-image-preview .placeholder-icon span {
  font-size: 12px;
  color: rgba(255,255,255,0.3);
  font-weight: 600;
}

.deal-image-upload-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 11px 20px;
  background: rgba(220,38,38,0.15);
  border: 1.5px solid rgba(220,38,38,0.35);
  color: #fca5a5;
  border-radius: 10px;
  font-size: 13.5px;
  font-weight: 700;
  cursor: pointer;
  transition: all .2s;
  font-family: inherit;
}
.deal-image-upload-btn:hover {
  background: rgba(220,38,38,0.25);
  border-color: #dc2626;
  color: #fff;
}
.deal-image-hint {
  font-size: 11.5px;
  color: rgba(255,255,255,0.4);
  margin-top: 8px;
  line-height: 1.5;
}

.deal-item-row {
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
  align-items: stretch;
}
.deal-item-row .deal-select {
  flex: 1;
  margin-bottom: 0;
}
.deal-item-row input[type="number"] {
  width: 80px;
  margin-bottom: 0;
  text-align: center;
  font-weight: 700;
}
.deal-item-remove {
  width: 44px;
  background: rgba(220,38,38,0.15);
  border: 1.5px solid rgba(220,38,38,0.35);
  color: #fca5a5;
  border-radius: 11px;
  cursor: pointer;
  font-size: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: all .15s;
}
.deal-item-remove:hover {
  background: #dc2626;
  color: #fff;
}
.deal-add-item-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 18px;
  background: rgba(34,197,94,0.15);
  border: 1.5px solid rgba(34,197,94,0.35);
  color: #4ade80;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 700;
  cursor: pointer;
  transition: all .2s;
  font-family: inherit;
}
.deal-add-item-btn:hover {
  background: rgba(34,197,94,0.25);
  border-color: #22c55e;
}

.deal-toggle-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px;
  background: rgba(0,0,0,0.3);
  border: 1.5px solid rgba(255,255,255,0.08);
  border-radius: 11px;
  cursor: pointer;
  transition: all .15s;
  margin-bottom: 16px;
}
.deal-toggle-row:hover { border-color: rgba(220,38,38,0.4); }
.deal-toggle-row input {
  width: 18px !important;
  height: 18px !important;
  accent-color: #dc2626;
  cursor: pointer;
}
.deal-toggle-row span { font-size: 14px; font-weight: 600; color: #fff; }

.deal-actions {
  display: flex;
  gap: 12px;
  align-items: center;
  padding-top: 8px;
}
.deal-btn-save {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 14px 32px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  border: 0;
  border-radius: 12px;
  font-size: 14.5px;
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 8px 24px rgba(220,38,38,0.4);
  transition: all .2s;
  font-family: inherit;
}
.deal-btn-save:hover {
  transform: translateY(-1px);
  box-shadow: 0 12px 32px rgba(220,38,38,0.55);
}
.deal-btn-cancel {
  padding: 14px 28px;
  background: rgba(255,255,255,0.05);
  border: 1.5px solid rgba(255,255,255,0.1);
  color: rgba(255,255,255,0.8);
  border-radius: 12px;
  font-size: 14px;
  font-weight: 700;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.deal-btn-cancel:hover { background: rgba(255,255,255,0.1); color: #fff; text-decoration: none; }

.deal-error {
  background: rgba(220,38,38,0.12);
  border: 1.5px solid rgba(220,38,38,0.4);
  color: #fca5a5;
  padding: 14px 16px;
  border-radius: 12px;
  font-size: 13.5px;
  margin-bottom: 20px;
  line-height: 1.6;
}
.deal-error div { padding: 2px 0; }

.deal-back {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: rgba(255,255,255,0.5);
  font-size: 13px;
  text-decoration: none;
  margin-bottom: 16px;
}
.deal-back:hover { color: #dc2626; text-decoration: none; }
</style>

<div class="deal-form-wrap">
  <a href="<?= url('admin/combos/index.php') ?>" class="deal-back">
    <i class="fa-solid fa-arrow-left"></i> Back to Deals
  </a>

  <?php if ($errors): ?>
    <div class="deal-error">
      <?php foreach ($errors as $e_): ?><div>• <?= e($e_) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">

    <!-- Image -->
    <div class="deal-card">
      <h3><i class="fa-solid fa-image"></i> Deal Image</h3>

      <div class="deal-image-preview" id="imagePreview">
        <div class="placeholder-icon">
          <i class="fa-solid fa-image"></i>
          <span>No image yet</span>
        </div>
      </div>

      <label class="deal-image-upload-btn">
        <i class="fa-solid fa-upload"></i>
        <span>Choose Image</span>
        <input type="file" name="image" accept="image/jpeg,image/png,image/webp"
               style="display:none;" onchange="previewImage(event);">
      </label>

      <div class="deal-image-hint">
        <i class="fa-solid fa-circle-info"></i>
        Recommended: <strong>800×500 px</strong> · Formats: JPG, PNG, WEBP · Max size: 5 MB
      </div>
    </div>

    <!-- Basic info -->
    <div class="deal-card">
      <h3><i class="fa-solid fa-tag"></i> Deal Information</h3>

      <label class="deal-label">Deal Name *</label>
      <input type="text" name="name" required value="<?= e(post('name','')) ?>"
             placeholder="e.g. Deal 01 — Family Feast" class="deal-input">

      <label class="deal-label">Short Description</label>
      <textarea name="description" rows="2" class="deal-textarea"
                placeholder="What's included in this deal?"><?= e(post('description','')) ?></textarea>

      <div class="deal-grid-2">
        <div>
          <label class="deal-label">Deal Price (Rs.) *</label>
          <input type="number" step="0.01" name="price" required
                 value="<?= e(post('price','')) ?>" placeholder="1400" class="deal-input">
        </div>
        <div>
          <label class="deal-label">Compare Price (Rs.)</label>
          <input type="number" step="0.01" name="compare_price"
                 value="<?= e(post('compare_price','')) ?>"
                 placeholder="Original price (optional)" class="deal-input">
        </div>
      </div>

      <label class="deal-label">Sort Order</label>
      <input type="number" name="sort_order" value="<?= e(post('sort_order','0')) ?>" class="deal-input">
    </div>

    <!-- Items -->
    <div class="deal-card">
      <h3><i class="fa-solid fa-basket-shopping"></i> Items in this Deal</h3>

      <div id="items">
        <div class="deal-item-row">
          <select name="product_ids[]" class="deal-select">
            <option value="">— Select product —</option>
            <?php foreach ($products as $p): ?>
              <option value="<?= (int)$p['id'] ?>"><?= e($p['name']) ?> (Rs. <?= number_format((float)$p['price'],0) ?>)</option>
            <?php endforeach; ?>
          </select>
          <input type="number" name="quantities[]" value="1" min="1" class="deal-input">
          <button type="button" class="deal-item-remove" onclick="removeItem(this)">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
      </div>

      <button type="button" class="deal-add-item-btn" onclick="addItem()">
        <i class="fa-solid fa-plus"></i> Add Item
      </button>
    </div>

    <!-- Status -->
    <div class="deal-card">
      <h3><i class="fa-solid fa-power-off"></i> Status</h3>

      <label class="deal-toggle-row">
        <input type="checkbox" name="is_active" value="1" checked>
        <span>Deal is Active (visible to customers)</span>
      </label>

      <div class="deal-actions">
        <button type="submit" class="deal-btn-save">
          <i class="fa-solid fa-save"></i> Create Deal
        </button>
        <a href="<?= url('admin/combos/index.php') ?>" class="deal-btn-cancel">
          <i class="fa-solid fa-xmark"></i> Cancel
        </a>
      </div>
    </div>

  </form>
</div>

<script>
function previewImage(e) {
  var file = e.target.files[0];
  if (!file) return;
  var preview = document.getElementById('imagePreview');
  var reader = new FileReader();
  reader.onload = function(ev) {
    preview.innerHTML = '<img src="' + ev.target.result + '" alt="Preview">';
  };
  reader.readAsDataURL(file);
}

function addItem() {
  var wrap = document.getElementById('items');
  var firstRow = wrap.querySelector('.deal-item-row');
  var newRow = firstRow.cloneNode(true);
  newRow.querySelector('select').value = '';
  newRow.querySelector('input[type="number"]').value = 1;
  wrap.appendChild(newRow);
}

function removeItem(btn) {
  var rows = document.querySelectorAll('#items .deal-item-row');
  if (rows.length <= 1) {
    btn.closest('.deal-item-row').querySelector('select').value = '';
    btn.closest('.deal-item-row').querySelector('input').value = 1;
    return;
  }
  btn.closest('.deal-item-row').remove();
}
</script>

<?php require __DIR__ . '/../common/footer.php'; ?>