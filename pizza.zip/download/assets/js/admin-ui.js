// Data-confirm on forms
document.addEventListener('submit', e => {
  const f = e.target.closest('form[data-confirm]');
  if (f && !confirm(f.dataset.confirm)) e.preventDefault();
}, true);