<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/categories/index.php'));
verify_csrf();
$order = (array)post('order', []); // [id => sort_order]
foreach ($order as $id => $sort) {
    Database::execute("UPDATE categories SET sort_order=? WHERE id=?", [(int)$sort, (int)$id]);
}
flash_success('Order saved.');
redirect(url('admin/categories/index.php'));