<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Add-ons';
$errors = [];

// Check if size columns exist
$hasSizeCols = false;
try {
    $check = Database::fetch("SHOW COLUMNS FROM addons LIKE 'has_sizes'");
    $hasSizeCols = !empty($check);
} catch (Throwable $e) { $hasSizeCols = false; }

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'create') {
        $name = trim((string)post('name', ''));
        $hasSizes = post('has_sizes') ? 1 : 0;

        if ($name === '') {
            $errors[] = 'Name required.';
        } else {
            // Base data (always safe)
            $data = [
                'name' => $name,
                'category' => (string)post('category', 'topping'),
                'is_active' => post('is_active') ? 1 : 0,
                'sort_order' => (int)post('sort_order', 0),
                'price' => $hasSizes ? (float)post('price_s', 0) : (float)post('price', 0),
            ];

            // Add size data only if columns exist
            if ($hasSizeCols && $hasSizes) {
                $data['has_sizes'] = 1;
                $data['price_s'] = (float)post('price_s', 0);
                $data['price_m'] = (float)post('price_m', 0);
                $data['price_l'] = (float)post('price_l', 0);
                $data['size_labels'] = 'S,M,L';
            } elseif ($hasSizeCols) {
                $data['has_sizes'] = 0;
            }

            try {
                Database::insert('addons', $data);
                flash_success('Add-on created.');
                redirect(url('admin/addons/index.php'));
            } catch (Throwable $ex) {
                error_log('addon create error: ' . $ex->getMessage());
                $errors[] = 'Error: ' . $ex->getMessage();
            }
        }
    } elseif ($action === 'update') {
        $id = (int)post('id', 0);
        $name = trim((string)post('name', ''));
        $hasSizes = post('has_sizes') ? 1 : 0;

        if ($name === '') {
            $errors[] = 'Name required.';
        } else {
            $data = [
                'name' => $name,
                'category' => (string)post('category', 'topping'),
                'is_active' => post('is_active') ? 1 : 0,
                'sort_order' => (int)post('sort_order', 0),
                'price' => $hasSizes ? (float)post('price_s', 0) : (float)post('price', 0),
            ];

            if ($hasSizeCols && $hasSizes) {
                $data['has_sizes'] = 1;
                $data['price_s'] = (float)post('price_s', 0);
                $data['price_m'] = (float)post('price_m', 0);
                $data['price_l'] = (float)post('price_l', 0);
                $data['size_labels'] = 'S,M,L';
            } elseif ($hasSizeCols) {
                $data['has_sizes'] = 0;
                $data['price_s'] = null;
                $data['price_m'] = null;
                $data['price_l'] = null;
            }

            try {
                Database::update('addons', $data, 'id = :id', ['id' => $id]);
                flash_success('Add-on updated.');
                redirect(url('admin/addons/index.php'));
            } catch (Throwable $ex) {
                error_log('addon update error: ' . $ex->getMessage());
                $errors[] = 'Error: ' . $ex->getMessage();
            }
        }
    } elseif ($action === 'delete') {
        try {
            Database::execute("DELETE FROM addons WHERE id = ?", [(int)post('id')]);
            flash_success('Add-on deleted.');
        } catch (Throwable $ex) {
            flash_error('Delete failed.');
        }
        redirect(url('admin/addons/index.php'));
    } elseif ($action === 'toggle') {
        try {
            Database::execute("UPDATE addons SET is_active = 1 - is_active WHERE id = ?", [(int)post('id')]);
            flash_success('Updated.');
        } catch (Throwable $ex) {}
        redirect(url('admin/addons/index.php'));
    }
}

try {
    $addons = Database::fetchAll("SELECT * FROM addons ORDER BY category, sort_order, id");
} catch (Throwable $ex) {
    $addons = [];
}

$editId = (int)get('edit', 0);
$editItem = null;
if ($editId) {
    try {
        $editItem = Database::fetch("SELECT * FROM addons WHERE id = ?", [$editId]);
    } catch (Throwable $ex) {}
}

require __DIR__ . '/../common/header.php';
?>

<style>
.addons-grid { display: grid; grid-template-columns: 1fr; gap: 20px; }
@media (min-width: 1024px) { .addons-grid { grid-template-columns: 400px 1fr; } }

.ad-card { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 20px; }
.ad-card h3 { font-size: 14px; font-weight: 800; color: #dc2626; margin: 0 0 18px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.06); text-transform: uppercase; letter-spacing: 0.6px; display: flex; align-items: center; gap: 8px; }

.ad-label { display: block; font-size: 12.5px; font-weight: 700; color: rgba(255,255,255,0.7); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
.ad-input, .ad-select { width: 100%; padding: 12px 14px; background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 10px; color: #fff; font-size: 14.5px; font-family: inherit; outline: none; margin-bottom: 14px; transition: all .15s; -webkit-appearance: none; appearance: none; }
.ad-input:focus, .ad-select:focus { border-color: #dc2626; box-shadow: 0 0 0 3px rgba(220,38,38,0.15); }
.ad-input::placeholder { color: rgba(255,255,255,0.3); }
.ad-select option { background: #171717; color: #fff; }

.ad-toggle { display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: rgba(0,0,0,0.3); border: 1.5px solid rgba(255,255,255,0.08); border-radius: 10px; cursor: pointer; margin-bottom: 16px; transition: all .15s; }
.ad-toggle:hover { border-color: rgba(220,38,38,0.4); }
.ad-toggle input { width: 18px !important; height: 18px !important; accent-color: #dc2626; cursor: pointer; }
.ad-toggle span { font-size: 13.5px; font-weight: 600; color: #fff; }

.size-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 14px; }
.size-input-wrap { background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 10px; text-align: center; transition: all .15s; }
.size-input-wrap.s { border-color: rgba(59,130,246,0.4); background: rgba(59,130,246,0.05); }
.size-input-wrap.m { border-color: rgba(234,179,8,0.4); background: rgba(234,179,8,0.05); }
.size-input-wrap.l { border-color: rgba(220,38,38,0.4); background: rgba(220,38,38,0.05); }
.size-input-label { font-size: 11px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 4px; }
.size-input-wrap.s .size-input-label { color: #60a5fa; }
.size-input-wrap.m .size-input-label { color: #facc15; }
.size-input-wrap.l .size-input-label { color: #f87171; }
.size-input { width: 100%; background: transparent; border: 0; color: #fff; font-size: 15px; font-weight: 700; text-align: center; outline: none; padding: 4px 0; font-family: inherit; -webkit-appearance: none; }
.size-input::-webkit-outer-spin-button, .size-input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }

.btn-primary { width: 100%; padding: 13px; background: linear-gradient(135deg, #dc2626, #b91c1c); color: #fff; border: 0; border-radius: 10px; font-weight: 800; font-size: 14px; cursor: pointer; box-shadow: 0 6px 18px rgba(220,38,38,0.3); transition: all .2s; font-family: inherit; display: flex; align-items: center; justify-content: center; gap: 8px; }
.btn-primary:hover { transform: translateY(-1px); box-shadow: 0 10px 24px rgba(220,38,38,0.5); }
.btn-cancel { display: inline-flex; align-items: center; gap: 6px; padding: 13px 20px; background: rgba(255,255,255,0.05); border: 1.5px solid rgba(255,255,255,0.1); color: rgba(255,255,255,0.8); border-radius: 10px; font-size: 13.5px; font-weight: 700; text-decoration: none; margin-top: 8px; width: 100%; justify-content: center; box-sizing: border-box; }
.btn-cancel:hover { background: rgba(255,255,255,0.1); color: #fff; text-decoration: none; }

.addon-list { display: flex; flex-direction: column; gap: 12px; }
.addon-item { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 16px; display: flex; gap: 14px; align-items: flex-start; transition: all .2s; }
.addon-item:hover { border-color: rgba(220,38,38,0.3); }
.addon-item-info { flex: 1; min-width: 0; }
.addon-item-name { font-size: 15px; font-weight: 800; color: #fff; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.addon-item-badge { font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; padding: 2px 8px; border-radius: 999px; }
.addon-item-badge.active { background: rgba(34,197,94,0.18); color: #4ade80; }
.addon-item-badge.inactive { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.5); }

.addon-sizes { display: flex; gap: 8px; flex-wrap: wrap; }
.addon-size-chip { background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 6px 12px; display: inline-flex; align-items: center; gap: 8px; font-size: 12.5px; }
.addon-size-chip .lbl { font-weight: 800; letter-spacing: 0.5px; }
.addon-size-chip.s { border-color: rgba(59,130,246,0.4); }
.addon-size-chip.m { border-color: rgba(234,179,8,0.4); }
.addon-size-chip.l { border-color: rgba(220,38,38,0.4); }
.addon-size-chip.s .lbl { color: #60a5fa; }
.addon-size-chip.m .lbl { color: #facc15; }
.addon-size-chip.l .lbl { color: #f87171; }
.addon-size-chip .price { color: #fff; font-weight: 700; }

.addon-price-single { display: inline-flex; align-items: center; gap: 8px; background: rgba(220,38,38,0.12); border: 1.5px solid rgba(220,38,38,0.3); border-radius: 8px; padding: 6px 14px; }
.addon-price-single .price { color: #dc2626; font-size: 14px; font-weight: 800; }

.addon-item-actions { display: flex; flex-direction: column; gap: 6px; flex-shrink: 0; }
.addon-btn { padding: 6px 12px; border-radius: 7px; font-size: 11.5px; font-weight: 700; text-decoration: none; border: 0; cursor: pointer; text-align: center; white-space: nowrap; transition: all .15s; font-family: inherit; }
.addon-btn-edit { background: rgba(59,130,246,0.15); color: #93c5fd; }
.addon-btn-edit:hover { background: rgba(59,130,246,0.25); text-decoration: none; color: #bfdbfe; }
.addon-btn-toggle { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.6); }
.addon-btn-toggle:hover { background: rgba(255,255,255,0.15); color: #fff; }
.addon-btn-delete { background: rgba(220,38,38,0.15); color: #fca5a5; }
.addon-btn-delete:hover { background: rgba(220,38,38,0.3); color: #fff; }

.err-box { background: rgba(220,38,38,0.12); border: 1.5px solid rgba(220,38,38,0.4); color: #fca5a5; padding: 12px 16px; border-radius: 10px; font-size: 13.5px; margin-bottom: 16px; line-height: 1.6; }

.warn-box { background: rgba(234,179,8,0.12); border: 1.5px solid rgba(234,179,8,0.4); color: #fcd34d; padding: 12px 16px; border-radius: 10px; font-size: 12.5px; margin-bottom: 16px; line-height: 1.6; }
</style>

<div class="addons-grid">

  <div>
    <?php if (!$hasSizeCols): ?>
      <div class="warn-box">
        <strong><i class="fa-solid fa-triangle-exclamation"></i> Size feature OFF</strong><br>
        Size columns database mein nahi hain. Size-based add-ons use karne ke liye <strong>phpMyAdmin</strong> mein ye SQL chalao:
        <pre style="background:rgba(0,0,0,0.4);padding:10px;border-radius:6px;margin-top:8px;font-size:11px;overflow-x:auto;white-space:pre-wrap;">ALTER TABLE addons ADD COLUMN has_sizes TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE addons ADD COLUMN price_s DECIMAL(12,2) NULL;
ALTER TABLE addons ADD COLUMN price_m DECIMAL(12,2) NULL;
ALTER TABLE addons ADD COLUMN price_l DECIMAL(12,2) NULL;</pre>
      </div>
    <?php endif; ?>

    <div class="ad-card">
      <h3>
        <i class="fa-solid <?= $editItem ? 'fa-pen' : 'fa-plus-circle' ?>"></i>
        <?= $editItem ? 'Edit Add-on' : 'Add New Add-on' ?>
      </h3>

      <?php if ($errors): ?>
        <div class="err-box">
          <?php foreach ($errors as $e_): ?><div>• <?= e($e_) ?></div><?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= $editItem ? 'update' : 'create' ?>">
        <?php if ($editItem): ?>
          <input type="hidden" name="id" value="<?= (int)$editItem['id'] ?>">
        <?php endif; ?>

        <label class="ad-label">Name *</label>
        <input type="text" name="name" required
               value="<?= e($editItem['name'] ?? post('name','')) ?>"
               placeholder="e.g. Chicken, Cheese, Dip Sauce"
               class="ad-input">

        <label class="ad-label">Category</label>
        <select name="category" class="ad-select">
          <?php
          $currentCat = $editItem['category'] ?? post('category', 'topping');
          $cats = ['topping'=>'Topping','extra'=>'Extra','drink'=>'Drink','sauce'=>'Sauce','side'=>'Side','other'=>'Other'];
          foreach ($cats as $k => $v):
          ?>
            <option value="<?= $k ?>" <?= $currentCat === $k ? 'selected' : '' ?>><?= $v ?></option>
          <?php endforeach; ?>
        </select>

        <?php if ($hasSizeCols): ?>
        <?php $hasSizes = !empty($editItem['has_sizes']) || post('has_sizes') ? true : false; ?>
        <label class="ad-toggle">
          <input type="checkbox" name="has_sizes" value="1" id="hasSizesToggle"
                 <?= $hasSizes ? 'checked' : '' ?>
                 onchange="toggleSizeMode();">
          <span><i class="fa-solid fa-ruler" style="color:#f59e0b;margin-right:6px;"></i> This add-on has sizes (S / M / L)</span>
        </label>
        <?php else: ?>
        <input type="hidden" name="has_sizes" value="0">
        <?php endif; ?>

        <!-- SIZE MODE -->
        <?php if ($hasSizeCols): ?>
        <div id="sizeModeFields" style="<?= !empty($hasSizes) ? '' : 'display:none;' ?>">
          <label class="ad-label">Prices by Size (Rs.)</label>
          <div class="size-grid">
            <div class="size-input-wrap s">
              <div class="size-input-label">S</div>
              <input type="number" step="0.01" name="price_s" min="0"
                     value="<?= e($editItem['price_s'] ?? post('price_s','50')) ?>"
                     class="size-input" placeholder="50">
            </div>
            <div class="size-input-wrap m">
              <div class="size-input-label">M</div>
              <input type="number" step="0.01" name="price_m" min="0"
                     value="<?= e($editItem['price_m'] ?? post('price_m','100')) ?>"
                     class="size-input" placeholder="100">
            </div>
            <div class="size-input-wrap l">
              <div class="size-input-label">L</div>
              <input type="number" step="0.01" name="price_l" min="0"
                     value="<?= e($editItem['price_l'] ?? post('price_l','150')) ?>"
                     class="size-input" placeholder="150">
            </div>
          </div>
        </div>
        <?php endif; ?>

        <div id="singlePriceField" style="<?= ($hasSizeCols && !empty($hasSizes)) ? 'display:none;' : '' ?>">
          <label class="ad-label">Price (Rs.)</label>
          <input type="number" step="0.01" name="price" min="0"
                 value="<?= e($editItem['price'] ?? post('price','50')) ?>"
                 class="ad-input" placeholder="50">
        </div>

        <label class="ad-label">Sort Order</label>
        <input type="number" name="sort_order"
               value="<?= (int)($editItem['sort_order'] ?? post('sort_order', 0)) ?>"
               class="ad-input">

        <label class="ad-toggle">
          <input type="checkbox" name="is_active" value="1"
                 <?= (!$editItem || $editItem['is_active']) ? 'checked' : '' ?>>
          <span>Active (show to customers)</span>
        </label>

        <button type="submit" class="btn-primary">
          <i class="fa-solid fa-save"></i>
          <?= $editItem ? 'Save Changes' : 'Create Add-on' ?>
        </button>

        <?php if ($editItem): ?>
          <a href="<?= url('admin/addons/index.php') ?>" class="btn-cancel">
            <i class="fa-solid fa-xmark"></i> Cancel
          </a>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <div>
    <div class="ad-card">
      <h3><i class="fa-solid fa-list"></i> Current Add-ons (<?= count($addons) ?>)</h3>

      <?php if (!$addons): ?>
        <div style="text-align:center;padding:40px 20px;color:rgba(255,255,255,0.4);">
          <i class="fa-solid fa-plus-circle" style="font-size:40px;color:rgba(220,38,38,0.3);display:block;margin-bottom:12px;"></i>
          No add-ons yet.
        </div>
      <?php else: ?>
        <div class="addon-list">
          <?php foreach ($addons as $a): 
            $hasSz = $hasSizeCols && (int)($a['has_sizes'] ?? 0) === 1;
          ?>
            <div class="addon-item">
              <div class="addon-item-info">
                <div class="addon-item-name">
                  <?= e($a['name']) ?>
                  <span class="addon-item-badge <?= $a['is_active'] ? 'active' : 'inactive' ?>">
                    <?= $a['is_active'] ? 'Active' : 'Inactive' ?>
                  </span>
                  <span style="font-size:11px;color:rgba(255,255,255,0.4);font-weight:600;text-transform:uppercase;">
                    <?= e($a['category']) ?>
                  </span>
                </div>

                <?php if ($hasSz): ?>
                  <div class="addon-sizes">
                    <div class="addon-size-chip s"><span class="lbl">S</span><span class="price">Rs. <?= number_format((float)($a['price_s'] ?? 0), 0) ?></span></div>
                    <div class="addon-size-chip m"><span class="lbl">M</span><span class="price">Rs. <?= number_format((float)($a['price_m'] ?? 0), 0) ?></span></div>
                    <div class="addon-size-chip l"><span class="lbl">L</span><span class="price">Rs. <?= number_format((float)($a['price_l'] ?? 0), 0) ?></span></div>
                  </div>
                <?php else: ?>
                  <div class="addon-price-single">
                    <i class="fa-solid fa-tag" style="color:#dc2626;"></i>
                    <span class="price">Rs. <?= number_format((float)($a['price'] ?? 0), 0) ?></span>
                  </div>
                <?php endif; ?>
              </div>

              <div class="addon-item-actions">
                <a href="?edit=<?= (int)$a['id'] ?>" class="addon-btn addon-btn-edit">
                  <i class="fa-solid fa-pen"></i> Edit
                </a>
                <form method="post" style="display:inline;">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                  <button class="addon-btn addon-btn-toggle">
                    <i class="fa-solid fa-<?= $a['is_active'] ? 'eye-slash' : 'eye' ?>"></i>
                    <?= $a['is_active'] ? 'Hide' : 'Show' ?>
                  </button>
                </form>
                <form method="post" style="display:inline;" onsubmit="return confirm('Delete this add-on?');">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                  <button class="addon-btn addon-btn-delete">
                    <i class="fa-solid fa-trash"></i> Delete
                  </button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
function toggleSizeMode() {
  var el = document.getElementById('hasSizesToggle');
  if (!el) return;
  var checked = el.checked;
  var sizeF = document.getElementById('sizeModeFields');
  var singleF = document.getElementById('singlePriceField');
  if (sizeF) sizeF.style.display = checked ? '' : 'none';
  if (singleF) singleF.style.display = checked ? 'none' : '';
}
</script>

<?php require __DIR__ . '/../common/footer.php'; ?>