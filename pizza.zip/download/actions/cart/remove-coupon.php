<?php
// actions/cart/remove-coupon.php
require_once __DIR__ . '/../../common/bootstrap.php';
cart_clear_coupon();
flash_info('Coupon removed.');
redirect(url('cart.php'));