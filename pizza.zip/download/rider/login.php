<?php
require_once __DIR__ . '/../common/bootstrap.php';
if (!feature_enabled('rider_module')) { redirect(url('index.php')); }
if (!empty($_SESSION['rider_id'])) redirect(url('rider/dashboard.php'));

$error = '';
if (is_post()) {
    verify_csrf();
    $r = rider_login((string)post('phone', ''), (string)post('pin', ''));
    if ($r) {
        session_regenerate();
        $_SESSION['rider_id'] = (int)$r['id'];
        $_SESSION['rider_name'] = $r['name'];
        Database::execute("UPDATE riders SET last_login = NOW() WHERE id = ?", [$r['id']]);
        redirect(url('rider/dashboard.php'));
    }
    $error = 'Invalid phone or PIN.';
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rider Login</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center p-4 font-sans">
<div class="w-full max-w-sm">
  <div class="text-center mb-6">
    <div class="w-16 h-16 mx-auto rounded-full bg-brand flex items-center justify-center mb-3">
      <i class="fa-solid fa-motorcycle text-white text-2xl"></i>
    </div>
    <h1 class="text-2xl font-bold">Rider Panel</h1>
    <p class="text-gray-500 text-sm">Friends Pizza Hut</p>
  </div>

  <?php if ($error): ?>
    <div class="bg-red-100 border border-red-300 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm"><?= e($error) ?></div>
  <?php endif; ?>

  <form method="post" class="bg-white rounded-2xl shadow-lg p-6 space-y-4">
    <?= csrf_field() ?>
    <div>
      <label class="block text-sm font-semibold mb-1">Phone</label>
      <input name="phone" required autofocus placeholder="03XXXXXXXXX" class="w-full border rounded-lg px-4 py-3 text-lg">
    </div>
    <div>
      <label class="block text-sm font-semibold mb-1">PIN</label>
      <input name="pin" type="password" required maxlength="6" inputmode="numeric" placeholder="••••" class="w-full border rounded-lg px-4 py-3 text-lg text-center tracking-widest font-mono">
    </div>
    <button class="w-full bg-brand hover:bg-red-700 text-white py-3 rounded-lg font-bold text-lg">
      Login
    </button>
  </form>
</div>
</body>
</html>