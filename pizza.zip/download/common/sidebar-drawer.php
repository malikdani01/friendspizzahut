<?php
/**
 * Mobile sidebar / drawer
 */
$user = customer_logged_in() ? current_customer() : null;
?>
<div class="fph-drawer-overlay" id="fphDrawerOverlay"></div>

<aside class="fph-drawer" id="fphDrawer">
  <div class="fph-drawer-head">
    <div class="fph-drawer-logo">
      <i class="fa-solid fa-pizza-slice"></i>
      <div>
        <div class="fph-logo-top">FRIENDS</div>
        <div class="fph-logo-bottom">PIZZA HUT</div>
      </div>
    </div>
    <button type="button" class="fph-drawer-close" id="fphDrawerClose" aria-label="Close">
      <i class="fa-solid fa-xmark"></i>
    </button>
  </div>

  <?php if ($user): ?>
  <div class="fph-drawer-user">
    <div class="fph-drawer-avatar"><i class="fa-solid fa-user"></i></div>
    <div>
      <div class="fph-drawer-name"><?= e($user['name']) ?></div>
      <div class="fph-drawer-phone"><?= e($user['phone']) ?></div>
    </div>
  </div>
  <?php endif; ?>

  <nav class="fph-drawer-nav">
    <a href="<?= url('index.php') ?>"><i class="fa-solid fa-house"></i> Home</a>
    <a href="<?= url('menu.php') ?>"><i class="fa-solid fa-utensils"></i> Menu</a>
    <a href="<?= url('deals.php') ?>"><i class="fa-solid fa-tags"></i> Deals</a>
    <a href="<?= url('orders.php') ?>"><i class="fa-solid fa-receipt"></i> My Orders</a>
    <a href="<?= url('cart.php') ?>"><i class="fa-solid fa-cart-shopping"></i> Cart</a>

    <div class="fph-drawer-sep">Categories</div>
    <?php foreach (get_categories(true) as $c): ?>
      <a href="<?= url('menu.php?category=' . urlencode($c['slug'])) ?>">
        <i class="fa-solid <?= e($c['icon'] ?: 'fa-utensils') ?>"></i> <?= e($c['name']) ?>
      </a>
    <?php endforeach; ?>

    <div class="fph-drawer-sep">Account</div>
    <?php if ($user): ?>
      <a href="<?= url('account.php') ?>"><i class="fa-solid fa-user"></i> My Account</a>
      <a href="<?= url('notifications.php') ?>"><i class="fa-solid fa-bell"></i> Notifications</a>
      <?php if ($user): ?>
        <?php $chatUnread = 0; try { $chatUnread = chat_unread_count((int)$_SESSION['user_id'], 'user', null); } catch (Throwable $e) {} ?>
        <a href="<?= url('messages.php') ?>" style="position:relative;">
          <i class="fa-solid fa-comments"></i> Messages
          <?php if ($chatUnread > 0): ?>
            <span style="margin-left:auto;background:#dc2626;color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:999px;"><?= $chatUnread ?></span>
          <?php endif; ?>
        </a>
      <?php endif; ?>
      <a href="<?= url('wishlist.php') ?>"><i class="fa-solid fa-heart"></i> Wishlist</a>
      <a href="<?= url('addresses.php') ?>"><i class="fa-solid fa-location-dot"></i> Addresses</a>
      <?php if (feature_enabled('loyalty_points')): ?>
      <a href="<?= url('loyalty.php') ?>"><i class="fa-solid fa-gift"></i> Loyalty Points</a>
      <?php endif; ?>
      <a href="<?= url('logout.php') ?>" class="fph-drawer-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    <?php else: ?>
      <a href="<?= url('login.php') ?>"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
      <a href="<?= url('register.php') ?>"><i class="fa-solid fa-user-plus"></i> Register</a>
    <?php endif; ?>

    <div class="fph-drawer-sep">Info</div>
    <?php if ($user): ?>
      <?php $chatUnread = 0; try { $chatUnread = chat_unread_count((int)$_SESSION['user_id'], 'user', null); } catch (Throwable $e) {} ?>
      <a href="<?= url('messages.php') ?>" style="position:relative;">
        <i class="fa-solid fa-comments"></i> Messages
        <?php if ($chatUnread > 0): ?>
          <span style="margin-left:auto;background:#dc2626;color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:999px;"><?= $chatUnread ?></span>
        <?php endif; ?>
      </a>
    <?php endif; ?>
    <a href="<?= url('contact.php') ?>"><i class="fa-solid fa-envelope"></i> Contact</a>
    <a href="<?= url('about.php') ?>"><i class="fa-solid fa-circle-info"></i> About</a>
    <a href="tel:<?= e(setting('restaurant_phone')) ?>"><i class="fa-solid fa-phone"></i> Call: <?= e(setting('restaurant_phone')) ?></a>
  </nav>
</aside>