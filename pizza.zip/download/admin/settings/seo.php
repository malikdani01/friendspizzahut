<?php
// seo.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'SEO Settings';
if (is_post()) {
    verify_csrf();
    foreach (['seo_title','seo_description','seo_keywords'] as $k) update_setting($k, (string)post($k,''));
    flash_success('Saved.');
    redirect(url('admin/settings/seo.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <div><label class="text-xs text-gray-500">Title</label><input name="seo_title" value="<?= e(setting('seo_title', setting('restaurant_name'))) ?>" class="w-full border rounded px-3 py-2"></div>
    <div><label class="text-xs text-gray-500">Description</label><textarea name="seo_description" rows="3" class="w-full border rounded px-3 py-2"><?= e(setting('seo_description', setting('tagline'))) ?></textarea></div>
    <div><label class="text-xs text-gray-500">Keywords</label><input name="seo_keywords" value="<?= e(setting('seo_keywords','pizza, burgers, deals')) ?>" class="w-full border rounded px-3 py-2"></div>
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>