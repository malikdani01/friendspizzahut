-- ═══════════════════════════════════════════════════════════════
-- Migration 010: Option A Features (8 premium modules)
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('backup_restore',         'Backup & Restore',        'advanced',      'Database backup and restore tool', 1,0,1,0, 200),
('daily_closing',          'Daily Closing Report',    'orders',        'Day-end cash register report',     1,0,1,0, 201),
('customer_tiers',         'Customer Tiers',          'customer',      'Silver/Gold/Platinum tiers with auto discount', 0,0,0,0, 202),
('scheduled_orders',       'Scheduled Orders',        'orders',        'Customer pre-booking for future delivery', 0,0,0,0, 203),
('bulk_sms_marketing',     'Bulk SMS Marketing',      'marketing',     'Send SMS to customer segments',    0,0,0,1, 204),
('profit_loss_report',     'Profit & Loss Report',    'advanced',      'Monthly P&L with costs and margins', 1,0,1,0, 205),
('whatsapp_business_api',  'WhatsApp Business API',   'integrations',  'Official Cloud API for auto messages', 0,0,0,1, 206),
('peak_hours_heatmap',     'Peak Hours Heatmap',      'advanced',      'Order density visualization by day/hour', 1,0,1,0, 207)
ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);