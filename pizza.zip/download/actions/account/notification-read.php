<?php
// actions/account/notification-read.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('notifications.php'));
verify_csrf();
$id = (int)post('id',0);
if ($id) Database::execute("UPDATE notifications SET is_read=1, read_at=NOW() WHERE id=? AND user_id=?", [$id, (int)$_SESSION['user_id']]);
else Database::execute("UPDATE notifications SET is_read=1, read_at=NOW() WHERE user_type='customer' AND user_id=?", [(int)$_SESSION['user_id']]);
redirect(url('notifications.php'));