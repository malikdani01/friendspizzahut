<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Settings';

$groups = [
    'restaurant' => 'Restaurant Info',
    'branding'   => 'Branding',
    'checkout'   => 'Checkout & Pricing',
    'delivery'   => 'Delivery',
    'payment'    => 'Payment',
    'ordering'   => 'Ordering',
];

if (is_post()) {
    verify_csrf();
    $allowed = [];
    foreach (Database::fetchAll("SELECT setting_key FROM settings") as $r) $allowed[] = $r['setting_key'];
    $saved = 0;
    foreach ($_POST as $k => $v) {
        if ($k === 'csrf_token') continue;
        if (!in_array($k, $allowed, true)) continue;
        if (is_array($v)) continue;
        update_setting($k, (string)$v);
        $saved++;
    }
    // checkbox fallbacks for known boolean settings
    foreach (['cod_enabled','bank_transfer_enabled','online_payment_enabled','scheduled_orders_enabled'] as $cb) {
        update_setting($cb, isset($_POST[$cb]) ? '1' : '0');
    }
    flash_success("Settings saved ($saved values).");
    redirect(url('admin/settings/index.php'));
}

$all = Database::fetchAll("SELECT * FROM settings ORDER BY setting_group, setting_key");
$byGroup = [];
foreach ($all as $row) $byGroup[$row['setting_group']][] = $row;

require __DIR__ . '/../common/header.php';
?>
<form method="post" class="space-y-6 max-w-4xl">
  <?= csrf_field() ?>
  <?php foreach ($groups as $gk => $glabel): if (empty($byGroup[$gk])) continue; ?>
    <div class="bg-white rounded-xl shadow-sm border p-5">
      <h3 class="font-bold mb-4 text-brand"><?= e($glabel) ?></h3>
      <div class="grid md:grid-cols-2 gap-4">
        <?php foreach ($byGroup[$gk] as $s):
          $key = $s['setting_key']; $val = $s['setting_value'];
          $isBool = in_array($key, ['cod_enabled','bank_transfer_enabled','online_payment_enabled','scheduled_orders_enabled'], true);
        ?>
          <div>
            <label class="block text-xs font-semibold text-gray-600 mb-1"><?= e(str_replace(['_','.'],' ', ucfirst($key))) ?></label>
            <?php if ($isBool): ?>
              <label class="flex items-center gap-2 text-sm">
                <input type="checkbox" name="<?= e($key) ?>" value="1" <?= $val == '1' ? 'checked' : '' ?> class="w-4 h-4"> Enabled
              </label>
            <?php else: ?>
              <input name="<?= e($key) ?>" value="<?= e($val) ?>" class="w-full border rounded px-3 py-2 text-sm">
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endforeach; ?>
  <div class="sticky bottom-4">
    <button class="bg-brand text-white px-8 py-3 rounded-lg font-semibold shadow-lg">Save All Settings</button>
  </div>
</form>
<?php require __DIR__ . '/../common/footer.php'; ?>