<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('bulk_product_import')) {
    flash_error('Bulk import disabled.');
    redirect(url('admin/dashboard.php'));
}

$pageTitle = 'Bulk Import Products';
$result = null;

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'download_sample') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="products-sample.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['name', 'category_slug', 'short_description', 'description', 'price', 'sale_price', 'is_available']);
        fputcsv($out, ['Sample Pizza', 'pizza', 'Loaded pizza', 'Full description here', '999', '', '1']);
        fputcsv($out, ['Sample Burger', 'burgers', 'Fresh burger', '', '299', '249', '1']);
        fclose($out);
        exit;
    }

    if ($action === 'import' && !empty($_FILES['csv']['tmp_name'])) {
        $file = $_FILES['csv'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($ext !== 'csv') {
            $result = ['ok' => false, 'msg' => 'Only .csv files allowed.'];
        } else {
            $handle = fopen($file['tmp_name'], 'r');
            $header = fgetcsv($handle);
            $imported = 0; $errors = [];

            $expected = ['name', 'category_slug', 'short_description', 'description', 'price', 'sale_price', 'is_available'];
            if ($header !== $expected) {
                $result = ['ok' => false, 'msg' => 'CSV header mismatch. Expected: ' . implode(', ', $expected)];
            } else {
                $row = 1;
                while (($data = fgetcsv($handle)) !== false) {
                    $row++;
                    if (count($data) < 5) continue;

                    [$name, $catSlug, $shortDesc, $desc, $price, $salePrice, $available] = array_pad($data, 7, '');
                    $name = trim($name);
                    if (!$name) continue;

                    $catId = null;
                    if ($catSlug) {
                        $cat = Database::fetch("SELECT id FROM categories WHERE slug = ?", [trim($catSlug)]);
                        $catId = $cat ? (int)$cat['id'] : null;
                    }

                    try {
                        Database::insert('products', [
                            'category_id' => $catId,
                            'name' => $name,
                            'slug' => generate_product_slug($name),
                            'short_description' => trim($shortDesc) ?: null,
                            'description' => trim($desc) ?: null,
                            'price' => (float)$price,
                            'sale_price' => trim($salePrice) !== '' ? (float)$salePrice : null,
                            'is_available' => (int)$available,
                            'status' => 'active',
                        ]);
                        $imported++;
                    } catch (Throwable $e) {
                        $errors[] = "Row $row: " . $e->getMessage();
                    }
                }
                fclose($handle);
                $result = ['ok' => true, 'msg' => "$imported products imported." . ($errors ? ' Errors: ' . count($errors) : '')];
            }
        }
    }
}

require __DIR__ . '/../common/header.php';
?>

<?php if ($result): ?>
<div class="<?= $result['ok'] ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800' ?> border px-4 py-3 rounded-lg mb-5">
  <?= e($result['msg']) ?>
</div>
<?php endif; ?>

<div class="max-w-3xl space-y-5">

  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-3">Step 1: Download Template</h3>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="download_sample">
      <button class="bg-gray-800 text-white px-5 py-2.5 rounded-lg font-semibold">
        <i class="fa-solid fa-download mr-1"></i> Download CSV Sample
      </button>
    </form>
    <div class="text-xs text-gray-500 mt-3">
      Required columns: <code>name, category_slug, short_description, description, price, sale_price, is_available</code>
    </div>
  </div>

  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-3">Step 2: Upload CSV</h3>
    <form method="post" enctype="multipart/form-data" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="import">
      <input type="file" name="csv" accept=".csv" required class="w-full border rounded px-3 py-2">
      <button class="bg-brand text-white px-5 py-2.5 rounded-lg font-semibold">
        <i class="fa-solid fa-upload mr-1"></i> Import Products
      </button>
    </form>
    <div class="text-xs text-gray-500 mt-3">
      Note: Images separately upload karni hongi admin panel se.
    </div>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>