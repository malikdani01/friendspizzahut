<?php
require_once __DIR__ . '/common/bootstrap.php';
if (customer_logged_in()) redirect(url('index.php'));
$pageTitle = 'Create Account';
$errors = [];
if (is_post()) {
    verify_csrf();
    $r = register_customer(
        (string)post('name',''),
        (string)post('phone',''),
        post('email') ? (string)post('email') : null,
        (string)post('password','')
    );
    if (!$r['ok']) { $errors[] = $r['error']; remember_old($_POST); }
    else {
        $login = login_customer((string)post('phone',''), (string)post('password',''));
        merge_guest_cart_after_login((int)$r['user_id']);
        flash_success('Welcome to Friends Pizza Hut, ' . (string)post('name','') . '!');
        redirect(url('index.php'));
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<title>Create Account — Friends Pizza Hut</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body {
  min-height: 100vh;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #0a0a0a;
  color: #f9fafb;
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
}
.auth-wrap {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  position: relative;
  background:
    radial-gradient(circle at 20% 30%, rgba(220,38,38,0.15), transparent 50%),
    radial-gradient(circle at 80% 70%, rgba(220,38,38,0.1), transparent 50%),
    #0a0a0a;
}
.auth-wrap::before,
.auth-wrap::after {
  content: '';
  position: absolute;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(220,38,38,0.18), transparent 70%);
  animation: floatOrb 14s ease-in-out infinite;
  pointer-events: none;
  z-index: 1;
}
.auth-wrap::before { width: 500px; height: 500px; top: -180px; left: -180px; }
.auth-wrap::after  { width: 600px; height: 600px; bottom: -220px; right: -220px; animation-delay: -7s; }
@keyframes floatOrb {
  0%, 100% { transform: translate(0,0) scale(1); }
  50%      { transform: translate(40px,-40px) scale(1.1); }
}
.auth-card {
  width: 100%;
  max-width: 1000px;
  background: #141414;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 24px;
  overflow: hidden;
  display: grid;
  grid-template-columns: 1fr;
  box-shadow: 0 30px 80px rgba(0,0,0,0.7);
  position: relative;
  z-index: 2;
  animation: cardIn 0.7s cubic-bezier(0.34, 1.56, 0.64, 1);
}
@keyframes cardIn {
  from { opacity: 0; transform: translateY(30px) scale(0.96); }
  to   { opacity: 1; transform: translateY(0) scale(1); }
}
@media (min-width: 900px) { .auth-card { grid-template-columns: 1fr 1fr; } }

.auth-brand {
  padding: 48px 40px;
  background: linear-gradient(135deg, #dc2626 0%, #7f1d1d 100%);
  color: #fff;
  display: flex; flex-direction: column; justify-content: center;
  position: relative; overflow: hidden;
  min-height: 280px;
}
.auth-brand::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(circle at 80% 20%, rgba(255,255,255,0.15), transparent 50%),
              radial-gradient(circle at 20% 80%, rgba(0,0,0,0.3), transparent 50%);
}
.auth-brand::after {
  content: '\f818';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  position: absolute;
  right: -50px; bottom: -60px;
  font-size: 300px;
  color: rgba(255,255,255,0.06);
  line-height: 1;
  transform: rotate(-15deg);
}
.auth-brand-content { position: relative; z-index: 1; }
.auth-brand-badge {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 8px 16px;
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 999px;
  font-size: 12px; font-weight: 700;
  margin-bottom: 24px;
  text-transform: uppercase; letter-spacing: 0.5px;
}
.auth-brand-title {
  font-size: 40px; font-weight: 900; line-height: 1.1;
  margin-bottom: 16px; letter-spacing: -0.02em;
}
@media (min-width: 900px) { .auth-brand-title { font-size: 48px; } }
.auth-brand-title .dark { color: #0a0a0a; }
.auth-brand-sub {
  font-size: 15px; opacity: 0.9; line-height: 1.6;
  max-width: 340px; margin-bottom: 32px;
}
.auth-brand-features { display: flex; flex-direction: column; gap: 12px; }
.auth-feature {
  display: flex; align-items: center; gap: 12px;
  padding: 12px 16px;
  background: rgba(0,0,0,0.25);
  border-radius: 12px;
  border: 1px solid rgba(255,255,255,0.1);
}
.auth-feature-icon {
  width: 36px; height: 36px; border-radius: 50%;
  background: rgba(255,255,255,0.15);
  display: flex; align-items: center; justify-content: center;
  font-size: 15px; flex-shrink: 0;
}
.auth-feature-text { font-size: 13px; font-weight: 600; }
.auth-feature-text small { display: block; opacity: 0.7; font-weight: 500; font-size: 11.5px; margin-top: 2px; }

.auth-form {
  padding: 48px 40px;
  display: flex; flex-direction: column; justify-content: center;
  background: #141414;
}
@media (max-width: 899px) {
  .auth-form { padding: 36px 24px; }
  .auth-brand { padding: 40px 28px; min-height: auto; }
}
.auth-title {
  font-size: 32px; font-weight: 900;
  margin-bottom: 8px; color: #fff;
  letter-spacing: -0.02em;
}
.auth-subtitle {
  font-size: 14px; color: rgba(255,255,255,0.55);
  margin-bottom: 28px;
}
.auth-error {
  background: rgba(220,38,38,0.12);
  border: 1.5px solid rgba(220,38,38,0.4);
  color: #fca5a5;
  padding: 12px 16px;
  border-radius: 12px;
  font-size: 13.5px; font-weight: 600;
  margin-bottom: 20px;
  line-height: 1.6;
  animation: shake 0.4s ease;
}
@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-6px); }
  75% { transform: translateX(6px); }
}
.auth-field { margin-bottom: 16px; }
.auth-label {
  display: block;
  font-size: 12.5px; font-weight: 700;
  color: rgba(255,255,255,0.7);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 8px;
}
.auth-input-wrap { position: relative; }
.auth-input {
  width: 100%;
  padding: 13px 14px 13px 44px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 12px;
  color: #fff;
  font-size: 15px; font-family: inherit;
  outline: none;
  transition: all .2s;
  -webkit-appearance: none;
}
.auth-input:focus {
  border-color: #dc2626;
  background: rgba(0,0,0,0.6);
  box-shadow: 0 0 0 4px rgba(220,38,38,0.15);
}
.auth-input::placeholder { color: rgba(255,255,255,0.3); }
.auth-input-icon {
  position: absolute;
  left: 16px; top: 50%;
  transform: translateY(-50%);
  color: rgba(255,255,255,0.35);
  font-size: 14px;
  pointer-events: none;
  transition: color .2s;
}
.auth-input:focus ~ .auth-input-icon { color: #dc2626; }

.auth-submit {
  width: 100%; padding: 15px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff; border: 0; border-radius: 12px;
  font-size: 15px; font-weight: 800;
  cursor: pointer;
  display: flex; align-items: center; justify-content: center; gap: 10px;
  box-shadow: 0 10px 30px rgba(220,38,38,0.4);
  transition: all .25s;
  position: relative; overflow: hidden;
  font-family: inherit; letter-spacing: 0.3px;
  margin-top: 12px;
}
.auth-submit::before {
  content: ''; position: absolute;
  top: 0; left: -100%; width: 100%; height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
  transition: left .6s;
}
.auth-submit:hover::before { left: 100%; }
.auth-submit:hover { transform: translateY(-2px); box-shadow: 0 14px 40px rgba(220,38,38,0.55); }
.auth-submit:active { transform: scale(0.98); }

.auth-divider {
  display: flex; align-items: center; gap: 12px;
  margin: 20px 0;
  color: rgba(255,255,255,0.3);
  font-size: 12px;
}
.auth-divider::before,
.auth-divider::after {
  content: ''; flex: 1; height: 1px;
  background: rgba(255,255,255,0.08);
}
.auth-footer {
  text-align: center; font-size: 14px;
  color: rgba(255,255,255,0.6);
}
.auth-footer a { color: #dc2626; font-weight: 700; text-decoration: none; }
.auth-footer a:hover { text-decoration: underline; }
.auth-home-link {
  display: inline-flex; align-items: center; gap: 6px;
  margin-top: 20px;
  color: rgba(255,255,255,0.5);
  font-size: 13px; text-decoration: none;
  align-self: center;
  transition: color .15s;
}
.auth-home-link:hover { color: #dc2626; }
</style>
</head>
<body>

<div class="auth-wrap">
  <div class="auth-card">

    <!-- LEFT: Brand -->
    <div class="auth-brand">
      <div class="auth-brand-content">
        <div class="auth-brand-badge">
          <i class="fa-solid fa-user-plus"></i> Join Us
        </div>

        <h1 class="auth-brand-title">
          Order faster.<br>
          <span class="dark">Eat better.</span>
        </h1>

        <p class="auth-brand-sub">
          Create your account to enjoy quick ordering, saved addresses and exclusive offers.
        </p>

        <div class="auth-brand-features">
          <div class="auth-feature">
            <div class="auth-feature-icon"><i class="fa-solid fa-gift"></i></div>
            <div class="auth-feature-text">
              Exclusive Offers
              <small>Special deals for members.</small>
            </div>
          </div>
          <div class="auth-feature">
            <div class="auth-feature-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
            <div class="auth-feature-text">
              Order History
              <small>Reorder your favorites.</small>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- RIGHT: Form -->
    <div class="auth-form">
      <h2 class="auth-title">Create Account</h2>
      <p class="auth-subtitle">Join us and start ordering in seconds.</p>

      <?php if ($errors): ?>
        <div class="auth-error">
          <?php foreach ($errors as $er): ?>
            <div style="display:flex;gap:8px;align-items:flex-start;padding:3px 0;">
              <i class="fa-solid fa-circle-exclamation"></i>
              <span><?= e($er) ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form method="post" autocomplete="on">
        <?= csrf_field() ?>

        <div class="auth-field">
          <label class="auth-label">Full Name *</label>
          <div class="auth-input-wrap">
            <input type="text" name="name" required autofocus
                   value="<?= old('name') ?>"
                   placeholder="Your full name"
                   class="auth-input"
                   autocomplete="name">
            <i class="fa-solid fa-user auth-input-icon"></i>
          </div>
        </div>

        <div class="auth-field">
          <label class="auth-label">Phone Number *</label>
          <div class="auth-input-wrap">
            <input type="tel" name="phone" required
                   value="<?= old('phone') ?>"
                   placeholder="03XXXXXXXXX"
                   class="auth-input"
                   inputmode="tel"
                   autocomplete="tel">
            <i class="fa-solid fa-phone auth-input-icon"></i>
          </div>
        </div>

        <div class="auth-field">
          <label class="auth-label">Email (optional)</label>
          <div class="auth-input-wrap">
            <input type="email" name="email"
                   value="<?= old('email') ?>"
                   placeholder="you@example.com"
                   class="auth-input"
                   autocomplete="email">
            <i class="fa-solid fa-envelope auth-input-icon"></i>
          </div>
        </div>

        <div class="auth-field">
          <label class="auth-label">Password *</label>
          <div class="auth-input-wrap">
            <input type="password" name="password" required minlength="6"
                   placeholder="At least 6 characters"
                   class="auth-input"
                   autocomplete="new-password">
            <i class="fa-solid fa-lock auth-input-icon"></i>
          </div>
        </div>

        <button type="submit" class="auth-submit">
          Create Account <i class="fa-solid fa-arrow-right"></i>
        </button>
      </form>

      <div class="auth-divider">or</div>

      <div class="auth-footer">
        Already have an account? <a href="<?= url('login.php') ?>">Login →</a>
      </div>

      <a href="<?= url('index.php') ?>" class="auth-home-link">
        <i class="fa-solid fa-arrow-left"></i> Back to Home
      </a>
    </div>
  </div>
</div>

</body>
</html>
<?php clear_old(); ?>