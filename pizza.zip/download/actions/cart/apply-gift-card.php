<?php
// actions/cart/apply-gift-card.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('cart.php'));
verify_csrf();
$r = gift_card_validate((string)post('gift_code',''));
if ($r['ok']) {
    $_SESSION['cart_gift_card'] = $r['card']['code'];
    flash_success('Gift card applied.');
} else { unset($_SESSION['cart_gift_card']); flash_error($r['error']); }
redirect(url('cart.php'));