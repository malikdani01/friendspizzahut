<?php
function get_riders(bool $activeOnly = true): array {
    $sql = "SELECT * FROM riders";
    if ($activeOnly) $sql .= " WHERE is_active = 1";
    $sql .= " ORDER BY name";
    return Database::fetchAll($sql);
}

function get_rider(int $id): ?array {
    return Database::fetch("SELECT * FROM riders WHERE id = ?", [$id]);
}

function assign_rider(int $orderId, int $riderId): bool {
    $r = Database::fetch("SELECT id FROM riders WHERE id = ? AND is_active = 1", [$riderId]);
    if (!$r) return false;

    Database::execute("UPDATE orders SET rider_id = ? WHERE id = ?", [$riderId, $orderId]);
    Database::insert('order_status_history', [
        'order_id' => $orderId,
        'old_status' => null,
        'new_status' => 'rider_assigned',
        'changed_by_admin' => $_SESSION['admin_id'] ?? null,
        'note' => 'Assigned to rider #' . $riderId,
    ]);
    return true;
}

function rider_login(string $phone, string $pin): ?array {
    $r = Database::fetch("SELECT * FROM riders WHERE phone = ? AND is_active = 1", [$phone]);
    if (!$r || !password_verify($pin, $r['pin_hash'])) return null;
    return $r;
}

function rider_orders(int $riderId): array {
    return Database::fetchAll(
        "SELECT * FROM orders 
         WHERE rider_id = ? 
         AND order_status IN ('confirmed','preparing','ready','out_for_delivery')
         ORDER BY created_at ASC",
        [$riderId]
    );
}