-- ═══════════════════════════════════════════════════════════════
-- Migration 012: Easypaisa Integration + Remove Bank Transfer
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── 1. Disable bank_transfer feature ─────────────────────────
UPDATE features SET is_enabled = 0, default_state = 0 WHERE feature_key = 'bank_transfer';

-- ─── 2. Add Easypaisa feature toggle ──────────────────────────
INSERT INTO features (feature_key, feature_name, category, description, is_enabled, is_core, default_state, requires_config, sort_order) VALUES
('easypaisa_payment', 'Easypaisa Payment', 'payments', 'Easypaisa mobile wallet payment gateway', 0, 0, 0, 1, 51)
ON DUPLICATE KEY UPDATE feature_name = VALUES(feature_name);

-- ─── 3. Easypaisa settings defaults ───────────────────────────
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('easypaisa_enabled',      '0',          'payment'),
('easypaisa_mode',         'sandbox',    'payment'),
('easypaisa_store_id',     '',           'payment'),
('easypaisa_hash_key',     '',           'payment'),
('easypaisa_username',     '',           'payment'),
('easypaisa_password',     '',           'payment'),
('easypaisa_mobile_number','',           'payment'),
('cod_enabled',            '1',          'payment'),
('bank_transfer_enabled',  '0',          'payment'),
('pickup_enabled',         '1',          'ordering')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);