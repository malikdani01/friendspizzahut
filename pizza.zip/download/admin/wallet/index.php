<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('customer_wallet')) {
    flash_error('Wallet disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Customer Wallets';

if (is_post()) {
    verify_csrf();
    if (post('action') === 'credit') {
        $uid = (int)post('user_id', 0);
        $amt = (float)post('amount', 0);
        $reason = trim((string)post('reason', 'Manual credit'));
        if ($uid && $amt > 0) {
            wallet_credit($uid, $amt, $reason);
            flash_success('Wallet credited ' . money($amt));
        }
    }
    redirect(url('admin/wallet/index.php'));
}

$users = Database::fetchAll(
    "SELECT u.id, u.name, u.phone, COALESCE(SUM(w.amount), 0) AS balance
     FROM users u
     LEFT JOIN wallet_transactions w ON w.user_id = u.id
     GROUP BY u.id
     HAVING balance != 0 OR u.id IN (SELECT DISTINCT user_id FROM wallet_transactions)
     ORDER BY balance DESC
     LIMIT 200"
);

require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div class="bg-white rounded-xl border p-5 h-fit">
    <h3 class="font-bold mb-3">Credit Wallet</h3>
    <form method="post" class="space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="credit">
      <input name="user_id" type="number" required placeholder="User ID" class="w-full border rounded px-3 py-2">
      <input name="amount" type="number" step="0.01" required placeholder="Amount" class="w-full border rounded px-3 py-2">
      <input name="reason" placeholder="Reason" value="Manual credit by admin" class="w-full border rounded px-3 py-2">
      <button class="w-full bg-brand text-white py-2 rounded font-semibold">Credit</button>
    </form>
  </div>
  <div class="md:col-span-2 bg-white rounded-xl border overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
        <tr>
          <th class="text-left px-4 py-3">Customer</th>
          <th class="text-left px-4 py-3">Phone</th>
          <th class="text-right px-4 py-3">Balance</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr class="border-t hover:bg-gray-50">
          <td class="px-4 py-3 font-semibold"><?= e($u['name']) ?></td>
          <td class="px-4 py-3"><?= e($u['phone']) ?></td>
          <td class="px-4 py-3 text-right font-bold <?= (float)$u['balance'] >= 0 ? 'text-green-600' : 'text-red-600' ?>">
            <?= money($u['balance']) ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$users): ?><tr><td colspan="3" class="py-8 text-center text-gray-400">No wallet activity yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>