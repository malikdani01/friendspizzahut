<?php
require_once __DIR__ . '/../common/bootstrap.php';
$cutoff = date('Y-m-d H:i:s', time() - 24*3600);
$n = Database::execute("DELETE FROM cart_items WHERE created_at < ? AND user_id IS NULL", [$cutoff]);
echo "[" . date('c') . "] Abandoned guest carts cleaned: $n\n";