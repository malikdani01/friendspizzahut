-- ═══════════════════════════════════════════════════════════════
-- FRIENDS PIZZA HUT — Migration 002: Performance Indexes
-- ═══════════════════════════════════════════════════════════════

-- Orders: frequent filter + sort combinations
CREATE INDEX IF NOT EXISTS idx_orders_status_created
    ON orders(order_status, created_at);
CREATE INDEX IF NOT EXISTS idx_orders_customer_phone
    ON orders(customer_phone);
CREATE INDEX IF NOT EXISTS idx_orders_payment_status
    ON orders(payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_date_status
    ON orders(created_at, order_status);

-- Products: category browsing
CREATE INDEX IF NOT EXISTS idx_products_category_active
    ON products(category_id, status, is_available);
CREATE INDEX IF NOT EXISTS idx_products_slug_status
    ON products(slug, status);

-- Cart: session lookup
CREATE INDEX IF NOT EXISTS idx_cart_user_product
    ON cart_items(user_id, product_id);
CREATE INDEX IF NOT EXISTS idx_cart_session_product
    ON cart_items(session_id, product_id);

-- Notifications
CREATE INDEX IF NOT EXISTS idx_notifications_user_created
    ON notifications(user_type, user_id, created_at DESC);

-- Loyalty
CREATE INDEX IF NOT EXISTS idx_loyalty_user_type
    ON loyalty_points(user_id, type);
CREATE INDEX IF NOT EXISTS idx_loyalty_order
    ON loyalty_points(order_id);

-- Coupons
CREATE INDEX IF NOT EXISTS idx_coupon_usage_coupon_user
    ON coupon_usage(coupon_id, user_id);
CREATE INDEX IF NOT EXISTS idx_coupon_usage_order
    ON coupon_usage(order_id);

-- Payments
CREATE INDEX IF NOT EXISTS idx_payments_order_status
    ON payments(order_id, payment_status);

-- Reviews
CREATE INDEX IF NOT EXISTS idx_reviews_product_approved
    ON reviews(product_id, is_approved, created_at DESC);

-- Audit logs
CREATE INDEX IF NOT EXISTS idx_audit_user_created
    ON audit_logs(user_type, user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action
    ON audit_logs(action);

-- Login attempts
CREATE INDEX IF NOT EXISTS idx_login_ip_success_time
    ON login_attempts(ip_address, success, created_at);

-- Delivery areas
CREATE INDEX IF NOT EXISTS idx_delivery_active_order
    ON delivery_areas(is_active, sort_order);

-- Gift cards
CREATE INDEX IF NOT EXISTS idx_gift_code_active
    ON gift_cards(code, is_active);