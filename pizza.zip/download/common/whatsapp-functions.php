<?php
function whatsapp_order_url(?string $orderNumber = null): string {
    $num = preg_replace('/\D/', '', setting('restaurant_whatsapp', setting('restaurant_phone','')));
    $msg = $orderNumber ? "Hello, I want to ask about order $orderNumber" : "Hello, I'd like to place an order";
    return 'https://wa.me/' . $num . '?text=' . urlencode($msg);
}
function whatsapp_button(?string $orderNumber = null): string {
    if (!feature_enabled('whatsapp_ordering')) return '';
    return '<a href="' . e(whatsapp_order_url($orderNumber)) . '" target="_blank" class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-semibold"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>';
}