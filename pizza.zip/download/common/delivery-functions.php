<?php
function get_delivery_areas(bool $activeOnly = true): array {
    $sql = "SELECT * FROM delivery_areas";
    if ($activeOnly) $sql .= " WHERE is_active=1";
    $sql .= " ORDER BY sort_order, name";
    return Database::fetchAll($sql);
}
function get_delivery_area(int $id): ?array { return Database::fetch("SELECT * FROM delivery_areas WHERE id=?", [$id]); }
function get_delivery_fee_for_area(?int $areaId): float {
    if (!$areaId) return (float) setting('default_delivery_fee', 100);
    $a = get_delivery_area($areaId);
    return $a ? (float)$a['delivery_fee'] : (float) setting('default_delivery_fee', 100);
}