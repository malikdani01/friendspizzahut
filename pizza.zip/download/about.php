<?php
// about.php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'About Us';
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-16">
  <h1 class="text-4xl font-extrabold mb-3">About <span class="text-brand">Friends Pizza Hut</span></h1>
  <p class="text-white/60 mb-8">The Magician of Taste</p>
  <div class="space-y-4 text-white/80 leading-relaxed">
    <p>Welcome to Friends Pizza Hut — a place where great taste meets warm hospitality. Located in City Tamman, near MCB Bank, we've been serving the community with freshly baked pizzas, juicy burgers, crispy wings, and mouth-watering deals.</p>
    <p>Every dish is crafted with fresh ingredients, prepared with love, and served hot. Whether you're craving a classic Friends Special Pizza or our signature Crown Crust, we've got something for everyone.</p>
    <p><strong class="text-brand">Our Promise:</strong> Hot. Fresh. Delicious. Every single time.</p>
  </div>
  <div class="mt-10 grid grid-cols-3 gap-4 text-center">
    <div class="bg-white/5 border border-white/10 rounded-xl p-5">
      <div class="text-3xl font-extrabold text-brand">100%</div>
      <div class="text-xs text-white/60 mt-1">Fresh Ingredients</div>
    </div>
    <div class="bg-white/5 border border-white/10 rounded-xl p-5">
      <div class="text-3xl font-extrabold text-brand">30min</div>
      <div class="text-xs text-white/60 mt-1">Avg Delivery</div>
    </div>
    <div class="bg-white/5 border border-white/10 rounded-xl p-5">
      <div class="text-3xl font-extrabold text-brand">FREE</div>
      <div class="text-xs text-white/60 mt-1">Delivery Rs.1500+</div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>