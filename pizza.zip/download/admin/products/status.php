<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/products/index.php'));
verify_csrf();
$id = (int)post('id', 0);
$status = (string)post('status', 'active');
if (in_array($status, ['active','inactive','archived'], true)) {
    Database::execute("UPDATE products SET status=? WHERE id=?", [$status, $id]);
    audit_log('product.status', 'product', $id, null, ['status'=>$status]);
    flash_success('Status updated.');
}
redirect(url('admin/products/index.php'));