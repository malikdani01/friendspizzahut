<?php
require_once __DIR__ . '/common/bootstrap.php';
require_customer();
$pageTitle = 'My Orders';
$orders = get_user_orders((int)$_SESSION['user_id'], 50);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-5xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-8">My Orders</h1>
  <?php if (!$orders): ?>
    <div class="text-center py-16 text-white/60">No orders yet. <a href="<?= url('menu.php') ?>" class="text-brand hover:underline">Order now</a></div>
  <?php else: ?>
    <div class="space-y-3">
      <?php foreach ($orders as $o): ?>
      <div class="bg-white/5 border border-white/10 rounded-xl p-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div class="font-mono text-sm text-white/60"><?= e($o['order_number']) ?></div>
          <div class="font-bold text-lg"><?= money($o['total']) ?></div>
          <div class="text-xs text-white/50"><?= date('d M Y, H:i', strtotime($o['created_at'])) ?></div>
        </div>
        <div class="flex items-center gap-3">
          <?= status_badge($o['order_status']) ?>
          <a href="<?= url('track-order.php?order=' . urlencode($o['order_number'])) ?>" class="text-brand text-sm hover:underline">Track →</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>