<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('staff_roles')) { flash_error('Roles disabled.'); redirect(url('admin/dashboard.php')); }
$pageTitle = 'Roles & Permissions';

if (is_post()) {
    verify_csrf();
    $action = post('action');
    if ($action === 'create') {
        $name = trim((string)post('name',''));
        $slug = slugify($name);
        if ($name && !Database::fetch("SELECT id FROM roles WHERE slug=?", [$slug])) {
            Database::insert('roles', ['name'=>$name, 'slug'=>$slug, 'description'=>trim((string)post('description',''))]);
            flash_success('Role created.');
        }
    } elseif ($action === 'delete') {
        $id = (int)post('id');
        $r = Database::fetch("SELECT is_system FROM roles WHERE id=?", [$id]);
        if ($r && !(int)$r['is_system']) {
            Database::execute("DELETE FROM role_permissions WHERE role_id=?", [$id]);
            Database::execute("DELETE FROM roles WHERE id=?", [$id]);
            flash_success('Deleted.');
        }
    } elseif ($action === 'save_perms') {
        $rid = (int)post('role_id');
        Database::execute("DELETE FROM role_permissions WHERE role_id=?", [$rid]);
        foreach ((array)post('permissions', []) as $pid) {
            Database::insert('role_permissions', ['role_id'=>$rid, 'permission_id'=>(int)$pid]);
        }
        flash_success('Permissions saved.');
    }
    redirect(url('admin/roles/index.php'));
}

$roles = Database::fetchAll("SELECT * FROM roles ORDER BY name");
$perms = Database::fetchAll("SELECT * FROM permissions ORDER BY module, slug");
$groupedPerms = [];
foreach ($perms as $p) $groupedPerms[$p['module']][] = $p;
require __DIR__ . '/../common/header.php';
?>
<div class="grid md:grid-cols-3 gap-6">
  <div>
    <div class="bg-white rounded-xl shadow-sm border p-5 mb-5">
      <h3 class="font-bold mb-3">Add Role</h3>
      <form method="post" class="space-y-3">
        <?= csrf_field() ?><input type="hidden" name="action" value="create">
        <input name="name" required placeholder="Role name" class="w-full border rounded px-3 py-2">
        <input name="description" placeholder="Description" class="w-full border rounded px-3 py-2">
        <button class="w-full bg-brand text-white py-2 rounded font-semibold">Create Role</button>
      </form>
    </div>
  </div>
  <div class="md:col-span-2 space-y-4">
    <?php foreach ($roles as $r): 
      $rolePerms = array_column(Database::fetchAll("SELECT permission_id FROM role_permissions WHERE role_id=?", [$r['id']]), 'permission_id');
    ?>
    <div class="bg-white rounded-xl shadow-sm border p-5">
      <div class="flex justify-between items-center mb-3">
        <div><div class="font-bold"><?= e($r['name']) ?></div><div class="text-xs text-gray-500"><?= e($r['description']) ?></div></div>
        <?php if (!(int)$r['is_system']): ?>
        <form method="post" class="inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="text-xs text-red-600">Delete</button></form>
        <?php endif; ?>
      </div>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="save_perms"><input type="hidden" name="role_id" value="<?= (int)$r['id'] ?>">
        <div class="space-y-3">
          <?php foreach ($groupedPerms as $module => $items): ?>
          <div>
            <div class="text-xs font-bold text-gray-500 uppercase mb-1"><?= e($module) ?></div>
            <div class="flex flex-wrap gap-3">
              <?php foreach ($items as $p): ?>
                <label class="text-xs flex items-center gap-1"><input type="checkbox" name="permissions[]" value="<?= (int)$p['id'] ?>" <?= in_array($p['id'], $rolePerms)?'checked':'' ?>> <?= e($p['name']) ?></label>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <button class="mt-3 bg-gray-800 text-white px-4 py-2 rounded text-sm">Save Permissions</button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>