<?php
require_once __DIR__ . '/common/bootstrap.php';
$pageTitle = 'Deals & Combos';
$deals = feature_enabled('combo_deals')
    ? Database::fetchAll("SELECT * FROM combos WHERE is_active=1 ORDER BY sort_order")
    : [];
require __DIR__ . '/common/header.php';
?>
<div class="fph-container" style="padding-top:20px;padding-bottom:100px;">
  <h1 style="font-size:32px;font-weight:900;color:#fff;margin:0 0 6px;">Special <span style="color:#dc2626;">Deals</span></h1>
  <p style="color:rgba(255,255,255,0.6);margin-bottom:28px;">Save big with our value combos</p>

  <?php if (!$deals): ?>
    <div style="text-align:center;padding:60px 20px;background:#171717;border:1px solid rgba(255,255,255,0.08);border-radius:16px;">
      <i class="fa-solid fa-tags" style="font-size:48px;color:rgba(255,255,255,0.2);display:block;margin-bottom:14px;"></i>
      <p style="color:rgba(255,255,255,0.5);margin:0;">No deals available right now.</p>
    </div>
  <?php else: ?>
    <div style="display:grid;grid-template-columns:1fr;gap:18px;" class="deals-grid">
      <?php foreach ($deals as $d):
        $items = Database::fetchAll("SELECT ci.*, p.name FROM combo_items ci LEFT JOIN products p ON p.id=ci.product_id WHERE ci.combo_id=? ORDER BY ci.sort_order", [$d['id']]);
        $img = !empty($d['image']) ? upload_url($d['image']) : null;
      ?>
      <div class="deal-public-card" style="background:#171717;border:1px solid rgba(255,255,255,0.08);border-radius:16px;overflow:hidden;transition:all .2s;">
        <?php if ($img): ?>
          <div style="aspect-ratio:16/10;background:#0a0a0a;overflow:hidden;">
            <img src="<?= e($img) ?>" alt="<?= e($d['name']) ?>" style="width:100%;height:100%;object-fit:cover;display:block;">
          </div>
        <?php else: ?>
          <div style="aspect-ratio:16/10;background:linear-gradient(135deg,rgba(220,38,38,0.25),rgba(220,38,38,0.05));display:flex;align-items:center;justify-content:center;">
            <i class="fa-solid fa-pizza-slice" style="font-size:56px;color:rgba(255,255,255,0.2);"></i>
          </div>
        <?php endif; ?>

        <div style="padding:20px;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:12px;">
            <div>
              <h3 style="font-size:20px;font-weight:900;color:#fff;margin:0 0 6px;"><?= e($d['name']) ?></h3>
              <p style="font-size:13.5px;color:rgba(255,255,255,0.6);line-height:1.5;margin:0;"><?= e($d['description']) ?></p>
            </div>
            <div style="text-align:right;flex-shrink:0;">
              <div style="font-size:24px;font-weight:900;color:#dc2626;line-height:1;"><?= money($d['fixed_price']) ?></div>
              <?php if (!empty($d['compare_price']) && $d['compare_price'] > $d['fixed_price']): ?>
                <div style="font-size:13px;color:rgba(255,255,255,0.4);text-decoration:line-through;margin-top:2px;"><?= money($d['compare_price']) ?></div>
              <?php endif; ?>
            </div>
          </div>

          <?php if ($items): ?>
            <div style="background:rgba(0,0,0,0.3);border-radius:10px;padding:12px;margin-bottom:16px;">
              <div style="font-size:11px;font-weight:800;color:#dc2626;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px;">Includes:</div>
              <?php foreach ($items as $it): ?>
                <div style="font-size:13px;color:rgba(255,255,255,0.7);padding:3px 0;">
                  <i class="fa-solid fa-check" style="color:#4ade80;margin-right:8px;"></i>
                  <?= (int)$it['quantity'] ?>× <?= e($it['name'] ?? 'Item') ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <form method="post" action="<?= url('actions/cart/add-deal.php') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="combo_id" value="<?= (int)$d['id'] ?>">
            <button type="submit" style="width:100%;padding:14px;background:linear-gradient(135deg,#dc2626,#b91c1c);color:#fff;border:0;border-radius:11px;font-size:14.5px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 6px 18px rgba(220,38,38,0.35);font-family:inherit;">
              <i class="fa-solid fa-cart-plus"></i> Add Deal to Cart
            </button>
          </form>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <style>
      @media (min-width: 768px) { .deals-grid { grid-template-columns: repeat(2, 1fr) !important; } }
      @media (min-width: 1200px) { .deals-grid { grid-template-columns: repeat(3, 1fr) !important; } }
      .deal-public-card:hover { border-color: rgba(220,38,38,0.4) !important; transform: translateY(-3px); box-shadow: 0 12px 32px rgba(220,38,38,0.2); }
    </style>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>