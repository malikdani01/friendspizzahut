<?php
function inventory_adjust(int $productId, int $change, string $type, ?string $reason = null, ?int $orderId = null): void {
    $p = Database::fetch("SELECT stock_quantity FROM products WHERE id=?", [$productId]);
    if (!$p) return;
    $before = (int)$p['stock_quantity'];
    $after = max(0, $before + $change);
    Database::execute("UPDATE products SET stock_quantity=? WHERE id=?", [$after, $productId]);
    Database::insert('inventory_adjustments', [
        'product_id' => $productId, 'adjustment_type' => $type,
        'quantity_before' => $before, 'quantity_change' => $change, 'quantity_after' => $after,
        'reason' => $reason, 'order_id' => $orderId,
        'changed_by_admin' => $_SESSION['admin_id'] ?? null,
    ]);
}
function product_in_stock(int $productId, int $qty = 1): bool {
    $p = Database::fetch("SELECT stock_tracking, stock_quantity FROM products WHERE id=?", [$productId]);
    if (!$p) return false;
    if (!(int)$p['stock_tracking']) return true;
    return (int)$p['stock_quantity'] >= $qty;
}
function low_stock_products(int $limit = 20): array {
    return Database::fetchAll("SELECT * FROM products WHERE stock_tracking=1 AND stock_quantity <= low_stock_threshold AND status='active' ORDER BY stock_quantity ASC LIMIT " . (int)$limit);
}