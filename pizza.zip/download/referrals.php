<?php
require_once __DIR__ . '/common/bootstrap.php';
if (!feature_enabled('referral_system')) { flash_error('Referrals not available.'); redirect(url('account.php')); }
require_customer();
$pageTitle = 'Referrals';
$uid = (int)$_SESSION['user_id'];
$code = referral_get_code($uid);
$stats = referral_stats($uid);
$rows = Database::fetchAll("SELECT r.*, u.name AS referred_name FROM referrals r
    LEFT JOIN users u ON u.id=r.referred_user_id WHERE r.referrer_user_id=? ORDER BY r.id DESC LIMIT 50", [$uid]);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-3xl mx-auto px-4 py-10">
  <h1 class="text-3xl font-extrabold mb-8">Refer Friends</h1>
  <div class="bg-gradient-to-br from-brand to-red-900 rounded-2xl p-8 text-center mb-8">
    <div class="text-white/80 text-sm">Your Referral Code</div>
    <div class="text-4xl font-extrabold tracking-widest my-3"><?= e($code) ?></div>
    <p class="text-white/70 text-sm">Share this code with friends. Both of you earn rewards!</p>
  </div>
  <div class="grid grid-cols-2 gap-4 mb-8">
    <div class="bg-white/5 rounded-xl p-5 text-center"><div class="text-3xl font-extrabold text-brand"><?= $stats['total'] ?></div><div class="text-xs text-white/60 mt-1">Referred</div></div>
    <div class="bg-white/5 rounded-xl p-5 text-center"><div class="text-3xl font-extrabold text-green-400"><?= $stats['rewarded'] ?></div><div class="text-xs text-white/60 mt-1">Rewarded</div></div>
  </div>
  <?php if ($rows): ?>
  <h3 class="font-bold mb-3">Your Referrals</h3>
  <div class="bg-white/5 border border-white/10 rounded-xl divide-y divide-white/5">
    <?php foreach ($rows as $r): ?>
    <div class="px-4 py-3 flex justify-between text-sm">
      <div><?= e($r['referred_name'] ?? 'Pending') ?></div>
      <div class="text-xs <?= $r['status']==='rewarded'?'text-green-400':'text-white/60' ?>"><?= e(ucfirst($r['status'])) ?></div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>