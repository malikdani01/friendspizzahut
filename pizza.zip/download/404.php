<?php
// 404.php
require_once __DIR__ . '/common/bootstrap.php';
http_response_code(404);
$pageTitle = 'Page Not Found';
require __DIR__ . '/common/header.php';
?>
<div class="max-w-xl mx-auto px-4 py-24 text-center">
  <div class="text-7xl font-extrabold text-brand mb-4">404</div>
  <h1 class="text-2xl font-bold mb-3">Page Not Found</h1>
  <p class="text-white/60 mb-6">The page you're looking for doesn't exist.</p>
  <a href="<?= url('index.php') ?>" class="bg-brand px-6 py-3 rounded-full font-bold">Back Home</a>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>