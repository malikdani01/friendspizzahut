<?php
function loyalty_points_balance(int $userId): int {
    $earn = (int)(Database::fetch("SELECT COALESCE(SUM(points),0) s FROM loyalty_points WHERE user_id=? AND type='earn'", [$userId])['s'] ?? 0);
    $red  = (int)(Database::fetch("SELECT COALESCE(SUM(points),0) s FROM loyalty_points WHERE user_id=? AND type='redeem'", [$userId])['s'] ?? 0);
    return max(0, $earn - $red);
}
function loyalty_award(int $userId, int $orderId, float $orderTotal): int {
    if (!feature_enabled('loyalty_points')) return 0;
    $s = Database::fetch("SELECT * FROM loyalty_settings ORDER BY id LIMIT 1");
    if (!$s || !(int)$s['is_active']) return 0;
    $points = (int)floor($orderTotal * (float)$s['earn_rate'] / 100);
    if ($points <= 0) return 0;
    Database::insert('loyalty_points', [
        'user_id' => $userId, 'order_id' => $orderId, 'points' => $points,
        'type' => 'earn', 'description' => "Earned on order #$orderId",
    ]);
    return $points;
}
function loyalty_redeem(int $userId, int $points, ?int $orderId = null): bool {
    if ($points <= 0) return false;
    if ($points > loyalty_points_balance($userId)) return false;
    Database::insert('loyalty_points', [
        'user_id' => $userId, 'order_id' => $orderId, 'points' => $points,
        'type' => 'redeem', 'description' => 'Redeemed',
    ]);
    return true;
}
function loyalty_history(int $userId): array {
    return Database::fetchAll("SELECT * FROM loyalty_points WHERE user_id=? ORDER BY id DESC LIMIT 100", [$userId]);
}