<?php
/**
 * Bootstrap — include at top of every page
 */
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// ─── Config ──────────────────────────────────────────────
$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    $self = $_SERVER['SCRIPT_NAME'] ?? '';
    if (!str_contains($self, 'setup.php')) {
        header('Location: ' . rtrim(dirname($self), '/') . '/setup.php');
        exit;
    }
    return;
}
require_once $configFile;

// ─── SESSION — start FIRST before anything ──────────────
if (session_status() !== PHP_SESSION_ACTIVE) {
    // Try to use system temp dir (Byethost friendly)
    $savePath = ini_get('session.save_path');
    if (!$savePath || !is_writable($savePath)) {
        $tmp = sys_get_temp_dir();
        if ($tmp && is_writable($tmp)) {
            session_save_path($tmp);
        }
    }

    @session_name(defined('SESSION_NAME') ? SESSION_NAME : 'fph_session');
    @session_set_cookie_params([
        'lifetime' => defined('SESSION_LIFETIME') ? SESSION_LIFETIME : 604800,
        'path'     => '/',
        'domain'   => '',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    @session_start();
}

// ─── Core requires ───────────────────────────────────────
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/flash.php';
require_once __DIR__ . '/settings-functions.php';
require_once __DIR__ . '/features.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/admin-auth.php';

// ─── Extended helpers (only if exist) ────────────────────
$helpers = [
    'product-functions', 'category-functions', 'cart-functions', 'pricing-functions',
    'order-functions', 'coupon-functions', 'offer-functions', 'combo-functions',
    'review-functions', 'wishlist-functions', 'notification-functions',
    'loyalty-functions', 'referral-functions', 'gift-card-functions',
    'sms-functions', 'chat-functions', 'message-functions',
    'dashboard-functions', 'upsell-functions', 'alert-functions',
    'dealbar-functions', 'badge-functions', 'section-functions',
    'transaction-functions', 'reservation-functions', 'inventory-functions',
];
foreach ($helpers as $h) {
    $f = __DIR__ . '/' . $h . '.php';
    if (file_exists($f)) require_once $f;
}

// ─── Timezone ────────────────────────────────────────────
try {
    date_default_timezone_set(setting('timezone', 'Asia/Karachi'));
} catch (Throwable $e) {
    date_default_timezone_set('Asia/Karachi');
}

// ─── Auth Gate — Force login ─────────────────────────────
try {
    if (!customer_logged_in()) {
        $self = basename($_SERVER['SCRIPT_NAME'] ?? '');
        $dir  = basename(dirname($_SERVER['SCRIPT_NAME'] ?? ''));

        $publicPages = [
            'login.php', 'register.php', 'logout.php',
            'forgot-password.php', 'reset-password.php',
            'setup.php', 'maintenance.php',
            '404.php', '403.php', '500.php',
            'checkout-test.php', 'test-db.php', 'test-session.php',
        ];
        $publicDirs = ['admin', 'payment', 'actions', 'cron', 'rider'];

        if (!in_array($self, $publicPages, true) && !in_array($dir, $publicDirs, true)) {
            $_SESSION['_redirect_after_login'] = current_url();
            header('Location: ' . url('login.php'));
            exit;
        }
    }
} catch (Throwable $e) {
    error_log('Auth gate error: ' . $e->getMessage());
}