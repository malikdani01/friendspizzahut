<?php
// admin/staff/create.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('staff_roles')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Add Staff';
$errors = [];
$roles = Database::fetchAll("SELECT * FROM roles ORDER BY name");

if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name',''));
    $username = trim((string)post('username',''));
    $email = trim((string)post('email',''));
    $password = (string)post('password','');
    if (strlen($name) < 2) $errors[] = 'Name required.';
    if (!$username) $errors[] = 'Username required.';
    if (Database::fetch("SELECT id FROM staff WHERE username=?", [$username])) $errors[] = 'Username taken.';
    if (strlen($password) < 6) $errors[] = 'Password 6+ chars.';
    if (!$errors) {
        Database::insert('staff', [
            'name' => $name, 'username' => $username,
            'email' => $email ?: null,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'role_id' => (int)post('role_id') ?: null,
            'is_active' => 1,
        ]);
        flash_success('Staff created.');
        redirect(url('admin/staff/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl">
  <?php if ($errors): ?><div class="bg-red-50 text-red-700 px-4 py-3 rounded mb-4"><?php foreach($errors as $e_) echo '• '.e($e_).'<br>'; ?></div><?php endif; ?>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input name="name" required placeholder="Full name" class="w-full border rounded px-3 py-2">
    <input name="username" required placeholder="Username" class="w-full border rounded px-3 py-2">
    <input type="email" name="email" placeholder="Email" class="w-full border rounded px-3 py-2">
    <input type="password" name="password" required minlength="6" placeholder="Password" class="w-full border rounded px-3 py-2">
    <select name="role_id" class="w-full border rounded px-3 py-2">
      <option value="">— No role —</option>
      <?php foreach ($roles as $r): ?><option value="<?= (int)$r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?>
    </select>
    <div class="flex gap-2">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Create</button>
      <a href="<?= url('admin/staff/index.php') ?>" class="px-6 py-2.5 rounded-lg bg-gray-100">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>