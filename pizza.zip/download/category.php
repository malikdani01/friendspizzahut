<?php
require_once __DIR__ . '/common/bootstrap.php';
$slug = (string)get('slug', get('category', ''));
if (!$slug) { redirect(url('menu.php')); }
$cat = get_category_by_slug($slug);
if (!$cat) { flash_error('Category not found.'); redirect(url('menu.php')); }

$pageTitle = $cat['name'];
$products = get_products(['category_id' => (int)$cat['id'], 'available' => 1, 'limit' => 60]);
require __DIR__ . '/common/header.php';
?>
<div class="max-w-7xl mx-auto px-4 py-10">
  <a href="<?= url('menu.php') ?>" class="text-sm text-white/60 hover:text-brand mb-4 inline-block">← All Menu</a>
  <h1 class="text-3xl md:text-4xl font-extrabold mb-2"><?= e($cat['name']) ?></h1>
  <?php if ($cat['description']): ?><p class="text-white/60 mb-6"><?= e($cat['description']) ?></p><?php endif; ?>
  <p class="text-white/50 text-sm mb-6"><?= count($products) ?> items</p>

  <?php if (!$products): ?>
    <div class="text-center py-20 text-white/60">
      <i class="fa-solid fa-pizza-slice text-5xl mb-4 opacity-40"></i>
      <p>No items in this category yet.</p>
      <a href="<?= url('menu.php') ?>" class="mt-4 inline-block bg-brand px-6 py-3 rounded-full font-bold">Browse Full Menu</a>
    </div>
  <?php else: ?>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      <?php foreach ($products as $p): require __DIR__ . '/common/components/product-card.php'; endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/common/footer.php'; ?>