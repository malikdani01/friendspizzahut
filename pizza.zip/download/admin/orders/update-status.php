<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!is_post()) redirect(url('admin/orders/index.php'));
verify_csrf();
$id = (int)post('id', 0);
$status = (string)post('status', '');
$note = (string)post('note', '');
if ($id && $status) {
    update_order_status($id, $status, (int)$_SESSION['admin_id'], null, $note);
    audit_log('order.status.update', 'order', $id, null, ['status'=>$status]);
    flash_success('Order status updated.');
}
redirect(url('admin/orders/view.php?id=' . $id));