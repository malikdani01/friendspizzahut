-- ═══════════════════════════════════════════════════════════════
-- FRIENDS PIZZA HUT — Migration 005
-- Default Email + SMS + WhatsApp Notification Templates
-- 
-- Ye templates admin panel se edit ho sakte hain:
--   Admin → Settings → Templates
-- 
-- Placeholders: {customer_name}, {order_number}, {total},
--               {track_url}, {review_url}, {restaurant_name},
--               {restaurant_phone}, {login_url}, {reset_url},
--               {status}, {reason}, {code}, {address}
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── EMAIL TEMPLATES ──────────────────────────────────────────
INSERT INTO notification_templates (tpl_key, channel, subject, body, is_active) VALUES

-- Welcome email on registration
('welcome', 'email',
 'Welcome to {restaurant_name}!',
 '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;">
   <div style="background:#dc2626;color:#fff;padding:24px;text-align:center;">
     <h1 style="margin:0;font-size:24px;">🍕 {restaurant_name}</h1>
   </div>
   <div style="padding:24px;color:#333;line-height:1.6;">
     <h2 style="color:#dc2626;margin-top:0;">Welcome, {customer_name}!</h2>
     <p>Shukriya join karne ke liye. Aap ab online order kar sakte hain — ghar baithe, 30 minute mein delivery.</p>
     <p style="text-align:center;margin:32px 0;">
       <a href="{login_url}" style="background:#dc2626;color:#fff;padding:14px 32px;text-decoration:none;border-radius:8px;font-weight:bold;display:inline-block;">Start Ordering</a>
     </p>
     <p style="font-size:14px;color:#666;">Aapka account: <strong>{customer_phone}</strong></p>
     <p style="font-size:14px;color:#666;">Koi sawaal? Call us: <a href="tel:{restaurant_phone}" style="color:#dc2626;">{restaurant_phone}</a></p>
   </div>
   <div style="background:#0a0a0a;color:#fff;padding:16px;text-align:center;font-size:12px;">
     — {restaurant_name} Team
   </div>
 </div>', 1),

-- Order placed confirmation
('order_placed', 'email',
 'Order Confirm — {order_number}',
 '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;">
   <div style="background:#dc2626;color:#fff;padding:24px;text-align:center;">
     <h1 style="margin:0;font-size:22px;">Order Received!</h1>
   </div>
   <div style="padding:24px;color:#333;line-height:1.6;">
     <p>Shukriya, <strong>{customer_name}</strong>!</p>
     <p>Aapka order successfully place ho gaya hai. Hum jaldi preparation shuru karenge.</p>
     <div style="background:#f5f5f5;border-radius:8px;padding:16px;margin:20px 0;">
       <table style="width:100%;font-size:14px;">
         <tr><td style="padding:4px 0;color:#666;">Order Number:</td><td style="text-align:right;font-weight:bold;">{order_number}</td></tr>
         <tr><td style="padding:4px 0;color:#666;">Total:</td><td style="text-align:right;font-weight:bold;color:#dc2626;font-size:18px;">Rs. {total}</td></tr>
         <tr><td style="padding:4px 0;color:#666;">Status:</td><td style="text-align:right;font-weight:bold;">{status}</td></tr>
       </table>
     </div>
     <p style="text-align:center;margin:28px 0;">
       <a href="{track_url}" style="background:#dc2626;color:#fff;padding:14px 32px;text-decoration:none;border-radius:8px;font-weight:bold;display:inline-block;">Track Your Order</a>
     </p>
     <p style="font-size:14px;color:#666;">Koi tabdeeli? Call us: <a href="tel:{restaurant_phone}" style="color:#dc2626;">{restaurant_phone}</a></p>
   </div>
   <div style="background:#0a0a0a;color:#fff;padding:16px;text-align:center;font-size:12px;">
     {restaurant_name}
   </div>
 </div>', 1),

-- Order delivered
('order_delivered', 'email',
 'Order Delivered — {order_number}',
 '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;">
   <div style="background:#16a34a;color:#fff;padding:24px;text-align:center;">
     <h1 style="margin:0;font-size:22px;">✅ Order Delivered!</h1>
   </div>
   <div style="padding:24px;color:#333;line-height:1.6;">
     <p>Shukriya, <strong>{customer_name}</strong>!</p>
     <p>Aapka order <strong>{order_number}</strong> successfully deliver ho gaya hai. Umeed hai khana pasand aaya!</p>
     <p>Aapki feedback humare liye bohot important hai:</p>
     <p style="text-align:center;margin:28px 0;">
       <a href="{review_url}" style="background:#dc2626;color:#fff;padding:14px 32px;text-decoration:none;border-radius:8px;font-weight:bold;display:inline-block;">⭐⭐⭐⭐⭐ Give Feedback</a>
     </p>
     <p style="font-size:14px;color:#666;">Dobara order karne pe discount? Code <strong>THANKYOU10</strong> use karein.</p>
   </div>
   <div style="background:#0a0a0a;color:#fff;padding:16px;text-align:center;font-size:12px;">
     {restaurant_name}
   </div>
 </div>', 1),

-- Password reset
('password_reset', 'email',
 'Password Reset Request — {restaurant_name}',
 '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;">
   <div style="background:#dc2626;color:#fff;padding:24px;text-align:center;">
     <h1 style="margin:0;font-size:22px;">Password Reset</h1>
   </div>
   <div style="padding:24px;color:#333;line-height:1.6;">
     <p>Assalam-o-Alaikum <strong>{customer_name}</strong>,</p>
     <p>Aapne password reset ki request ki hai. Neeche diye button se naya password set karein:</p>
     <p style="text-align:center;margin:28px 0;">
       <a href="{reset_url}" style="background:#dc2626;color:#fff;padding:14px 32px;text-decoration:none;border-radius:8px;font-weight:bold;display:inline-block;">Reset Password</a>
     </p>
     <p style="font-size:13px;color:#666;">Ya ye link copy karein:<br><span style="word-break:break-all;color:#dc2626;">{reset_url}</span></p>
     <p style="font-size:13px;color:#999;border-top:1px solid #eee;padding-top:16px;">Link 1 ghante mein expire ho jayega. Agar aapne reset request nahi ki, to ignore karein.</p>
   </div>
   <div style="background:#0a0a0a;color:#fff;padding:16px;text-align:center;font-size:12px;">
     {restaurant_name}
   </div>
 </div>', 1),

-- Order cancelled
('order_cancelled', 'email',
 'Order Cancelled — {order_number}',
 '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;">
   <div style="background:#dc2626;color:#fff;padding:24px;text-align:center;">
     <h1 style="margin:0;font-size:22px;">Order Cancelled</h1>
   </div>
   <div style="padding:24px;color:#333;line-height:1.6;">
     <p>Assalam-o-Alaikum <strong>{customer_name}</strong>,</p>
     <p>Aapka order <strong>{order_number}</strong> cancel ho gaya hai.</p>
     <div style="background:#fff5f5;border-left:4px solid #dc2626;padding:12px 16px;margin:16px 0;">
       <strong style="color:#dc2626;">Wajah:</strong> {reason}
     </div>
     <p>Agar ye galti se hua ya aap dobara order karna chahte hain:</p>
     <p style="text-align:center;margin:24px 0;">
       <a href="{login_url}" style="background:#dc2626;color:#fff;padding:14px 32px;text-decoration:none;border-radius:8px;font-weight:bold;display:inline-block;">Order Again</a>
     </p>
   </div>
   <div style="background:#0a0a0a;color:#fff;padding:16px;text-align:center;font-size:12px;">
     {restaurant_name}
   </div>
 </div>', 1),

-- First order offer
('first_order_offer', 'email',
 'Welcome Offer — 10% Off Your First Order!',
 '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;">
   <div style="background:linear-gradient(135deg,#dc2626,#7f1d1d);color:#fff;padding:32px;text-align:center;">
     <h1 style="margin:0;font-size:28px;">🎉 10% OFF!</h1>
     <p style="margin:8px 0 0;font-size:14px;">Your first order</p>
   </div>
   <div style="padding:24px;color:#333;line-height:1.6;">
     <p>Khush Aamdeed <strong>{customer_name}</strong>!</p>
     <p>Aapki pehli order pe <strong>10% discount</strong> ka code:</p>
     <div style="text-align:center;padding:20px;background:#f5f5f5;border:2px dashed #dc2626;border-radius:8px;margin:20px 0;">
       <div style="font-family:monospace;font-size:24px;font-weight:bold;color:#dc2626;letter-spacing:2px;">FIRST10</div>
     </div>
     <p style="text-align:center;margin:28px 0;">
       <a href="{login_url}" style="background:#dc2626;color:#fff;padding:14px 32px;text-decoration:none;border-radius:8px;font-weight:bold;display:inline-block;">Order Now</a>
     </p>
     <p style="font-size:12px;color:#999;text-align:center;">Valid on orders above Rs. 500</p>
   </div>
   <div style="background:#0a0a0a;color:#fff;padding:16px;text-align:center;font-size:12px;">
     {restaurant_name}
   </div>
 </div>', 1),

-- Payment received
('payment_received', 'email',
 'Payment Confirmed — Order {order_number}',
 '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;">
   <div style="background:#16a34a;color:#fff;padding:24px;text-align:center;">
     <h1 style="margin:0;font-size:22px;">✅ Payment Confirmed</h1>
   </div>
   <div style="padding:24px;color:#333;line-height:1.6;">
     <p>Shukriya <strong>{customer_name}</strong>!</p>
     <p>Aapka payment successfully receive ho gaya hai.</p>
     <div style="background:#f0fdf4;border-radius:8px;padding:16px;margin:16px 0;">
       <table style="width:100%;font-size:14px;">
         <tr><td style="padding:4px 0;color:#666;">Order Number:</td><td style="text-align:right;font-weight:bold;">{order_number}</td></tr>
         <tr><td style="padding:4px 0;color:#666;">Amount Paid:</td><td style="text-align:right;font-weight:bold;color:#16a34a;">Rs. {total}</td></tr>
       </table>
     </div>
     <p>Aapka order ab preparation ke liye chala gaya hai.</p>
     <p style="text-align:center;margin:24px 0;">
       <a href="{track_url}" style="background:#dc2626;color:#fff;padding:14px 32px;text-decoration:none;border-radius:8px;font-weight:bold;display:inline-block;">Track Order</a>
     </p>
   </div>
   <div style="background:#0a0a0a;color:#fff;padding:16px;text-align:center;font-size:12px;">
     {restaurant_name}
   </div>
 </div>', 1)

ON DUPLICATE KEY UPDATE 
    subject = VALUES(subject), 
    body = VALUES(body), 
    is_active = VALUES(is_active);

-- ─── SMS TEMPLATES (max 160 chars each) ───────────────────────
INSERT INTO notification_templates (tpl_key, channel, subject, body, is_active) VALUES

('order_placed', 'sms', NULL,
 'Order {order_number} confirmed! Total: Rs.{total}. Track: {track_url}', 1),

('order_confirmed', 'sms', NULL,
 'Order {order_number} confirm ho gaya. Preparation shuru.', 1),

('order_preparing', 'sms', NULL,
 'Order {order_number} ban raha hai. Ready hone mein kuch minutes.', 1),

('order_ready', 'sms', NULL,
 'Order {order_number} ready hai!', 1),

('order_dispatched', 'sms', NULL,
 'Order {order_number} rider ke saath nikal gaya. Address: {address}', 1),

('order_delivered', 'sms', NULL,
 'Order {order_number} deliver ho gaya. Shukriya! Feedback: {review_url}', 1),

('order_cancelled', 'sms', NULL,
 'Order {order_number} cancel. Wajah: {reason}', 1),

('otp_verification', 'sms', NULL,
 'Aapka verification code: {code}. 10 minutes mein expire.', 1),

('password_reset', 'sms', NULL,
 'Password reset code: {code}. Kisi aur ne request ki ho to ignore karein.', 1),

('payment_received', 'sms', NULL,
 'Payment Rs.{total} received for order {order_number}. Thank you!', 1)

ON DUPLICATE KEY UPDATE 
    body = VALUES(body), 
    is_active = VALUES(is_active);

-- ─── WHATSAPP TEMPLATES ───────────────────────────────────────
INSERT INTO notification_templates (tpl_key, channel, subject, body, is_active) VALUES

('order_confirmed', 'whatsapp', NULL,
 'Assalam-o-Alaikum {customer_name}! Aapka order {order_number} confirm ho gaya. Total: Rs.{total}. Track: {track_url}', 1),

('order_dispatched', 'whatsapp', NULL,
 'Order {order_number} rider ke saath nikal gaya hai. Aapka khana {estimated_time} mein pohanch jayega.', 1),

('order_delivered', 'whatsapp', NULL,
 'Order {order_number} deliver ho gaya. Shukriya! Feedback dein: {review_url}', 1),

('payment_received', 'whatsapp', NULL,
 'Payment Rs.{total} received! Order {order_number} ab prepare ho raha hai.', 1),

('order_cancelled', 'whatsapp', NULL,
 'Order {order_number} cancel ho gaya. Wajah: {reason}', 1)

ON DUPLICATE KEY UPDATE 
    body = VALUES(body), 
    is_active = VALUES(is_active);

-- ─── PUSH NOTIFICATION TEMPLATES ──────────────────────────────
INSERT INTO notification_templates (tpl_key, channel, subject, body, is_active) VALUES

('order_status', 'push',
 'Order Update — {order_number}',
 'Aapka order ab {status} hai.', 1),

('promo_offer', 'push',
 'Special Offer!',
 '{restaurant_name} pe aaj {discount}% off. Order karein!', 0)

ON DUPLICATE KEY UPDATE 
    subject = VALUES(subject),
    body = VALUES(body), 
    is_active = VALUES(is_active);