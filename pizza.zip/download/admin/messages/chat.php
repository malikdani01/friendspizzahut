<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();

$userId = (int)get('user_id', 0);
$user = Database::fetch("SELECT * FROM users WHERE id = ?", [$userId]);
if (!$user) { flash_error('User not found.'); redirect(url('admin/messages/index.php')); }

$pageTitle = 'Chat: ' . $user['name'];

// Mark messages as read
chat_mark_read($userId, 'admin', null);

if (is_post()) {
    verify_csrf();
    $msg = (string)post('message', '');
    $admin = current_admin();
    $r = chat_send($userId, 'admin', $admin['name'] . ' (Support)', $msg, (int)$admin['id'], null);
    if ($r['ok']) {
        redirect(url('admin/messages/chat.php?user_id=' . $userId));
    }
    flash_error($r['error']);
}

$messages = chat_get_messages($userId, null);

require __DIR__ . '/../common/header.php';
?>

<style>
.ac-wrap {
  max-width: 900px;
  margin: 0 auto;
  height: calc(100vh - 160px);
  display: flex;
  flex-direction: column;
}
@media (max-width: 767px) { .ac-wrap { height: calc(100vh - 140px); } }

.ac-back {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: rgba(255,255,255,0.6);
  text-decoration: none;
  font-size: 13px;
  margin-bottom: 12px;
  font-weight: 600;
}
.ac-back:hover { color: #dc2626; }

.ac-head {
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px 14px 0 0;
  padding: 14px 18px;
  display: flex;
  align-items: center;
  gap: 12px;
  border-bottom: 1px solid rgba(255,255,255,0.04);
}
.ac-avatar {
  width: 44px; height: 44px;
  border-radius: 50%;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-weight: 800; font-size: 17px;
  flex-shrink: 0;
}
.ac-user-name { font-size: 15px; font-weight: 800; color: #fff; }
.ac-user-meta { font-size: 12px; color: rgba(255,255,255,0.5); margin-top: 2px; }

.ac-chat {
  flex: 1;
  overflow-y: auto;
  background: #171717;
  border-left: 1px solid rgba(255,255,255,0.08);
  border-right: 1px solid rgba(255,255,255,0.08);
  padding: 18px;
  min-height: 200px;
}

.ac-msg {
  margin-bottom: 14px;
  max-width: 78%;
  display: flex;
  flex-direction: column;
}
.ac-msg.admin { margin-left: auto; align-items: flex-end; }
.ac-msg.user, .ac-msg.rider { margin-right: auto; align-items: flex-start; }

.ac-bubble {
  padding: 11px 15px;
  border-radius: 14px;
  font-size: 14px;
  line-height: 1.5;
  word-wrap: break-word;
  max-width: 100%;
}
.ac-msg.admin .ac-bubble {
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  border-bottom-right-radius: 4px;
}
.ac-msg.user .ac-bubble {
  background: rgba(59,130,246,0.15);
  border: 1px solid rgba(59,130,246,0.3);
  color: #f9fafb;
  border-bottom-left-radius: 4px;
}
.ac-msg.rider .ac-bubble {
  background: rgba(34,197,94,0.15);
  border: 1px solid rgba(34,197,94,0.3);
  color: #f9fafb;
  border-bottom-left-radius: 4px;
}

.ac-sender {
  font-size: 10.5px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: rgba(255,255,255,0.5);
  margin-bottom: 4px;
}
.ac-time { font-size: 10px; color: rgba(255,255,255,0.4); margin-top: 4px; }

.ac-empty {
  text-align: center;
  padding: 60px 20px;
  color: rgba(255,255,255,0.4);
  font-size: 13.5px;
}
.ac-empty i { font-size: 40px; opacity: 0.3; display: block; margin-bottom: 12px; color: #dc2626; }

.ac-form {
  display: flex;
  gap: 10px;
  padding: 12px;
  background: #171717;
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 0 0 14px 14px;
  border-top: 1px solid rgba(255,255,255,0.04);
}
.ac-input {
  flex: 1;
  padding: 12px 16px;
  background: rgba(0,0,0,0.4);
  border: 1.5px solid rgba(255,255,255,0.1);
  border-radius: 10px;
  color: #fff;
  font-size: 14px;
  outline: none;
  font-family: inherit;
  resize: none;
  min-height: 46px;
  max-height: 100px;
}
.ac-input:focus { border-color: #dc2626; box-shadow: 0 0 0 3px rgba(220,38,38,0.15); }
.ac-input::placeholder { color: rgba(255,255,255,0.35); }

.ac-send {
  width: 46px;
  height: 46px;
  border-radius: 10px;
  background: linear-gradient(135deg, #dc2626, #b91c1c);
  color: #fff;
  border: 0;
  cursor: pointer;
  font-size: 17px;
  flex-shrink: 0;
  box-shadow: 0 4px 14px rgba(220,38,38,0.3);
  transition: all .15s;
}
.ac-send:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(220,38,38,0.45); }
</style>

<div class="ac-wrap">
  <a href="<?= url('admin/messages/index.php') ?>" class="ac-back">
    <i class="fa-solid fa-arrow-left"></i> Back to Support Chat
  </a>

  <div class="ac-head">
    <div class="ac-avatar"><?= e(strtoupper(mb_substr($user['name'], 0, 1))) ?></div>
    <div style="flex:1;min-width:0;">
      <div class="ac-user-name"><?= e($user['name']) ?></div>
      <div class="ac-user-meta">
        <i class="fa-solid fa-phone"></i> <?= e($user['phone']) ?>
        <?php if (!empty($user['email'])): ?> · <?= e($user['email']) ?><?php endif; ?>
      </div>
    </div>
  </div>

  <div class="ac-chat" id="acChat">
    <?php if (!$messages): ?>
      <div class="ac-empty">
        <i class="fa-solid fa-comments"></i>
        No messages yet. Send the first message below.
      </div>
    <?php else: foreach ($messages as $m): ?>
      <div class="ac-msg <?= e($m['sender_type']) ?>">
        <?php if ($m['sender_type'] !== 'admin'): ?>
          <div class="ac-sender"><?= e($m['sender_name']) ?></div>
        <?php endif; ?>
        <div class="ac-bubble"><?= nl2br(e($m['message'])) ?></div>
        <div class="ac-time"><?= date('d M, H:i', strtotime($m['created_at'])) ?></div>
      </div>
    <?php endforeach; endif; ?>
  </div>

  <form method="post" class="ac-form">
    <?= csrf_field() ?>
    <textarea name="message" required class="ac-input" placeholder="Type your reply..." id="acInput" rows="1"></textarea>
    <button type="submit" class="ac-send"><i class="fa-solid fa-paper-plane"></i></button>
  </form>
</div>

<script>
(function() {
  var chat = document.getElementById('acChat');
  if (chat) chat.scrollTop = chat.scrollHeight;

  var inp = document.getElementById('acInput');
  if (inp) {
    inp.addEventListener('input', function() {
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    });
  }
})();
</script>

<?php require __DIR__ . '/../common/footer.php'; ?>