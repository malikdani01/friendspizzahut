<?php
// services/OrderService.php
class OrderService {
    public static function get(int $id): ?array { return get_order($id); }
    public static function getByNumber(string $n): ?array { return get_order_by_number($n); }
    public static function items(int $id): array { return get_order_items($id); }
    public static function updateStatus(int $id, string $s, ?int $a = null): bool { return update_order_status($id, $s, $a); }
    public static function cancel(int $id, string $r, string $by): bool { return cancel_order($id, $r, $by); }
}