<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Add Product';
$errors = [];

$cats = [];
try { $cats = get_categories(); } catch (Throwable $e) { $cats = []; }
$allAddons = [];
try { $allAddons = Database::fetchAll("SELECT * FROM addons WHERE is_active = 1 ORDER BY category, sort_order"); } catch (Throwable $e) { $allAddons = []; }

$hasExtraCols = false;
try {
    $c = Database::fetch("SHOW COLUMNS FROM products LIKE 'has_sizes'");
    $hasExtraCols = !empty($c);
} catch (Throwable $e) { $hasExtraCols = false; }

if (is_post()) {
    verify_csrf();
    $name = trim((string)post('name', ''));
    $price = (float)post('price', 0);
    $catId = (int)post('category_id', 0);
    if (strlen($name) < 2)  $errors[] = 'Name required.';
    if ($price <= 0)        $errors[] = 'Price required.';
    if (!$catId)            $errors[] = 'Select category.';

    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $r = save_uploaded_image($_FILES['image'], 'products');
        if (!$r['ok']) $errors[] = 'Image: ' . $r['error'];
        else $image = $r['path'];
    }

    if (!$errors) {
        $data = [
            'category_id' => $catId,
            'name' => $name,
            'slug' => generate_product_slug($name),
            'short_description' => trim((string)post('short_description','')) ?: null,
            'description' => trim((string)post('description','')) ?: null,
            'price' => $price,
            'sale_price' => post('sale_price') !== '' ? (float)post('sale_price') : null,
            'image' => $image,
            'is_featured' => post('is_featured') ? 1 : 0,
            'is_bestseller' => post('is_bestseller') ? 1 : 0,
            'is_new' => post('is_new') ? 1 : 0,
            'is_available' => post('is_available') ? 1 : 0,
            'sort_order' => (int)post('sort_order', 0),
            'status' => (string)post('status', 'active'),
        ];

        if ($hasExtraCols) {
            $hasSizes = post('has_sizes') ? 1 : 0;
            $data['has_sizes'] = $hasSizes;
            if ($hasSizes) {
                $data['price_s'] = (float)post('price_s', 0);
                $data['price_m'] = (float)post('price_m', 0);
                $data['price_l'] = (float)post('price_l', 0);
                $data['size_labels'] = 'Small,Medium,Large';
            }
            $data['button_mode'] = (string)post('button_mode', 'add_to_cart');
            $data['order_button_text'] = trim((string)post('order_button_text','')) ?: 'Add to Cart';
            $data['order_button_enabled'] = post('order_button_enabled') ? 1 : 0;
            $data['button_bg_color'] = trim((string)post('button_bg_color','')) ?: null;
            $data['button_text_color'] = trim((string)post('button_text_color','')) ?: null;
            $data['prep_time_minutes'] = (int)post('prep_time_minutes', 15);
        }

        try {
            $pid = Database::insert('products', $data);

            // Addons
            try {
                $addonIds = array_map('intval', (array)post('addons', []));
                foreach ($addonIds as $aid) {
                    if ($aid > 0) {
                        Database::insert('product_addons', [
                            'product_id' => $pid,
                            'addon_id' => $aid,
                            'sort_order' => 0,
                        ]);
                    }
                }
            } catch (Throwable $ex) { error_log('addon: ' . $ex->getMessage()); }

            flash_success('Product created.');
            redirect(url('admin/products/edit.php?id=' . $pid));
        } catch (Throwable $ex) {
            error_log('product create: ' . $ex->getMessage());
            $errors[] = 'Error: ' . $ex->getMessage();
        }
    }
}

require __DIR__ . '/../common/header.php';
?>

<!-- SAME STYLES AS edit.php -->
<style>
.pe-wrap { max-width: 900px; }
.pe-card { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 24px; margin-bottom: 20px; }
.pe-card h3 { font-size: 14px; font-weight: 800; color: #dc2626; margin: 0 0 18px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.06); text-transform: uppercase; letter-spacing: 0.6px; display: flex; align-items: center; gap: 8px; }
.pe-label { display: block; font-size: 12.5px; font-weight: 700; color: rgba(255,255,255,0.7); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
.pe-input, .pe-textarea, .pe-select { width: 100%; padding: 12px 14px; background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 10px; color: #fff; font-size: 14.5px; font-family: inherit; outline: none; margin-bottom: 16px; }
.pe-input:focus, .pe-textarea:focus, .pe-select:focus { border-color: #dc2626; box-shadow: 0 0 0 3px rgba(220,38,38,0.15); }
.pe-input::placeholder, .pe-textarea::placeholder { color: rgba(255,255,255,0.3); }
.pe-textarea { resize: vertical; min-height: 80px; line-height: 1.5; }
.pe-select option { background: #171717; color: #fff; }
.pe-grid-2 { display: grid; grid-template-columns: 1fr; gap: 0 16px; }
@media (min-width: 640px) { .pe-grid-2 { grid-template-columns: 1fr 1fr; } }
.pe-grid-3 { display: grid; grid-template-columns: 1fr; gap: 0 12px; }
@media (min-width: 640px) { .pe-grid-3 { grid-template-columns: 1fr 1fr 1fr; } }
.pe-checkbox-row { display: flex; flex-wrap: wrap; gap: 14px; margin-bottom: 16px; padding: 12px; background: rgba(0,0,0,0.3); border-radius: 10px; border: 1.5px solid rgba(255,255,255,0.06); }
.pe-checkbox-row label { display: flex; align-items: center; gap: 8px; font-size: 13.5px; font-weight: 600; color: #fff; cursor: pointer; }
.pe-checkbox-row input[type="checkbox"] { width: 16px !important; height: 16px !important; accent-color: #dc2626; cursor: pointer; }
.pe-toggle-row { display: flex; align-items: center; gap: 10px; padding: 14px; background: rgba(0,0,0,0.3); border: 1.5px solid rgba(255,255,255,0.08); border-radius: 11px; cursor: pointer; margin-bottom: 16px; }
.pe-toggle-row:hover { border-color: rgba(220,38,38,0.4); }
.pe-toggle-row input { width: 18px !important; height: 18px !important; accent-color: #dc2626; cursor: pointer; }
.pe-toggle-row span { font-size: 14px; font-weight: 600; color: #fff; }
.pe-size-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 16px; }
.pe-size-box { background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 11px; padding: 14px 10px; text-align: center; }
.pe-size-box.s { border-color: rgba(59,130,246,0.4); background: rgba(59,130,246,0.05); }
.pe-size-box.m { border-color: rgba(234,179,8,0.4); background: rgba(234,179,8,0.05); }
.pe-size-box.l { border-color: rgba(220,38,38,0.4); background: rgba(220,38,38,0.05); }
.pe-size-label { font-size: 11px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 6px; }
.pe-size-box.s .pe-size-label { color: #60a5fa; }
.pe-size-box.m .pe-size-label { color: #facc15; }
.pe-size-box.l .pe-size-label { color: #f87171; }
.pe-size-input { width: 100%; background: transparent; border: 0; color: #fff; font-size: 16px; font-weight: 800; text-align: center; outline: none; padding: 4px 0; }
.pe-size-hint { font-size: 10.5px; color: rgba(255,255,255,0.4); margin-top: 4px; }
.pe-addon-grid { display: grid; grid-template-columns: 1fr; gap: 10px; }
@media (min-width: 640px) { .pe-addon-grid { grid-template-columns: 1fr 1fr; } }
.pe-addon-item { display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: rgba(0,0,0,0.3); border: 1.5px solid rgba(255,255,255,0.08); border-radius: 10px; cursor: pointer; }
.pe-addon-item:hover { border-color: rgba(220,38,38,0.4); background: rgba(220,38,38,0.05); }
.pe-addon-item input[type="checkbox"] { width: 18px !important; height: 18px !important; accent-color: #dc2626; cursor: pointer; flex-shrink: 0; }
.pe-addon-info { flex: 1; min-width: 0; }
.pe-addon-name { font-size: 13.5px; font-weight: 700; color: #fff; }
.pe-addon-price { font-size: 11.5px; color: #dc2626; font-weight: 700; margin-top: 2px; }
.pe-addon-sizes { font-size: 10.5px; color: rgba(255,255,255,0.5); margin-top: 2px; }
.pe-btn-preview { padding: 14px; background: rgba(0,0,0,0.3); border: 1.5px solid rgba(255,255,255,0.08); border-radius: 11px; text-align: center; margin-top: 8px; }
.pe-btn-preview button { padding: 12px 28px; border: 0; border-radius: 10px; font-size: 15px; font-weight: 800; font-family: inherit; cursor: default; }
.pe-actions { display: flex; gap: 12px; }
.pe-btn-save { padding: 14px 32px; background: linear-gradient(135deg, #dc2626, #b91c1c); color: #fff; border: 0; border-radius: 10px; font-size: 14.5px; font-weight: 800; cursor: pointer; box-shadow: 0 8px 24px rgba(220,38,38,0.4); display: flex; align-items: center; gap: 8px; font-family: inherit; }
.pe-btn-cancel { padding: 14px 28px; background: rgba(255,255,255,0.05); border: 1.5px solid rgba(255,255,255,0.1); color: rgba(255,255,255,0.8); border-radius: 10px; font-size: 14px; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
.pe-btn-cancel:hover { background: rgba(255,255,255,0.1); color: #fff; text-decoration: none; }
.pe-error { background: rgba(220,38,38,0.12); border: 1.5px solid rgba(220,38,38,0.4); color: #fca5a5; padding: 14px 16px; border-radius: 12px; font-size: 13.5px; margin-bottom: 20px; line-height: 1.6; }
.pe-warn { background: rgba(234,179,8,0.12); border: 1.5px solid rgba(234,179,8,0.4); color: #fcd34d; padding: 14px 16px; border-radius: 12px; font-size: 13px; margin-bottom: 20px; line-height: 1.7; }
.pe-back { display: inline-flex; align-items: center; gap: 6px; color: rgba(255,255,255,0.5); font-size: 13px; text-decoration: none; margin-bottom: 16px; }
.pe-back:hover { color: #dc2626; text-decoration: none; }
</style>

<div class="pe-wrap">
  <a href="<?= url('admin/products/index.php') ?>" class="pe-back">
    <i class="fa-solid fa-arrow-left"></i> Back to Products
  </a>

  <?php if ($errors): ?>
    <div class="pe-error">
      <?php foreach ($errors as $e_): ?><div>• <?= e($e_) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php if (!$hasExtraCols): ?>
    <div class="pe-warn">
      <strong><i class="fa-solid fa-triangle-exclamation"></i> Advanced features OFF</strong><br>
      Size, add-ons, button customization use karne ke liye phpMyAdmin mein SQL chalao (upar wali SQL).
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="pe-card">
      <h3><i class="fa-solid fa-cube"></i> Basic Information</h3>
      <label class="pe-label">Product Name *</label>
      <input type="text" name="name" required value="<?= e(post('name','')) ?>" class="pe-input" placeholder="e.g. Friends Special Pizza">

      <div class="pe-grid-2">
        <div>
          <label class="pe-label">Category *</label>
          <select name="category_id" required class="pe-select">
            <option value="">— Select —</option>
            <?php foreach ($cats as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= post('category_id')==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="pe-label">Status</label>
          <select name="status" class="pe-select">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="archived">Archived</option>
          </select>
        </div>
      </div>

      <label class="pe-label">Short Description</label>
      <input type="text" name="short_description" value="<?= e(post('short_description','')) ?>" class="pe-input">

      <label class="pe-label">Full Description</label>
      <textarea name="description" rows="3" class="pe-textarea"><?= e(post('description','')) ?></textarea>

      <div class="pe-grid-3">
        <div>
          <label class="pe-label">Base Price (Rs.) *</label>
          <input type="number" step="0.01" name="price" required value="<?= e(post('price','')) ?>" class="pe-input">
        </div>
        <div>
          <label class="pe-label">Sale Price</label>
          <input type="number" step="0.01" name="sale_price" value="<?= e(post('sale_price','')) ?>" class="pe-input">
        </div>
        <div>
          <label class="pe-label">Sort Order</label>
          <input type="number" name="sort_order" value="<?= e(post('sort_order','0')) ?>" class="pe-input">
        </div>
      </div>

      <label class="pe-label">Product Image</label>
      <input type="file" name="image" accept="image/*" class="pe-input" style="padding:10px;">

      <label class="pe-label">Flags</label>
      <div class="pe-checkbox-row">
        <label><input type="checkbox" name="is_available" value="1" checked> Available</label>
        <label><input type="checkbox" name="is_featured" value="1"> Featured</label>
        <label><input type="checkbox" name="is_bestseller" value="1"> Bestseller</label>
        <label><input type="checkbox" name="is_new" value="1"> New</label>
      </div>
    </div>

    <?php if ($hasExtraCols): ?>

    <div class="pe-card">
      <h3><i class="fa-solid fa-ruler"></i> Sizes & Prices</h3>
      <label class="pe-toggle-row">
        <input type="checkbox" name="has_sizes" value="1" id="hasSizesToggle" onchange="toggleSizes();">
        <span><i class="fa-solid fa-ruler" style="color:#f59e0b;margin-right:6px;"></i> This product has different sizes (S / M / L)</span>
      </label>
      <div id="sizesBlock" style="display:none;">
        <label class="pe-label">Prices by Size (Rs.)</label>
        <div class="pe-size-grid">
          <div class="pe-size-box s">
            <div class="pe-size-label">Small</div>
            <input type="number" step="0.01" name="price_s" value="<?= e(post('price_s','')) ?>" class="pe-size-input" placeholder="0">
          </div>
          <div class="pe-size-box m">
            <div class="pe-size-label">Medium</div>
            <input type="number" step="0.01" name="price_m" value="<?= e(post('price_m','')) ?>" class="pe-size-input" placeholder="0">
          </div>
          <div class="pe-size-box l">
            <div class="pe-size-label">Large</div>
            <input type="number" step="0.01" name="price_l" value="<?= e(post('price_l','')) ?>" class="pe-size-input" placeholder="0">
          </div>
        </div>
      </div>
    </div>

    <div class="pe-card">
      <h3><i class="fa-solid fa-plus-circle"></i> Add-ons & Extras</h3>
      <?php if (!$allAddons): ?>
        <div style="text-align:center;padding:30px;color:rgba(255,255,255,0.4);">
          No add-ons yet. <a href="<?= url('admin/addons/index.php') ?>" style="color:#dc2626;font-weight:700;">Create add-ons →</a>
        </div>
      <?php else: ?>
        <div class="pe-addon-grid">
          <?php foreach ($allAddons as $a): 
            $hasSz = !empty($a['has_sizes']);
          ?>
            <label class="pe-addon-item">
              <input type="checkbox" name="addons[]" value="<?= (int)$a['id'] ?>">
              <div class="pe-addon-info">
                <div class="pe-addon-name"><?= e($a['name']) ?></div>
                <?php if ($hasSz): ?>
                  <div class="pe-addon-sizes">S: Rs. <?= number_format((float)$a['price_s'],0) ?> · M: Rs. <?= number_format((float)$a['price_m'],0) ?> · L: Rs. <?= number_format((float)$a['price_l'],0) ?></div>
                <?php else: ?>
                  <div class="pe-addon-price">Rs. <?= number_format((float)$a['price'],0) ?></div>
                <?php endif; ?>
              </div>
            </label>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="pe-card">
      <h3><i class="fa-solid fa-hand-pointer"></i> Customer Button</h3>
      <div class="pe-grid-2">
        <div>
          <label class="pe-label">Button Mode</label>
          <select name="button_mode" id="buttonMode" class="pe-select" onchange="updateButtonPreview();">
            <option value="add_to_cart">Add to Cart</option>
            <option value="coming_soon">Coming Soon</option>
            <option value="out_of_stock">Out of Stock</option>
            <option value="custom">Custom Text</option>
          </select>
        </div>
        <div>
          <label class="pe-label">Button Text</label>
          <input type="text" name="order_button_text" id="buttonText" value="Add to Cart" class="pe-input" oninput="updateButtonPreview();">
        </div>
      </div>
      <div class="pe-grid-2">
        <div>
          <label class="pe-label">Background</label>
          <input type="color" name="button_bg_color" value="#dc2626" class="pe-input" style="height:46px;padding:4px;" onchange="updateButtonPreview();">
        </div>
        <div>
          <label class="pe-label">Text Color</label>
          <input type="color" name="button_text_color" value="#ffffff" class="pe-input" style="height:46px;padding:4px;" onchange="updateButtonPreview();">
        </div>
      </div>
      <label class="pe-toggle-row">
        <input type="checkbox" name="order_button_enabled" value="1" checked>
        <span>Show button on product card</span>
      </label>
      <label class="pe-label">Preview</label>
      <div class="pe-btn-preview">
        <button type="button" id="btnPreview" style="background:#dc2626;color:#fff;">Add to Cart</button>
      </div>
    </div>

    <div class="pe-card">
      <h3><i class="fa-solid fa-clock"></i> Preparation Time</h3>
      <label class="pe-label">Prep Time (minutes)</label>
      <input type="number" name="prep_time_minutes" min="0" max="180" value="15" class="pe-input">
    </div>

    <?php endif; ?>

    <div class="pe-card">
      <div class="pe-actions">
        <button type="submit" class="pe-btn-save">
          <i class="fa-solid fa-save"></i> Create Product
        </button>
        <a href="<?= url('admin/products/index.php') ?>" class="pe-btn-cancel">
          <i class="fa-solid fa-xmark"></i> Cancel
        </a>
      </div>
    </div>

  </form>
</div>

<script>
function toggleSizes() {
  var el = document.getElementById('hasSizesToggle');
  var block = document.getElementById('sizesBlock');
  if (!el || !block) return;
  block.style.display = el.checked ? '' : 'none';
}
function updateButtonPreview() {
  var mode = document.getElementById('buttonMode')?.value || 'add_to_cart';
  var textEl = document.getElementById('buttonText');
  var preview = document.getElementById('btnPreview');
  if (!preview) return;
  var autoText = {'add_to_cart':'Add to Cart','coming_soon':'Coming Soon','out_of_stock':'Out of Stock','custom':textEl?.value || 'Order Now'};
  if (mode !== 'custom' && textEl) textEl.value = autoText[mode];
  preview.textContent = textEl?.value || autoText[mode];
  var bg = document.querySelector('input[name="button_bg_color"]')?.value || '#dc2626';
  var tc = document.querySelector('input[name="button_text_color"]')?.value || '#ffffff';
  if (mode === 'coming_soon') { bg = '#6b7280'; tc = '#ffffff'; }
  if (mode === 'out_of_stock') { bg = '#1f2937'; tc = '#9ca3af'; }
  preview.style.background = bg;
  preview.style.color = tc;
}
document.addEventListener('DOMContentLoaded', updateButtonPreview);
</script>

<?php require __DIR__ . '/../common/footer.php'; ?>