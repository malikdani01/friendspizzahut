-- Performance indexes
CREATE INDEX idx_orders_status_created ON orders(order_status, created_at);
CREATE INDEX idx_orders_customer ON orders(customer_phone);
CREATE INDEX idx_products_category_active ON products(category_id, status, is_available);
CREATE INDEX idx_cart_user ON cart_items(user_id);
CREATE INDEX idx_notifications_user ON notifications(user_type, user_id, is_read);
CREATE INDEX idx_loyalty_user ON loyalty_points(user_id, type);