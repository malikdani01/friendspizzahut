<?php
// admin/coupons/edit.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$id = (int)get('id', 0);
$c = Database::fetch("SELECT * FROM coupons WHERE id = ?", [$id]);
if (!$c) { flash_error('Not found.'); redirect(url('admin/coupons/index.php')); }
$pageTitle = 'Edit Coupon';
$errors = [];
if (is_post()) {
    verify_csrf();
    $code = strtoupper(trim((string)post('code','')));
    if (!$code) $errors[] = 'Code required.';
    if (Database::fetch("SELECT id FROM coupons WHERE code = ? AND id != ?", [$code, $id])) $errors[] = 'Code already in use.';
    if (!$errors) {
        Database::update('coupons', [
            'code' => $code,
            'description' => trim((string)post('description','')) ?: null,
            'discount_type' => (string)post('discount_type','percentage'),
            'discount_value' => (float)post('discount_value',0),
            'min_order' => (float)post('min_order',0),
            'max_discount' => post('max_discount') !== '' ? (float)post('max_discount') : null,
            'usage_limit' => post('usage_limit') !== '' ? (int)post('usage_limit') : null,
            'per_user_limit' => post('per_user_limit') !== '' ? (int)post('per_user_limit') : null,
            'start_date' => post('start_date') ?: null,
            'end_date' => post('end_date') ?: null,
            'is_active' => post('is_active') ? 1 : 0,
        ], 'id = :id', ['id' => $id]);
        flash_success('Coupon updated.');
        redirect(url('admin/coupons/index.php'));
    }
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-2xl">
  <?php if ($errors): ?><div class="bg-red-50 text-red-700 px-4 py-3 rounded mb-4"><?php foreach($errors as $e_) echo '• '.e($e_).'<br>'; ?></div><?php endif; ?>
  <form method="post" class="bg-white rounded-xl shadow-sm border p-6 space-y-4">
    <?= csrf_field() ?>
    <input name="code" value="<?= e($c['code']) ?>" required class="w-full border rounded px-3 py-2 uppercase">
    <input name="description" value="<?= e($c['description']) ?>" class="w-full border rounded px-3 py-2">
    <div class="grid grid-cols-2 gap-4">
      <select name="discount_type" class="border rounded px-3 py-2">
        <?php foreach (['percentage','fixed','free_delivery'] as $t): ?>
          <option value="<?= $t ?>" <?= $c['discount_type']===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
        <?php endforeach; ?>
      </select>
      <input type="number" step="0.01" name="discount_value" value="<?= e($c['discount_value']) ?>" required class="border rounded px-3 py-2">
      <input type="number" step="0.01" name="min_order" value="<?= e($c['min_order']) ?>" class="border rounded px-3 py-2">
      <input type="number" step="0.01" name="max_discount" value="<?= e($c['max_discount']) ?>" class="border rounded px-3 py-2">
      <input type="number" name="usage_limit" value="<?= e($c['usage_limit']) ?>" class="border rounded px-3 py-2">
      <input type="number" name="per_user_limit" value="<?= e($c['per_user_limit']) ?>" class="border rounded px-3 py-2">
      <input type="datetime-local" name="start_date" value="<?= $c['start_date'] ? date('Y-m-d\TH:i', strtotime($c['start_date'])) : '' ?>" class="border rounded px-3 py-2">
      <input type="datetime-local" name="end_date" value="<?= $c['end_date'] ? date('Y-m-d\TH:i', strtotime($c['end_date'])) : '' ?>" class="border rounded px-3 py-2">
    </div>
    <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" <?= $c['is_active']?'checked':'' ?>> Active</label>
    <div class="flex gap-2">
      <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
      <a href="<?= url('admin/coupons/index.php') ?>" class="px-6 py-2.5 rounded-lg bg-gray-100">Cancel</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>