<?php
// actions/cart/apply-coupon.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('cart.php'));
verify_csrf();
$code = strtoupper(trim((string)post('coupon_code','')));
$r = validate_coupon($code, calculate_cart_subtotal(), $_SESSION['user_id'] ?? null);
if ($r['ok']) {
    cart_persist_coupon($code);
    flash_success('Coupon applied: -' . money($r['discount']));
} else { cart_clear_coupon(); flash_error($r['error']); }
redirect(url('cart.php'));