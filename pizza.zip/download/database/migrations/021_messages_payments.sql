-- ═══════════════════════════════════════════════════════════════
-- Migration 021: Message Threading + Payment Status Update
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── PAYMENTS: allow new statuses ─────────────────────────────
ALTER TABLE payments MODIFY COLUMN payment_status VARCHAR(40) NOT NULL DEFAULT 'pending';
ALTER TABLE orders MODIFY COLUMN payment_status VARCHAR(40) NOT NULL DEFAULT 'pending';

-- ─── CONTACT MESSAGES: threading support ──────────────────────
ALTER TABLE contact_messages 
    ADD COLUMN IF NOT EXISTS user_id INT UNSIGNED NULL,
    ADD COLUMN IF NOT EXISTS thread_id INT UNSIGNED NULL,
    ADD COLUMN IF NOT EXISTS parent_id INT UNSIGNED NULL,
    ADD COLUMN IF NOT EXISTS sender_type ENUM('guest','user','admin') NOT NULL DEFAULT 'guest';

CREATE INDEX IF NOT EXISTS idx_thread ON contact_messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_user_id ON contact_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_sender ON contact_messages(sender_type, is_read);