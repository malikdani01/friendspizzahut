<?php
// email.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('email_notifications')) redirect(url('admin/dashboard.php'));
$pageTitle = 'Email Settings';
if (is_post()) {
    verify_csrf();
    foreach (['smtp_host','smtp_port','smtp_user','smtp_pass','smtp_from_name','smtp_from_email'] as $k) update_setting($k, (string)post($k,''));
    flash_success('Saved.');
    redirect(url('admin/integrations/email.php'));
}
require __DIR__ . '/../common/header.php';
?>
<div class="max-w-xl bg-white rounded-xl border p-6">
  <form method="post" class="space-y-3"><?= csrf_field() ?>
    <input name="smtp_host" value="<?= e(setting('smtp_host','')) ?>" placeholder="SMTP Host" class="w-full border rounded px-3 py-2">
    <input name="smtp_port" value="<?= e(setting('smtp_port','587')) ?>" placeholder="Port" class="w-full border rounded px-3 py-2">
    <input name="smtp_user" value="<?= e(setting('smtp_user','')) ?>" placeholder="Username" class="w-full border rounded px-3 py-2">
    <input type="password" name="smtp_pass" value="<?= e(setting('smtp_pass','')) ?>" placeholder="Password" class="w-full border rounded px-3 py-2">
    <input name="smtp_from_name" value="<?= e(setting('smtp_from_name', setting('restaurant_name',''))) ?>" placeholder="From name" class="w-full border rounded px-3 py-2">
    <input name="smtp_from_email" value="<?= e(setting('smtp_from_email', setting('restaurant_email',''))) ?>" placeholder="From email" class="w-full border rounded px-3 py-2">
    <button class="bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
  </form>
</div>
<?php require __DIR__ . '/../common/footer.php'; ?>