<?php
// services/InventoryService.php
class InventoryService {
    public static function adjust(int $p, int $c, string $t, ?string $r = null, ?int $o = null): void { inventory_adjust($p, $c, $t, $r, $o); }
    public static function inStock(int $p, int $q = 1): bool { return product_in_stock($p, $q); }
    public static function lowStock(int $l = 20): array { return low_stock_products($l); }
}