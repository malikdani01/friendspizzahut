<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Limited Time Deal Bar';

if (is_post()) {
    verify_csrf();
    $action = post('action');

    if ($action === 'settings') {
        update_setting('deal_bar_enabled', isset($_POST['deal_bar_enabled']) ? '1' : '0');
        flash_success('Settings saved.');
    } elseif ($action === 'create') {
        $name = trim((string)post('deal_name', ''));
        $start = (string)post('start_at', '');
        $end = (string)post('end_at', '');
        if (strlen($name) < 2 || !$start || !$end) {
            flash_error('Name, start, and end required.');
        } elseif (strtotime($end) <= strtotime($start)) {
            flash_error('End time must be after start.');
        } else {
            Database::insert('deal_bar_items', [
                'deal_name' => $name,
                'description' => trim((string)post('description', '')) ?: null,
                'discount_text' => trim((string)post('discount_text', '')) ?: null,
                'bg_color' => (string)post('bg_color', '#dc2626'),
                'text_color' => (string)post('text_color', '#ffffff'),
                'product_id' => (int)post('product_id', 0) ?: null,
                'combo_id' => (int)post('combo_id', 0) ?: null,
                'order_url' => trim((string)post('order_url', '')) ?: null,
                'start_at' => date('Y-m-d H:i:s', strtotime($start)),
                'end_at' => date('Y-m-d H:i:s', strtotime($end)),
                'is_active' => 1,
                'sort_order' => (int)post('sort_order', 0),
            ]);
            flash_success('Deal bar added.');
        }
    } elseif ($action === 'delete') {
        Database::execute("DELETE FROM deal_bar_items WHERE id = ?", [(int)post('id')]);
        flash_success('Deleted.');
    } elseif ($action === 'toggle') {
        Database::execute("UPDATE deal_bar_items SET is_active = 1 - is_active WHERE id = ?", [(int)post('id')]);
        flash_success('Updated.');
    }

    redirect(url('admin/ui/deal-bar.php'));
}

$items = Database::fetchAll("SELECT * FROM deal_bar_items ORDER BY sort_order, id");
$products = Database::fetchAll("SELECT id, name FROM products WHERE status='active' ORDER BY name LIMIT 200");
$combos = Database::fetchAll("SELECT id, name FROM combos WHERE is_active=1 ORDER BY name");
require __DIR__ . '/../common/header.php';
?>

<div class="space-y-5">

  <div class="bg-white rounded-xl border p-6">
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="settings">
      <label class="flex items-center gap-2">
        <input type="checkbox" name="deal_bar_enabled" value="1" <?= setting('deal_bar_enabled') === '1' ? 'checked' : '' ?> class="w-4 h-4">
        <span class="font-semibold">Enable Limited Time Deal Bar</span>
      </label>
      <button class="mt-3 bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Save</button>
    </form>
  </div>

  <div class="bg-white rounded-xl border p-6">
    <h3 class="font-bold mb-4">Add Deal Bar</h3>
    <form method="post" class="grid md:grid-cols-2 gap-4">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">

      <div class="md:col-span-2">
        <label class="block text-sm font-semibold mb-1">Deal Name *</label>
        <input name="deal_name" required placeholder="Friday Night Special" class="w-full border rounded px-3 py-2">
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm font-semibold mb-1">Short Description</label>
        <input name="description" placeholder="Limited offer" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Discount Text</label>
        <input name="discount_text" placeholder="30% OFF" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Sort Order</label>
        <input type="number" name="sort_order" value="0" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Start *</label>
        <input type="datetime-local" name="start_at" required value="<?= date('Y-m-d\TH:i') ?>" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">End *</label>
        <input type="datetime-local" name="end_at" required value="<?= date('Y-m-d\TH:i', strtotime('+1 day')) ?>" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Background</label>
        <input type="color" name="bg_color" value="#dc2626" class="w-full border rounded px-3 py-1 h-10">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Text Color</label>
        <input type="color" name="text_color" value="#ffffff" class="w-full border rounded px-3 py-1 h-10">
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Link to Product (optional)</label>
        <select name="product_id" class="w-full border rounded px-3 py-2">
          <option value="">— None —</option>
          <?php foreach ($products as $p): ?>
            <option value="<?= (int)$p['id'] ?>"><?= e($p['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="block text-sm font-semibold mb-1">Link to Combo (optional)</label>
        <select name="combo_id" class="w-full border rounded px-3 py-2">
          <option value="">— None —</option>
          <?php foreach ($combos as $c): ?>
            <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="md:col-span-2">
        <label class="block text-sm font-semibold mb-1">Or Custom Order URL</label>
        <input name="order_url" placeholder="/menu.php?category=pizza" class="w-full border rounded px-3 py-2">
      </div>

      <button class="md:col-span-2 bg-brand text-white px-6 py-2.5 rounded-lg font-semibold">Add Deal Bar</button>
    </form>
  </div>

  <div class="bg-white rounded-xl border overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
        <tr>
          <th class="text-left px-4 py-3">Deal</th>
          <th class="text-left px-4 py-3">Period</th>
          <th class="text-left px-4 py-3">Status</th>
          <th class="text-right px-4 py-3">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $it):
          $now = time();
          $start = strtotime($it['start_at']);
          $end = strtotime($it['end_at']);
          $live = $it['is_active'] && $start <= $now && $end > $now;
        ?>
        <tr class="border-t">
          <td class="px-4 py-3">
            <div class="font-semibold"><?= e($it['deal_name']) ?></div>
            <div class="text-xs text-gray-500"><?= e($it['discount_text'] ?: '') ?></div>
          </td>
          <td class="px-4 py-3 text-xs">
            <?= date('d M H:i', $start) ?> → <?= date('d M H:i', $end) ?>
          </td>
          <td class="px-4 py-3">
            <?php if ($live): ?>
              <span class="text-xs px-2 py-1 rounded bg-green-100 text-green-800 font-bold">LIVE</span>
            <?php elseif (!$it['is_active']): ?>
              <span class="text-xs px-2 py-1 rounded bg-gray-200">Disabled</span>
            <?php elseif ($end <= $now): ?>
              <span class="text-xs px-2 py-1 rounded bg-red-100 text-red-800">Expired</span>
            <?php else: ?>
              <span class="text-xs px-2 py-1 rounded bg-yellow-100 text-yellow-800">Scheduled</span>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3 text-right space-x-2">
            <form method="post" class="inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
              <button class="text-xs text-gray-600 hover:text-brand">Toggle</button>
            </form>
            <form method="post" class="inline" data-confirm="Delete?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
              <button class="text-red-600 text-xs">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$items): ?><tr><td colspan="4" class="py-8 text-center text-gray-400">No deal bars yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>

</div>

<?php require __DIR__ . '/../common/footer.php'; ?>