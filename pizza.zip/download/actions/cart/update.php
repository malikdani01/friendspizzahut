<?php
// actions/cart/update.php
require_once __DIR__ . '/../../common/bootstrap.php';
if (!is_post()) redirect(url('cart.php'));
verify_csrf();
foreach ((array)post('quantities', []) as $id => $q) update_cart_quantity((int)$id, (int)$q);
flash_success('Cart updated.');
redirect(url('cart.php'));