<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
if (!feature_enabled('table_reservation')) {
    flash_error('Table reservation module disabled.');
    redirect(url('admin/dashboard.php'));
}
$pageTitle = 'Table Reservations';

$status = (string)get('status', '');
$date = (string)get('date', '');
$search = trim((string)get('q', ''));
$view = (string)get('view', 'upcoming');

$filters = [];
if ($status) $filters['status'] = $status;
if ($date) $filters['date'] = $date;
if ($search) $filters['search'] = $search;
if ($view === 'upcoming') $filters['upcoming'] = 1;

$rows = reservation_admin_list($filters);

// Stats
$stats = [
    'today' => (int)(Database::fetch("SELECT COUNT(*) c FROM reservations WHERE reservation_date = CURDATE() AND status IN ('pending','confirmed','seated')")['c'] ?? 0),
    'pending' => (int)(Database::fetch("SELECT COUNT(*) c FROM reservations WHERE status = 'pending'")['c'] ?? 0),
    'upcoming' => (int)(Database::fetch("SELECT COUNT(*) c FROM reservations WHERE reservation_date >= CURDATE() AND status IN ('pending','confirmed')")['c'] ?? 0),
];

require __DIR__ . '/../common/header.php';
?>

<div class="grid grid-cols-3 gap-4 mb-6">
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Today's Reservations</div>
    <div class="text-2xl font-extrabold"><?= $stats['today'] ?></div>
  </div>
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Pending Confirmation</div>
    <div class="text-2xl font-extrabold text-yellow-600"><?= $stats['pending'] ?></div>
  </div>
  <div class="bg-white rounded-xl border p-5">
    <div class="text-xs text-gray-500 uppercase">Upcoming</div>
    <div class="text-2xl font-extrabold text-blue-600"><?= $stats['upcoming'] ?></div>
  </div>
</div>

<div class="flex flex-wrap items-center gap-2 mb-5">
  <a href="?view=upcoming" class="px-4 py-2 rounded text-sm <?= $view === 'upcoming' ? 'bg-brand text-white' : 'bg-white border' ?>">Upcoming</a>
  <a href="?view=all" class="px-4 py-2 rounded text-sm <?= $view === 'all' ? 'bg-brand text-white' : 'bg-white border' ?>">All</a>
  <a href="?status=pending" class="px-4 py-2 rounded text-sm <?= $status === 'pending' ? 'bg-brand text-white' : 'bg-white border' ?>">Pending</a>
  <a href="?status=confirmed" class="px-4 py-2 rounded text-sm <?= $status === 'confirmed' ? 'bg-brand text-white' : 'bg-white border' ?>">Confirmed</a>
  <a href="?status=seated" class="px-4 py-2 rounded text-sm <?= $status === 'seated' ? 'bg-brand text-white' : 'bg-white border' ?>">Seated</a>
  <a href="?status=completed" class="px-4 py-2 rounded text-sm <?= $status === 'completed' ? 'bg-brand text-white' : 'bg-white border' ?>">Completed</a>
  <a href="?status=cancelled" class="px-4 py-2 rounded text-sm <?= $status === 'cancelled' ? 'bg-brand text-white' : 'bg-white border' ?>">Cancelled</a>

  <form class="ml-auto flex gap-2">
    <input type="date" name="date" value="<?= e($date) ?>" class="border rounded px-3 py-2 text-sm">
    <input name="q" value="<?= e($search) ?>" placeholder="Search..." class="border rounded px-3 py-2 text-sm w-48">
    <button class="bg-gray-800 text-white px-4 py-2 rounded text-sm">Filter</button>
  </form>
</div>

<div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
      <tr>
        <th class="text-left px-4 py-3">Code</th>
        <th class="text-left px-4 py-3">Customer</th>
        <th class="text-left px-4 py-3">Date &amp; Time</th>
        <th class="text-left px-4 py-3">Party</th>
        <th class="text-left px-4 py-3">Table</th>
        <th class="text-left px-4 py-3">Status</th>
        <th class="text-right px-4 py-3">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7" class="py-8 text-center text-gray-400">No reservations found.</td></tr>
      <?php else: foreach ($rows as $r): ?>
        <tr class="border-t hover:bg-gray-50">
          <td class="px-4 py-3 font-mono text-xs"><?= e($r['reservation_code']) ?></td>
          <td class="px-4 py-3">
            <div class="font-semibold"><?= e($r['customer_name']) ?></div>
            <div class="text-xs text-gray-500"><?= e($r['customer_phone']) ?></div>
          </td>
          <td class="px-4 py-3">
            <div class="font-semibold"><?= date('d M Y', strtotime($r['reservation_date'])) ?></div>
            <div class="text-xs text-gray-500"><?= date('h:i A', strtotime($r['reservation_time'])) ?></div>
          </td>
          <td class="px-4 py-3"><?= (int)$r['party_size'] ?> pax</td>
          <td class="px-4 py-3"><?= e($r['table_number'] ?: '—') ?></td>
          <td class="px-4 py-3"><?= reservation_status_badge($r['status']) ?></td>
          <td class="px-4 py-3 text-right">
            <a href="<?= url('admin/reservations/view.php?id=' . (int)$r['id']) ?>" class="text-brand text-xs font-semibold">View →</a>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php require __DIR__ . '/../common/footer.php'; ?>