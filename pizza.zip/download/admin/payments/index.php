<?php
require_once __DIR__ . '/../../common/bootstrap.php';
require_admin();
$pageTitle = 'Payments';

// Handle status update
if (is_post()) {
    verify_csrf();
    $action = post('action', 'update_status');
    $paymentId = (int)post('payment_id', 0);
    $newStatus = (string)post('status', '');
    $note = trim((string)post('note', ''));

    $valid = ['pending','collected','cancelled','refunded','failed'];
    if (!in_array($newStatus, $valid, true)) {
        flash_error('Invalid status.');
        redirect(url('admin/payments/index.php'));
    }

    $payment = Database::fetch("SELECT * FROM payments WHERE id = ?", [$paymentId]);
    if (!$payment) {
        flash_error('Payment not found.');
        redirect(url('admin/payments/index.php'));
    }

    Database::beginTransaction();
    try {
        Database::execute(
            "UPDATE payments SET payment_status = ?, notes = COALESCE(?, notes) WHERE id = ?",
            [$newStatus, $note ?: null, $paymentId]
        );

        // Update related order's payment_status to match
        $orderStatusMap = [
            'collected' => 'paid',
            'cancelled' => 'failed',
            'refunded'  => 'refunded',
            'failed'    => 'failed',
            'pending'   => 'pending',
        ];
        $orderPayStatus = $orderStatusMap[$newStatus] ?? 'pending';
        Database::execute(
            "UPDATE orders SET payment_status = ? WHERE id = ?",
            [$orderPayStatus, (int)$payment['order_id']]
        );

        audit_log('payment.status', 'payment', $paymentId, null, ['status' => $newStatus]);
        Database::commit();
        flash_success('Payment status updated to ' . $newStatus . '.');
    } catch (Throwable $e) {
        Database::rollback();
        flash_error('Update failed.');
    }

    redirect(url('admin/payments/index.php?' . http_build_query($_GET)));
}

// Filters
$statusFilter = (string)get('status', '');
$methodFilter = (string)get('method', '');
$search = trim((string)get('q', ''));
$page = max(1, (int)get('page', 1));
$per = 30;
$offset = ($page - 1) * $per;

$where = "1=1";
$params = [];
if ($statusFilter) { $where .= " AND p.payment_status = ?"; $params[] = $statusFilter; }
if ($methodFilter) { $where .= " AND p.method = ?"; $params[] = $methodFilter; }
if ($search) {
    $where .= " AND (o.order_number LIKE ? OR o.customer_name LIKE ? OR o.customer_phone LIKE ? OR p.transaction_reference LIKE ?)";
    $s = '%' . $search . '%';
    $params = array_merge($params, [$s, $s, $s, $s]);
}

$total = (int)(Database::fetch("SELECT COUNT(*) c FROM payments p JOIN orders o ON o.id = p.order_id WHERE $where", $params)['c'] ?? 0);
$pages = max(1, (int)ceil($total / $per));

$rows = Database::fetchAll(
    "SELECT p.*, o.order_number, o.customer_name, o.customer_phone, o.total AS order_total, o.order_status, o.payment_status AS order_pay_status
     FROM payments p
     JOIN orders o ON o.id = p.order_id
     WHERE $where
     ORDER BY p.id DESC
     LIMIT $per OFFSET $offset",
    $params
);

// Summary counts
$summary = [
    'pending'   => (int)(Database::fetch("SELECT COUNT(*) c FROM payments WHERE payment_status = 'pending'")['c'] ?? 0),
    'collected' => (int)(Database::fetch("SELECT COUNT(*) c FROM payments WHERE payment_status = 'collected'")['c'] ?? 0),
    'cancelled' => (int)(Database::fetch("SELECT COUNT(*) c FROM payments WHERE payment_status = 'cancelled'")['c'] ?? 0),
    'total_amt' => (float)(Database::fetch("SELECT COALESCE(SUM(amount),0) s FROM payments WHERE payment_status = 'collected'")['s'] ?? 0),
];

require __DIR__ . '/../common/header.php';
?>

<style>
.pm-summary { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px; }
@media (min-width: 768px) { .pm-summary { grid-template-columns: repeat(4, 1fr); } }
.pm-stat {
  background: #171717; border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px; padding: 16px;
  position: relative; overflow: hidden;
}
.pm-stat::after {
  content: ''; position: absolute; top: 0; left: 0; right: 0;
  height: 3px; background: var(--pm-c, #dc2626);
  border-radius: 14px 14px 0 0;
}
.pm-stat-label { font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.6px; font-weight: 800; color: rgba(255,255,255,0.5); margin-bottom: 6px; }
.pm-stat-value { font-size: 22px; font-weight: 900; color: #fff; line-height: 1; }

.pm-filter { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 14px 16px; margin-bottom: 16px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
.pm-filter input, .pm-filter select { background: rgba(0,0,0,0.4); border: 1.5px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 8px 12px; color: #fff; font-size: 13px; outline: none; font-family: inherit; }
.pm-filter input:focus, .pm-filter select:focus { border-color: #dc2626; }
.pm-btn {
  background: #dc2626; color: #fff; border: 0; padding: 9px 16px;
  border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer;
}
.pm-btn:hover { background: #b91c1c; }

.pm-table-wrap { background: #171717; border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; overflow: hidden; }
.pm-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.pm-table thead { background: rgba(255,255,255,0.03); }
.pm-table th { padding: 12px 14px; text-align: left; font-size: 10.5px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; color: rgba(255,255,255,0.55); border-bottom: 1px solid rgba(255,255,255,0.06); }
.pm-table td { padding: 12px 14px; border-top: 1px solid rgba(255,255,255,0.04); color: #f9fafb; vertical-align: middle; }
.pm-table tr:hover { background: rgba(255,255,255,0.03); }

.pm-badge { display: inline-block; padding: 4px 10px; border-radius: 999px; font-size: 10.5px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.3px; }
.pm-badge-pending { background: rgba(234,179,8,0.18); color: #fcd34d; }
.pm-badge-collected, .pm-badge-paid { background: rgba(34,197,94,0.18); color: #4ade80; }
.pm-badge-cancelled, .pm-badge-failed { background: rgba(220,38,38,0.18); color: #fca5a5; }
.pm-badge-refunded { background: rgba(148,163,184,0.18); color: #cbd5e1; }
.pm-badge-method { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.8); }

.pm-action-btn {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 5px 10px; border-radius: 7px; font-size: 11.5px;
  font-weight: 700; text-decoration: none; border: 0; cursor: pointer;
  transition: all .15s;
}
.pm-action-btn.primary { background: rgba(34,197,94,0.2); color: #4ade80; }
.pm-action-btn.primary:hover { background: rgba(34,197,94,0.35); }
.pm-action-btn.danger { background: rgba(220,38,38,0.15); color: #f87171; }
.pm-action-btn.danger:hover { background: rgba(220,38,38,0.3); }
.pm-action-btn.neutral { background: rgba(255,255,255,0.08); color: #fff; }
.pm-action-btn.neutral:hover { background: rgba(255,255,255,0.15); }

.pm-empty { text-align: center; padding: 60px 20px; color: rgba(255,255,255,0.4); }

.pm-pagination { display: flex; gap: 6px; justify-content: center; margin-top: 20px; }
.pm-pagination a, .pm-pagination span {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 36px; height: 36px; padding: 0 10px;
  border-radius: 8px; font-size: 13px; font-weight: 700;
  text-decoration: none; color: rgba(255,255,255,0.7);
  background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.06);
}
.pm-pagination a:hover { background: rgba(220,38,38,0.15); color: #fff; }
.pm-pagination .current { background: linear-gradient(135deg, #dc2626, #b91c1c); color: #fff; border-color: #dc2626; }
</style>

<!-- Summary Stats -->
<div class="pm-summary">
  <div class="pm-stat" style="--pm-c:#f59e0b;">
    <div class="pm-stat-label">Pending</div>
    <div class="pm-stat-value"><?= number_format($summary['pending']) ?></div>
  </div>
  <div class="pm-stat" style="--pm-c:#16a34a;">
    <div class="pm-stat-label">Collected</div>
    <div class="pm-stat-value"><?= number_format($summary['collected']) ?></div>
  </div>
  <div class="pm-stat" style="--pm-c:#dc2626;">
    <div class="pm-stat-label">Cancelled</div>
    <div class="pm-stat-value"><?= number_format($summary['cancelled']) ?></div>
  </div>
  <div class="pm-stat" style="--pm-c:#0ea5e9;">
    <div class="pm-stat-label">Collected Amount</div>
    <div class="pm-stat-value" style="font-size:18px;"><?= money($summary['total_amt']) ?></div>
  </div>
</div>

<!-- Filter -->
<form class="pm-filter" method="get">
  <input type="search" name="q" value="<?= e($search) ?>" placeholder="Search order, customer, TID..." style="flex:1;min-width:180px;">
  <select name="status">
    <option value="">All Statuses</option>
    <option value="pending" <?= $statusFilter === 'pending' ? 'selected' : '' ?>>Pending</option>
    <option value="collected" <?= $statusFilter === 'collected' ? 'selected' : '' ?>>Collected</option>
    <option value="cancelled" <?= $statusFilter === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
    <option value="refunded" <?= $statusFilter === 'refunded' ? 'selected' : '' ?>>Refunded</option>
  </select>
  <select name="method">
    <option value="">All Methods</option>
    <option value="cod" <?= $methodFilter === 'cod' ? 'selected' : '' ?>>COD</option>
    <option value="easypaisa" <?= $methodFilter === 'easypaisa' ? 'selected' : '' ?>>Easypaisa</option>
    <option value="jazzcash" <?= $methodFilter === 'jazzcash' ? 'selected' : '' ?>>JazzCash</option>
  </select>
  <button type="submit" class="pm-btn"><i class="fa-solid fa-filter"></i> Filter</button>
</form>

<!-- Table -->
<div class="pm-table-wrap">
  <?php if (!$rows): ?>
    <div class="pm-empty">
      <i class="fa-solid fa-credit-card" style="font-size:40px;opacity:0.3;display:block;margin-bottom:12px;"></i>
      No payments found.
    </div>
  <?php else: ?>
  <div style="overflow-x:auto;">
    <table class="pm-table">
      <thead>
        <tr>
          <th>Order</th>
          <th>Customer</th>
          <th>Method</th>
          <th>Txn ID</th>
          <th>Amount</th>
          <th>Status</th>
          <th style="text-align:right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $p):
          $st = $p['payment_status'];
          $badgeClass = in_array($st, ['collected','paid']) ? 'pm-badge-collected' : (in_array($st, ['cancelled','failed']) ? 'pm-badge-cancelled' : ($st === 'refunded' ? 'pm-badge-refunded' : 'pm-badge-pending'));
        ?>
        <tr>
          <td>
            <a href="<?= url('admin/orders/view.php?id=' . (int)$p['order_id']) ?>"
               style="color:#dc2626;text-decoration:none;font-family:monospace;font-weight:700;font-size:12px;">
              <?= e($p['order_number']) ?>
            </a>
            <div style="font-size:10.5px;color:rgba(255,255,255,0.4);margin-top:2px;">
              <?= date('d M, H:i', strtotime($p['created_at'])) ?>
            </div>
          </td>
          <td>
            <div style="font-weight:700;color:#fff;"><?= e($p['customer_name']) ?></div>
            <div style="font-size:11px;color:rgba(255,255,255,0.5);"><?= e($p['customer_phone']) ?></div>
          </td>
          <td>
            <span class="pm-badge pm-badge-method"><?= strtoupper(e($p['method'])) ?></span>
          </td>
          <td>
            <?php if ($p['transaction_reference']): ?>
              <span style="font-family:monospace;font-size:11.5px;color:#fff;"><?= e($p['transaction_reference']) ?></span>
            <?php else: ?>
              <span style="color:rgba(255,255,255,0.3);">—</span>
            <?php endif; ?>
          </td>
          <td style="font-weight:800;color:#dc2626;"><?= money($p['amount']) ?></td>
          <td>
            <span class="pm-badge <?= $badgeClass ?>"><?= e($st) ?></span>
          </td>
          <td style="text-align:right;">
            <?php if ($st === 'pending'): ?>
              <form method="post" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="payment_id" value="<?= (int)$p['id'] ?>">
                <input type="hidden" name="status" value="collected">
                <button class="pm-action-btn primary" title="Mark as collected">
                  <i class="fa-solid fa-check"></i> Collected
                </button>
              </form>
              <form method="post" style="display:inline;" onsubmit="return confirm('Cancel this payment?');">
                <?= csrf_field() ?>
                <input type="hidden" name="payment_id" value="<?= (int)$p['id'] ?>">
                <input type="hidden" name="status" value="cancelled">
                <button class="pm-action-btn danger" title="Cancel payment">
                  <i class="fa-solid fa-xmark"></i> Cancel
                </button>
              </form>
            <?php else: ?>
              <form method="post" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="payment_id" value="<?= (int)$p['id'] ?>">
                <input type="hidden" name="status" value="pending">
                <button class="pm-action-btn neutral" title="Reset to pending">
                  <i class="fa-solid fa-rotate-left"></i> Reset
                </button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php if ($pages > 1): ?>
<div class="pm-pagination">
  <?php for ($i = 1; $i <= $pages; $i++):
    $qs = http_build_query(array_merge($_GET, ['page' => $i]));
  ?>
    <?php if ($i === $page): ?>
      <span class="current"><?= $i ?></span>
    <?php else: ?>
      <a href="?<?= $qs ?>"><?= $i ?></a>
    <?php endif; ?>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../common/footer.php'; ?>