-- ═══════════════════════════════════════════════════════════════
-- Migration 016: Advanced Product Fields
-- ═══════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

-- ─── PRODUCTS: Additional columns ─────────────────────────────
ALTER TABLE products ADD COLUMN IF NOT EXISTS allergens VARCHAR(500) NULL AFTER ingredients;
ALTER TABLE products ADD COLUMN IF NOT EXISTS spice_level ENUM('none','mild','medium','hot','extra_hot') NOT NULL DEFAULT 'none' AFTER allergens;
ALTER TABLE products ADD COLUMN IF NOT EXISTS dietary_info VARCHAR(190) NULL AFTER spice_level;
ALTER TABLE products ADD COLUMN IF NOT EXISTS serving_info VARCHAR(120) NULL AFTER dietary_info;
ALTER TABLE products ADD COLUMN IF NOT EXISTS calories INT NULL AFTER serving_info;

ALTER TABLE products ADD COLUMN IF NOT EXISTS prep_time_min INT NULL AFTER prep_time_minutes;
ALTER TABLE products ADD COLUMN IF NOT EXISTS prep_time_max INT NULL AFTER prep_time_min;

ALTER TABLE products ADD COLUMN IF NOT EXISTS availability_start DATETIME NULL;
ALTER TABLE products ADD COLUMN IF NOT EXISTS availability_end DATETIME NULL;

-- Button customization
ALTER TABLE products ADD COLUMN IF NOT EXISTS button_mode VARCHAR(30) NOT NULL DEFAULT 'add_to_cart' AFTER order_button_text;
ALTER TABLE products ADD COLUMN IF NOT EXISTS button_bg_color VARCHAR(20) NULL AFTER button_mode;
ALTER TABLE products ADD COLUMN IF NOT EXISTS button_text_color VARCHAR(20) NULL AFTER button_bg_color;
ALTER TABLE products ADD COLUMN IF NOT EXISTS button_hover_color VARCHAR(20) NULL AFTER button_text_color;
ALTER TABLE products ADD COLUMN IF NOT EXISTS button_border_color VARCHAR(20) NULL AFTER button_hover_color;
ALTER TABLE products ADD COLUMN IF NOT EXISTS button_border_radius VARCHAR(20) NULL AFTER button_border_color;
ALTER TABLE products ADD COLUMN IF NOT EXISTS button_icon VARCHAR(60) NULL AFTER button_border_radius;

-- ─── PRODUCT IMAGES already exists, ensure columns ────────────
-- No change needed (product_images table already has: product_id, image, sort_order)

-- ─── PRODUCT BADGES: add style fields ─────────────────────────
ALTER TABLE product_badges ADD COLUMN IF NOT EXISTS border_color VARCHAR(20) NULL;
ALTER TABLE product_badges ADD COLUMN IF NOT EXISTS style ENUM('solid','outline','subtle') NOT NULL DEFAULT 'solid';
ALTER TABLE product_badges ADD COLUMN IF NOT EXISTS border_radius VARCHAR(20) NULL DEFAULT '999px';
ALTER TABLE product_badges ADD COLUMN IF NOT EXISTS position VARCHAR(20) NULL DEFAULT 'top-left';

-- ─── VARIATION OPTIONS: enhance ───────────────────────────────
ALTER TABLE variation_options ADD COLUMN IF NOT EXISTS sale_price DECIMAL(12,2) NULL AFTER price_delta;
ALTER TABLE variation_options ADD COLUMN IF NOT EXISTS sku VARCHAR(80) NULL AFTER absolute_price;
ALTER TABLE variation_options ADD COLUMN IF NOT EXISTS prep_time_extra INT NULL AFTER sku;
ALTER TABLE variation_options ADD COLUMN IF NOT EXISTS is_available TINYINT(1) NOT NULL DEFAULT 1 AFTER is_active;

-- ─── ADDON GROUPS (new table for grouping) ────────────────────
CREATE TABLE IF NOT EXISTS addon_groups (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    display_name VARCHAR(150) NOT NULL,
    description VARCHAR(255) NULL,
    is_required TINYINT(1) NOT NULL DEFAULT 0,
    type ENUM('single','multiple') NOT NULL DEFAULT 'multiple',
    min_selections INT NOT NULL DEFAULT 0,
    max_selections INT NOT NULL DEFAULT 10,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Link addons to groups
ALTER TABLE addons ADD COLUMN IF NOT EXISTS group_id INT UNSIGNED NULL AFTER category;

-- Product <-> Addon Group linking
CREATE TABLE IF NOT EXISTS product_addon_groups (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_id INT UNSIGNED NOT NULL,
    group_id INT UNSIGNED NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    UNIQUE KEY uq_product_group (product_id, group_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed default group
INSERT INTO addon_groups (name, display_name, description, is_required, type, min_selections, max_selections, sort_order)
SELECT 'extra_toppings', 'Extra Toppings', 'Add extra items to your order', 0, 'multiple', 0, 10, 1
WHERE NOT EXISTS (SELECT 1 FROM addon_groups WHERE name = 'extra_toppings');