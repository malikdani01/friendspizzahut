<?php
// actions/account/address-update.php
require_once __DIR__ . '/../../common/bootstrap.php';
require_customer();
if (!is_post()) redirect(url('addresses.php'));
verify_csrf();
$uid = (int)$_SESSION['user_id'];
$id = (int)post('id',0);
if (!Database::fetch("SELECT id FROM addresses WHERE id=? AND user_id=?", [$id, $uid])) { flash_error('Not found.'); redirect(url('addresses.php')); }
Database::update('addresses', [
    'label'=>trim((string)post('label','')) ?: null,
    'customer_name'=>trim((string)post('customer_name','')),
    'mobile'=>trim((string)post('mobile','')),
    'address_line'=>trim((string)post('address_line','')),
    'area'=>trim((string)post('area','')) ?: null,
    'city'=>trim((string)post('city','')) ?: null,
    'landmark'=>trim((string)post('landmark','')) ?: null,
], 'id=:id', ['id'=>$id]);
flash_success('Address updated.');
redirect(url('addresses.php'));